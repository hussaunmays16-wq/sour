﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200017A RID: 378
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Logs the value of a Vector3 Variable in the PlayMaker Log Window.")]
	public class DebugVector3 : FsmStateAction
	{
		// Token: 0x060006F4 RID: 1780 RVA: 0x00031824 File Offset: 0x0002FA24
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.vector3Variable = null;
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x00031834 File Offset: 0x0002FA34
		public override void OnEnter()
		{
			string text = "None";
			if (!this.vector3Variable.IsNone)
			{
				text = this.vector3Variable.Name + ": " + this.vector3Variable.Value;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009E9 RID: 2537
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009EA RID: 2538
		[Tooltip("Prints the value of a Vector3 variable in the PlayMaker log window.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector3Variable;
	}
}
