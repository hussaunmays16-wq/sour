﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000256 RID: 598
	[ActionCategory(ActionCategory.String)]
	[Tooltip("Gets the Left n characters from a String Variable.")]
	public class GetStringLeft : FsmStateAction
	{
		// Token: 0x06000A32 RID: 2610 RVA: 0x0003F47C File Offset: 0x0003D67C
		public override void Reset()
		{
			this.stringVariable = null;
			this.charCount = 0;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A33 RID: 2611 RVA: 0x0003F4A0 File Offset: 0x0003D6A0
		public override void OnEnter()
		{
			this.DoGetStringLeft();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A34 RID: 2612 RVA: 0x0003F4BC File Offset: 0x0003D6BC
		public override void OnUpdate()
		{
			this.DoGetStringLeft();
		}

		// Token: 0x06000A35 RID: 2613 RVA: 0x0003F4C4 File Offset: 0x0003D6C4
		private void DoGetStringLeft()
		{
			if (this.stringVariable == null)
			{
				return;
			}
			if (this.storeResult == null)
			{
				return;
			}
			this.storeResult.Value = this.stringVariable.Value.Substring(0, this.charCount.Value);
		}

		// Token: 0x04000E1E RID: 3614
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString stringVariable;

		// Token: 0x04000E1F RID: 3615
		public FsmInt charCount;

		// Token: 0x04000E20 RID: 3616
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString storeResult;

		// Token: 0x04000E21 RID: 3617
		public bool everyFrame;
	}
}
