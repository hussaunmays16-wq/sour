﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000269 RID: 617
	[Tooltip("Checks if an Object has a Component. Optionally remove the Component on exiting the state.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class HasComponent : FsmStateAction
	{
		// Token: 0x06000A85 RID: 2693 RVA: 0x00040250 File Offset: 0x0003E450
		public override void Reset()
		{
			this.aComponent = null;
			this.gameObject = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.component = null;
			this.store = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x00040284 File Offset: 0x0003E484
		public override void OnEnter()
		{
			this.DoHasComponent((this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner);
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x000402D4 File Offset: 0x0003E4D4
		public override void OnUpdate()
		{
			this.DoHasComponent((this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner);
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x00040314 File Offset: 0x0003E514
		public override void OnExit()
		{
			if (this.removeOnExit.Value && this.aComponent != null)
			{
				UnityEngine.Object.Destroy(this.aComponent);
			}
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x00040350 File Offset: 0x0003E550
		private void DoHasComponent(GameObject go)
		{
			this.aComponent = go.GetComponent(this.component.Value);
			base.Fsm.Event((!(this.aComponent != null)) ? this.falseEvent : this.trueEvent);
		}

		// Token: 0x04000E6C RID: 3692
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E6D RID: 3693
		[RequiredField]
		[UIHint(UIHint.ScriptComponent)]
		public FsmString component;

		// Token: 0x04000E6E RID: 3694
		public FsmBool removeOnExit;

		// Token: 0x04000E6F RID: 3695
		public FsmEvent trueEvent;

		// Token: 0x04000E70 RID: 3696
		public FsmEvent falseEvent;

		// Token: 0x04000E71 RID: 3697
		[UIHint(UIHint.Variable)]
		public FsmBool store;

		// Token: 0x04000E72 RID: 3698
		public bool everyFrame;

		// Token: 0x04000E73 RID: 3699
		private Component aComponent;
	}
}
