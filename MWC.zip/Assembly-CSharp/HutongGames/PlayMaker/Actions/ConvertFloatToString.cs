﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000168 RID: 360
	[ActionCategory(ActionCategory.Convert)]
	[Tooltip("Converts a Float value to a String value with optional format.")]
	public class ConvertFloatToString : FsmStateAction
	{
		// Token: 0x060006B1 RID: 1713 RVA: 0x00030CD0 File Offset: 0x0002EED0
		public override void Reset()
		{
			this.floatVariable = null;
			this.stringVariable = null;
			this.everyFrame = false;
			this.format = null;
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00030CF0 File Offset: 0x0002EEF0
		public override void OnEnter()
		{
			this.DoConvertFloatToString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00030D0C File Offset: 0x0002EF0C
		public override void OnUpdate()
		{
			this.DoConvertFloatToString();
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x00030D14 File Offset: 0x0002EF14
		private void DoConvertFloatToString()
		{
			if (this.format.IsNone || string.IsNullOrEmpty(this.format.Value))
			{
				this.stringVariable.Value = this.floatVariable.Value.ToString();
			}
			else
			{
				this.stringVariable.Value = this.floatVariable.Value.ToString(this.format.Value);
			}
		}

		// Token: 0x040009B0 RID: 2480
		[Tooltip("The float variable to convert.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x040009B1 RID: 2481
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("A string variable to store the converted value.")]
		public FsmString stringVariable;

		// Token: 0x040009B2 RID: 2482
		[Tooltip("Optional Format, allows for leading zeroes. E.g., 0000")]
		public FsmString format;

		// Token: 0x040009B3 RID: 2483
		[Tooltip("Repeat every frame. Useful if the float variable is changing.")]
		public bool everyFrame;
	}
}
