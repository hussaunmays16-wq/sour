﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200013B RID: 315
	[ActionCategory(ActionCategory.AnimateVariables)]
	[Tooltip("Easing Animation - Float")]
	public class EaseFloat : EaseFsmAction
	{
		// Token: 0x060005CB RID: 1483 RVA: 0x0002CA8C File Offset: 0x0002AC8C
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.fromValue = null;
			this.toValue = null;
			this.finishInNextStep = false;
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x0002CABC File Offset: 0x0002ACBC
		public override void OnEnter()
		{
			base.OnEnter();
			this.fromFloats = new float[1];
			this.fromFloats[0] = this.fromValue.Value;
			this.toFloats = new float[1];
			this.toFloats[0] = this.toValue.Value;
			this.resultFloats = new float[1];
			this.finishInNextStep = false;
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x0002CB20 File Offset: 0x0002AD20
		public override void OnExit()
		{
			base.OnExit();
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x0002CB28 File Offset: 0x0002AD28
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.floatVariable.IsNone && this.isRunning)
			{
				this.floatVariable.Value = this.resultFloats[0];
			}
			if (this.finishInNextStep)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.floatVariable.IsNone)
				{
					this.floatVariable.Value = ((!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value : this.fromValue.Value) : this.toValue.Value);
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x040008B7 RID: 2231
		[RequiredField]
		public FsmFloat fromValue;

		// Token: 0x040008B8 RID: 2232
		[RequiredField]
		public FsmFloat toValue;

		// Token: 0x040008B9 RID: 2233
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x040008BA RID: 2234
		private bool finishInNextStep;
	}
}
