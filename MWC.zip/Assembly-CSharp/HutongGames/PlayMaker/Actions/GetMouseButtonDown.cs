﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000241 RID: 577
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when the specified Mouse Button is pressed. Optionally store the button state in a bool variable.")]
	public class GetMouseButtonDown : FsmStateAction
	{
		// Token: 0x060009DB RID: 2523 RVA: 0x0003E770 File Offset: 0x0003C970
		public override void Reset()
		{
			this.button = MouseButton.Left;
			this.sendEvent = null;
			this.storeResult = null;
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x0003E788 File Offset: 0x0003C988
		public override void OnUpdate()
		{
			bool mouseButtonDown = Input.GetMouseButtonDown((int)this.button);
			if (mouseButtonDown)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = mouseButtonDown;
		}

		// Token: 0x04000DD8 RID: 3544
		[RequiredField]
		public MouseButton button;

		// Token: 0x04000DD9 RID: 3545
		public FsmEvent sendEvent;

		// Token: 0x04000DDA RID: 3546
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;
	}
}
