﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E6 RID: 486
	[Tooltip("GUI Horizontal Slider connected to a Float Variable.")]
	[ActionCategory(ActionCategory.GUI)]
	public class GUIHorizontalSlider : GUIAction
	{
		// Token: 0x06000880 RID: 2176 RVA: 0x000399B8 File Offset: 0x00037BB8
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.leftValue = 0f;
			this.rightValue = 100f;
			this.sliderStyle = "horizontalslider";
			this.thumbStyle = "horizontalsliderthumb";
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x00039A14 File Offset: 0x00037C14
		public override void OnGUI()
		{
			base.OnGUI();
			if (this.floatVariable != null)
			{
				this.floatVariable.Value = GUI.HorizontalSlider(this.rect, this.floatVariable.Value, this.leftValue.Value, this.rightValue.Value, (!(this.sliderStyle.Value != string.Empty)) ? "horizontalslider" : this.sliderStyle.Value, (!(this.thumbStyle.Value != string.Empty)) ? "horizontalsliderthumb" : this.thumbStyle.Value);
			}
		}

		// Token: 0x04000C37 RID: 3127
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000C38 RID: 3128
		[RequiredField]
		public FsmFloat leftValue;

		// Token: 0x04000C39 RID: 3129
		[RequiredField]
		public FsmFloat rightValue;

		// Token: 0x04000C3A RID: 3130
		public FsmString sliderStyle;

		// Token: 0x04000C3B RID: 3131
		public FsmString thumbStyle;
	}
}
