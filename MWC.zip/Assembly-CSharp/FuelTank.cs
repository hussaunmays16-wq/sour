﻿using System;
using UnityEngine;

// Token: 0x02000488 RID: 1160
public class FuelTank : MonoBehaviour
{
	// Token: 0x1700009D RID: 157
	// (get) Token: 0x06001388 RID: 5000 RVA: 0x00075364 File Offset: 0x00073564
	// (set) Token: 0x06001389 RID: 5001 RVA: 0x0007536C File Offset: 0x0007356C
	public float tankWeight
	{
		get
		{
			return this._tankWeight;
		}
		set
		{
			if (value <= 0f)
			{
				this._tankWeight = 0.001f;
			}
			else
			{
				this._tankWeight = value;
			}
		}
	}

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x0600138A RID: 5002 RVA: 0x0007539C File Offset: 0x0007359C
	// (set) Token: 0x0600138B RID: 5003 RVA: 0x000753A4 File Offset: 0x000735A4
	public float tankCapacity
	{
		get
		{
			return this._tankCapacity;
		}
		set
		{
			if (value < 0f)
			{
				this._tankCapacity = 0f;
			}
			else
			{
				this._tankCapacity = value;
			}
			if (this._currentFuel > this._tankCapacity)
			{
				this._currentFuel = this._tankCapacity;
			}
		}
	}

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x0600138C RID: 5004 RVA: 0x000753F0 File Offset: 0x000735F0
	// (set) Token: 0x0600138D RID: 5005 RVA: 0x000753F8 File Offset: 0x000735F8
	public float currentFuel
	{
		get
		{
			return this._currentFuel;
		}
		set
		{
			if (value < 0f)
			{
				this._currentFuel = 0f;
			}
			else if (value > this.tankCapacity)
			{
				this._currentFuel = this.tankCapacity;
			}
			else
			{
				this._currentFuel = value;
			}
		}
	}

	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x0600138E RID: 5006 RVA: 0x00075444 File Offset: 0x00073644
	// (set) Token: 0x0600138F RID: 5007 RVA: 0x0007544C File Offset: 0x0007364C
	public float fuelDensity
	{
		get
		{
			return this._fuelDensity;
		}
		set
		{
			if (value < 0f)
			{
				this._fuelDensity = 0f;
			}
			else
			{
				this._fuelDensity = value;
			}
		}
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x0007547C File Offset: 0x0007367C
	private void Start()
	{
		this.myTransform = base.transform;
		Transform parent = this.myTransform.parent;
		while (parent.GetComponent<Drivetrain>() == null)
		{
			parent = parent.parent;
		}
		this.drivetrain = parent.GetComponent<Drivetrain>();
		this.tankCapacity = this.tankCapacity;
		this.currentFuel = this.currentFuel;
		this.fuelDensity = this.fuelDensity;
		this.myTransform.gameObject.layer = this.drivetrain.transform.gameObject.layer;
		this.fuelTank = this.myTransform.gameObject.GetComponent<Rigidbody>();
		if (this.fuelTank == null)
		{
			this.fuelTank = this.myTransform.gameObject.AddComponent<Rigidbody>();
		}
		this.boxCollider = this.myTransform.gameObject.GetComponent<BoxCollider>();
		if (this.boxCollider == null)
		{
			this.boxCollider = this.myTransform.gameObject.AddComponent<BoxCollider>();
			this.boxCollider.size = new Vector3(0.7f, 0.25f, 0.6f);
		}
		this.fuelTank.drag = 0f;
		this.fuelTank.angularDrag = 0f;
		this.fuelTank.useGravity = true;
		this.fuelTank.isKinematic = false;
		ConfigurableJoint configurableJoint = this.fuelTank.GetComponent<ConfigurableJoint>();
		if (configurableJoint == null)
		{
			configurableJoint = this.fuelTank.gameObject.AddComponent<ConfigurableJoint>();
			configurableJoint.xMotion = ConfigurableJointMotion.Locked;
			configurableJoint.yMotion = ConfigurableJointMotion.Locked;
			configurableJoint.zMotion = ConfigurableJointMotion.Locked;
			configurableJoint.angularXMotion = ConfigurableJointMotion.Locked;
			configurableJoint.angularYMotion = ConfigurableJointMotion.Locked;
			configurableJoint.angularZMotion = ConfigurableJointMotion.Locked;
		}
		configurableJoint.connectedBody = this.drivetrain.transform.GetComponent<Rigidbody>();
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x00075650 File Offset: 0x00073850
	private void FixedUpdate()
	{
		if (this.tankCapacity > 0f && this.currentFuel >= 0f && this.drivetrain.rpm >= 20f)
		{
			this.currentFuel -= this.drivetrain.istantConsumption * Time.deltaTime * (1f / (float)this.drivetrain.fuelTanks.Length);
			this.currentFuel = Mathf.Clamp(this.currentFuel, 0f, this.currentFuel);
		}
		this.fuelTank.mass = this.currentFuel * this.fuelDensity + this.tankWeight;
	}

	// Token: 0x04001ADC RID: 6876
	private Rigidbody fuelTank;

	// Token: 0x04001ADD RID: 6877
	private BoxCollider boxCollider;

	// Token: 0x04001ADE RID: 6878
	private Drivetrain drivetrain;

	// Token: 0x04001ADF RID: 6879
	private Transform myTransform;

	// Token: 0x04001AE0 RID: 6880
	public float _tankCapacity = 50f;

	// Token: 0x04001AE1 RID: 6881
	public float _currentFuel = 50f;

	// Token: 0x04001AE2 RID: 6882
	public float _tankWeight = 10f;

	// Token: 0x04001AE3 RID: 6883
	public float _fuelDensity = 0.73722f;
}
