﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C6 RID: 966
	[Tooltip("Gets items from a PlayMaker HashTable Proxy component")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableGetMany : HashTableActions
	{
		// Token: 0x06001051 RID: 4177 RVA: 0x00059070 File Offset: 0x00057270
		public override void Reset()
		{
			this.gameObject = null;
			this.keys = null;
			this.results = null;
		}

		// Token: 0x06001052 RID: 4178 RVA: 0x00059088 File Offset: 0x00057288
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.Get();
			}
			base.Finish();
		}

		// Token: 0x06001053 RID: 4179 RVA: 0x000590C8 File Offset: 0x000572C8
		public void Get()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			for (int i = 0; i < this.keys.Length; i++)
			{
				if (this.proxy.hashTable.ContainsKey(this.keys[i].Value))
				{
					PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.results[i], this.proxy.hashTable[this.keys[i].Value]);
				}
			}
		}

		// Token: 0x0400152C RID: 5420
		[RequiredField]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400152D RID: 5421
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400152E RID: 5422
		[ActionSection("Data")]
		[CompoundArray("Count", "Key", "Value")]
		[RequiredField]
		[Tooltip("The Key value for that hash set")]
		[UIHint(UIHint.FsmString)]
		public FsmString[] keys;

		// Token: 0x0400152F RID: 5423
		[Tooltip("The value for that key")]
		[UIHint(UIHint.Variable)]
		public FsmVar[] results;
	}
}
