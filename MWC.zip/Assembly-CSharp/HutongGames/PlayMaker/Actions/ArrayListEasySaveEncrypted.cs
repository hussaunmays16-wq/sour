﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DE RID: 990
	[ActionCategory("Easy Save 2")]
	[Tooltip("Saves a PlayMaker Array List Proxy component")]
	public class ArrayListEasySaveEncrypted : ArrayListActions
	{
		// Token: 0x060010C1 RID: 4289 RVA: 0x0005B94C File Offset: 0x00059B4C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.encryption = false;
			this.password = string.Empty;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x0005B9A8 File Offset: 0x00059BA8
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SaveArrayList();
			}
			base.Finish();
		}

		// Token: 0x060010C3 RID: 4291 RVA: 0x0005B9E8 File Offset: 0x00059BE8
		public void SaveArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = "false";
			if (this.encryption.Value)
			{
				text = "true";
			}
			List<string> list = new List<string>();
			foreach (object item in this.proxy.arrayList)
			{
				list.Add(PlayMakerUtils.ParseValueToString(item));
			}
			ES2.Save<string>(list, string.Concat(new object[]
			{
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag,
				"&encrypt=",
				text,
				"&password=",
				this.password.Value
			}));
			this.Log(string.Concat(new object[]
			{
				"Saved to ",
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			Debug.LogWarning("Persistent Data Path:" + Application.persistentDataPath);
			base.Finish();
		}

		// Token: 0x040015C2 RID: 5570
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015C3 RID: 5571
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x040015C4 RID: 5572
		[ActionSection("Easy Save Set Up")]
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015C5 RID: 5573
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x040015C6 RID: 5574
		[Tooltip("the password of the saved item")]
		public FsmString password = string.Empty;

		// Token: 0x040015C7 RID: 5575
		[Tooltip("The name of the file that we'll create to store our data.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
