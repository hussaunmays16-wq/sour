﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000135 RID: 309
	[ActionCategory(ActionCategory.AnimateVariables)]
	[Tooltip("Animates the value of a Float Variable FROM-TO with assistance of Deformation Curve.")]
	public class CurveFloat : CurveFsmAction
	{
		// Token: 0x060005B2 RID: 1458 RVA: 0x0002B038 File Offset: 0x00029238
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = new FsmFloat
			{
				UseVariable = true
			};
			this.toValue = new FsmFloat
			{
				UseVariable = true
			};
			this.fromValue = new FsmFloat
			{
				UseVariable = true
			};
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0002B088 File Offset: 0x00029288
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[1];
			this.fromFloats = new float[1];
			this.fromFloats[0] = ((!this.fromValue.IsNone) ? this.fromValue.Value : 0f);
			this.toFloats = new float[1];
			this.toFloats[0] = ((!this.toValue.IsNone) ? this.toValue.Value : 0f);
			this.calculations = new CurveFsmAction.Calculation[1];
			this.calculations[0] = this.calculation;
			this.curves = new AnimationCurve[1];
			this.curves[0] = this.animCurve.curve;
			base.Init();
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x0002B160 File Offset: 0x00029360
		public override void OnExit()
		{
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x0002B164 File Offset: 0x00029364
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.floatVariable.IsNone && this.isRunning)
			{
				this.floatVariable.Value = this.resultFloats[0];
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.floatVariable.IsNone)
				{
					this.floatVariable.Value = this.resultFloats[0];
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x04000875 RID: 2165
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000876 RID: 2166
		[RequiredField]
		public FsmFloat fromValue;

		// Token: 0x04000877 RID: 2167
		[RequiredField]
		public FsmFloat toValue;

		// Token: 0x04000878 RID: 2168
		[RequiredField]
		public FsmAnimationCurve animCurve;

		// Token: 0x04000879 RID: 2169
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue and toValue.")]
		public CurveFsmAction.Calculation calculation;

		// Token: 0x0400087A RID: 2170
		private bool finishInNextStep;
	}
}
