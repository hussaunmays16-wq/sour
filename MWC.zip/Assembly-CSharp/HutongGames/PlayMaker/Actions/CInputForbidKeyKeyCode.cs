﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A0 RID: 1184
	[ActionCategory("cInput")]
	[Tooltip("Forbids a cInput key.")]
	public class CInputForbidKeyKeyCode : FsmStateAction
	{
		// Token: 0x0600143D RID: 5181 RVA: 0x000888F8 File Offset: 0x00086AF8
		public override void OnEnter()
		{
			cInput.ForbidKey(this.keyName);
			base.Finish();
		}

		// Token: 0x04001CA8 RID: 7336
		[Tooltip("The name of the key to forbid.")]
		public KeyCode keyName;
	}
}
