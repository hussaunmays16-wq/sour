﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000227 RID: 551
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Get the value of a Float Variable from another FSM.")]
	public class GetFsmFloat : FsmStateAction
	{
		// Token: 0x06000967 RID: 2407 RVA: 0x0003D0C8 File Offset: 0x0003B2C8
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x0003D0E8 File Offset: 0x0003B2E8
		public override void OnEnter()
		{
			this.DoGetFsmFloat();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x0003D104 File Offset: 0x0003B304
		public override void OnUpdate()
		{
			this.DoGetFsmFloat();
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x0003D10C File Offset: 0x0003B30C
		private void DoGetFsmFloat()
		{
			if (this.storeValue.IsNone)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
				this.goLastFrame = ownerDefaultTarget;
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmFloat fsmFloat = this.fsm.FsmVariables.GetFsmFloat(this.variableName.Value);
			if (fsmFloat == null)
			{
				return;
			}
			this.storeValue.Value = fsmFloat.Value;
		}

		// Token: 0x04000D4D RID: 3405
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D4E RID: 3406
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000D4F RID: 3407
		[UIHint(UIHint.FsmFloat)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D50 RID: 3408
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeValue;

		// Token: 0x04000D51 RID: 3409
		public bool everyFrame;

		// Token: 0x04000D52 RID: 3410
		private GameObject goLastFrame;

		// Token: 0x04000D53 RID: 3411
		private PlayMakerFSM fsm;
	}
}
