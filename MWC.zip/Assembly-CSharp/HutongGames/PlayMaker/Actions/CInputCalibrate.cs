﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049D RID: 1181
	[ActionCategory("cInput")]
	[Tooltip("Calibrates cInput.")]
	public class CInputCalibrate : FsmStateAction
	{
		// Token: 0x06001435 RID: 5173 RVA: 0x00088748 File Offset: 0x00086948
		public override void OnEnter()
		{
			cInput.Calibrate();
			base.Finish();
		}
	}
}
