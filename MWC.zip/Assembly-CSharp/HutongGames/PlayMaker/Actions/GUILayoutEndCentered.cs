﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F4 RID: 500
	[Tooltip("End a centered GUILayout block started with GUILayoutBeginCentered.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutEndCentered : FsmStateAction
	{
		// Token: 0x060008AA RID: 2218 RVA: 0x0003A5E0 File Offset: 0x000387E0
		public override void Reset()
		{
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x0003A5E4 File Offset: 0x000387E4
		public override void OnGUI()
		{
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			GUILayout.FlexibleSpace();
			GUILayout.EndVertical();
		}
	}
}
