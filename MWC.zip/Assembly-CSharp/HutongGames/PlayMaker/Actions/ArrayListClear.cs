﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000399 RID: 921
	[Tooltip("Removes all elements from a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListClear : ArrayListActions
	{
		// Token: 0x06000F9B RID: 3995 RVA: 0x00055D98 File Offset: 0x00053F98
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x00055DA8 File Offset: 0x00053FA8
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.ClearArrayList();
			}
			base.Finish();
		}

		// Token: 0x06000F9D RID: 3997 RVA: 0x00055DE8 File Offset: 0x00053FE8
		public void ClearArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.arrayList.Clear();
		}

		// Token: 0x0400144A RID: 5194
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400144B RID: 5195
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
