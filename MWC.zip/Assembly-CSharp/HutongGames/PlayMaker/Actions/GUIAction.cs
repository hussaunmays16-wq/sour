﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E1 RID: 481
	[Tooltip("GUI base action - don't use!")]
	public abstract class GUIAction : FsmStateAction
	{
		// Token: 0x06000870 RID: 2160 RVA: 0x00039468 File Offset: 0x00037668
		public override void Reset()
		{
			this.screenRect = null;
			this.left = 0f;
			this.top = 0f;
			this.width = 1f;
			this.height = 1f;
			this.normalized = true;
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x000394C8 File Offset: 0x000376C8
		public override void OnGUI()
		{
			this.rect = (this.screenRect.IsNone ? default(Rect) : this.screenRect.Value);
			if (!this.left.IsNone)
			{
				this.rect.x = this.left.Value;
			}
			if (!this.top.IsNone)
			{
				this.rect.y = this.top.Value;
			}
			if (!this.width.IsNone)
			{
				this.rect.width = this.width.Value;
			}
			if (!this.height.IsNone)
			{
				this.rect.height = this.height.Value;
			}
			if (this.normalized.Value)
			{
				this.rect.x = this.rect.x * (float)Screen.width;
				this.rect.width = this.rect.width * (float)Screen.width;
				this.rect.y = this.rect.y * (float)Screen.height;
				this.rect.height = this.rect.height * (float)Screen.height;
			}
		}

		// Token: 0x04000C1E RID: 3102
		[UIHint(UIHint.Variable)]
		public FsmRect screenRect;

		// Token: 0x04000C1F RID: 3103
		public FsmFloat left;

		// Token: 0x04000C20 RID: 3104
		public FsmFloat top;

		// Token: 0x04000C21 RID: 3105
		public FsmFloat width;

		// Token: 0x04000C22 RID: 3106
		public FsmFloat height;

		// Token: 0x04000C23 RID: 3107
		[RequiredField]
		public FsmBool normalized;

		// Token: 0x04000C24 RID: 3108
		internal Rect rect;
	}
}
