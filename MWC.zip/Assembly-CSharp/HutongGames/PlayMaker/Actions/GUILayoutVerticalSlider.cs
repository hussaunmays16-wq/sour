﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000206 RID: 518
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("A Vertical Slider linked to a Float Variable.")]
	public class GUILayoutVerticalSlider : GUILayoutAction
	{
		// Token: 0x060008E2 RID: 2274 RVA: 0x0003B314 File Offset: 0x00039514
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.topValue = 100f;
			this.bottomValue = 0f;
			this.changedEvent = null;
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x0003B358 File Offset: 0x00039558
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			if (this.floatVariable != null)
			{
				this.floatVariable.Value = GUILayout.VerticalSlider(this.floatVariable.Value, this.topValue.Value, this.bottomValue.Value, base.LayoutOptions);
			}
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000CA6 RID: 3238
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000CA7 RID: 3239
		[RequiredField]
		public FsmFloat topValue;

		// Token: 0x04000CA8 RID: 3240
		[RequiredField]
		public FsmFloat bottomValue;

		// Token: 0x04000CA9 RID: 3241
		public FsmEvent changedEvent;
	}
}
