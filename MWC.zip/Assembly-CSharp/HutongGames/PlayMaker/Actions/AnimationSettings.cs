﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000140 RID: 320
	[ActionCategory(ActionCategory.Animation)]
	[Tooltip("Set the Wrap Mode, Blend Mode, Layer and Speed of an Animation.\nNOTE: Settings are applied once, on entering the state, NOT continuously. To dynamically control an animation's settings, use Set Animation Speede etc.")]
	public class AnimationSettings : FsmStateAction
	{
		// Token: 0x060005FF RID: 1535 RVA: 0x0002E304 File Offset: 0x0002C504
		public override void Reset()
		{
			this.gameObject = null;
			this.animName = null;
			this.wrapMode = WrapMode.Loop;
			this.blendMode = AnimationBlendMode.Blend;
			this.speed = 1f;
			this.layer = 0;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x0002E34C File Offset: 0x0002C54C
		public override void OnEnter()
		{
			this.DoAnimationSettings();
			base.Finish();
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x0002E35C File Offset: 0x0002C55C
		private void DoAnimationSettings()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null || string.IsNullOrEmpty(this.animName.Value))
			{
				return;
			}
			Animation component = ownerDefaultTarget.GetComponent<Animation>();
			if (component == null)
			{
				this.LogWarning("Missing animation component: " + ownerDefaultTarget.name);
				return;
			}
			AnimationState animationState = component[this.animName.Value];
			if (animationState == null)
			{
				this.LogWarning("Missing animation: " + this.animName.Value);
				return;
			}
			animationState.wrapMode = this.wrapMode;
			animationState.blendMode = this.blendMode;
			if (!this.layer.IsNone)
			{
				animationState.layer = this.layer.Value;
			}
			if (!this.speed.IsNone)
			{
				animationState.speed = this.speed.Value;
			}
		}

		// Token: 0x040008F6 RID: 2294
		[CheckForComponent(typeof(Animation))]
		[RequiredField]
		[Tooltip("A GameObject with an Animation Component.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040008F7 RID: 2295
		[RequiredField]
		[UIHint(UIHint.Animation)]
		[Tooltip("The name of the animation.")]
		public FsmString animName;

		// Token: 0x040008F8 RID: 2296
		[Tooltip("The behavior of the animation when it wraps.")]
		public WrapMode wrapMode;

		// Token: 0x040008F9 RID: 2297
		[Tooltip("How the animation is blended with other animations on the Game Object.")]
		public AnimationBlendMode blendMode;

		// Token: 0x040008FA RID: 2298
		[Tooltip("The speed of the animation. 1 = normal; 2 = double speed...")]
		[HasFloatSlider(0f, 5f)]
		public FsmFloat speed;

		// Token: 0x040008FB RID: 2299
		[Tooltip("The animation layer")]
		public FsmInt layer;
	}
}
