﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A3 RID: 931
	[Tooltip("Each time this action is called it gets the previous item from a PlayMaker ArrayList Proxy component. \nThis lets you quickly loop backward through all the children of an object to perform actions on them.\nNOTE: To get to specific item use ArrayListGet instead.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetPrevious : ArrayListActions
	{
		// Token: 0x06000FC4 RID: 4036 RVA: 0x00056B38 File Offset: 0x00054D38
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.reset = null;
			this.startIndex = null;
			this.endIndex = null;
			this.loopEvent = null;
			this.finishedEvent = null;
			this.failureEvent = null;
			this.currentIndex = null;
			this.result = null;
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x00056B8C File Offset: 0x00054D8C
		public override void OnEnter()
		{
			if (this.reset.Value)
			{
				this.reset.Value = false;
				this.nextItemIndex = 0;
			}
			if (this.nextItemIndex == 0)
			{
				if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
				{
					base.Fsm.Event(this.failureEvent);
					base.Finish();
				}
				this.countBase = this.proxy.arrayList.Count - 1;
				if (this.startIndex.Value > 0)
				{
					this.nextItemIndex = this.startIndex.Value;
				}
			}
			this.DoGetPreviousItem();
			base.Finish();
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x00056C4C File Offset: 0x00054E4C
		private void DoGetPreviousItem()
		{
			if (this.nextItemIndex > this.countBase)
			{
				this.nextItemIndex = 0;
				base.Fsm.Event(this.finishedEvent);
				return;
			}
			this.GetItemAtIndex();
			if (this.nextItemIndex >= this.countBase)
			{
				this.nextItemIndex = 0;
				base.Fsm.Event(this.finishedEvent);
				return;
			}
			if (this.endIndex.Value > 0 && this.nextItemIndex > this.countBase - this.endIndex.Value)
			{
				this.nextItemIndex = 0;
				base.Fsm.Event(this.finishedEvent);
				return;
			}
			this.nextItemIndex++;
			if (this.loopEvent != null)
			{
				base.Fsm.Event(this.loopEvent);
			}
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x00056D24 File Offset: 0x00054F24
		public void GetItemAtIndex()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.currentIndex.Value = this.countBase - this.nextItemIndex;
			object value = null;
			try
			{
				value = this.proxy.arrayList[this.currentIndex.Value];
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Fsm.Event(this.failureEvent);
				return;
			}
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.result, value);
		}

		// Token: 0x0400147E RID: 5246
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400147F RID: 5247
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001480 RID: 5248
		[Tooltip("Set to true to force iterating from the last item. This variable will be set to false as it carries on iterating, force it back to true if you want to renter this action back to the last item.")]
		[UIHint(UIHint.Variable)]
		public FsmBool reset;

		// Token: 0x04001481 RID: 5249
		[Tooltip("From where to start iteration, leave to 0 to start from the end. index is relative to the last item, so if the start index is 2, this will start 2 items before the last item.")]
		public FsmInt startIndex;

		// Token: 0x04001482 RID: 5250
		[Tooltip("When to end iteration, leave to 0 to iterate until the beginning, index is relative to the last item.")]
		public FsmInt endIndex;

		// Token: 0x04001483 RID: 5251
		[Tooltip("Event to send to get the previous item.")]
		public FsmEvent loopEvent;

		// Token: 0x04001484 RID: 5252
		[Tooltip("Event to send when there are no more items.")]
		public FsmEvent finishedEvent;

		// Token: 0x04001485 RID: 5253
		[Tooltip("The event to trigger if the action fails ( likely and index is out of range exception)")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent failureEvent;

		// Token: 0x04001486 RID: 5254
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		public FsmInt currentIndex;

		// Token: 0x04001487 RID: 5255
		[UIHint(UIHint.Variable)]
		public FsmVar result;

		// Token: 0x04001488 RID: 5256
		private int nextItemIndex;

		// Token: 0x04001489 RID: 5257
		private int countBase;
	}
}
