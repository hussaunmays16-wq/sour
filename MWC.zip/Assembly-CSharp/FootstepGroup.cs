﻿using System;
using System.Collections.Generic;

// Token: 0x0200007E RID: 126
[Serializable]
public class FootstepGroup
{
	// Token: 0x040002E8 RID: 744
	public bool isExpanded = true;

	// Token: 0x040002E9 RID: 745
	public bool useLayerFilter;

	// Token: 0x040002EA RID: 746
	public bool useTagFilter;

	// Token: 0x040002EB RID: 747
	public List<int> matchingLayers = new List<int>
	{
		0
	};

	// Token: 0x040002EC RID: 748
	public List<string> matchingTags = new List<string>
	{
		"Default"
	};

	// Token: 0x040002ED RID: 749
	public string soundType = "[None]";

	// Token: 0x040002EE RID: 750
	public EventSounds.VariationType variationType = EventSounds.VariationType.PlayRandom;

	// Token: 0x040002EF RID: 751
	public string variationName = string.Empty;

	// Token: 0x040002F0 RID: 752
	public float volume = 1f;

	// Token: 0x040002F1 RID: 753
	public bool useFixedPitch;

	// Token: 0x040002F2 RID: 754
	public float pitch = 1f;

	// Token: 0x040002F3 RID: 755
	public float delaySound;
}
