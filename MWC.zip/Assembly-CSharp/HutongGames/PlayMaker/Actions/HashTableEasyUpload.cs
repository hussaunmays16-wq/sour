﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E7 RID: 999
	[ActionCategory("Easy Save 2")]
	[Tooltip("Saves a PlayMaker HashTable Proxy component to MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	public class HashTableEasyUpload : HashTableActions
	{
		// Token: 0x060010E9 RID: 4329 RVA: 0x0005D278 File Offset: 0x0005B478
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x0005D2F0 File Offset: 0x0005B4F0
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.UploadHashTable();
			}
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x0005D32C File Offset: 0x0005B52C
		private void UploadHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text))
			{
				text = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/hashTable/",
					this.reference.Value
				});
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (object obj in this.proxy.hashTable.Keys)
			{
				dictionary[(string)obj] = PlayMakerUtils.ParseValueToString(this.proxy.hashTable[obj]);
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				text,
				"&webfilename=",
				this.saveFile.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Upload<string, string>(dictionary));
			this.Log(string.Concat(new string[]
			{
				"Uploading to ",
				this.urlToPHPFile.Value,
				"?tag=",
				text,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x0005D504 File Offset: 0x0005B704
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isUploaded);
				base.Finish();
			}
		}

		// Token: 0x04001611 RID: 5649
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001612 RID: 5650
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001613 RID: 5651
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + hashTable Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04001614 RID: 5652
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data. Leave as default if unsure.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04001615 RID: 5653
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04001616 RID: 5654
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04001617 RID: 5655
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04001618 RID: 5656
		[Tooltip("The Event to send if Upload succeeded.")]
		[ActionSection("Result")]
		public FsmEvent isUploaded;

		// Token: 0x04001619 RID: 5657
		[Tooltip("The event to send if Upload failed.")]
		public FsmEvent isError;

		// Token: 0x0400161A RID: 5658
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x0400161B RID: 5659
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x0400161C RID: 5660
		private ES2Web web;
	}
}
