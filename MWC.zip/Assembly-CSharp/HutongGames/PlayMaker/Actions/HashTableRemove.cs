﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003CA RID: 970
	[Tooltip("Remove an item by key ( key/value pairs) in a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy).")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableRemove : HashTableActions
	{
		// Token: 0x06001061 RID: 4193 RVA: 0x00059594 File Offset: 0x00057794
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
		}

		// Token: 0x06001062 RID: 4194 RVA: 0x000595AC File Offset: 0x000577AC
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doHashTableRemove();
			}
			base.Finish();
		}

		// Token: 0x06001063 RID: 4195 RVA: 0x000595EC File Offset: 0x000577EC
		public void doHashTableRemove()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.hashTable.Remove(this.key.Value);
		}

		// Token: 0x04001545 RID: 5445
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001546 RID: 5446
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001547 RID: 5447
		[Tooltip("The item key in that hashTable")]
		[RequiredField]
		public FsmString key;
	}
}
