﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F8 RID: 504
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Inserts a flexible space element.")]
	public class GUILayoutFlexibleSpace : FsmStateAction
	{
		// Token: 0x060008B5 RID: 2229 RVA: 0x0003A640 File Offset: 0x00038840
		public override void Reset()
		{
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x0003A644 File Offset: 0x00038844
		public override void OnGUI()
		{
			GUILayout.FlexibleSpace();
		}
	}
}
