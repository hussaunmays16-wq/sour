﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000192 RID: 402
	[Tooltip("Downloads a Vector2 from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class DownloadVector2 : FsmStateAction
	{
		// Token: 0x0600074A RID: 1866 RVA: 0x00033704 File Offset: 0x00031904
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.loadValue = null;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x00033770 File Offset: 0x00031970
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new object[]
			{
				"Downloading from ",
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile
			}));
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00033844 File Offset: 0x00031A44
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				this.loadValue.Value = this.web.Load<Vector2>(this.uniqueTag.Value);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
			}
		}

		// Token: 0x04000A79 RID: 2681
		[RequiredField]
		[Tooltip("The variable we want to load our data into.")]
		public FsmVector2 loadValue;

		// Token: 0x04000A7A RID: 2682
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000A7B RID: 2683
		[RequiredField]
		[Tooltip("The username that you have specified in your ES2.php file.")]
		public FsmString username = "ES2";

		// Token: 0x04000A7C RID: 2684
		[RequiredField]
		[Tooltip("The password that you have specified in your ES2.php file.")]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000A7D RID: 2685
		[RequiredField]
		[Tooltip("The unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000A7E RID: 2686
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04000A7F RID: 2687
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04000A80 RID: 2688
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x04000A81 RID: 2689
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x04000A82 RID: 2690
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000A83 RID: 2691
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000A84 RID: 2692
		private ES2Web web;
	}
}
