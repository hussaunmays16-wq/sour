﻿using System;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class Dissolver : MonoBehaviour
{
	// Token: 0x06000004 RID: 4 RVA: 0x0000211C File Offset: 0x0000031C
	private void Update()
	{
		base.GetComponent<Renderer>().material.SetFloat("_Cutoff", Mathf.Clamp01(Mathf.PingPong(Time.time * 0.5f, 1.6f)));
	}
}
