﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014C RID: 332
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if any of the given Bool Variables are True.")]
	public class BoolAnyTrue : FsmStateAction
	{
		// Token: 0x0600062B RID: 1579 RVA: 0x0002EDA8 File Offset: 0x0002CFA8
		public override void Reset()
		{
			this.boolVariables = null;
			this.sendEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x0002EDC8 File Offset: 0x0002CFC8
		public override void OnEnter()
		{
			this.DoAnyTrue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x0002EDE4 File Offset: 0x0002CFE4
		public override void OnUpdate()
		{
			this.DoAnyTrue();
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x0002EDEC File Offset: 0x0002CFEC
		private void DoAnyTrue()
		{
			if (this.boolVariables.Length == 0)
			{
				return;
			}
			this.storeResult.Value = false;
			for (int i = 0; i < this.boolVariables.Length; i++)
			{
				if (this.boolVariables[i].Value)
				{
					base.Fsm.Event(this.sendEvent);
					this.storeResult.Value = true;
					return;
				}
			}
		}

		// Token: 0x04000922 RID: 2338
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The Bool variables to check.")]
		public FsmBool[] boolVariables;

		// Token: 0x04000923 RID: 2339
		[Tooltip("Event to send if any of the Bool variables are True.")]
		public FsmEvent sendEvent;

		// Token: 0x04000924 RID: 2340
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a Bool variable.")]
		public FsmBool storeResult;

		// Token: 0x04000925 RID: 2341
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
