﻿using System;
using UnityEngine;

// Token: 0x02000457 RID: 1111
[AddComponentMenu("Image Effects/Edge Detection")]
[ExecuteInEditMode]
public class EdgeDetectEffect : ImageEffectBase
{
	// Token: 0x060012A7 RID: 4775 RVA: 0x00068EDC File Offset: 0x000670DC
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		base.material.SetFloat("_Treshold", this.threshold * this.threshold);
		Graphics.Blit(source, destination, base.material);
	}

	// Token: 0x04001858 RID: 6232
	public float threshold = 0.2f;
}
