﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A0 RID: 928
	[Tooltip("Gets an item from a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGet : ArrayListActions
	{
		// Token: 0x06000FB6 RID: 4022 RVA: 0x00056604 File Offset: 0x00054804
		public override void Reset()
		{
			this.atIndex = null;
			this.gameObject = null;
			this.failureEvent = null;
			this.result = null;
		}

		// Token: 0x06000FB7 RID: 4023 RVA: 0x00056624 File Offset: 0x00054824
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.GetItemAtIndex();
			}
			base.Finish();
		}

		// Token: 0x06000FB8 RID: 4024 RVA: 0x00056664 File Offset: 0x00054864
		public void GetItemAtIndex()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			object value = null;
			try
			{
				value = this.proxy.arrayList[this.atIndex.Value];
			}
			catch (Exception ex)
			{
				Debug.Log(ex.Message);
				base.Fsm.Event(this.failureEvent);
				return;
			}
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.result, value);
		}

		// Token: 0x04001467 RID: 5223
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001468 RID: 5224
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001469 RID: 5225
		[Tooltip("The index to retrieve the item from")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt atIndex;

		// Token: 0x0400146A RID: 5226
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmVar result;

		// Token: 0x0400146B RID: 5227
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger if the action fails ( likely and index is out of range exception)")]
		public FsmEvent failureEvent;
	}
}
