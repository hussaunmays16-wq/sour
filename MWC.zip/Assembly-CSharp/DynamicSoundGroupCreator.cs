﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000B8 RID: 184
public class DynamicSoundGroupCreator : MonoBehaviour
{
	// Token: 0x06000341 RID: 833 RVA: 0x00015604 File Offset: 0x00013804
	private void Awake()
	{
		this._trans = base.transform;
		this._hasCreated = false;
		AudioSource component = base.GetComponent<AudioSource>();
		if (component != null)
		{
			UnityEngine.Object.Destroy(component);
		}
	}

	// Token: 0x06000342 RID: 834 RVA: 0x00015640 File Offset: 0x00013840
	private void OnEnable()
	{
		this.CreateItemsIfReady();
	}

	// Token: 0x06000343 RID: 835 RVA: 0x00015648 File Offset: 0x00013848
	private void Start()
	{
		this.CreateItemsIfReady();
	}

	// Token: 0x06000344 RID: 836 RVA: 0x00015650 File Offset: 0x00013850
	private void OnDisable()
	{
		if (MasterAudio.AppIsShuttingDown)
		{
			return;
		}
		if (!this.removeGroupsOnSceneChange)
		{
			return;
		}
		if (MasterAudio.SafeInstance != null)
		{
			this.RemoveItems();
		}
	}

	// Token: 0x06000345 RID: 837 RVA: 0x00015680 File Offset: 0x00013880
	private void CreateItemsIfReady()
	{
		if (this.createOnAwake && MasterAudio.SoundsReady && !this._hasCreated)
		{
			this.CreateItems();
		}
	}

	// Token: 0x06000346 RID: 838 RVA: 0x000156B4 File Offset: 0x000138B4
	public void RemoveItems()
	{
		for (int i = 0; i < this.groupBuses.Count; i++)
		{
			GroupBus groupBus = this.groupBuses[i];
			if (!groupBus.isExisting)
			{
				MasterAudio.DeleteBusByName(groupBus.busName);
			}
		}
		for (int j = 0; j < this._groupsToRemove.Count; j++)
		{
			MasterAudio.RemoveSoundGroup(this._groupsToRemove[j]);
		}
		this._groupsToRemove.Clear();
		for (int k = 0; k < this.customEventsToCreate.Count; k++)
		{
			CustomEvent customEvent = this.customEventsToCreate[k];
			MasterAudio.DeleteCustomEvent(customEvent.EventName);
		}
		for (int l = 0; l < this.musicPlaylists.Count; l++)
		{
			MasterAudio.Playlist playlist = this.musicPlaylists[l];
			MasterAudio.DeletePlaylist(playlist.playlistName);
		}
		if (this.reUseMode == DynamicSoundGroupCreator.CreateItemsWhen.EveryEnable)
		{
			this._hasCreated = false;
		}
	}

	// Token: 0x06000347 RID: 839 RVA: 0x000157C4 File Offset: 0x000139C4
	public void CreateItems()
	{
		if (this._hasCreated)
		{
			Debug.LogWarning("DynamicSoundGroupCreator '" + base.transform.name + "' has already created its items. Cannot create again.");
			return;
		}
		MasterAudio instance = MasterAudio.Instance;
		if (instance == null)
		{
			return;
		}
		this.PopulateGroupData();
		for (int i = 0; i < this.groupBuses.Count; i++)
		{
			GroupBus groupBus = this.groupBuses[i];
			if (groupBus.isExisting)
			{
				if (MasterAudio.GrabBusByName(groupBus.busName) == null)
				{
					MasterAudio.LogWarning(string.Concat(new string[]
					{
						"Existing bus '",
						groupBus.busName,
						"' was not found, specified in prefab '",
						base.name,
						"'."
					}));
				}
			}
			else if (MasterAudio.CreateBus(groupBus.busName, this.errorOnDuplicates))
			{
				GroupBus groupBus2 = MasterAudio.GrabBusByName(groupBus.busName);
				if (groupBus2 != null)
				{
					groupBus2.volume = groupBus.volume;
					groupBus2.voiceLimit = groupBus.voiceLimit;
					groupBus2.stopOldest = groupBus.stopOldest;
					groupBus2.mixerChannel = groupBus.mixerChannel;
				}
			}
		}
		for (int j = 0; j < this._groupsToCreate.Count; j++)
		{
			DynamicSoundGroup dynamicSoundGroup = this._groupsToCreate[j];
			string busName = string.Empty;
			int num = (dynamicSoundGroup.busIndex != -1) ? dynamicSoundGroup.busIndex : 0;
			if (num >= DynamicSoundGroupCreator.HardCodedBusOptions)
			{
				GroupBus groupBus3 = this.groupBuses[num - DynamicSoundGroupCreator.HardCodedBusOptions];
				busName = groupBus3.busName;
			}
			dynamicSoundGroup.busName = busName;
			Transform transform = MasterAudio.CreateNewSoundGroup(dynamicSoundGroup, this._trans.name, this.errorOnDuplicates);
			for (int k = 0; k < dynamicSoundGroup.groupVariations.Count; k++)
			{
				DynamicGroupVariation dynamicGroupVariation = dynamicSoundGroup.groupVariations[k];
				if (dynamicGroupVariation.LowPassFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.LowPassFilter);
				}
				if (dynamicGroupVariation.HighPassFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.HighPassFilter);
				}
				if (dynamicGroupVariation.DistortionFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.DistortionFilter);
				}
				if (dynamicGroupVariation.ChorusFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.ChorusFilter);
				}
				if (dynamicGroupVariation.EchoFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.EchoFilter);
				}
				if (dynamicGroupVariation.ReverbFilter != null)
				{
					UnityEngine.Object.Destroy(dynamicGroupVariation.ReverbFilter);
				}
			}
			if (!(transform == null))
			{
				this._groupsToRemove.Add(transform);
			}
		}
		for (int l = 0; l < this.musicDuckingSounds.Count; l++)
		{
			DuckGroupInfo duckGroupInfo = this.musicDuckingSounds[l];
			if (!(duckGroupInfo.soundType == "[None]"))
			{
				MasterAudio.AddSoundGroupToDuckList(duckGroupInfo.soundType, duckGroupInfo.riseVolStart);
			}
		}
		for (int m = 0; m < this.customEventsToCreate.Count; m++)
		{
			CustomEvent customEvent = this.customEventsToCreate[m];
			MasterAudio.CreateCustomEvent(customEvent.EventName, customEvent.eventReceiveMode, customEvent.distanceThreshold, this.errorOnDuplicates);
		}
		for (int n = 0; n < this.musicPlaylists.Count; n++)
		{
			MasterAudio.Playlist playlist = this.musicPlaylists[n];
			MasterAudio.CreatePlaylist(playlist, this.errorOnDuplicates);
		}
		this._hasCreated = true;
		if (this.itemsCreatedEventExpanded)
		{
			MasterAudio.FireCustomEvent(this.itemsCreatedCustomEvent, this._trans.position);
		}
	}

	// Token: 0x06000348 RID: 840 RVA: 0x00015BB8 File Offset: 0x00013DB8
	private void PopulateGroupData()
	{
		this._groupsToCreate.Clear();
		for (int i = 0; i < this._trans.childCount; i++)
		{
			DynamicSoundGroup component = this._trans.GetChild(i).GetComponent<DynamicSoundGroup>();
			if (!(component == null))
			{
				component.groupVariations.Clear();
				for (int j = 0; j < component.transform.childCount; j++)
				{
					DynamicGroupVariation component2 = component.transform.GetChild(j).GetComponent<DynamicGroupVariation>();
					if (!(component2 == null))
					{
						component.groupVariations.Add(component2);
					}
				}
				this._groupsToCreate.Add(component);
			}
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x06000349 RID: 841 RVA: 0x00015C74 File Offset: 0x00013E74
	public static int HardCodedBusOptions
	{
		get
		{
			return 3;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x0600034A RID: 842 RVA: 0x00015C78 File Offset: 0x00013E78
	public List<DynamicSoundGroup> GroupsToCreate
	{
		get
		{
			return this._groupsToCreate;
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x0600034B RID: 843 RVA: 0x00015C80 File Offset: 0x00013E80
	public bool ShouldShowUnityAudioMixerGroupAssignments
	{
		get
		{
			return this.showUnityMixerGroupAssignment;
		}
	}

	// Token: 0x040004FA RID: 1274
	public const int ExtraHardCodedBusOptions = 1;

	// Token: 0x040004FB RID: 1275
	public SystemLanguage previewLanguage = SystemLanguage.English;

	// Token: 0x040004FC RID: 1276
	public MasterAudio.DragGroupMode curDragGroupMode;

	// Token: 0x040004FD RID: 1277
	public GameObject groupTemplate;

	// Token: 0x040004FE RID: 1278
	public GameObject variationTemplate;

	// Token: 0x040004FF RID: 1279
	public bool errorOnDuplicates;

	// Token: 0x04000500 RID: 1280
	public bool createOnAwake = true;

	// Token: 0x04000501 RID: 1281
	public bool soundGroupsAreExpanded = true;

	// Token: 0x04000502 RID: 1282
	public bool removeGroupsOnSceneChange = true;

	// Token: 0x04000503 RID: 1283
	public DynamicSoundGroupCreator.CreateItemsWhen reUseMode;

	// Token: 0x04000504 RID: 1284
	public bool showCustomEvents = true;

	// Token: 0x04000505 RID: 1285
	public MasterAudio.AudioLocation bulkVariationMode;

	// Token: 0x04000506 RID: 1286
	public List<CustomEvent> customEventsToCreate = new List<CustomEvent>();

	// Token: 0x04000507 RID: 1287
	public string newEventName = "my event";

	// Token: 0x04000508 RID: 1288
	public bool showMusicDucking = true;

	// Token: 0x04000509 RID: 1289
	public List<DuckGroupInfo> musicDuckingSounds = new List<DuckGroupInfo>();

	// Token: 0x0400050A RID: 1290
	public List<GroupBus> groupBuses = new List<GroupBus>();

	// Token: 0x0400050B RID: 1291
	public bool playListExpanded;

	// Token: 0x0400050C RID: 1292
	public bool playlistEditorExp = true;

	// Token: 0x0400050D RID: 1293
	public List<MasterAudio.Playlist> musicPlaylists = new List<MasterAudio.Playlist>();

	// Token: 0x0400050E RID: 1294
	public List<GameObject> audioSourceTemplates = new List<GameObject>(10);

	// Token: 0x0400050F RID: 1295
	public string audioSourceTemplateName = "Max Distance 500";

	// Token: 0x04000510 RID: 1296
	public bool itemsCreatedEventExpanded;

	// Token: 0x04000511 RID: 1297
	public string itemsCreatedCustomEvent = string.Empty;

	// Token: 0x04000512 RID: 1298
	public bool showUnityMixerGroupAssignment = true;

	// Token: 0x04000513 RID: 1299
	private bool _hasCreated;

	// Token: 0x04000514 RID: 1300
	private readonly List<Transform> _groupsToRemove = new List<Transform>();

	// Token: 0x04000515 RID: 1301
	private Transform _trans;

	// Token: 0x04000516 RID: 1302
	private readonly List<DynamicSoundGroup> _groupsToCreate = new List<DynamicSoundGroup>();

	// Token: 0x020000B9 RID: 185
	public enum CreateItemsWhen
	{
		// Token: 0x04000518 RID: 1304
		FirstEnableOnly,
		// Token: 0x04000519 RID: 1305
		EveryEnable
	}
}
