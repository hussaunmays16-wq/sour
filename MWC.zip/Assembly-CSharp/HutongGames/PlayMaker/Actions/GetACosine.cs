﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200002D RID: 45
	[Tooltip("Get the Arc Cosine. You can get the result in degrees, simply check on the RadToDeg conversion")]
	[ActionCategory("Trigonometry")]
	public class GetACosine : FsmStateAction
	{
		// Token: 0x06000092 RID: 146 RVA: 0x000062B0 File Offset: 0x000044B0
		public override void Reset()
		{
			this.angle = null;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.Value = null;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x000062D4 File Offset: 0x000044D4
		public override void OnEnter()
		{
			this.DoACosine();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000094 RID: 148 RVA: 0x000062F0 File Offset: 0x000044F0
		public override void OnUpdate()
		{
			this.DoACosine();
		}

		// Token: 0x06000095 RID: 149 RVA: 0x000062F8 File Offset: 0x000044F8
		private void DoACosine()
		{
			float num = Mathf.Acos(this.Value.Value);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000E9 RID: 233
		[RequiredField]
		[Tooltip("The value of the cosine")]
		public FsmFloat Value;

		// Token: 0x040000EA RID: 234
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat angle;

		// Token: 0x040000EB RID: 235
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x040000EC RID: 236
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
