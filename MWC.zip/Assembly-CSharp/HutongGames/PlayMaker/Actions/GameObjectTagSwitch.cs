﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000210 RID: 528
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Sends an Event based on a Game Object's Tag.")]
	public class GameObjectTagSwitch : FsmStateAction
	{
		// Token: 0x0600090C RID: 2316 RVA: 0x0003BA94 File Offset: 0x00039C94
		public override void Reset()
		{
			this.gameObject = null;
			this.compareTo = new FsmString[1];
			this.sendEvent = new FsmEvent[1];
			this.everyFrame = false;
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x0003BAC8 File Offset: 0x00039CC8
		public override void OnEnter()
		{
			this.DoTagSwitch();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0003BAE4 File Offset: 0x00039CE4
		public override void OnUpdate()
		{
			this.DoTagSwitch();
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x0003BAEC File Offset: 0x00039CEC
		private void DoTagSwitch()
		{
			GameObject value = this.gameObject.Value;
			if (value == null)
			{
				return;
			}
			for (int i = 0; i < this.compareTo.Length; i++)
			{
				if (value.tag == this.compareTo[i].Value)
				{
					base.Fsm.Event(this.sendEvent[i]);
					return;
				}
			}
		}

		// Token: 0x04000CD4 RID: 3284
		[UIHint(UIHint.Variable)]
		[Tooltip("The GameObject to test.")]
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000CD5 RID: 3285
		[CompoundArray("Tag Switches", "Compare Tag", "Send Event")]
		[UIHint(UIHint.Tag)]
		public FsmString[] compareTo;

		// Token: 0x04000CD6 RID: 3286
		public FsmEvent[] sendEvent;

		// Token: 0x04000CD7 RID: 3287
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
