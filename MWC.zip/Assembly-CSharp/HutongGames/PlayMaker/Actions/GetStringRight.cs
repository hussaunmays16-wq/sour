﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000258 RID: 600
	[Tooltip("Gets the Right n characters from a String.")]
	[ActionCategory(ActionCategory.String)]
	public class GetStringRight : FsmStateAction
	{
		// Token: 0x06000A3C RID: 2620 RVA: 0x0003F594 File Offset: 0x0003D794
		public override void Reset()
		{
			this.stringVariable = null;
			this.charCount = 0;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A3D RID: 2621 RVA: 0x0003F5B8 File Offset: 0x0003D7B8
		public override void OnEnter()
		{
			this.DoGetStringRight();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A3E RID: 2622 RVA: 0x0003F5D4 File Offset: 0x0003D7D4
		public override void OnUpdate()
		{
			this.DoGetStringRight();
		}

		// Token: 0x06000A3F RID: 2623 RVA: 0x0003F5DC File Offset: 0x0003D7DC
		private void DoGetStringRight()
		{
			if (this.stringVariable == null)
			{
				return;
			}
			if (this.storeResult == null)
			{
				return;
			}
			string value = this.stringVariable.Value;
			this.storeResult.Value = value.Substring(value.Length - this.charCount.Value, this.charCount.Value);
		}

		// Token: 0x04000E25 RID: 3621
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString stringVariable;

		// Token: 0x04000E26 RID: 3622
		public FsmInt charCount;

		// Token: 0x04000E27 RID: 3623
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;

		// Token: 0x04000E28 RID: 3624
		public bool everyFrame;
	}
}
