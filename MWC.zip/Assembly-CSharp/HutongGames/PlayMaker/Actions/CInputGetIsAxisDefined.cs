﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A9 RID: 1193
	[ActionCategory("cInput")]
	[Tooltip("Gets if an axis is defined and puts the value into a fsm variable.")]
	public class CInputGetIsAxisDefined : FsmStateAction
	{
		// Token: 0x06001456 RID: 5206 RVA: 0x00088C8C File Offset: 0x00086E8C
		public override void Reset()
		{
			this.axisName = null;
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x00088C98 File Offset: 0x00086E98
		public override void OnUpdate()
		{
			if (this.axisName == null)
			{
				return;
			}
			this.storeAxisIsDefined.Value = cInput.IsAxisDefined(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CC3 RID: 7363
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CC4 RID: 7364
		[Tooltip("Store if the axis is defined.")]
		public FsmBool storeAxisIsDefined;

		// Token: 0x04001CC5 RID: 7365
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
