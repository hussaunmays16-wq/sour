﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000246 RID: 582
	[Tooltip("Each time this action is called it gets the next child of a GameObject. This lets you quickly loop through all the children of an object to perform actions on them. NOTE: To find a specific child use Find Child.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetNextChild : FsmStateAction
	{
		// Token: 0x060009F0 RID: 2544 RVA: 0x0003E9A4 File Offset: 0x0003CBA4
		public override void Reset()
		{
			this.gameObject = null;
			this.storeNextChild = null;
			this.loopEvent = null;
			this.finishedEvent = null;
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0003E9C4 File Offset: 0x0003CBC4
		public override void OnEnter()
		{
			this.DoGetNextChild(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x0003E9E4 File Offset: 0x0003CBE4
		private void DoGetNextChild(GameObject parent)
		{
			if (parent == null)
			{
				return;
			}
			if (this.go != parent)
			{
				this.go = parent;
				this.nextChildIndex = 0;
			}
			if (this.nextChildIndex >= this.go.transform.childCount)
			{
				this.nextChildIndex = 0;
				base.Fsm.Event(this.finishedEvent);
				return;
			}
			this.storeNextChild.Value = parent.transform.GetChild(this.nextChildIndex).gameObject;
			if (this.nextChildIndex >= this.go.transform.childCount)
			{
				this.nextChildIndex = 0;
				base.Fsm.Event(this.finishedEvent);
				return;
			}
			this.nextChildIndex++;
			if (this.loopEvent != null)
			{
				base.Fsm.Event(this.loopEvent);
			}
		}

		// Token: 0x04000DE5 RID: 3557
		[Tooltip("The parent GameObject. Note, if GameObject changes, this action will reset and start again at the first child.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DE6 RID: 3558
		[Tooltip("Store the next child in a GameObject variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmGameObject storeNextChild;

		// Token: 0x04000DE7 RID: 3559
		[Tooltip("Event to send to get the next child.")]
		public FsmEvent loopEvent;

		// Token: 0x04000DE8 RID: 3560
		[Tooltip("Event to send when there are no more children.")]
		public FsmEvent finishedEvent;

		// Token: 0x04000DE9 RID: 3561
		private GameObject go;

		// Token: 0x04000DEA RID: 3562
		private int nextChildIndex;
	}
}
