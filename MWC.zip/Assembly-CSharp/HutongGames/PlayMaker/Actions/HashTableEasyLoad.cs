﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E3 RID: 995
	[ActionCategory("Easy Save 2")]
	[Tooltip("Loads a PlayMaker HashTable Proxy component using EasySave")]
	public class HashTableEasyLoad : HashTableActions
	{
		// Token: 0x060010D9 RID: 4313 RVA: 0x0005C998 File Offset: 0x0005AB98
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
			this.loadFromResources = false;
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0005C9E4 File Offset: 0x0005ABE4
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.LoadHashTable();
			}
			base.Finish();
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x0005CA24 File Offset: 0x0005AC24
		public void LoadHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text))
			{
				text = string.Concat(new object[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/hashTable/",
					this.reference
				});
			}
			ES2Settings es2Settings = new ES2Settings();
			if (this.loadFromResources.Value)
			{
				es2Settings.saveLocation = ES2Settings.SaveLocation.Resources;
			}
			Dictionary<string, string> dictionary = ES2.LoadDictionary<string, string>(this.saveFile.Value + "?tag=" + text);
			this.Log("Loaded from " + this.saveFile.Value + "?tag=" + text);
			this.proxy.hashTable.Clear();
			foreach (string key in dictionary.Keys)
			{
				this.proxy.hashTable[key] = PlayMakerUtils.ParseValueFromString(dictionary[key]);
			}
			base.Finish();
		}

		// Token: 0x040015FB RID: 5627
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015FC RID: 5628
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015FD RID: 5629
		[ActionSection("Easy Save Set Up")]
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015FE RID: 5630
		[Tooltip("The name of the file that we'll create to store our data.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015FF RID: 5631
		[Tooltip("Whether the data we are loading is stored in the Resources folder.")]
		public FsmBool loadFromResources;
	}
}
