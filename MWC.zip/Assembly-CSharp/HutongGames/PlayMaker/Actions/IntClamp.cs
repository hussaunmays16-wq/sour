﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200026D RID: 621
	[Tooltip("Clamp the value of an Integer Variable to a Min/Max range.")]
	[ActionCategory(ActionCategory.Math)]
	public class IntClamp : FsmStateAction
	{
		// Token: 0x06000A96 RID: 2710 RVA: 0x000404F0 File Offset: 0x0003E6F0
		public override void Reset()
		{
			this.intVariable = null;
			this.minValue = null;
			this.maxValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x00040510 File Offset: 0x0003E710
		public override void OnEnter()
		{
			this.DoClamp();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A98 RID: 2712 RVA: 0x0004052C File Offset: 0x0003E72C
		public override void OnUpdate()
		{
			this.DoClamp();
		}

		// Token: 0x06000A99 RID: 2713 RVA: 0x00040534 File Offset: 0x0003E734
		private void DoClamp()
		{
			this.intVariable.Value = Mathf.Clamp(this.intVariable.Value, this.minValue.Value, this.maxValue.Value);
		}

		// Token: 0x04000E7B RID: 3707
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmInt intVariable;

		// Token: 0x04000E7C RID: 3708
		[RequiredField]
		public FsmInt minValue;

		// Token: 0x04000E7D RID: 3709
		[RequiredField]
		public FsmInt maxValue;

		// Token: 0x04000E7E RID: 3710
		public bool everyFrame;
	}
}
