﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000186 RID: 390
	[ActionCategory(ActionCategory.GUI)]
	[Tooltip("Fills the screen with a Color. NOTE: Uses OnGUI so you need a PlayMakerGUI component in the scene.")]
	public class DrawFullscreenColor : FsmStateAction
	{
		// Token: 0x0600071D RID: 1821 RVA: 0x00031D70 File Offset: 0x0002FF70
		public override void Reset()
		{
			this.color = Color.white;
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x00031D84 File Offset: 0x0002FF84
		public override void OnGUI()
		{
			Color color = GUI.color;
			GUI.color = this.color.Value;
			GUI.DrawTexture(new Rect(0f, 0f, (float)Screen.width, (float)Screen.height), ActionHelpers.WhiteTexture);
			GUI.color = color;
		}

		// Token: 0x04000A05 RID: 2565
		[Tooltip("Color. NOTE: Uses OnGUI so you need a PlayMakerGUI component in the scene.")]
		[RequiredField]
		public FsmColor color;
	}
}
