﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A4 RID: 1188
	[ActionCategory("cInput")]
	[Tooltip("Gets the gravity of an axis and stores it in a fsm variable.")]
	public class CInputGetAxisGravity : FsmStateAction
	{
		// Token: 0x06001447 RID: 5191 RVA: 0x000889F8 File Offset: 0x00086BF8
		public override void Reset()
		{
			this.axisName = null;
			this.storeAxisGravity = null;
		}

		// Token: 0x06001448 RID: 5192 RVA: 0x00088A08 File Offset: 0x00086C08
		public override void OnUpdate()
		{
			this.storeAxisGravity.Value = cInput.GetAxisGravity(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CB0 RID: 7344
		[RequiredField]
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CB1 RID: 7345
		[Tooltip("The value of the axis gravity.")]
		public FsmFloat storeAxisGravity;

		// Token: 0x04001CB2 RID: 7346
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
