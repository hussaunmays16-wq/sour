﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000265 RID: 613
	[Tooltip("Gets the Velocity of a Game Object and stores it in a Vector3 Variable or each Axis in a Float Variable. NOTE: The Game Object must have a Rigid Body.")]
	[ActionCategory(ActionCategory.Physics)]
	public class GetVelocity : ComponentAction<Rigidbody>
	{
		// Token: 0x06000A73 RID: 2675 RVA: 0x0003FF40 File Offset: 0x0003E140
		public override void Reset()
		{
			this.gameObject = null;
			this.vector = null;
			this.x = null;
			this.y = null;
			this.z = null;
			this.space = Space.World;
			this.everyFrame = false;
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0003FF74 File Offset: 0x0003E174
		public override void OnEnter()
		{
			this.DoGetVelocity();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x0003FF90 File Offset: 0x0003E190
		public override void OnUpdate()
		{
			this.DoGetVelocity();
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x0003FF98 File Offset: 0x0003E198
		private void DoGetVelocity()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (!base.UpdateCache(ownerDefaultTarget))
			{
				return;
			}
			Vector3 vector = base.rigidbody.velocity;
			if (this.space == Space.Self)
			{
				vector = ownerDefaultTarget.transform.InverseTransformDirection(vector);
			}
			this.vector.Value = vector;
			this.x.Value = vector.x;
			this.y.Value = vector.y;
			this.z.Value = vector.z;
		}

		// Token: 0x04000E5D RID: 3677
		[CheckForComponent(typeof(Rigidbody))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E5E RID: 3678
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector;

		// Token: 0x04000E5F RID: 3679
		[UIHint(UIHint.Variable)]
		public FsmFloat x;

		// Token: 0x04000E60 RID: 3680
		[UIHint(UIHint.Variable)]
		public FsmFloat y;

		// Token: 0x04000E61 RID: 3681
		[UIHint(UIHint.Variable)]
		public FsmFloat z;

		// Token: 0x04000E62 RID: 3682
		public Space space;

		// Token: 0x04000E63 RID: 3683
		public bool everyFrame;
	}
}
