﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039B RID: 923
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Check if an item is contains in a particula PlayMaker ArrayList Proxy component")]
	public class ArrayListContains : ArrayListActions
	{
		// Token: 0x06000FA3 RID: 4003 RVA: 0x00055F6C File Offset: 0x0005416C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.variable = null;
			this.isContained = null;
			this.isContainedEvent = null;
			this.isNotContainedEvent = null;
		}

		// Token: 0x06000FA4 RID: 4004 RVA: 0x00055FA4 File Offset: 0x000541A4
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doesArrayListContains();
			}
			base.Finish();
		}

		// Token: 0x06000FA5 RID: 4005 RVA: 0x00055FE4 File Offset: 0x000541E4
		public void doesArrayListContains()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			bool flag = false;
			PlayMakerUtils.RefreshValueFromFsmVar(base.Fsm, this.variable);
			switch (this.variable.Type)
			{
			case VariableType.Float:
				flag = this.proxy.arrayList.Contains(this.variable.floatValue);
				break;
			case VariableType.Int:
				flag = this.proxy.arrayList.Contains(this.variable.intValue);
				break;
			case VariableType.Bool:
				flag = this.proxy.arrayList.Contains(this.variable.boolValue);
				break;
			case VariableType.GameObject:
				flag = this.proxy.arrayList.Contains(this.variable.gameObjectValue);
				break;
			case VariableType.String:
				flag = this.proxy.arrayList.Contains(this.variable.stringValue);
				break;
			case VariableType.Vector2:
				flag = this.proxy.arrayList.Contains(this.variable.vector2Value);
				break;
			case VariableType.Vector3:
				flag = this.proxy.arrayList.Contains(this.variable.vector3Value);
				break;
			case VariableType.Color:
				flag = this.proxy.arrayList.Contains(this.variable.colorValue);
				break;
			case VariableType.Rect:
				flag = this.proxy.arrayList.Contains(this.variable.rectValue);
				break;
			case VariableType.Material:
				flag = this.proxy.arrayList.Contains(this.variable.materialValue);
				break;
			case VariableType.Texture:
				flag = this.proxy.arrayList.Contains(this.variable.textureValue);
				break;
			case VariableType.Quaternion:
				flag = this.proxy.arrayList.Contains(this.variable.quaternionValue);
				break;
			case VariableType.Object:
				flag = this.proxy.arrayList.Contains(this.variable.objectReference);
				break;
			}
			this.isContained.Value = flag;
			if (flag)
			{
				base.Fsm.Event(this.isContainedEvent);
			}
			else
			{
				base.Fsm.Event(this.isNotContainedEvent);
			}
		}

		// Token: 0x04001450 RID: 5200
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001451 RID: 5201
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x04001452 RID: 5202
		[Tooltip("The variable to check.")]
		[RequiredField]
		[ActionSection("Data")]
		public FsmVar variable;

		// Token: 0x04001453 RID: 5203
		[Tooltip("Store in a bool wether it contains or not that element (described below)")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmBool isContained;

		// Token: 0x04001454 RID: 5204
		[Tooltip("Event sent if this arraList contains that element ( described below)")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent isContainedEvent;

		// Token: 0x04001455 RID: 5205
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this arraList does not contains that element ( described below)")]
		public FsmEvent isNotContainedEvent;
	}
}
