﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000177 RID: 375
	[Tooltip("Logs the value of an Integer Variable in the PlayMaker Log Window.")]
	[ActionCategory(ActionCategory.Debug)]
	public class DebugInt : FsmStateAction
	{
		// Token: 0x060006EB RID: 1771 RVA: 0x000316D0 File Offset: 0x0002F8D0
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.intVariable = null;
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x000316E0 File Offset: 0x0002F8E0
		public override void OnEnter()
		{
			string text = "None";
			if (!this.intVariable.IsNone)
			{
				text = this.intVariable.Name + ": " + this.intVariable.Value;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009E3 RID: 2531
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009E4 RID: 2532
		[Tooltip("Prints the value of an Int variable in the PlayMaker log window.")]
		[UIHint(UIHint.Variable)]
		public FsmInt intVariable;
	}
}
