﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200007D RID: 125
public class DynamicSoundGroup : MonoBehaviour
{
	// Token: 0x040002C7 RID: 711
	public GameObject variationTemplate;

	// Token: 0x040002C8 RID: 712
	public bool alwaysHighestPriority;

	// Token: 0x040002C9 RID: 713
	public float groupMasterVolume = 1f;

	// Token: 0x040002CA RID: 714
	public int retriggerPercentage = 50;

	// Token: 0x040002CB RID: 715
	public MasterAudioGroup.VariationSequence curVariationSequence;

	// Token: 0x040002CC RID: 716
	public bool useInactivePeriodPoolRefill;

	// Token: 0x040002CD RID: 717
	public float inactivePeriodSeconds = 5f;

	// Token: 0x040002CE RID: 718
	public MasterAudioGroup.VariationMode curVariationMode;

	// Token: 0x040002CF RID: 719
	public MasterAudio.AudioLocation bulkVariationMode;

	// Token: 0x040002D0 RID: 720
	public float chainLoopDelayMin;

	// Token: 0x040002D1 RID: 721
	public float chainLoopDelayMax;

	// Token: 0x040002D2 RID: 722
	public MasterAudioGroup.ChainedLoopLoopMode chainLoopMode;

	// Token: 0x040002D3 RID: 723
	public int chainLoopNumLoops;

	// Token: 0x040002D4 RID: 724
	public bool useDialogFadeOut;

	// Token: 0x040002D5 RID: 725
	public float dialogFadeOutTime = 0.5f;

	// Token: 0x040002D6 RID: 726
	public bool resourceClipsAllLoadAsync = true;

	// Token: 0x040002D7 RID: 727
	public bool logSound;

	// Token: 0x040002D8 RID: 728
	public int busIndex = -1;

	// Token: 0x040002D9 RID: 729
	public MasterAudio.ItemSpatialBlendType spatialBlendType = MasterAudio.ItemSpatialBlendType.ForceTo3D;

	// Token: 0x040002DA RID: 730
	public float spatialBlend = 1f;

	// Token: 0x040002DB RID: 731
	public string busName = string.Empty;

	// Token: 0x040002DC RID: 732
	public MasterAudioGroup.LimitMode limitMode;

	// Token: 0x040002DD RID: 733
	public int limitPerXFrames = 1;

	// Token: 0x040002DE RID: 734
	public float minimumTimeBetween = 0.1f;

	// Token: 0x040002DF RID: 735
	public bool limitPolyphony;

	// Token: 0x040002E0 RID: 736
	public int voiceLimitCount = 1;

	// Token: 0x040002E1 RID: 737
	public MasterAudioGroup.TargetDespawnedBehavior targetDespawnedBehavior;

	// Token: 0x040002E2 RID: 738
	public float despawnFadeTime = 1f;

	// Token: 0x040002E3 RID: 739
	public bool copySettingsExpanded;

	// Token: 0x040002E4 RID: 740
	public int selectedVariationIndex;

	// Token: 0x040002E5 RID: 741
	public MasterAudioGroup.ChildGroupMode childGroupMode;

	// Token: 0x040002E6 RID: 742
	public List<string> childSoundGroups = new List<string>();

	// Token: 0x040002E7 RID: 743
	public List<DynamicGroupVariation> groupVariations = new List<DynamicGroupVariation>();
}
