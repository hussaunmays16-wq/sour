﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200017F RID: 383
	[Tooltip("Sends an Event based on the Orientation of the mobile device.")]
	[ActionCategory(ActionCategory.Device)]
	public class DeviceOrientationEvent : FsmStateAction
	{
		// Token: 0x06000706 RID: 1798 RVA: 0x00031ABC File Offset: 0x0002FCBC
		public override void Reset()
		{
			this.orientation = DeviceOrientation.Portrait;
			this.sendEvent = null;
			this.everyFrame = false;
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00031AD4 File Offset: 0x0002FCD4
		public override void OnEnter()
		{
			this.DoDetectDeviceOrientation();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00031AF0 File Offset: 0x0002FCF0
		public override void OnUpdate()
		{
			this.DoDetectDeviceOrientation();
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00031AF8 File Offset: 0x0002FCF8
		private void DoDetectDeviceOrientation()
		{
			if (Input.deviceOrientation == this.orientation)
			{
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x040009F3 RID: 2547
		[Tooltip("Note: If device is physically situated between discrete positions, as when (for example) rotated diagonally, system will report Unknown orientation.")]
		public DeviceOrientation orientation;

		// Token: 0x040009F4 RID: 2548
		[Tooltip("The event to send if the device orientation matches Orientation.")]
		public FsmEvent sendEvent;

		// Token: 0x040009F5 RID: 2549
		[Tooltip("Repeat every frame. Useful if you want to wait for the orientation to be true.")]
		public bool everyFrame;
	}
}
