﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DD RID: 477
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Forward an event recieved by this FSM to another target.")]
	public class ForwardEvent : FsmStateAction
	{
		// Token: 0x06000860 RID: 2144 RVA: 0x00039154 File Offset: 0x00037354
		public override void Reset()
		{
			this.forwardTo = new FsmEventTarget
			{
				target = FsmEventTarget.EventTarget.FSMComponent
			};
			this.eventsToForward = null;
			this.eatEvents = true;
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x00039184 File Offset: 0x00037384
		public override bool Event(FsmEvent fsmEvent)
		{
			if (this.eventsToForward != null)
			{
				foreach (FsmEvent fsmEvent2 in this.eventsToForward)
				{
					if (fsmEvent2 == fsmEvent)
					{
						base.Fsm.Event(this.forwardTo, fsmEvent);
						return this.eatEvents;
					}
				}
			}
			return false;
		}

		// Token: 0x04000C06 RID: 3078
		[Tooltip("Forward to this target.")]
		public FsmEventTarget forwardTo;

		// Token: 0x04000C07 RID: 3079
		[Tooltip("The events to forward.")]
		public FsmEvent[] eventsToForward;

		// Token: 0x04000C08 RID: 3080
		[Tooltip("Should this action eat the events or pass them on.")]
		public bool eatEvents;
	}
}
