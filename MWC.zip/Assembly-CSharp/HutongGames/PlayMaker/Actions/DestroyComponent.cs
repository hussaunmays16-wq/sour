﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200017B RID: 379
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Destroys a Component of an Object.")]
	public class DestroyComponent : FsmStateAction
	{
		// Token: 0x060006F7 RID: 1783 RVA: 0x000318A0 File Offset: 0x0002FAA0
		public override void Reset()
		{
			this.aComponent = null;
			this.gameObject = null;
			this.component = null;
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x000318B8 File Offset: 0x0002FAB8
		public override void OnEnter()
		{
			this.DoDestroyComponent((this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner);
			base.Finish();
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x000318FC File Offset: 0x0002FAFC
		private void DoDestroyComponent(GameObject go)
		{
			this.aComponent = go.GetComponent(this.component.Value);
			if (this.aComponent == null)
			{
				this.LogError("No such component: " + this.component.Value);
			}
			else
			{
				UnityEngine.Object.Destroy(this.aComponent);
			}
		}

		// Token: 0x040009EB RID: 2539
		[Tooltip("The GameObject that owns the Component.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040009EC RID: 2540
		[RequiredField]
		[UIHint(UIHint.ScriptComponent)]
		[Tooltip("The name of the Component to destroy.")]
		public FsmString component;

		// Token: 0x040009ED RID: 2541
		private Component aComponent;
	}
}
