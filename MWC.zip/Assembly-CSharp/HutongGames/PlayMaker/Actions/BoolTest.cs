﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000152 RID: 338
	[Tooltip("Sends Events based on the value of a Boolean Variable.")]
	[ActionCategory(ActionCategory.Logic)]
	public class BoolTest : FsmStateAction
	{
		// Token: 0x06000641 RID: 1601 RVA: 0x0002F108 File Offset: 0x0002D308
		public override void Reset()
		{
			this.boolVariable = null;
			this.isTrue = null;
			this.isFalse = null;
			this.everyFrame = false;
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0002F128 File Offset: 0x0002D328
		public override void OnEnter()
		{
			base.Fsm.Event((!this.boolVariable.Value) ? this.isFalse : this.isTrue);
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x0002F174 File Offset: 0x0002D374
		public override void OnUpdate()
		{
			base.Fsm.Event((!this.boolVariable.Value) ? this.isFalse : this.isTrue);
		}

		// Token: 0x04000939 RID: 2361
		[Tooltip("The Bool variable to test.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmBool boolVariable;

		// Token: 0x0400093A RID: 2362
		[Tooltip("Event to send if the Bool variable is True.")]
		public FsmEvent isTrue;

		// Token: 0x0400093B RID: 2363
		[Tooltip("Event to send if the Bool variable is False.")]
		public FsmEvent isFalse;

		// Token: 0x0400093C RID: 2364
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
