﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000255 RID: 597
	[ActionCategory(ActionCategory.Physics)]
	[Tooltip("Gets the Speed of a Game Object and stores it in a Float Variable. NOTE: The Game Object must have a rigid body.")]
	public class GetSpeed : ComponentAction<Rigidbody>
	{
		// Token: 0x06000A2D RID: 2605 RVA: 0x0003F3C8 File Offset: 0x0003D5C8
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A2E RID: 2606 RVA: 0x0003F3E0 File Offset: 0x0003D5E0
		public override void OnEnter()
		{
			this.DoGetSpeed();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A2F RID: 2607 RVA: 0x0003F3FC File Offset: 0x0003D5FC
		public override void OnUpdate()
		{
			this.DoGetSpeed();
		}

		// Token: 0x06000A30 RID: 2608 RVA: 0x0003F404 File Offset: 0x0003D604
		private void DoGetSpeed()
		{
			if (this.storeResult == null)
			{
				return;
			}
			GameObject go = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			if (base.UpdateCache(go))
			{
				Vector3 velocity = base.rigidbody.velocity;
				this.storeResult.Value = velocity.magnitude;
			}
		}

		// Token: 0x04000E1B RID: 3611
		[CheckForComponent(typeof(Rigidbody))]
		[Tooltip("The GameObject with a Rigidbody.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E1C RID: 3612
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the speed in a float variable.")]
		public FsmFloat storeResult;

		// Token: 0x04000E1D RID: 3613
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
