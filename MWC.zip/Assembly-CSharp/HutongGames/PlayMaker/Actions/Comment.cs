﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015C RID: 348
	[Tooltip("Adds a text area to the action list. NOTE: Doesn't do anything, just for notes...")]
	[ActionCategory(ActionCategory.Debug)]
	public class Comment : FsmStateAction
	{
		// Token: 0x0600067A RID: 1658 RVA: 0x000302DC File Offset: 0x0002E4DC
		public override void Reset()
		{
			this.comment = string.Empty;
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x000302EC File Offset: 0x0002E4EC
		public override void OnEnter()
		{
			base.Finish();
		}

		// Token: 0x04000974 RID: 2420
		[UIHint(UIHint.Comment)]
		public string comment;
	}
}
