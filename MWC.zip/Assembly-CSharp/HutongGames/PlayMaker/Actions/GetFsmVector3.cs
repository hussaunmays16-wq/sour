﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000234 RID: 564
	[Tooltip("Get the value of a Vector3 Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmVector3 : FsmStateAction
	{
		// Token: 0x060009AA RID: 2474 RVA: 0x0003DF80 File Offset: 0x0003C180
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x0003DFA0 File Offset: 0x0003C1A0
		public override void OnEnter()
		{
			this.DoGetFsmVector3();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x0003DFBC File Offset: 0x0003C1BC
		public override void OnUpdate()
		{
			this.DoGetFsmVector3();
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x0003DFC4 File Offset: 0x0003C1C4
		private void DoGetFsmVector3()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmVector3 fsmVector = this.fsm.FsmVariables.GetFsmVector3(this.variableName.Value);
			if (fsmVector == null)
			{
				return;
			}
			this.storeValue.Value = fsmVector.Value;
		}

		// Token: 0x04000DA9 RID: 3497
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DAA RID: 3498
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000DAB RID: 3499
		[UIHint(UIHint.FsmVector3)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000DAC RID: 3500
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmVector3 storeValue;

		// Token: 0x04000DAD RID: 3501
		public bool everyFrame;

		// Token: 0x04000DAE RID: 3502
		private GameObject goLastFrame;

		// Token: 0x04000DAF RID: 3503
		private PlayMakerFSM fsm;
	}
}
