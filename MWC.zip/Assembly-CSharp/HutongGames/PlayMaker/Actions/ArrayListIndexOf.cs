﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A5 RID: 933
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Return the index of an item from a PlayMaker Array List Proxy component. Can search within a range")]
	public class ArrayListIndexOf : ArrayListActions
	{
		// Token: 0x06000FCD RID: 4045 RVA: 0x00056F10 File Offset: 0x00055110
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.startIndex = null;
			this.count = null;
			this.itemFound = null;
			this.itemNotFound = null;
			this.variable = null;
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x00056F44 File Offset: 0x00055144
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListIndexOf();
			}
			base.Finish();
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x00056F84 File Offset: 0x00055184
		public void DoArrayListIndexOf()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			object valueFromFsmVar = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable);
			int num = -1;
			try
			{
				if (this.startIndex.IsNone)
				{
					Debug.Log("hello");
					num = PlayMakerUtils_Extensions.IndexOf(this.proxy.arrayList, valueFromFsmVar);
				}
				else if (this.count.IsNone || this.count.Value == 0)
				{
					if (this.startIndex.Value < 0 || this.startIndex.Value >= this.proxy.arrayList.Count)
					{
						this.LogError("start index out of range");
						return;
					}
					num = PlayMakerUtils_Extensions.IndexOf(this.proxy.arrayList, valueFromFsmVar);
				}
				else
				{
					if (this.startIndex.Value < 0 || this.startIndex.Value >= this.proxy.arrayList.Count - this.count.Value)
					{
						this.LogError("start index and count out of range");
						return;
					}
					num = PlayMakerUtils_Extensions.IndexOf(this.proxy.arrayList, valueFromFsmVar);
				}
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Fsm.Event(this.failureEvent);
				return;
			}
			this.indexOf.Value = num;
			if (num == -1)
			{
				base.Fsm.Event(this.itemNotFound);
			}
			else
			{
				base.Fsm.Event(this.itemFound);
			}
		}

		// Token: 0x0400148F RID: 5263
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001490 RID: 5264
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x04001491 RID: 5265
		[Tooltip("Optional start index to search from: set to 0 to ignore")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt startIndex;

		// Token: 0x04001492 RID: 5266
		[UIHint(UIHint.FsmInt)]
		[Tooltip("Optional amount of elements to search within: set to 0 to ignore")]
		public FsmInt count;

		// Token: 0x04001493 RID: 5267
		[ActionSection("Data")]
		[Tooltip("The variable to get the index of.")]
		[RequiredField]
		public FsmVar variable;

		// Token: 0x04001494 RID: 5268
		[UIHint(UIHint.Variable)]
		[Tooltip("The index of the item described below")]
		[ActionSection("Result")]
		public FsmInt indexOf;

		// Token: 0x04001495 RID: 5269
		[Tooltip("Optional Event sent if this arrayList contains that element ( described below)")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent itemFound;

		// Token: 0x04001496 RID: 5270
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Optional Event sent if this arrayList does not contains that element ( described below)")]
		public FsmEvent itemNotFound;

		// Token: 0x04001497 RID: 5271
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Optional Event to trigger if the action fails ( likely an out of range exception when using wrong values for index and/or count)")]
		public FsmEvent failureEvent;
	}
}
