﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000257 RID: 599
	[Tooltip("Gets the Length of a String.")]
	[ActionCategory(ActionCategory.String)]
	public class GetStringLength : FsmStateAction
	{
		// Token: 0x06000A37 RID: 2615 RVA: 0x0003F518 File Offset: 0x0003D718
		public override void Reset()
		{
			this.stringVariable = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0003F530 File Offset: 0x0003D730
		public override void OnEnter()
		{
			this.DoGetStringLength();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x0003F54C File Offset: 0x0003D74C
		public override void OnUpdate()
		{
			this.DoGetStringLength();
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x0003F554 File Offset: 0x0003D754
		private void DoGetStringLength()
		{
			if (this.stringVariable == null)
			{
				return;
			}
			if (this.storeResult == null)
			{
				return;
			}
			this.storeResult.Value = this.stringVariable.Value.Length;
		}

		// Token: 0x04000E22 RID: 3618
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString stringVariable;

		// Token: 0x04000E23 RID: 3619
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt storeResult;

		// Token: 0x04000E24 RID: 3620
		public bool everyFrame;
	}
}
