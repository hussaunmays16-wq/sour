﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003AF RID: 943
	[Tooltip("Revert a PlayMaker ArrayList Proxy component to the prefill data, either defined at runtime or when the action ArrayListTakeSnapShot was used. ")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListRevertToSnapShot : ArrayListActions
	{
		// Token: 0x06000FF4 RID: 4084 RVA: 0x00057A8C File Offset: 0x00055C8C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06000FF5 RID: 4085 RVA: 0x00057A9C File Offset: 0x00055C9C
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListRevertToSnapShot();
			}
			base.Finish();
		}

		// Token: 0x06000FF6 RID: 4086 RVA: 0x00057ADC File Offset: 0x00055CDC
		public void DoArrayListRevertToSnapShot()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.RevertToSnapShot();
		}

		// Token: 0x040014C3 RID: 5315
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014C4 RID: 5316
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
