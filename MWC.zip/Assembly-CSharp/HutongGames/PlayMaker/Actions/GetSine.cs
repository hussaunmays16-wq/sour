﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000035 RID: 53
	[ActionCategory("Trigonometry")]
	[Tooltip("Get the sine. You can use degrees, simply check on the DegToRad conversion")]
	public class GetSine : FsmStateAction
	{
		// Token: 0x060000B5 RID: 181 RVA: 0x000067B4 File Offset: 0x000049B4
		public override void Reset()
		{
			this.angle = null;
			this.DegToRad = true;
			this.everyFrame = false;
			this.result = null;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x000067D8 File Offset: 0x000049D8
		public override void OnEnter()
		{
			this.DoSine();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x000067F4 File Offset: 0x000049F4
		public override void OnUpdate()
		{
			this.DoSine();
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x000067FC File Offset: 0x000049FC
		private void DoSine()
		{
			float num = this.angle.Value;
			if (this.DegToRad.Value)
			{
				num *= 0.017453292f;
			}
			this.result.Value = Mathf.Sin(num);
		}

		// Token: 0x0400010C RID: 268
		[RequiredField]
		[Tooltip("The angle. Note: You can use degrees, simply check DegtoRad if the angle is expressed in degrees.")]
		public FsmFloat angle;

		// Token: 0x0400010D RID: 269
		[Tooltip("Check on if the angle is expressed in degrees.")]
		public FsmBool DegToRad;

		// Token: 0x0400010E RID: 270
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The angle tan")]
		public FsmFloat result;

		// Token: 0x0400010F RID: 271
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
