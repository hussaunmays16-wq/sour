﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200012A RID: 298
	[Tooltip("Play an animation on a subset of the hierarchy. E.g., A waving animation on the upper body.")]
	[ActionCategory(ActionCategory.Animation)]
	public class AddMixingTransform : FsmStateAction
	{
		// Token: 0x06000583 RID: 1411 RVA: 0x0002919C File Offset: 0x0002739C
		public override void Reset()
		{
			this.gameObject = null;
			this.animationName = string.Empty;
			this.transform = string.Empty;
			this.recursive = true;
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x000291D4 File Offset: 0x000273D4
		public override void OnEnter()
		{
			this.DoAddMixingTransform();
			base.Finish();
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x000291E4 File Offset: 0x000273E4
		private void DoAddMixingTransform()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			Animation component = ownerDefaultTarget.GetComponent<Animation>();
			if (component == null)
			{
				return;
			}
			AnimationState animationState = component[this.animationName.Value];
			if (animationState == null)
			{
				return;
			}
			Transform mix = ownerDefaultTarget.transform.Find(this.transform.Value);
			animationState.AddMixingTransform(mix, this.recursive.Value);
		}

		// Token: 0x0400080D RID: 2061
		[CheckForComponent(typeof(Animation))]
		[Tooltip("The GameObject playing the animation.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400080E RID: 2062
		[RequiredField]
		[Tooltip("The name of the animation to mix. NOTE: The animation should already be added to the Animation Component on the GameObject.")]
		public FsmString animationName;

		// Token: 0x0400080F RID: 2063
		[Tooltip("The mixing transform. E.g., root/upper_body/left_shoulder")]
		[RequiredField]
		public FsmString transform;

		// Token: 0x04000810 RID: 2064
		[Tooltip("If recursive is true all children of the mix transform will also be animated.")]
		public FsmBool recursive;
	}
}
