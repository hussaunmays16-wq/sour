﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001CC RID: 460
	[Tooltip("Randomly flickers a Game Object on/off.")]
	[ActionCategory(ActionCategory.Effects)]
	public class Flicker : ComponentAction<Renderer>
	{
		// Token: 0x06000815 RID: 2069 RVA: 0x00038450 File Offset: 0x00036650
		public override void Reset()
		{
			this.gameObject = null;
			this.frequency = 0.1f;
			this.amountOn = 0.5f;
			this.rendererOnly = true;
			this.realTime = false;
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x00038488 File Offset: 0x00036688
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.timer = 0f;
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x000384A0 File Offset: 0x000366A0
		public override void OnUpdate()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (this.realTime)
			{
				this.timer = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.timer += Time.deltaTime;
			}
			if (this.timer > this.frequency.Value)
			{
				bool flag = UnityEngine.Random.Range(0f, 1f) < this.amountOn.Value;
				if (this.rendererOnly)
				{
					if (base.UpdateCache(ownerDefaultTarget))
					{
						base.renderer.enabled = flag;
					}
				}
				else
				{
					ownerDefaultTarget.SetActive(flag);
				}
				this.startTime = this.timer;
				this.timer = 0f;
			}
		}

		// Token: 0x04000BB8 RID: 3000
		[Tooltip("The GameObject to flicker.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000BB9 RID: 3001
		[HasFloatSlider(0f, 1f)]
		[Tooltip("The frequency of the flicker in seconds.")]
		public FsmFloat frequency;

		// Token: 0x04000BBA RID: 3002
		[Tooltip("Amount of time flicker is On (0-1). E.g. Use 0.95 for an occasional flicker.")]
		[HasFloatSlider(0f, 1f)]
		public FsmFloat amountOn;

		// Token: 0x04000BBB RID: 3003
		[Tooltip("Only effect the renderer, leaving other components active.")]
		public bool rendererOnly;

		// Token: 0x04000BBC RID: 3004
		[Tooltip("Ignore time scale. Useful if flickering UI when the game is paused.")]
		public bool realTime;

		// Token: 0x04000BBD RID: 3005
		private float startTime;

		// Token: 0x04000BBE RID: 3006
		private float timer;
	}
}
