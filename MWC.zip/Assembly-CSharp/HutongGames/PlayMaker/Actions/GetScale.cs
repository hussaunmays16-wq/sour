﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000252 RID: 594
	[ActionCategory(ActionCategory.Transform)]
	[Tooltip("Gets the Scale of a Game Object and stores it in a Vector3 Variable or each Axis in a Float Variable")]
	public class GetScale : FsmStateAction
	{
		// Token: 0x06000A22 RID: 2594 RVA: 0x0003F270 File Offset: 0x0003D470
		public override void Reset()
		{
			this.gameObject = null;
			this.vector = null;
			this.xScale = null;
			this.yScale = null;
			this.zScale = null;
			this.space = Space.World;
			this.everyFrame = false;
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0003F2A4 File Offset: 0x0003D4A4
		public override void OnEnter()
		{
			this.DoGetScale();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x0003F2C0 File Offset: 0x0003D4C0
		public override void OnUpdate()
		{
			this.DoGetScale();
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x0003F2C8 File Offset: 0x0003D4C8
		private void DoGetScale()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			Vector3 value = (this.space != Space.World) ? ownerDefaultTarget.transform.localScale : ownerDefaultTarget.transform.lossyScale;
			this.vector.Value = value;
			this.xScale.Value = value.x;
			this.yScale.Value = value.y;
			this.zScale.Value = value.z;
		}

		// Token: 0x04000E12 RID: 3602
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E13 RID: 3603
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector;

		// Token: 0x04000E14 RID: 3604
		[UIHint(UIHint.Variable)]
		public FsmFloat xScale;

		// Token: 0x04000E15 RID: 3605
		[UIHint(UIHint.Variable)]
		public FsmFloat yScale;

		// Token: 0x04000E16 RID: 3606
		[UIHint(UIHint.Variable)]
		public FsmFloat zScale;

		// Token: 0x04000E17 RID: 3607
		public Space space;

		// Token: 0x04000E18 RID: 3608
		public bool everyFrame;
	}
}
