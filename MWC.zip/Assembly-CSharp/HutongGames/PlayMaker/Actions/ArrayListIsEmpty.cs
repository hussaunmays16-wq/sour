﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A7 RID: 935
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Check if an ArrayList Proxy component is empty.")]
	public class ArrayListIsEmpty : ArrayListActions
	{
		// Token: 0x06000FD5 RID: 4053 RVA: 0x0005723C File Offset: 0x0005543C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.isEmpty = null;
			this.isNotEmptyEvent = null;
			this.isEmptyEvent = null;
		}

		// Token: 0x06000FD6 RID: 4054 RVA: 0x00057264 File Offset: 0x00055464
		public override void OnEnter()
		{
			PlayMakerArrayListProxy arrayListProxyPointer = base.GetArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value, true);
			bool flag = arrayListProxyPointer.arrayList.Count == 0;
			this.isEmpty.Value = flag;
			if (flag)
			{
				base.Fsm.Event(this.isEmptyEvent);
			}
			else
			{
				base.Fsm.Event(this.isNotEmptyEvent);
			}
			base.Finish();
		}

		// Token: 0x0400149D RID: 5277
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400149E RID: 5278
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x0400149F RID: 5279
		[Tooltip("Store in a bool wether it is empty or not")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmBool isEmpty;

		// Token: 0x040014A0 RID: 5280
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this arrayList is empty ")]
		public FsmEvent isEmptyEvent;

		// Token: 0x040014A1 RID: 5281
		[Tooltip("Event sent if this arrayList is not empty")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent isNotEmptyEvent;
	}
}
