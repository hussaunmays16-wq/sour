﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020D RID: 525
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if a GameObject is a Child of another GameObject.")]
	public class GameObjectIsChildOf : FsmStateAction
	{
		// Token: 0x060008FE RID: 2302 RVA: 0x0003B86C File Offset: 0x00039A6C
		public override void Reset()
		{
			this.gameObject = null;
			this.isChildOf = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x0003B894 File Offset: 0x00039A94
		public override void OnEnter()
		{
			this.DoIsChildOf(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x0003B8B4 File Offset: 0x00039AB4
		private void DoIsChildOf(GameObject go)
		{
			if (go == null || this.isChildOf == null)
			{
				return;
			}
			bool flag = go.transform.IsChildOf(this.isChildOf.Value.transform);
			this.storeResult.Value = flag;
			base.Fsm.Event((!flag) ? this.falseEvent : this.trueEvent);
		}

		// Token: 0x04000CC5 RID: 3269
		[Tooltip("GameObject to test.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CC6 RID: 3270
		[RequiredField]
		[Tooltip("Is it a child of this GameObject?")]
		public FsmGameObject isChildOf;

		// Token: 0x04000CC7 RID: 3271
		[Tooltip("Event to send if GameObject is a child.")]
		public FsmEvent trueEvent;

		// Token: 0x04000CC8 RID: 3272
		[Tooltip("Event to send if GameObject is NOT a child.")]
		public FsmEvent falseEvent;

		// Token: 0x04000CC9 RID: 3273
		[UIHint(UIHint.Variable)]
		[Tooltip("Store result in a bool variable")]
		[RequiredField]
		public FsmBool storeResult;
	}
}
