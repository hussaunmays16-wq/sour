﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020F RID: 527
	[Tooltip("Tests if a Game Object is visible.")]
	[ActionCategory(ActionCategory.Logic)]
	public class GameObjectIsVisible : ComponentAction<Renderer>
	{
		// Token: 0x06000907 RID: 2311 RVA: 0x0003B9D8 File Offset: 0x00039BD8
		public override void Reset()
		{
			this.gameObject = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x0003BA00 File Offset: 0x00039C00
		public override void OnEnter()
		{
			this.DoIsVisible();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000909 RID: 2313 RVA: 0x0003BA1C File Offset: 0x00039C1C
		public override void OnUpdate()
		{
			this.DoIsVisible();
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x0003BA24 File Offset: 0x00039C24
		private void DoIsVisible()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (base.UpdateCache(ownerDefaultTarget))
			{
				bool isVisible = base.renderer.isVisible;
				this.storeResult.Value = isVisible;
				base.Fsm.Event((!isVisible) ? this.falseEvent : this.trueEvent);
			}
		}

		// Token: 0x04000CCF RID: 3279
		[CheckForComponent(typeof(Renderer))]
		[Tooltip("The GameObject to test.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CD0 RID: 3280
		[Tooltip("Event to send if the GameObject is visible.")]
		public FsmEvent trueEvent;

		// Token: 0x04000CD1 RID: 3281
		[Tooltip("Event to send if the GameObject is NOT visible.")]
		public FsmEvent falseEvent;

		// Token: 0x04000CD2 RID: 3282
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a bool variable.")]
		public FsmBool storeResult;

		// Token: 0x04000CD3 RID: 3283
		public bool everyFrame;
	}
}
