﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000139 RID: 313
	[Tooltip("Animates the value of a Vector3 Variable FROM-TO with assistance of Deformation Curves.")]
	[ActionCategory(ActionCategory.AnimateVariables)]
	public class CurveVector3 : CurveFsmAction
	{
		// Token: 0x060005C1 RID: 1473 RVA: 0x0002C37C File Offset: 0x0002A57C
		public override void Reset()
		{
			base.Reset();
			this.vectorVariable = new FsmVector3
			{
				UseVariable = true
			};
			this.toValue = new FsmVector3
			{
				UseVariable = true
			};
			this.fromValue = new FsmVector3
			{
				UseVariable = true
			};
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x0002C3CC File Offset: 0x0002A5CC
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[3];
			this.fromFloats = new float[3];
			this.fromFloats[0] = ((!this.fromValue.IsNone) ? this.fromValue.Value.x : 0f);
			this.fromFloats[1] = ((!this.fromValue.IsNone) ? this.fromValue.Value.y : 0f);
			this.fromFloats[2] = ((!this.fromValue.IsNone) ? this.fromValue.Value.z : 0f);
			this.toFloats = new float[3];
			this.toFloats[0] = ((!this.toValue.IsNone) ? this.toValue.Value.x : 0f);
			this.toFloats[1] = ((!this.toValue.IsNone) ? this.toValue.Value.y : 0f);
			this.toFloats[2] = ((!this.toValue.IsNone) ? this.toValue.Value.z : 0f);
			this.curves = new AnimationCurve[3];
			this.curves[0] = this.curveX.curve;
			this.curves[1] = this.curveY.curve;
			this.curves[2] = this.curveZ.curve;
			this.calculations = new CurveFsmAction.Calculation[3];
			this.calculations[0] = this.calculationX;
			this.calculations[1] = this.calculationY;
			this.calculations[2] = this.calculationZ;
			base.Init();
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x0002C5CC File Offset: 0x0002A7CC
		public override void OnExit()
		{
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x0002C5D0 File Offset: 0x0002A7D0
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.vectorVariable.IsNone && this.isRunning)
			{
				this.vct = new Vector3(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2]);
				this.vectorVariable.Value = this.vct;
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.vectorVariable.IsNone)
				{
					this.vct = new Vector3(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2]);
					this.vectorVariable.Value = this.vct;
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x040008A8 RID: 2216
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmVector3 vectorVariable;

		// Token: 0x040008A9 RID: 2217
		[RequiredField]
		public FsmVector3 fromValue;

		// Token: 0x040008AA RID: 2218
		[RequiredField]
		public FsmVector3 toValue;

		// Token: 0x040008AB RID: 2219
		[RequiredField]
		public FsmAnimationCurve curveX;

		// Token: 0x040008AC RID: 2220
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.x and toValue.x.")]
		public CurveFsmAction.Calculation calculationX;

		// Token: 0x040008AD RID: 2221
		[RequiredField]
		public FsmAnimationCurve curveY;

		// Token: 0x040008AE RID: 2222
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.y and toValue.y.")]
		public CurveFsmAction.Calculation calculationY;

		// Token: 0x040008AF RID: 2223
		[RequiredField]
		public FsmAnimationCurve curveZ;

		// Token: 0x040008B0 RID: 2224
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.z and toValue.z.")]
		public CurveFsmAction.Calculation calculationZ;

		// Token: 0x040008B1 RID: 2225
		private Vector3 vct;

		// Token: 0x040008B2 RID: 2226
		private bool finishInNextStep;
	}
}
