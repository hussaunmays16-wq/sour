﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000211 RID: 529
	[Tooltip("Gets the Angle between a GameObject's forward axis and a Target. The Target can be defined as a GameObject or a world Position. If you specify both, then the Position will be used as a local offset from the Target Object's position.")]
	[ActionCategory(ActionCategory.Transform)]
	public class GetAngleToTarget : FsmStateAction
	{
		// Token: 0x06000911 RID: 2321 RVA: 0x0003BB64 File Offset: 0x00039D64
		public override void Reset()
		{
			this.gameObject = null;
			this.targetObject = null;
			this.targetPosition = new FsmVector3
			{
				UseVariable = true
			};
			this.ignoreHeight = true;
			this.storeAngle = null;
			this.everyFrame = false;
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x0003BBB0 File Offset: 0x00039DB0
		public override void OnLateUpdate()
		{
			this.DoGetAngleToTarget();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x0003BBCC File Offset: 0x00039DCC
		private void DoGetAngleToTarget()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			GameObject value = this.targetObject.Value;
			if (value == null && this.targetPosition.IsNone)
			{
				return;
			}
			Vector3 a;
			if (value != null)
			{
				a = (this.targetPosition.IsNone ? value.transform.position : value.transform.TransformPoint(this.targetPosition.Value));
			}
			else
			{
				a = this.targetPosition.Value;
			}
			if (this.ignoreHeight.Value)
			{
				a.y = ownerDefaultTarget.transform.position.y;
			}
			Vector3 from = a - ownerDefaultTarget.transform.position;
			this.storeAngle.Value = Vector3.Angle(from, ownerDefaultTarget.transform.forward);
		}

		// Token: 0x04000CD8 RID: 3288
		[Tooltip("The game object whose forward axis we measure from. If the target is dead ahead the angle will be 0.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CD9 RID: 3289
		[Tooltip("The target object to measure the angle to. Or use target position.")]
		public FsmGameObject targetObject;

		// Token: 0x04000CDA RID: 3290
		[Tooltip("The world position to measure an angle to. If Target Object is also specified, this vector is used as an offset from that object's position.")]
		public FsmVector3 targetPosition;

		// Token: 0x04000CDB RID: 3291
		[Tooltip("Ignore height differences when calculating the angle.")]
		public FsmBool ignoreHeight;

		// Token: 0x04000CDC RID: 3292
		[Tooltip("Store the angle in a float variable.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeAngle;

		// Token: 0x04000CDD RID: 3293
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
