﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000267 RID: 615
	[ActionCategory("Mesh")]
	[Tooltip("Gets the position of a vertex in a GameObject's mesh. Hint: Use GetVertexCount to get the number of vertices in a mesh.")]
	public class GetVertexPosition : FsmStateAction
	{
		// Token: 0x06000A7D RID: 2685 RVA: 0x000400D8 File Offset: 0x0003E2D8
		public override void Reset()
		{
			this.gameObject = null;
			this.space = Space.World;
			this.storePosition = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A7E RID: 2686 RVA: 0x000400F8 File Offset: 0x0003E2F8
		public override void OnEnter()
		{
			this.DoGetVertexPosition();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x00040114 File Offset: 0x0003E314
		public override void OnUpdate()
		{
			this.DoGetVertexPosition();
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0004011C File Offset: 0x0003E31C
		private void DoGetVertexPosition()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget != null)
			{
				MeshFilter component = ownerDefaultTarget.GetComponent<MeshFilter>();
				if (component == null)
				{
					this.LogError("Missing MeshFilter!");
					return;
				}
				Space space = this.space;
				if (space != Space.World)
				{
					if (space == Space.Self)
					{
						this.storePosition.Value = component.mesh.vertices[this.vertexIndex.Value];
					}
				}
				else
				{
					Vector3 position = component.mesh.vertices[this.vertexIndex.Value];
					this.storePosition.Value = ownerDefaultTarget.transform.TransformPoint(position);
				}
			}
		}

		// Token: 0x04000E67 RID: 3687
		[CheckForComponent(typeof(MeshFilter))]
		[Tooltip("The GameObject to check.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E68 RID: 3688
		[Tooltip("The index of the vertex.")]
		[RequiredField]
		public FsmInt vertexIndex;

		// Token: 0x04000E69 RID: 3689
		[Tooltip("Coordinate system to use.")]
		public Space space;

		// Token: 0x04000E6A RID: 3690
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store the vertex position in a variable.")]
		public FsmVector3 storePosition;

		// Token: 0x04000E6B RID: 3691
		[Tooltip("Repeat every frame. Useful if the mesh is animated.")]
		public bool everyFrame;
	}
}
