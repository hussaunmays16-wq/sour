﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D5 RID: 469
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Multiplies one Float by another.")]
	public class FloatMultiply : FsmStateAction
	{
		// Token: 0x0600083F RID: 2111 RVA: 0x00038BD8 File Offset: 0x00036DD8
		public override void Reset()
		{
			this.floatVariable = null;
			this.multiplyBy = null;
			this.everyFrame = false;
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00038BF0 File Offset: 0x00036DF0
		public override void OnEnter()
		{
			this.floatVariable.Value *= this.multiplyBy.Value;
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00038C2C File Offset: 0x00036E2C
		public override void OnUpdate()
		{
			this.floatVariable.Value *= this.multiplyBy.Value;
		}

		// Token: 0x04000BE3 RID: 3043
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The float variable to multiply.")]
		public FsmFloat floatVariable;

		// Token: 0x04000BE4 RID: 3044
		[Tooltip("Multiply the float variable by this value.")]
		[RequiredField]
		public FsmFloat multiplyBy;

		// Token: 0x04000BE5 RID: 3045
		[Tooltip("Repeat every frame. Useful if the variables are changing.")]
		public bool everyFrame;
	}
}
