﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200016D RID: 365
	[Tooltip("Creates a Game Object at a spawn point.\nUse a Game Object and/or Position/Rotation for the Spawn Point. If you specify a Game Object, Position is used as a local offset, and Rotation will override the object's rotation.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class CreateEmptyObject : FsmStateAction
	{
		// Token: 0x060006CA RID: 1738 RVA: 0x00030F88 File Offset: 0x0002F188
		public override void Reset()
		{
			this.gameObject = null;
			this.spawnPoint = null;
			this.position = new FsmVector3
			{
				UseVariable = true
			};
			this.rotation = new FsmVector3
			{
				UseVariable = true
			};
			this.storeObject = null;
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00030FD4 File Offset: 0x0002F1D4
		public override void OnEnter()
		{
			GameObject value = this.gameObject.Value;
			Vector3 a = Vector3.zero;
			Vector3 eulerAngles = Vector3.up;
			if (this.spawnPoint.Value != null)
			{
				a = this.spawnPoint.Value.transform.position;
				if (!this.position.IsNone)
				{
					a += this.position.Value;
				}
				if (!this.rotation.IsNone)
				{
					eulerAngles = this.rotation.Value;
				}
				else
				{
					eulerAngles = this.spawnPoint.Value.transform.eulerAngles;
				}
			}
			else
			{
				if (!this.position.IsNone)
				{
					a = this.position.Value;
				}
				if (!this.rotation.IsNone)
				{
					eulerAngles = this.rotation.Value;
				}
			}
			GameObject gameObject = this.storeObject.Value;
			if (value != null)
			{
				gameObject = UnityEngine.Object.Instantiate<GameObject>(value);
				this.storeObject.Value = gameObject;
			}
			else
			{
				gameObject = new GameObject("EmptyObjectFromNull");
				this.storeObject.Value = gameObject;
			}
			if (gameObject != null)
			{
				gameObject.transform.position = a;
				gameObject.transform.eulerAngles = eulerAngles;
			}
			base.Finish();
		}

		// Token: 0x040009C1 RID: 2497
		public FsmGameObject gameObject;

		// Token: 0x040009C2 RID: 2498
		public FsmGameObject spawnPoint;

		// Token: 0x040009C3 RID: 2499
		public FsmVector3 position;

		// Token: 0x040009C4 RID: 2500
		public FsmVector3 rotation;

		// Token: 0x040009C5 RID: 2501
		[Tooltip("Optionally store the created object.")]
		[UIHint(UIHint.Variable)]
		public FsmGameObject storeObject;
	}
}
