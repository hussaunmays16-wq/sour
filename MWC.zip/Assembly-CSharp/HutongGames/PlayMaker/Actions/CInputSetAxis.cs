﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B4 RID: 1204
	[ActionCategory("cInput")]
	[Tooltip("To setup a axis you have to define two keys with the SetKey action before, otherwise you will get an cInput error.")]
	public class CInputSetAxis : FsmStateAction
	{
		// Token: 0x06001475 RID: 5237 RVA: 0x00089120 File Offset: 0x00087320
		public override void Reset()
		{
			this.axisName = null;
			this.negativeInput = null;
			this.positiveInput = null;
			this.axisSensitivity = null;
			this.axisGravity = null;
			this.axisDeadzone = null;
		}

		// Token: 0x06001476 RID: 5238 RVA: 0x00089158 File Offset: 0x00087358
		public override void OnEnter()
		{
			cInput.SetAxis(this.axisName.Value, this.negativeInput.Value, this.positiveInput.Value, this.axisSensitivity.Value, this.axisGravity.Value, this.axisDeadzone.Value);
			base.Finish();
		}

		// Token: 0x04001CE2 RID: 7394
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CE3 RID: 7395
		[Tooltip("The name of the positive axis value.")]
		public FsmString negativeInput;

		// Token: 0x04001CE4 RID: 7396
		[Tooltip("The name of the negative axis value.")]
		public FsmString positiveInput;

		// Token: 0x04001CE5 RID: 7397
		[Tooltip("The name of the axis sensitivity.")]
		public FsmFloat axisSensitivity;

		// Token: 0x04001CE6 RID: 7398
		[Tooltip("The name of the axis gravity.")]
		public FsmFloat axisGravity;

		// Token: 0x04001CE7 RID: 7399
		[Tooltip("The name of the axis deadzone.")]
		public FsmFloat axisDeadzone;
	}
}
