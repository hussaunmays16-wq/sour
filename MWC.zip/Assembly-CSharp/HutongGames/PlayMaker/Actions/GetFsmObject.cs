﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022B RID: 555
	[Tooltip("Get the value of an Object Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmObject : FsmStateAction
	{
		// Token: 0x0600097B RID: 2427 RVA: 0x0003D4D0 File Offset: 0x0003B6D0
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.variableName = string.Empty;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x0003D508 File Offset: 0x0003B708
		public override void OnEnter()
		{
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x0003D524 File Offset: 0x0003B724
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x0003D52C File Offset: 0x0003B72C
		private void DoGetFsmVariable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null || this.storeValue == null)
			{
				return;
			}
			FsmObject fsmObject = this.fsm.FsmVariables.GetFsmObject(this.variableName.Value);
			if (fsmObject != null)
			{
				this.storeValue.Value = fsmObject.Value;
			}
		}

		// Token: 0x04000D69 RID: 3433
		[Tooltip("The GameObject that owns the FSM.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D6A RID: 3434
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D6B RID: 3435
		[UIHint(UIHint.FsmObject)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D6C RID: 3436
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmObject storeValue;

		// Token: 0x04000D6D RID: 3437
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D6E RID: 3438
		private GameObject goLastFrame;

		// Token: 0x04000D6F RID: 3439
		protected PlayMakerFSM fsm;
	}
}
