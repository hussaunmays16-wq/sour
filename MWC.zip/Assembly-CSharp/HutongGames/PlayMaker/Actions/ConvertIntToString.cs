﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200016A RID: 362
	[ActionCategory(ActionCategory.Convert)]
	[Tooltip("Converts an Integer value to a String value with an optional format.")]
	public class ConvertIntToString : FsmStateAction
	{
		// Token: 0x060006BB RID: 1723 RVA: 0x00030DFC File Offset: 0x0002EFFC
		public override void Reset()
		{
			this.intVariable = null;
			this.stringVariable = null;
			this.everyFrame = false;
			this.format = null;
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00030E1C File Offset: 0x0002F01C
		public override void OnEnter()
		{
			this.DoConvertIntToString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00030E38 File Offset: 0x0002F038
		public override void OnUpdate()
		{
			this.DoConvertIntToString();
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00030E40 File Offset: 0x0002F040
		private void DoConvertIntToString()
		{
			if (this.format.IsNone || string.IsNullOrEmpty(this.format.Value))
			{
				this.stringVariable.Value = this.intVariable.Value.ToString();
			}
			else
			{
				this.stringVariable.Value = this.intVariable.Value.ToString(this.format.Value);
			}
		}

		// Token: 0x040009B7 RID: 2487
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The Int variable to convert.")]
		public FsmInt intVariable;

		// Token: 0x040009B8 RID: 2488
		[UIHint(UIHint.Variable)]
		[Tooltip("A String variable to store the converted value.")]
		[RequiredField]
		public FsmString stringVariable;

		// Token: 0x040009B9 RID: 2489
		[Tooltip("Optional Format, allows for leading zeroes. E.g., 0000")]
		public FsmString format;

		// Token: 0x040009BA RID: 2490
		[Tooltip("Repeat every frame. Useful if the Int variable is changing.")]
		public bool everyFrame;
	}
}
