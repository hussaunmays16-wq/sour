﻿using System;
using UnityEngine;

// Token: 0x020000D5 RID: 213
public class ArcadeCarNoPhysics : MonoBehaviour
{
	// Token: 0x0600040B RID: 1035 RVA: 0x0001AF7C File Offset: 0x0001917C
	private void Start()
	{
		if (this.rataKansio != null)
		{
			this.kaikkiTienPalat = this.rataKansio.GetComponentsInChildren<Transform>();
		}
		else
		{
			Debug.LogError("VIRHE: Aseta Rata Kansio!");
		}
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x0001AFB0 File Offset: 0x000191B0
	private void Update()
	{
		if (this.onAI)
		{
			this.kaasuSyote = this.ulkoinenKaasu;
			this.ohjausSyote = this.ulkoinenKaanto;
			this.kasijarruPaalla = false;
		}
		else if (!this.playMakerOhjaa)
		{
			this.kaasuSyote = Input.GetAxis("Vertical");
			this.ohjausSyote = Input.GetAxis("Horizontal");
			this.kasijarruPaalla = Input.GetKey(KeyCode.Space);
		}
		if (this.tormaysValahdysAika > 0f)
		{
			this.tormaysValahdysAika -= Time.deltaTime;
		}
		this.onRadalla = false;
		if (this.kaikkiTienPalat != null)
		{
			Vector3 position = base.transform.position;
			foreach (Transform transform in this.kaikkiTienPalat)
			{
				if (!(transform == this.rataKansio))
				{
					float num = position.x - transform.position.x;
					float num2 = position.z - transform.position.z;
					float num3 = Mathf.Sqrt(num * num + num2 * num2);
					if (num3 < this.tienLeveys)
					{
						this.onRadalla = true;
					}
				}
			}
		}
		float num4 = this.normaaliKitka;
		float num5 = this.normaaliPito;
		if (!this.onRadalla)
		{
			num4 = this.offRoadKitka;
			num5 = this.offRoadPito;
		}
		if (this.kasijarruPaalla)
		{
			num5 = this.kasijarruLuisto;
			num4 = this.kasijarruVoima;
		}
		if (Mathf.Abs(this.ohjausSyote) > 0.1f)
		{
			float num6 = (!this.kasijarruPaalla) ? 1f : 1.2f;
			float yAngle = this.ohjausSyote * this.kaantymisNopeus * num6 * Time.deltaTime;
			base.transform.Rotate(0f, yAngle, 0f, Space.World);
		}
		if (this.kaasuSyote != 0f && !this.kasijarruPaalla)
		{
			this.liikeVektori += base.transform.up * this.kaasuSyote * this.kiihtyvyys * Time.deltaTime;
		}
		this.liikeVektori = Vector3.Lerp(this.liikeVektori, Vector3.zero, num4 * Time.deltaTime);
		if (this.liikeVektori.magnitude > 0.1f)
		{
			float magnitude = this.liikeVektori.magnitude;
			if (magnitude > this.huippuNopeus)
			{
				magnitude = this.huippuNopeus;
				this.liikeVektori = this.liikeVektori.normalized * this.huippuNopeus;
			}
			Vector3 a;
			if (this.kaasuSyote != 0f && !this.kasijarruPaalla)
			{
				a = Vector3.Lerp(this.liikeVektori.normalized, base.transform.up * Mathf.Sign(this.kaasuSyote), num5 * Time.deltaTime);
			}
			else
			{
				a = Vector3.Lerp(this.liikeVektori.normalized, base.transform.up, num5 * Time.deltaTime);
			}
			this.liikeVektori = a * magnitude;
		}
		this.debugNopeus = this.liikeVektori.magnitude;
		Vector3 position2 = base.transform.position;
		position2.y = this.maanPintaTaso;
		base.transform.position = position2;
		base.transform.position += this.liikeVektori * Time.deltaTime;
		base.transform.position += this.tormaysTyonto * Time.deltaTime;
		this.tormaysTyonto = Vector3.Lerp(this.tormaysTyonto, Vector3.zero, Time.deltaTime * 5f);
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x0001B390 File Offset: 0x00019590
	private void OnDrawGizmosSelected()
	{
		if (this.kaikkiTienPalat != null)
		{
			Gizmos.color = Color.cyan;
			foreach (Transform transform in this.kaikkiTienPalat)
			{
				if (!(transform == this.rataKansio))
				{
					Gizmos.DrawWireSphere(transform.position, this.tienLeveys);
				}
			}
		}
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x0001B3F8 File Offset: 0x000195F8
	private void OnGUI()
	{
		if (this.tormaysValahdysAika > 0f)
		{
			GUI.color = Color.red;
			GUI.Box(new Rect(10f, 10f, 300f, 200f), string.Empty);
			GUIStyle guistyle = new GUIStyle(GUI.skin.label);
			guistyle.fontSize = 30;
			guistyle.fontStyle = FontStyle.Bold;
			GUI.Label(new Rect(30f, 50f, 300f, 50f), this.debugTeksti, guistyle);
		}
		else
		{
			GUI.color = new Color(0f, 0f, 0f, 0.5f);
			GUI.Box(new Rect(10f, 10f, 300f, 200f), "DEBUGGER");
		}
		GUIStyle guistyle2 = new GUIStyle(GUI.skin.label);
		guistyle2.fontSize = 20;
		guistyle2.normal.textColor = Color.white;
		GUI.color = Color.white;
		GUI.Label(new Rect(30f, 150f, 250f, 30f), "Nopeus: " + (this.liikeVektori.magnitude * 10f).ToString("F0"), guistyle2);
		if (this.onRadalla)
		{
			GUI.color = Color.green;
		}
		else
		{
			GUI.color = Color.red;
		}
		GUI.Label(new Rect(30f, 180f, 250f, 30f), (!this.onRadalla) ? "NURMIKOLLA" : "RADALLA", guistyle2);
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0001B5A4 File Offset: 0x000197A4
	public void NollaaVauhti()
	{
		this.liikeVektori = Vector3.zero;
		this.kaasuSyote = 0f;
		this.ohjausSyote = 0f;
	}

	// Token: 0x040005CD RID: 1485
	public bool playMakerOhjaa = true;

	// Token: 0x040005CE RID: 1486
	[Header("Ajotuntuma")]
	public float huippuNopeus = 8f;

	// Token: 0x040005CF RID: 1487
	public float kiihtyvyys = 12f;

	// Token: 0x040005D0 RID: 1488
	public float kaantymisNopeus = 230f;

	// Token: 0x040005D1 RID: 1489
	public float normaaliKitka = 2f;

	// Token: 0x040005D2 RID: 1490
	public float normaaliPito = 4f;

	// Token: 0x040005D3 RID: 1491
	[Header("Nurmikko (GPS-tunnistus)")]
	public Transform rataKansio;

	// Token: 0x040005D4 RID: 1492
	public float tienLeveys = 1.05f;

	// Token: 0x040005D5 RID: 1493
	public float offRoadKitka = 10f;

	// Token: 0x040005D6 RID: 1494
	public float offRoadPito = 2f;

	// Token: 0x040005D7 RID: 1495
	public bool onRadalla;

	// Token: 0x040005D8 RID: 1496
	[Header("Käsijarru")]
	public float kasijarruVoima = 1f;

	// Token: 0x040005D9 RID: 1497
	public float kasijarruLuisto = 0.9f;

	// Token: 0x040005DA RID: 1498
	[Header("Muut")]
	public float maanPintaTaso = 0.3f;

	// Token: 0x040005DB RID: 1499
	[Header("PlayMaker Kontrollit")]
	public float kaasuSyote;

	// Token: 0x040005DC RID: 1500
	public float ohjausSyote;

	// Token: 0x040005DD RID: 1501
	public bool kasijarruPaalla;

	// Token: 0x040005DE RID: 1502
	[Header("Vauhti Debug")]
	public float debugNopeus;

	// Token: 0x040005DF RID: 1503
	public Vector3 liikeVektori;

	// Token: 0x040005E0 RID: 1504
	private Transform[] kaikkiTienPalat;

	// Token: 0x040005E1 RID: 1505
	private float tormaysValahdysAika;

	// Token: 0x040005E2 RID: 1506
	private string debugTeksti = string.Empty;

	// Token: 0x040005E3 RID: 1507
	[Header("AI Kontrolli")]
	public bool onAI;

	// Token: 0x040005E4 RID: 1508
	[HideInInspector]
	public float ulkoinenKaasu;

	// Token: 0x040005E5 RID: 1509
	[HideInInspector]
	public float ulkoinenKaanto;

	// Token: 0x040005E6 RID: 1510
	[HideInInspector]
	public Vector3 tormaysTyonto = Vector3.zero;
}
