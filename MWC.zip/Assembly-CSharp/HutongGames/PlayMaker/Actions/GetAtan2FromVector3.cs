﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000032 RID: 50
	[ActionCategory("Trigonometry")]
	[Tooltip("Get the Arc Tangent 2 as in atan2(y,x) from a vector 3, where you pick which is x and y from the vector 3. You can get the result in degrees, simply check on the RadToDeg conversion")]
	public class GetAtan2FromVector3 : FsmStateAction
	{
		// Token: 0x060000AB RID: 171 RVA: 0x000065D0 File Offset: 0x000047D0
		public override void Reset()
		{
			this.vector3 = null;
			this.xAxis = GetAtan2FromVector3.aTan2EnumAxis.x;
			this.yAxis = GetAtan2FromVector3.aTan2EnumAxis.y;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.angle = null;
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00006604 File Offset: 0x00004804
		public override void OnEnter()
		{
			this.DoATan();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00006620 File Offset: 0x00004820
		public override void OnUpdate()
		{
			this.DoATan();
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00006628 File Offset: 0x00004828
		private void DoATan()
		{
			float x = this.vector3.Value.x;
			if (this.xAxis == GetAtan2FromVector3.aTan2EnumAxis.y)
			{
				x = this.vector3.Value.y;
			}
			else if (this.xAxis == GetAtan2FromVector3.aTan2EnumAxis.z)
			{
				x = this.vector3.Value.z;
			}
			float y = this.vector3.Value.y;
			if (this.yAxis == GetAtan2FromVector3.aTan2EnumAxis.x)
			{
				y = this.vector3.Value.x;
			}
			else if (this.yAxis == GetAtan2FromVector3.aTan2EnumAxis.z)
			{
				y = this.vector3.Value.z;
			}
			float num = Mathf.Atan2(y, x);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000FE RID: 254
		[RequiredField]
		[Tooltip("The vector3 definition of the tan")]
		public FsmVector3 vector3;

		// Token: 0x040000FF RID: 255
		[Tooltip("which axis in the vector3 to use as the x value of the tan")]
		[RequiredField]
		public GetAtan2FromVector3.aTan2EnumAxis xAxis;

		// Token: 0x04000100 RID: 256
		[Tooltip("which axis in the vector3 to use as the y value of the tan")]
		[RequiredField]
		public GetAtan2FromVector3.aTan2EnumAxis yAxis;

		// Token: 0x04000101 RID: 257
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat angle;

		// Token: 0x04000102 RID: 258
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x04000103 RID: 259
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x02000033 RID: 51
		public enum aTan2EnumAxis
		{
			// Token: 0x04000105 RID: 261
			x,
			// Token: 0x04000106 RID: 262
			y,
			// Token: 0x04000107 RID: 263
			z
		}
	}
}
