﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DF RID: 479
	[Tooltip("Sends Events based on the current State of an FSM.")]
	[ActionCategory(ActionCategory.Logic)]
	public class FsmStateSwitch : FsmStateAction
	{
		// Token: 0x06000866 RID: 2150 RVA: 0x00039234 File Offset: 0x00037434
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = null;
			this.compareTo = new FsmString[1];
			this.sendEvent = new FsmEvent[1];
			this.everyFrame = false;
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x00039264 File Offset: 0x00037464
		public override void OnEnter()
		{
			this.DoFsmStateSwitch();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00039280 File Offset: 0x00037480
		public override void OnUpdate()
		{
			this.DoFsmStateSwitch();
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00039288 File Offset: 0x00037488
		private void DoFsmStateSwitch()
		{
			GameObject value = this.gameObject.Value;
			if (value == null)
			{
				return;
			}
			if (value != this.previousGo)
			{
				this.fsm = ActionHelpers.GetGameObjectFsm(value, this.fsmName.Value);
				this.previousGo = value;
			}
			if (this.fsm == null)
			{
				return;
			}
			string activeStateName = this.fsm.ActiveStateName;
			for (int i = 0; i < this.compareTo.Length; i++)
			{
				if (activeStateName == this.compareTo[i].Value)
				{
					base.Fsm.Event(this.sendEvent[i]);
					return;
				}
			}
		}

		// Token: 0x04000C0E RID: 3086
		[Tooltip("The GameObject that owns the FSM.")]
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000C0F RID: 3087
		[Tooltip("Optional name of Fsm on GameObject. Useful if there is more than one FSM on the GameObject.")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000C10 RID: 3088
		[CompoundArray("State Switches", "Compare State", "Send Event")]
		public FsmString[] compareTo;

		// Token: 0x04000C11 RID: 3089
		public FsmEvent[] sendEvent;

		// Token: 0x04000C12 RID: 3090
		[Tooltip("Repeat every frame. Useful if you're waiting for a particular result.")]
		public bool everyFrame;

		// Token: 0x04000C13 RID: 3091
		private GameObject previousGo;

		// Token: 0x04000C14 RID: 3092
		private PlayMakerFSM fsm;
	}
}
