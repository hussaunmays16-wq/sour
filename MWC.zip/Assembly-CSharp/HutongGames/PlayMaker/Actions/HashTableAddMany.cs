﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BB RID: 955
	[Tooltip("Add key/value pairs to a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy).")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableAddMany : HashTableActions
	{
		// Token: 0x06001026 RID: 4134 RVA: 0x00058564 File Offset: 0x00056764
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.keys = null;
			this.variables = null;
			this.successEvent = null;
			this.keyExistsAlreadyEvent = null;
		}

		// Token: 0x06001027 RID: 4135 RVA: 0x0005859C File Offset: 0x0005679C
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				if (this.keyExistsAlreadyEvent != null)
				{
					foreach (FsmString fsmString in this.keys)
					{
						if (this.proxy.hashTable.ContainsKey(fsmString.Value))
						{
							base.Fsm.Event(this.keyExistsAlreadyEvent);
							base.Finish();
						}
					}
				}
				this.AddToHashTable();
				base.Fsm.Event(this.successEvent);
			}
			base.Finish();
		}

		// Token: 0x06001028 RID: 4136 RVA: 0x0005864C File Offset: 0x0005684C
		public void AddToHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			for (int i = 0; i < this.keys.Length; i++)
			{
				this.proxy.hashTable.Add(this.keys[i].Value, PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variables[i]));
			}
		}

		// Token: 0x040014F3 RID: 5363
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014F4 RID: 5364
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014F5 RID: 5365
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		[CompoundArray("Count", "Key", "Value")]
		[ActionSection("Data")]
		[Tooltip("The Key")]
		public FsmString[] keys;

		// Token: 0x040014F6 RID: 5366
		[RequiredField]
		[Tooltip("The value for that key")]
		public FsmVar[] variables;

		// Token: 0x040014F7 RID: 5367
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Result")]
		[Tooltip("The event to trigger when elements are added")]
		public FsmEvent successEvent;

		// Token: 0x040014F8 RID: 5368
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when elements exists already")]
		public FsmEvent keyExistsAlreadyEvent;
	}
}
