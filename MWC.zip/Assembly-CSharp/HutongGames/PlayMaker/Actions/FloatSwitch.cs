﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DA RID: 474
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Sends an Event based on the value of a Float Variable. The float could represent distance, angle to a target, health left... The array sets up float ranges that correspond to Events.")]
	public class FloatSwitch : FsmStateAction
	{
		// Token: 0x06000853 RID: 2131 RVA: 0x00038EE4 File Offset: 0x000370E4
		public override void Reset()
		{
			this.floatVariable = null;
			this.lessThan = new FsmFloat[1];
			this.sendEvent = new FsmEvent[1];
			this.everyFrame = false;
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x00038F18 File Offset: 0x00037118
		public override void OnEnter()
		{
			this.DoFloatSwitch();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x00038F34 File Offset: 0x00037134
		public override void OnUpdate()
		{
			this.DoFloatSwitch();
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x00038F3C File Offset: 0x0003713C
		private void DoFloatSwitch()
		{
			if (this.floatVariable.IsNone)
			{
				return;
			}
			for (int i = 0; i < this.lessThan.Length; i++)
			{
				if (this.floatVariable.Value < this.lessThan[i].Value)
				{
					base.Fsm.Event(this.sendEvent[i]);
					return;
				}
			}
		}

		// Token: 0x04000BFA RID: 3066
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The float variable to test.")]
		public FsmFloat floatVariable;

		// Token: 0x04000BFB RID: 3067
		[CompoundArray("Float Switches", "Less Than", "Send Event")]
		public FsmFloat[] lessThan;

		// Token: 0x04000BFC RID: 3068
		public FsmEvent[] sendEvent;

		// Token: 0x04000BFD RID: 3069
		[Tooltip("Repeat every frame. Useful if the variable is changing.")]
		public bool everyFrame;
	}
}
