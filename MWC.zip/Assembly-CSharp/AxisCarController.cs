﻿using System;

// Token: 0x0200046D RID: 1133
public class AxisCarController : CarController
{
	// Token: 0x06001314 RID: 4884 RVA: 0x0006C070 File Offset: 0x0006A270
	protected override void GetInput(out float throttleInput, out float brakeInput, out float steerInput, out float handbrakeInput, out float clutchInput, out bool startEngineInput, out int targetGear)
	{
		throttleInput = cInput.GetAxisRaw(this.throttleAxis);
		brakeInput = cInput.GetAxisRaw(this.brakeAxis);
		steerInput = cInput.GetAxisRaw(this.steerAxis);
		handbrakeInput = cInput.GetAxisRaw(this.handbrakeAxis);
		clutchInput = cInput.GetAxisRaw(this.clutchAxis);
		if (this.normalizeThrottleInput)
		{
			throttleInput = (throttleInput + 1f) / 2f;
		}
		if (this.exponentialThrottleInput)
		{
			throttleInput *= throttleInput;
		}
		if (this.normalizeBrakesInput)
		{
			brakeInput = (brakeInput + 1f) / 2f;
		}
		if (this.exponentialBrakesInput)
		{
			brakeInput *= brakeInput;
		}
		if (this.normalizeClutchInput)
		{
			clutchInput = (clutchInput + 1f) / 2f;
		}
		if (this.exponentialClutchInput)
		{
			clutchInput *= clutchInput;
		}
		startEngineInput = cInput.GetKeyDown(this.startEngineButton);
		targetGear = this.drivetrain.gear;
		if (cInput.GetKeyDown(this.shiftUpButton))
		{
			targetGear++;
		}
		if (cInput.GetKeyDown(this.shiftDownButton))
		{
			targetGear--;
		}
		if (this.drivetrain.shifter)
		{
			if (cInput.GetButton("reverse"))
			{
				targetGear = 0;
			}
			else if (cInput.GetButton("neutral"))
			{
				targetGear = 1;
			}
			else if (cInput.GetButton("first"))
			{
				targetGear = 2;
			}
			else if (cInput.GetButton("second"))
			{
				targetGear = 3;
			}
			else if (cInput.GetButton("third"))
			{
				targetGear = 4;
			}
			else if (cInput.GetButton("fourth"))
			{
				targetGear = 5;
			}
			else if (cInput.GetButton("fifth"))
			{
				targetGear = 6;
			}
			else if (cInput.GetButton("sixth"))
			{
				targetGear = 7;
			}
			else
			{
				targetGear = 1;
			}
		}
	}

	// Token: 0x040018D5 RID: 6357
	public string throttleAxis = "Throttle";

	// Token: 0x040018D6 RID: 6358
	public string brakeAxis = "Brake";

	// Token: 0x040018D7 RID: 6359
	public string steerAxis = "Horizontal";

	// Token: 0x040018D8 RID: 6360
	public string handbrakeAxis = "Handbrake";

	// Token: 0x040018D9 RID: 6361
	public string clutchAxis = "Clutch";

	// Token: 0x040018DA RID: 6362
	public string shiftUpButton = "ShiftUp";

	// Token: 0x040018DB RID: 6363
	public string shiftDownButton = "ShiftDown";

	// Token: 0x040018DC RID: 6364
	public string startEngineButton = "StartEngine";

	// Token: 0x040018DD RID: 6365
	public bool normalizeThrottleInput;

	// Token: 0x040018DE RID: 6366
	public bool exponentialThrottleInput;

	// Token: 0x040018DF RID: 6367
	public bool normalizeBrakesInput;

	// Token: 0x040018E0 RID: 6368
	public bool exponentialBrakesInput;

	// Token: 0x040018E1 RID: 6369
	public bool normalizeClutchInput;

	// Token: 0x040018E2 RID: 6370
	public bool exponentialClutchInput;
}
