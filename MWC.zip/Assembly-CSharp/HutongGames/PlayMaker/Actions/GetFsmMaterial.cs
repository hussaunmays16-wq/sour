﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022A RID: 554
	[Tooltip("Get the value of a Material Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmMaterial : FsmStateAction
	{
		// Token: 0x06000976 RID: 2422 RVA: 0x0003D3C0 File Offset: 0x0003B5C0
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.variableName = string.Empty;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x0003D3F8 File Offset: 0x0003B5F8
		public override void OnEnter()
		{
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x0003D414 File Offset: 0x0003B614
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x0003D41C File Offset: 0x0003B61C
		private void DoGetFsmVariable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null || this.storeValue == null)
			{
				return;
			}
			FsmMaterial fsmMaterial = this.fsm.FsmVariables.GetFsmMaterial(this.variableName.Value);
			if (fsmMaterial != null)
			{
				this.storeValue.Value = fsmMaterial.Value;
			}
		}

		// Token: 0x04000D62 RID: 3426
		[RequiredField]
		[Tooltip("The GameObject that owns the FSM.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D63 RID: 3427
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D64 RID: 3428
		[RequiredField]
		[UIHint(UIHint.FsmMaterial)]
		public FsmString variableName;

		// Token: 0x04000D65 RID: 3429
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmMaterial storeValue;

		// Token: 0x04000D66 RID: 3430
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D67 RID: 3431
		private GameObject goLastFrame;

		// Token: 0x04000D68 RID: 3432
		protected PlayMakerFSM fsm;
	}
}
