﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020C RID: 524
	[Tooltip("Tests if a GameObject has children.")]
	[ActionCategory(ActionCategory.Logic)]
	public class GameObjectHasChildren : FsmStateAction
	{
		// Token: 0x060008F9 RID: 2297 RVA: 0x0003B7AC File Offset: 0x000399AC
		public override void Reset()
		{
			this.gameObject = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0003B7D4 File Offset: 0x000399D4
		public override void OnEnter()
		{
			this.DoHasChildren();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x0003B7F0 File Offset: 0x000399F0
		public override void OnUpdate()
		{
			this.DoHasChildren();
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x0003B7F8 File Offset: 0x000399F8
		private void DoHasChildren()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			bool flag = ownerDefaultTarget.transform.childCount > 0;
			this.storeResult.Value = flag;
			base.Fsm.Event((!flag) ? this.falseEvent : this.trueEvent);
		}

		// Token: 0x04000CC0 RID: 3264
		[RequiredField]
		[Tooltip("The GameObject to test.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CC1 RID: 3265
		[Tooltip("Event to send if the GameObject has children.")]
		public FsmEvent trueEvent;

		// Token: 0x04000CC2 RID: 3266
		[Tooltip("Event to send if the GameObject does not have children.")]
		public FsmEvent falseEvent;

		// Token: 0x04000CC3 RID: 3267
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a bool variable.")]
		public FsmBool storeResult;

		// Token: 0x04000CC4 RID: 3268
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
