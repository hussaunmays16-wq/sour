﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200002B RID: 43
	[ActionCategory(ActionCategory.String)]
	[Tooltip("Coverts a string to upper or lower case.")]
	public class ConvertCase : FsmStateAction
	{
		// Token: 0x0600008D RID: 141 RVA: 0x000061EC File Offset: 0x000043EC
		public override void Reset()
		{
			this.stringVariable = null;
			this.stringValue = null;
			this.everyFrame = false;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00006204 File Offset: 0x00004404
		public override void OnEnter()
		{
			this.DoSetStringValue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00006220 File Offset: 0x00004420
		public override void OnUpdate()
		{
			this.DoSetStringValue();
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00006228 File Offset: 0x00004428
		private void DoSetStringValue()
		{
			if (this.stringVariable == null)
			{
				return;
			}
			if (this.stringValue == null)
			{
				return;
			}
			ConvertCase.Case @case = this.operation;
			if (@case != ConvertCase.Case.Lower)
			{
				if (@case == ConvertCase.Case.Upper)
				{
					this.stringValue.Value = this.stringVariable.Value.ToUpper();
				}
			}
			else
			{
				this.stringValue.Value = this.stringVariable.Value.ToLower();
			}
		}

		// Token: 0x040000E2 RID: 226
		[RequiredField]
		public FsmString stringVariable;

		// Token: 0x040000E3 RID: 227
		[Tooltip("Select upper or lower case.")]
		public ConvertCase.Case operation;

		// Token: 0x040000E4 RID: 228
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString stringValue;

		// Token: 0x040000E5 RID: 229
		public bool everyFrame;

		// Token: 0x0200002C RID: 44
		public enum Case
		{
			// Token: 0x040000E7 RID: 231
			Lower,
			// Token: 0x040000E8 RID: 232
			Upper
		}
	}
}
