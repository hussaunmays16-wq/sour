﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200001B RID: 27
	[ActionCategory("♥ Caligula ♥")]
	[Tooltip("Duplicates a material and renames it.")]
	public class DuplicateMaterial : FsmStateAction
	{
		// Token: 0x06000058 RID: 88 RVA: 0x00004458 File Offset: 0x00002658
		public override void OnEnter()
		{
			base.Finish();
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00004460 File Offset: 0x00002660
		private FsmMaterial doNew(FsmMaterial vanha)
		{
			return new FsmMaterial(vanha);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00004478 File Offset: 0x00002678
		private void setName(FsmMaterial matsku, string name)
		{
			matsku.Name = name;
		}

		// Token: 0x04000097 RID: 151
		[Tooltip("Materials new name")]
		[RequiredField]
		public FsmString material_name;

		// Token: 0x04000098 RID: 152
		[RequiredField]
		[Tooltip("Material to duplicate")]
		public FsmMaterial material;

		// Token: 0x04000099 RID: 153
		[RequiredField]
		[Tooltip("New material variable")]
		public FsmMaterial new_material;
	}
}
