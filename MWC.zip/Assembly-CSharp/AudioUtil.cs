﻿using System;
using UnityEngine;

// Token: 0x020000B4 RID: 180
public static class AudioUtil
{
	// Token: 0x06000331 RID: 817 RVA: 0x0001533C File Offset: 0x0001353C
	public static float GetSemitonesFromPitch(float pitch)
	{
		float result;
		if (pitch < 1f && pitch > 0f)
		{
			float f = 1f / pitch;
			result = Mathf.Log(f, 1.0594635f) * -1f;
		}
		else
		{
			result = Mathf.Log(pitch, 1.0594635f);
		}
		return result;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0001538C File Offset: 0x0001358C
	public static float GetPitchFromSemitones(float semitones)
	{
		if (semitones >= 0f)
		{
			return Mathf.Pow(1.0594635f, semitones);
		}
		return 1f / Mathf.Pow(1.0594635f, Mathf.Abs(semitones));
	}

	// Token: 0x06000333 RID: 819 RVA: 0x000153C8 File Offset: 0x000135C8
	public static float GetDbFromFloatVolume(float vol)
	{
		return Mathf.Log(vol) * 20f;
	}

	// Token: 0x06000334 RID: 820 RVA: 0x000153D8 File Offset: 0x000135D8
	public static float GetFloatVolumeFromDb(float db)
	{
		return Mathf.Exp(db / 20f);
	}

	// Token: 0x06000335 RID: 821 RVA: 0x000153E8 File Offset: 0x000135E8
	public static float GetAudioPlayedPercentage(AudioSource source)
	{
		if (source.clip == null || source.time == 0f)
		{
			return 0f;
		}
		return source.time / source.clip.length * 100f;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x00015438 File Offset: 0x00013638
	public static bool IsAudioPaused(AudioSource source)
	{
		return !source.isPlaying && AudioUtil.GetAudioPlayedPercentage(source) > 0f;
	}

	// Token: 0x06000337 RID: 823 RVA: 0x00015458 File Offset: 0x00013658
	public static bool IsClipReadyToPlay(AudioClip clip)
	{
		return clip.loadType != AudioClipLoadType.Streaming;
	}

	// Token: 0x040004F5 RID: 1269
	private const float SemitonePitchChangeAmt = 1.0594635f;
}
