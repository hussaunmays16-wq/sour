﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000158 RID: 344
	[ActionCategory(ActionCategory.Animation)]
	[Tooltip("Captures the current pose of a hierarchy as an animation clip.\n\nUseful to blend from an arbitrary pose (e.g. a ragdoll death) back to a known animation (e.g. idle).")]
	public class CapturePoseAsAnimationClip : FsmStateAction
	{
		// Token: 0x0600065D RID: 1629 RVA: 0x0002F988 File Offset: 0x0002DB88
		public override void Reset()
		{
			this.gameObject = null;
			this.position = false;
			this.rotation = true;
			this.scale = false;
			this.storeAnimationClip = null;
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x0002F9C8 File Offset: 0x0002DBC8
		public override void OnEnter()
		{
			this.DoCaptureAnimationClip();
			base.Finish();
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x0002F9D8 File Offset: 0x0002DBD8
		private void DoCaptureAnimationClip()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			AnimationClip animationClip = new AnimationClip();
			foreach (object obj in ownerDefaultTarget.transform)
			{
				Transform transform = (Transform)obj;
				this.CaptureTransform(transform, string.Empty, animationClip);
			}
			this.storeAnimationClip.Value = animationClip;
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x0002FA84 File Offset: 0x0002DC84
		private void CaptureTransform(Transform transform, string path, AnimationClip clip)
		{
			path += transform.name;
			if (this.position.Value)
			{
				this.CapturePosition(transform, path, clip);
			}
			if (this.rotation.Value)
			{
				this.CaptureRotation(transform, path, clip);
			}
			if (this.scale.Value)
			{
				this.CaptureScale(transform, path, clip);
			}
			foreach (object obj in transform)
			{
				Transform transform2 = (Transform)obj;
				this.CaptureTransform(transform2, path + "/", clip);
			}
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x0002FB54 File Offset: 0x0002DD54
		private void CapturePosition(Transform transform, string path, AnimationClip clip)
		{
			this.SetConstantCurve(clip, path, "localPosition.x", transform.localPosition.x);
			this.SetConstantCurve(clip, path, "localPosition.y", transform.localPosition.y);
			this.SetConstantCurve(clip, path, "localPosition.z", transform.localPosition.z);
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x0002FBB4 File Offset: 0x0002DDB4
		private void CaptureRotation(Transform transform, string path, AnimationClip clip)
		{
			this.SetConstantCurve(clip, path, "localRotation.x", transform.localRotation.x);
			this.SetConstantCurve(clip, path, "localRotation.y", transform.localRotation.y);
			this.SetConstantCurve(clip, path, "localRotation.z", transform.localRotation.z);
			this.SetConstantCurve(clip, path, "localRotation.w", transform.localRotation.w);
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x0002FC30 File Offset: 0x0002DE30
		private void CaptureScale(Transform transform, string path, AnimationClip clip)
		{
			this.SetConstantCurve(clip, path, "localScale.x", transform.localScale.x);
			this.SetConstantCurve(clip, path, "localScale.y", transform.localScale.y);
			this.SetConstantCurve(clip, path, "localScale.z", transform.localScale.z);
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x0002FC90 File Offset: 0x0002DE90
		private void SetConstantCurve(AnimationClip clip, string childPath, string propertyPath, float value)
		{
			AnimationCurve animationCurve = AnimationCurve.Linear(0f, value, 100f, value);
			animationCurve.postWrapMode = WrapMode.Loop;
			clip.SetCurve(childPath, typeof(Transform), propertyPath, animationCurve);
		}

		// Token: 0x0400095F RID: 2399
		[CheckForComponent(typeof(Animation))]
		[Tooltip("The GameObject root of the hierarchy to capture.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000960 RID: 2400
		[Tooltip("Capture position keys.")]
		public FsmBool position;

		// Token: 0x04000961 RID: 2401
		[Tooltip("Capture rotation keys.")]
		public FsmBool rotation;

		// Token: 0x04000962 RID: 2402
		[Tooltip("Capture scale keys.")]
		public FsmBool scale;

		// Token: 0x04000963 RID: 2403
		[RequiredField]
		[Tooltip("Store the result in an Object variable of type AnimationClip.")]
		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(AnimationClip))]
		public FsmObject storeAnimationClip;
	}
}
