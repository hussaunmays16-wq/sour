﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000484 RID: 1156
[RequireComponent(typeof(Axles))]
public class Drivetrain : MonoBehaviour
{
	// Token: 0x06001359 RID: 4953 RVA: 0x000736E4 File Offset: 0x000718E4
	private float Sqr(float x)
	{
		return x * x;
	}

	// Token: 0x1700009B RID: 155
	// (get) Token: 0x0600135A RID: 4954 RVA: 0x000736EC File Offset: 0x000718EC
	// (set) Token: 0x0600135B RID: 4955 RVA: 0x000736F4 File Offset: 0x000718F4
	public float fuelConsumptionAtCostantSpeed
	{
		get
		{
			return this._fuelConsumptionAtCostantSpeed;
		}
		set
		{
			if (value < 0f)
			{
				this._fuelConsumptionAtCostantSpeed = 0f;
			}
			else
			{
				this._fuelConsumptionAtCostantSpeed = value;
			}
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x0600135C RID: 4956 RVA: 0x00073724 File Offset: 0x00071924
	// (set) Token: 0x0600135D RID: 4957 RVA: 0x0007372C File Offset: 0x0007192C
	public float fuelConsumptionSpeed
	{
		get
		{
			return this._fuelConsumptionSpeed;
		}
		set
		{
			if (value < 1f)
			{
				this._fuelConsumptionSpeed = 1f;
			}
			else
			{
				this._fuelConsumptionSpeed = value;
			}
		}
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x0007375C File Offset: 0x0007195C
	private void Awake()
	{
		this.engineTorqueFromFile = false;
		this.torqueRPMValuesLen = 0;
		this.body = base.GetComponent<Rigidbody>();
		this.myTransform = base.transform;
		this.clutch = new Clutch();
		this.carController = base.GetComponent<CarController>();
		this.setup = base.GetComponent<Setup>();
		this.axles = base.GetComponent<Axles>();
		this.fuelTanks = base.GetComponentsInChildren<FuelTank>();
		this.poweredWheels = this.axles.rearAxle.wheels;
	}

	// Token: 0x0600135F RID: 4959 RVA: 0x000737E0 File Offset: 0x000719E0
	private IEnumerator Start()
	{
		if (this.setup != null && this.setup.enabled)
		{
			while (this.setup.loadingSetup)
			{
				yield return new WaitForSeconds(0.02f);
			}
		}
		this.CalcValues(1f, this.engineTorqueFromFile);
		if (this.shiftUpRPM == 0f)
		{
			this.shiftUpRPM = this.maxPowerRPM;
		}
		bool found = false;
		for (int i = 0; i < this.gearRatios.Length; i++)
		{
			if (this.gearRatios[i] == 0f)
			{
				this.neutral = i;
				this.first = this.neutral + 1;
				this.firstReverse = this.neutral - 1;
				found = true;
			}
		}
		if (!found)
		{
			Debug.LogError("UnityCar: Neutral gear (a gear with value 0) is missing in gearRatios array. Neutral gear is mandatory (" + this.myTransform.name + ")");
		}
		this.SetTransmission(this.transmission);
		if (this.clutch.maxTorque == 0f)
		{
			this.CalcClutchTorque();
		}
		if (this.shiftTime == 0f)
		{
			this.shiftTime = 0.5f;
		}
		this.lastGearRatio = this.gearRatios[this.gearRatios.Length - 1] * this.finalDriveRatio;
		this.fuelConsumptionAtCostantSpeed = this.fuelConsumptionAtCostantSpeed;
		this.fuelConsumptionSpeed = this.fuelConsumptionSpeed;
		this.RPMAtSpeedInLastGear = this.CalcRPMAtSpeedInLastGear(this.fuelConsumptionSpeed);
		this.secondsToCover100Km = 100f / this.fuelConsumptionSpeed * 3600f;
		this.CalcIdleThrottle();
		this.DisengageClutch();
		this.StartEngine();
		yield break;
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x000737FC File Offset: 0x000719FC
	public float CalcRPMAtSpeedInLastGear(float speed)
	{
		if (speed > 0f)
		{
			return speed / (this.axles.frontAxle.leftWheel.radius * 2f * 0.1885f / (Mathf.Abs(this.gearRatios[this.gearRatios.Length - 1]) * this.finalDriveRatio));
		}
		return 0f;
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x0007385C File Offset: 0x00071A5C
	public void CalcClutchTorque()
	{
		this.clutchMaxTorque = Mathf.Round(this.maxNetTorque * this.clutchTorqueMultiplier) * this.powerMultiplier;
		this.clutch.maxTorque = this.clutchMaxTorque;
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x0007389C File Offset: 0x00071A9C
	public void SetTransmission(Drivetrain.Transmissions transmission)
	{
		foreach (Wheel wheel in this.axles.allWheels)
		{
			wheel.lockingTorqueImpulse = 0f;
			wheel.drivetrainInertia = 0f;
			wheel.isPowered = false;
		}
		if (transmission == Drivetrain.Transmissions.FWD)
		{
			foreach (Wheel wheel2 in this.axles.frontAxle.wheels)
			{
				wheel2.isPowered = true;
			}
			this.poweredWheels = this.axles.frontAxle.wheels;
			this.axles.frontAxle.powered = true;
			this.axles.rearAxle.powered = false;
			foreach (Axle axle in this.axles.otherAxles)
			{
				axle.powered = false;
			}
		}
		else if (transmission == Drivetrain.Transmissions.RWD)
		{
			foreach (Wheel wheel3 in this.axles.rearAxle.wheels)
			{
				wheel3.isPowered = true;
			}
			this.poweredWheels = this.axles.rearAxle.wheels;
			this.axles.frontAxle.powered = false;
			this.axles.rearAxle.powered = true;
			foreach (Axle axle2 in this.axles.otherAxles)
			{
				axle2.powered = false;
			}
		}
		else if (transmission == Drivetrain.Transmissions.XWD)
		{
			List<Wheel> list = new List<Wheel>();
			if (this.axles.frontAxle.powered)
			{
				foreach (Wheel wheel4 in this.axles.frontAxle.wheels)
				{
					wheel4.isPowered = true;
					list.Add(wheel4);
				}
			}
			if (this.axles.rearAxle.powered)
			{
				foreach (Wheel wheel5 in this.axles.rearAxle.wheels)
				{
					wheel5.isPowered = true;
					list.Add(wheel5);
				}
			}
			foreach (Axle axle3 in this.axles.otherAxles)
			{
				if (axle3.powered)
				{
					foreach (Wheel wheel6 in axle3.wheels)
					{
						wheel6.isPowered = true;
						list.Add(wheel6);
					}
				}
			}
			this.poweredWheels = list.ToArray();
		}
		else if (transmission == Drivetrain.Transmissions.AWD)
		{
			foreach (Wheel wheel7 in this.axles.allWheels)
			{
				wheel7.isPowered = true;
			}
			this.poweredWheels = this.axles.allWheels;
			this.axles.frontAxle.powered = true;
			this.axles.rearAxle.powered = true;
			foreach (Axle axle4 in this.axles.otherAxles)
			{
				axle4.powered = true;
			}
		}
		this.drivetrainFraction = 1f / (float)this.poweredWheels.Length;
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x00073C4C File Offset: 0x00071E4C
	public float CalcEngineTorque(float factor, float rpm)
	{
		if (this.engineTorqueFromFile)
		{
			return this.CalcEngineTorqueExt(factor, rpm);
		}
		return this.CalcEngineTorqueInt(factor, rpm);
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x00073C6C File Offset: 0x00071E6C
	private float CalcEngineTorqueExt(float factor, float RPM)
	{
		if (this.torqueRPMValuesLen == 0)
		{
			return 0f;
		}
		int num = this.FindRightPoint(RPM);
		if (num == 0 || num == this.torqueRPMValuesLen)
		{
			return 0f;
		}
		float num2 = (RPM - this.torqueRPMValues[num, 0]) / (this.torqueRPMValues[num - 1, 0] - this.torqueRPMValues[num, 0]) * this.torqueRPMValues[num - 1, 1] - (RPM - this.torqueRPMValues[num - 1, 0]) / (this.torqueRPMValues[num - 1, 0] - this.torqueRPMValues[num, 0]) * this.torqueRPMValues[num, 1];
		return num2 * factor;
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x00073D2C File Offset: 0x00071F2C
	private int FindRightPoint(float RPM)
	{
		int i;
		for (i = 0; i <= this.torqueRPMValuesLen - 1; i++)
		{
			if (this.torqueRPMValues[i, 0] > RPM)
			{
				break;
			}
		}
		return i;
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x00073D6C File Offset: 0x00071F6C
	private float CalcEngineTorqueInt(float factor, float rpm)
	{
		float num;
		if (rpm < this.maxTorqueRPM)
		{
			num = this.maxTorque * (-this.Sqr(rpm / this.maxTorqueRPM - 1f) + 1f);
		}
		else
		{
			float num2 = this.maxPower * this.CV2KW * 1000f / this.maxPowerAngVel;
			float num3 = (this.maxTorque - num2) / (2f * this.maxTorqueRPM * this.maxPowerRPM - this.Sqr(this.maxPowerRPM) - this.Sqr(this.maxTorqueRPM));
			float num4 = num3 * this.Sqr(rpm - this.maxTorqueRPM) + this.maxTorque;
			num = ((num4 <= 0f) ? 0f : num4);
		}
		if (rpm < 0f || num < 0f)
		{
			num = 0f;
		}
		return num * factor;
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x00073E50 File Offset: 0x00072050
	public float CalcEngineTorqueInt_reference(float factor, float RPM)
	{
		float num = RPM * this.RPM2angularVelo;
		float num2 = this.P1 + this.P2 * num + this.P3 * (num * num);
		if (RPM < this.maxTorqueRPM)
		{
			num2 *= 1f - this.Sqr(RPM / this.maxTorqueRPM - 1f);
		}
		return num2 * 1000f * factor;
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x00073EB4 File Offset: 0x000720B4
	public float CalcEngineFrictionTorque(float factor, float rpm)
	{
		float num = 0.1f;
		if (rpm < this.minRPM)
		{
			num = 1f - 0.9f * (rpm / this.minRPM);
		}
		return this.maxPowerEngineTorque * factor * this.engineFrictionFactor * (num + (1f - num) * rpm / this.maxRPM);
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x00073F0C File Offset: 0x0007210C
	private float CalcEnginePower(float rpm, bool total, float factor)
	{
		if (total)
		{
			return (this.CalcEngineTorque(factor, rpm) - this.CalcEngineFrictionTorque(factor, rpm)) * rpm * this.RPM2angularVelo * 0.001f * this.KW2CV;
		}
		return this.CalcEngineTorque(factor, rpm) * rpm * this.RPM2angularVelo * 0.001f * this.KW2CV;
	}

	// Token: 0x0600136A RID: 4970 RVA: 0x00073F68 File Offset: 0x00072168
	public void StartEngine()
	{
		this.engineAngularVelo = this.minRPM * this.RPM2angularVelo * 1.5f;
	}

	// Token: 0x0600136B RID: 4971 RVA: 0x00073F84 File Offset: 0x00072184
	private void CalcEngineMaxPower(float powerMultiplier, bool setMaxPower)
	{
		for (float num = this.minRPM; num < this.maxRPM; num += 1f)
		{
			float num2 = this.CalcEnginePower(num, true, powerMultiplier);
			float num3 = this.CalcEnginePower(num + 1f, true, powerMultiplier);
			if (num3 > num2)
			{
				this.maxNetPowerRPM = num + 1f;
				this.maxNetPower = num3;
			}
			if (setMaxPower)
			{
				num2 = this.CalcEnginePower(num, false, powerMultiplier);
				num3 = this.CalcEnginePower(num + 1f, false, powerMultiplier);
				if (num3 > num2)
				{
					this.maxPowerRPM = num + 1f;
					this.maxPower = num3;
				}
			}
		}
	}

	// Token: 0x0600136C RID: 4972 RVA: 0x00074024 File Offset: 0x00072224
	private void CalcengineMaxTorque(float powerMultiplier, bool setMaxTorque)
	{
		for (float num = this.minRPM; num < this.maxRPM; num += 1f)
		{
			float num2 = this.CalcEngineTorque(powerMultiplier, num) - this.CalcEngineFrictionTorque(powerMultiplier, num);
			float num3 = this.CalcEngineTorque(powerMultiplier, num + 1f) - this.CalcEngineFrictionTorque(powerMultiplier, num + 1f);
			if (num3 > num2)
			{
				this.maxNetTorqueRPM = num + 1f;
				this.maxNetTorque = num3;
			}
			if (setMaxTorque)
			{
				num2 = this.CalcEngineTorque(powerMultiplier, num);
				num3 = this.CalcEngineTorque(powerMultiplier, num + 1f);
				if (num3 > num2)
				{
					this.maxTorqueRPM = num + 1f;
					this.maxTorque = num3;
				}
			}
		}
	}

	// Token: 0x0600136D RID: 4973 RVA: 0x000740D8 File Offset: 0x000722D8
	public void CalcIdleThrottle()
	{
		float num = this.CalcEngineFrictionTorque(this.powerMultiplier, this.minRPM);
		float num2 = this.CalcEngineTorque(this.powerMultiplier, this.minRPM);
		this.idleNetTorque = num2 - num;
		this.idlethrottle = 0f;
		while (this.idlethrottle < 1f)
		{
			if (num2 * this.idlethrottle >= num)
			{
				break;
			}
			this.idlethrottle += 0.0001f;
		}
		this.idlethrottleMinRPMDown = this.idlethrottle;
	}

	// Token: 0x0600136E RID: 4974 RVA: 0x00074168 File Offset: 0x00072368
	public void CalcValues(float externalFactor, bool setMaxPower)
	{
		this.maxPowerAngVel = this.maxPowerRPM * this.RPM2angularVelo;
		this.maxPowerKW = this.maxPower * this.CV2KW * externalFactor;
		this.maxPowerDriveShaft = this.maxPower * externalFactor;
		this.P1 = this.maxPowerKW / this.maxPowerAngVel;
		this.P2 = this.maxPowerKW / (this.maxPowerAngVel * this.maxPowerAngVel);
		this.P3 = -this.maxPowerKW / (this.maxPowerAngVel * this.maxPowerAngVel * this.maxPowerAngVel);
		this.maxPowerEngineTorque = this.CalcEngineTorque(1f, this.maxPowerRPM);
		this.CalcengineMaxTorque(1f, setMaxPower);
		this.CalcEngineMaxPower(1f, setMaxPower);
		this.originalMaxPower = this.maxPower;
		this.curveFactor = externalFactor;
	}

	// Token: 0x0600136F RID: 4975 RVA: 0x0007423C File Offset: 0x0007243C
	private void FixedUpdate()
	{
		if (this.clutch == null)
		{
			this.clutch = new Clutch();
			this.CalcClutchTorque();
		}
		if (this.shifter)
		{
			this.automatic = false;
		}
		this.ratio = this.gearRatios[this.gear] * this.finalDriveRatio;
		if (this.rpm <= this.minRPM + this.maxRPM * 0.05f)
		{
			this.idlethrottle = this.idlethrottleMinRPMDown * ((this.minRPM + 500f - Mathf.Clamp(this.rpm, this.minRPM, this.rpm)) * 0.002f);
		}
		else
		{
			this.idlethrottle = 0f;
		}
		this.currentPower = this.CalcEnginePower(this.rpm, true, this.powerMultiplier);
		float num = this.engineInertia * this.powerMultiplier * this.externalMultiplier;
		float num2 = this.drivetrainInertia * this.powerMultiplier * this.externalMultiplier;
		this.velo = Mathf.Abs(this.myTransform.InverseTransformDirection(this.body.velocity).z);
		if ((this.rpm >= this.engageRPM || this.engaging) && this.autoClutch && this.carController.clutchInput == 0f && this.clutch.GetClutchPosition() != 1f && this.carController.handbrakeInput == 0f && this.ratio != 0f)
		{
			this.EngageClutch();
		}
		if (this.rpm <= this.disengageRPM && !this.engaging && this.autoClutch)
		{
			this.DisengageClutch();
		}
		if (this.changingGear)
		{
			this.DoGearShifting();
		}
		else
		{
			this.lastShiftTime = 0f;
		}
		if (this.automatic)
		{
			this.autoClutch = true;
			if (!this.CanShiftAgain)
			{
				this.TimeToShiftAgain = Mathf.Clamp01((Time.time - this.ShiftDelay) / (this.shiftTime + this.shiftTime / 2f));
				if (this.TimeToShiftAgain >= 1f)
				{
					this.CanShiftAgain = true;
				}
			}
			if (!this.changingGear)
			{
				if (this.rpm >= this.shiftUpRPM)
				{
					if (this.gear >= 0 && this.gear < this.gearRatios.Length - 1 && Mathf.Abs(this.slipRatio / this.idealSlipRatio) <= 1f && this.clutch.GetClutchPosition() != 0f && this.clutch.speedDiff < 50f && !this.engaging)
					{
						if (this.CanShiftAgain && this.OnGround())
						{
							if (this.gearRatios[this.gear] > 0f)
							{
								this.Shift(this.gear + 1);
							}
							else
							{
								this.Shift(this.gear - 1);
							}
						}
						this.CanShiftAgain = false;
						this.ShiftDelay = Time.time;
					}
				}
				else if (this.rpm <= this.shiftDownRPM && this.gear != this.first && this.gear != this.firstReverse && this.gear != this.neutral && this.gear > 0 && this.gear < this.gearRatios.Length && this.clutch.GetClutchPosition() != 0f && Mathf.Abs(this.clutch.speedDiff) < 50f && !this.engaging && this.CanShiftAgain && this.OnGround())
				{
					if (this.velo < 3f)
					{
						this.Shift(this.first);
					}
					else if (this.gearRatios[this.gear] > 0f)
					{
						this.Shift(this.gear - 1);
					}
					else
					{
						this.Shift(this.gear + 1);
					}
					this.CanShiftAgain = false;
					this.ShiftDelay = Time.time;
				}
			}
		}
		float num3 = 0f;
		this.wheelImpulse = 0f;
		this.rotationalInertia = 0f;
		this.wheelTireVelo = 0f;
		foreach (Wheel wheel in this.poweredWheels)
		{
			num3 += wheel.angularVelocity;
			this.wheelImpulse += wheel.wheelImpulse;
			this.rotationalInertia += wheel.rotationalInertia;
			this.wheelTireVelo += wheel.wheelTireVelo;
		}
		num3 *= this.drivetrainFraction;
		this.wheelTireVelo *= this.drivetrainFraction;
		float num4 = num2 + this.rotationalInertia;
		if (this.rpm < 20f && this.startTorque == 0f)
		{
			this.differentialSpeed = 0f;
			this.wheelImpulse = 0f;
		}
		this.clutchSpeed = this.differentialSpeed * this.ratio;
		this.fuel = true;
		if (this.fuelTanks.Length != 0)
		{
			float num5 = this.velo * 3.6f;
			float num6 = Mathf.Clamp(num5, 50f, num5) / this.fuelConsumptionSpeed;
			num6 *= num6;
			if (this.RPMAtSpeedInLastGear != 0f)
			{
				this.istantConsumption = this.rpm * this.throttle * this.fuelConsumptionAtCostantSpeed / (this.RPMAtSpeedInLastGear * this.secondsToCover100Km) * num6;
			}
			if (this.velo > 1f)
			{
				this.currentConsumption = this.istantConsumption / this.velo * 100000f;
			}
			else
			{
				this.currentConsumption = 0f;
			}
			this.fuel = false;
			foreach (FuelTank fuelTank in this.fuelTanks)
			{
				if (fuelTank.currentFuel != 0f)
				{
					this.fuel = true;
				}
			}
		}
		this.torque = this.CalcEngineTorque(this.powerMultiplier, this.rpm) * (this.throttle + this.startThrottle) * (float)((!this.fuel) ? 0 : 1);
		this.frictionTorque = this.CalcEngineFrictionTorque(this.powerMultiplier, this.rpm);
		this.startThrottle = 0f;
		this.startTorque = 0f;
		this.netTorque = this.torque - this.frictionTorque;
		if (this.rpm < 20f && this.startTorque == 0f)
		{
			this.netTorque = 0f;
		}
		if (this.rpm < this.minRPM)
		{
			this.startThrottle = 1f - this.rpm / this.minRPM;
		}
		if (this.startEngine && this.rpm < this.minRPM && Time.time > this.nextStartImpulse)
		{
			if (this.duration == 0f)
			{
				this.duration = Time.time + 0.1f;
			}
			if (Time.time > this.duration)
			{
				this.nextStartImpulse = Time.time + 0.2f;
			}
			this.startThrottle = 1f;
			this.startTorque = this.idleNetTorque;
		}
		else
		{
			this.duration = 0f;
		}
		this.netTorqueImpulse = (this.netTorque + this.startTorque) * Time.deltaTime;
		if (this.engineAngularVelo >= this.maxRPM * this.RPM2angularVelo)
		{
			if (this.revLimiterTime == 0f && this.revLimiter)
			{
				this.engineAngularVelo = this.maxRPM * this.RPM2angularVelo;
			}
			else
			{
				this.revLimiterTriggered = true;
			}
		}
		else if (this.engineAngularVelo <= this.minRPM * this.RPM2angularVelo && !this.canStall)
		{
			this.engineAngularVelo = this.minRPM * this.RPM2angularVelo;
		}
		else if (this.engineAngularVelo < 0f)
		{
			this.engineAngularVelo = 0f;
		}
		this.rpm = this.engineAngularVelo * this.angularVelo2RPM;
		if (this.ratio == 0f || this.clutch.GetClutchPosition() == 0f)
		{
			this.clutchDragImpulse = 0f;
			this.differentialSpeed = num3;
			if (this.autoClutch)
			{
				this.DisengageClutch();
			}
			this.body.AddTorque(-this.engineOrientation * Mathf.Min(Mathf.Abs(this.netTorque), 2000f) * Mathf.Sign(this.netTorque));
		}
		else
		{
			this.clutchDragImpulse = this.clutch.GetDragImpulse(this.engineAngularVelo, this.clutchSpeed, num, num4, this.ratio, this.wheelImpulse, this.netTorqueImpulse);
		}
		this.engineAngularVelo += (this.netTorqueImpulse - this.clutchDragImpulse) / num;
		this.differentialSpeed += (this.wheelImpulse + this.clutchDragImpulse * this.ratio) / num4;
		if (float.IsNaN(this.differentialSpeed))
		{
			this.differentialSpeed = 0f;
		}
		float num7 = this.differentialSpeed - num3;
		this.slipRatio = 0f;
		this.idealSlipRatio = 0f;
		float num8 = this.maxRPM / (Mathf.Abs(this.ratio) * this.angularVelo2RPM);
		foreach (Wheel wheel2 in this.poweredWheels)
		{
			if (this.revLimiter && wheel2.angularVelocity > num8)
			{
				wheel2.angularVelocity = num8;
			}
			this.lockingTorqueImpulse = (num3 - wheel2.angularVelocity) * this.differentialLockCoefficient * Time.deltaTime;
			wheel2.drivetrainInertia = num2 * this.ratio * this.ratio * this.drivetrainFraction * this.clutch.GetClutchPosition();
			wheel2.angularVelocity += num7;
			wheel2.lockingTorqueImpulse = this.lockingTorqueImpulse;
			this.slipRatio += wheel2.slipRatio * this.drivetrainFraction;
			this.idealSlipRatio += wheel2.idealSlipRatio * this.drivetrainFraction;
		}
		if (this.revLimiter)
		{
			if (this.revLimiterTriggered)
			{
				this.revLimiterReleased = false;
				this.timer += Time.deltaTime;
				if (this.timer >= this.revLimiterTime)
				{
					this.timer = 0f;
					this.revLimiterTriggered = false;
					this.revLimiterReleased = true;
				}
			}
			else
			{
				this.revLimiterReleased = false;
			}
		}
		else
		{
			this.revLimiterTriggered = false;
			this.revLimiterReleased = false;
		}
	}

	// Token: 0x06001370 RID: 4976 RVA: 0x00074D84 File Offset: 0x00072F84
	private void DoGearShifting()
	{
		if (this.shiftImmediately)
		{
			this.gear = this.nextGear;
			if (this.nextGear != this.neutral)
			{
				this.shiftTriggered = true;
			}
			this.changingGear = false;
		}
		else if (this.throttle <= this.idlethrottle * 1.1f || !this.automatic)
		{
			if (this.lastShiftTime == 0f)
			{
				this.lastShiftTime = Time.time;
			}
			this.shiftTimer = (Time.time - this.lastShiftTime) / this.shiftTime;
			if (this.shiftTimer < 1f)
			{
				this.DisengageClutch();
			}
			if (this.shiftTimer >= 0.33f)
			{
				this.gear = this.neutral;
			}
			if (this.shiftTimer >= 0.66f)
			{
				this.gear = this.nextGear;
				if (!this.soundPlayed)
				{
					this.shiftTriggered = true;
				}
			}
			if (this.shiftTimer >= 1f && (this.rpm < this.engageRPM || this.carController.clutchInput != 0f))
			{
				this.changingGear = false;
			}
		}
	}

	// Token: 0x06001371 RID: 4977 RVA: 0x00074EC0 File Offset: 0x000730C0
	private void EngageClutch()
	{
		this.engaging = true;
		int num = 1;
		if (this.rpm < this.maxPowerRPM / 2f)
		{
			this.clutchEngageSpeed = Mathf.Clamp(this.clutchDragImpulse / this.netTorqueImpulse, Time.fixedDeltaTime * 2f, 1f);
			if (this.clutchDragImpulse < this.netTorqueImpulse || this.netTorque < 1f)
			{
				num = 1;
			}
			else
			{
				num = -1;
			}
		}
		else
		{
			this.clutchEngageSpeed = 0.1f;
		}
		if (this.clutchEngageSpeed != 0f)
		{
			this.clutchPosition += Time.deltaTime / this.clutchEngageSpeed * (float)num * ((this.throttle <= this.idlethrottle) ? 1f : this.throttle);
		}
		this.clutchPosition = Mathf.Clamp01(this.clutchPosition);
		this.clutch.SetClutchPosition(this.clutchPosition);
		if (this.clutchPosition == 1f)
		{
			this.engaging = false;
			this.changingGear = false;
		}
	}

	// Token: 0x06001372 RID: 4978 RVA: 0x00074FE0 File Offset: 0x000731E0
	private void DisengageClutch()
	{
		this.clutchPosition = 0f;
		this.clutch.SetClutchPosition(this.clutchPosition);
	}

	// Token: 0x06001373 RID: 4979 RVA: 0x00075000 File Offset: 0x00073200
	public bool OnGround()
	{
		bool flag = false;
		if (this.poweredWheels != null)
		{
			foreach (Wheel wheel in this.poweredWheels)
			{
				flag = wheel.onGroundDown;
				if (flag)
				{
					break;
				}
			}
		}
		return flag;
	}

	// Token: 0x06001374 RID: 4980 RVA: 0x0007504C File Offset: 0x0007324C
	public void Shift(int m_gear)
	{
		if (m_gear <= this.gearRatios.Length - 1 && m_gear >= 0 && !this.changingGear)
		{
			if (this.autoClutch || this.clutch.GetClutchPosition() == 0f)
			{
				this.soundPlayed = false;
				this.changingGear = true;
				this.nextGear = m_gear;
				if (this.nextGear == this.neutral || (this.gear == this.neutral && this.nextGear == this.first) || (this.gear == this.neutral && this.nextGear == this.firstReverse) || this.shifter)
				{
					this.shiftImmediately = true;
				}
				else
				{
					this.shiftImmediately = false;
				}
			}
		}
	}

	// Token: 0x04001A53 RID: 6739
	[HideInInspector]
	public bool engineTorqueFromFile;

	// Token: 0x04001A54 RID: 6740
	[HideInInspector]
	public int torqueRPMValuesLen;

	// Token: 0x04001A55 RID: 6741
	[HideInInspector]
	public float[,] torqueRPMValues = new float[0, 0];

	// Token: 0x04001A56 RID: 6742
	[HideInInspector]
	public Clutch clutch;

	// Token: 0x04001A57 RID: 6743
	[HideInInspector]
	public CarController carController;

	// Token: 0x04001A58 RID: 6744
	private Setup setup;

	// Token: 0x04001A59 RID: 6745
	private Axles axles;

	// Token: 0x04001A5A RID: 6746
	[HideInInspector]
	public FuelTank[] fuelTanks;

	// Token: 0x04001A5B RID: 6747
	private Rigidbody body;

	// Token: 0x04001A5C RID: 6748
	private Transform myTransform;

	// Token: 0x04001A5D RID: 6749
	[HideInInspector]
	public Wheel[] poweredWheels;

	// Token: 0x04001A5E RID: 6750
	public float maxPower = 210f;

	// Token: 0x04001A5F RID: 6751
	public float maxPowerRPM = 5000f;

	// Token: 0x04001A60 RID: 6752
	public float maxTorque = 360f;

	// Token: 0x04001A61 RID: 6753
	public float maxTorqueRPM = 2500f;

	// Token: 0x04001A62 RID: 6754
	[HideInInspector]
	public float originalMaxPower = 210f;

	// Token: 0x04001A63 RID: 6755
	[HideInInspector]
	public float maxNetPower;

	// Token: 0x04001A64 RID: 6756
	[HideInInspector]
	public float maxNetPowerRPM;

	// Token: 0x04001A65 RID: 6757
	[HideInInspector]
	public float maxNetTorque;

	// Token: 0x04001A66 RID: 6758
	[HideInInspector]
	public float maxNetTorqueRPM;

	// Token: 0x04001A67 RID: 6759
	[HideInInspector]
	public float torque;

	// Token: 0x04001A68 RID: 6760
	private float netTorque;

	// Token: 0x04001A69 RID: 6761
	private float netTorqueImpulse;

	// Token: 0x04001A6A RID: 6762
	[HideInInspector]
	public float wheelTireVelo;

	// Token: 0x04001A6B RID: 6763
	public float minRPM = 1000f;

	// Token: 0x04001A6C RID: 6764
	public float maxRPM = 6000f;

	// Token: 0x04001A6D RID: 6765
	public bool canStall;

	// Token: 0x04001A6E RID: 6766
	[HideInInspector]
	public bool startEngine;

	// Token: 0x04001A6F RID: 6767
	public bool revLimiter;

	// Token: 0x04001A70 RID: 6768
	public float revLimiterTime = 0.1f;

	// Token: 0x04001A71 RID: 6769
	[HideInInspector]
	public bool revLimiterTriggered;

	// Token: 0x04001A72 RID: 6770
	[HideInInspector]
	public bool revLimiterReleased;

	// Token: 0x04001A73 RID: 6771
	private float timer;

	// Token: 0x04001A74 RID: 6772
	public float engineInertia = 0.3f;

	// Token: 0x04001A75 RID: 6773
	public float drivetrainInertia = 0.02f;

	// Token: 0x04001A76 RID: 6774
	private float rotationalInertia;

	// Token: 0x04001A77 RID: 6775
	public float engineFrictionFactor = 0.25f;

	// Token: 0x04001A78 RID: 6776
	public Vector3 engineOrientation = Vector3.forward;

	// Token: 0x04001A79 RID: 6777
	public Drivetrain.Transmissions transmission;

	// Token: 0x04001A7A RID: 6778
	public float[] gearRatios = new float[]
	{
		-2.66f,
		0f,
		2.66f,
		1.91f,
		1.39f,
		1f,
		0.71f
	};

	// Token: 0x04001A7B RID: 6779
	[HideInInspector]
	public int neutral = 1;

	// Token: 0x04001A7C RID: 6780
	[HideInInspector]
	public int first;

	// Token: 0x04001A7D RID: 6781
	[HideInInspector]
	public int firstReverse;

	// Token: 0x04001A7E RID: 6782
	public float finalDriveRatio = 6.09f;

	// Token: 0x04001A7F RID: 6783
	public float differentialLockCoefficient = 1f;

	// Token: 0x04001A80 RID: 6784
	public bool shifter;

	// Token: 0x04001A81 RID: 6785
	public bool automatic = true;

	// Token: 0x04001A82 RID: 6786
	public bool autoReverse = true;

	// Token: 0x04001A83 RID: 6787
	public float shiftDownRPM = 2000f;

	// Token: 0x04001A84 RID: 6788
	public float shiftUpRPM;

	// Token: 0x04001A85 RID: 6789
	public float shiftTime = 0.5f;

	// Token: 0x04001A86 RID: 6790
	public float clutchMaxTorque;

	// Token: 0x04001A87 RID: 6791
	public bool autoClutch = true;

	// Token: 0x04001A88 RID: 6792
	public float engageRPM = 1500f;

	// Token: 0x04001A89 RID: 6793
	public float disengageRPM = 1000f;

	// Token: 0x04001A8A RID: 6794
	public float _fuelConsumptionAtCostantSpeed = 4.3f;

	// Token: 0x04001A8B RID: 6795
	public float _fuelConsumptionSpeed = 130f;

	// Token: 0x04001A8C RID: 6796
	public float currentConsumption;

	// Token: 0x04001A8D RID: 6797
	[HideInInspector]
	public float istantConsumption;

	// Token: 0x04001A8E RID: 6798
	[HideInInspector]
	public float RPMAtSpeedInLastGear;

	// Token: 0x04001A8F RID: 6799
	private float secondsToCover100Km;

	// Token: 0x04001A90 RID: 6800
	[HideInInspector]
	public float clutchTorqueMultiplier = 1.6f;

	// Token: 0x04001A91 RID: 6801
	public float clutchEngageSpeed;

	// Token: 0x04001A92 RID: 6802
	private float clutchPosition;

	// Token: 0x04001A93 RID: 6803
	[HideInInspector]
	public float throttle;

	// Token: 0x04001A94 RID: 6804
	[HideInInspector]
	public float idlethrottle;

	// Token: 0x04001A95 RID: 6805
	private float idlethrottleMinRPMDown;

	// Token: 0x04001A96 RID: 6806
	private float idleNetTorque;

	// Token: 0x04001A97 RID: 6807
	[HideInInspector]
	public float startTorque;

	// Token: 0x04001A98 RID: 6808
	private float startThrottle;

	// Token: 0x04001A99 RID: 6809
	private float nextStartImpulse;

	// Token: 0x04001A9A RID: 6810
	private float duration;

	// Token: 0x04001A9B RID: 6811
	[HideInInspector]
	public bool shiftTriggered;

	// Token: 0x04001A9C RID: 6812
	[HideInInspector]
	public bool soundPlayed;

	// Token: 0x04001A9D RID: 6813
	[HideInInspector]
	public float clutchDragImpulse;

	// Token: 0x04001A9E RID: 6814
	private float wheelImpulse;

	// Token: 0x04001A9F RID: 6815
	private float TransferredTorque;

	// Token: 0x04001AA0 RID: 6816
	[HideInInspector]
	public float differentialSpeed;

	// Token: 0x04001AA1 RID: 6817
	private float clutchSpeed;

	// Token: 0x04001AA2 RID: 6818
	[HideInInspector]
	public bool engaging;

	// Token: 0x04001AA3 RID: 6819
	private float shiftTimer;

	// Token: 0x04001AA4 RID: 6820
	private float TimeToShiftAgain;

	// Token: 0x04001AA5 RID: 6821
	[HideInInspector]
	public bool CanShiftAgain = true;

	// Token: 0x04001AA6 RID: 6822
	private float ShiftDelay = -1f;

	// Token: 0x04001AA7 RID: 6823
	private float lastShiftTime = -1f;

	// Token: 0x04001AA8 RID: 6824
	public int gear = 1;

	// Token: 0x04001AA9 RID: 6825
	public float rpm;

	// Token: 0x04001AAA RID: 6826
	private float slipRatio;

	// Token: 0x04001AAB RID: 6827
	private float idealSlipRatio;

	// Token: 0x04001AAC RID: 6828
	private float engineAngularVelo;

	// Token: 0x04001AAD RID: 6829
	[HideInInspector]
	public float angularVelo2RPM = 9.549296f;

	// Token: 0x04001AAE RID: 6830
	[HideInInspector]
	public float RPM2angularVelo = 0.10471976f;

	// Token: 0x04001AAF RID: 6831
	[HideInInspector]
	public float KW2CV = 1.359f;

	// Token: 0x04001AB0 RID: 6832
	[HideInInspector]
	public float CV2KW = 0.7358f;

	// Token: 0x04001AB1 RID: 6833
	[HideInInspector]
	public float maxPowerDriveShaft;

	// Token: 0x04001AB2 RID: 6834
	[HideInInspector]
	public float currentPower;

	// Token: 0x04001AB3 RID: 6835
	private float maxPowerKW;

	// Token: 0x04001AB4 RID: 6836
	private float maxPowerAngVel;

	// Token: 0x04001AB5 RID: 6837
	private float maxPowerEngineTorque;

	// Token: 0x04001AB6 RID: 6838
	private float P1;

	// Token: 0x04001AB7 RID: 6839
	private float P2;

	// Token: 0x04001AB8 RID: 6840
	private float P3;

	// Token: 0x04001AB9 RID: 6841
	[HideInInspector]
	public float curveFactor;

	// Token: 0x04001ABA RID: 6842
	[HideInInspector]
	public float frictionTorque;

	// Token: 0x04001ABB RID: 6843
	[HideInInspector]
	public float powerMultiplier = 1f;

	// Token: 0x04001ABC RID: 6844
	[HideInInspector]
	public float externalMultiplier = 1f;

	// Token: 0x04001ABD RID: 6845
	[HideInInspector]
	public float ratio;

	// Token: 0x04001ABE RID: 6846
	[HideInInspector]
	public float lastGearRatio;

	// Token: 0x04001ABF RID: 6847
	[HideInInspector]
	public bool changingGear;

	// Token: 0x04001AC0 RID: 6848
	private bool shiftImmediately;

	// Token: 0x04001AC1 RID: 6849
	private int nextGear;

	// Token: 0x04001AC2 RID: 6850
	private float lockingTorqueImpulse;

	// Token: 0x04001AC3 RID: 6851
	private float max_power;

	// Token: 0x04001AC4 RID: 6852
	[HideInInspector]
	public float drivetrainFraction;

	// Token: 0x04001AC5 RID: 6853
	[HideInInspector]
	public float velo;

	// Token: 0x04001AC6 RID: 6854
	[HideInInspector]
	private bool fuel = true;

	// Token: 0x04001AC7 RID: 6855
	[HideInInspector]
	public float RPMAt130Kmh;

	// Token: 0x02000485 RID: 1157
	public enum Transmissions
	{
		// Token: 0x04001AC9 RID: 6857
		RWD,
		// Token: 0x04001ACA RID: 6858
		FWD,
		// Token: 0x04001ACB RID: 6859
		AWD,
		// Token: 0x04001ACC RID: 6860
		XWD
	}
}
