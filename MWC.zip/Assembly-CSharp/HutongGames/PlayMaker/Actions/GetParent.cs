﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000248 RID: 584
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets the Parent of a Game Object.")]
	public class GetParent : FsmStateAction
	{
		// Token: 0x060009F7 RID: 2551 RVA: 0x0003EB08 File Offset: 0x0003CD08
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0003EB18 File Offset: 0x0003CD18
		public override void OnEnter()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget != null)
			{
				this.storeResult.Value = ((!(ownerDefaultTarget.transform.parent == null)) ? ownerDefaultTarget.transform.parent.gameObject : null);
			}
			else
			{
				this.storeResult.Value = null;
			}
			base.Finish();
		}

		// Token: 0x04000DEC RID: 3564
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DED RID: 3565
		[UIHint(UIHint.Variable)]
		public FsmGameObject storeResult;
	}
}
