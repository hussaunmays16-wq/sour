﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000165 RID: 357
	[Tooltip("Converts a Bool value to a String value.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertBoolToString : FsmStateAction
	{
		// Token: 0x060006A7 RID: 1703 RVA: 0x00030B50 File Offset: 0x0002ED50
		public override void Reset()
		{
			this.boolVariable = null;
			this.stringVariable = null;
			this.falseString = "False";
			this.trueString = "True";
			this.everyFrame = false;
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x00030B88 File Offset: 0x0002ED88
		public override void OnEnter()
		{
			this.DoConvertBoolToString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00030BA4 File Offset: 0x0002EDA4
		public override void OnUpdate()
		{
			this.DoConvertBoolToString();
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00030BAC File Offset: 0x0002EDAC
		private void DoConvertBoolToString()
		{
			this.stringVariable.Value = ((!this.boolVariable.Value) ? this.falseString.Value : this.trueString.Value);
		}

		// Token: 0x040009A3 RID: 2467
		[RequiredField]
		[Tooltip("The Bool variable to test.")]
		[UIHint(UIHint.Variable)]
		public FsmBool boolVariable;

		// Token: 0x040009A4 RID: 2468
		[Tooltip("The String variable to set based on the Bool variable value.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString stringVariable;

		// Token: 0x040009A5 RID: 2469
		[Tooltip("String value if Bool variable is false.")]
		public FsmString falseString;

		// Token: 0x040009A6 RID: 2470
		[Tooltip("String value if Bool variable is true.")]
		public FsmString trueString;

		// Token: 0x040009A7 RID: 2471
		[Tooltip("Repeat every frame. Useful if the Bool variable is changing.")]
		public bool everyFrame;
	}
}
