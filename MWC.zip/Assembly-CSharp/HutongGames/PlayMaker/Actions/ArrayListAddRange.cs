﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000398 RID: 920
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Add several items to a PlayMaker Array List Proxy component")]
	public class ArrayListAddRange : ArrayListActions
	{
		// Token: 0x06000F97 RID: 3991 RVA: 0x00055CD4 File Offset: 0x00053ED4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.variables = new FsmVar[2];
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x00055CF0 File Offset: 0x00053EF0
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListAddRange();
			}
			base.Finish();
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x00055D30 File Offset: 0x00053F30
		public void DoArrayListAddRange()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			foreach (FsmVar fsmVar in this.variables)
			{
				this.proxy.Add(PlayMakerUtils.GetValueFromFsmVar(base.Fsm, fsmVar), fsmVar.Type.ToString(), true);
			}
		}

		// Token: 0x04001447 RID: 5191
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001448 RID: 5192
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x04001449 RID: 5193
		[Tooltip("The variables to add.")]
		[RequiredField]
		[ActionSection("Data")]
		public FsmVar[] variables;
	}
}
