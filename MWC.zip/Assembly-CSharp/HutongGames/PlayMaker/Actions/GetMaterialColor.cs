﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200000C RID: 12
	[ActionCategory(ActionCategory.Material)]
	[Tooltip("Gets a named color value from a game object's material.")]
	public class GetMaterialColor : FsmStateAction
	{
		// Token: 0x06000024 RID: 36 RVA: 0x00002920 File Offset: 0x00000B20
		public override void Reset()
		{
			this.gameObject = null;
			this.materialIndex = 0;
			this.material = null;
			this.namedColor = "_Color";
			this.color = null;
			this.fail = null;
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00002968 File Offset: 0x00000B68
		public override void OnEnter()
		{
			this.DoGetMaterialColor();
			base.Finish();
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00002978 File Offset: 0x00000B78
		private void DoGetMaterialColor()
		{
			if (this.color.IsNone)
			{
				return;
			}
			string text = this.namedColor.Value;
			if (text == string.Empty)
			{
				text = "_Color";
			}
			if (this.material.Value != null)
			{
				if (!this.material.Value.HasProperty(text))
				{
					base.Fsm.Event(this.fail);
					return;
				}
				this.color.Value = this.material.Value.GetColor(text);
				return;
			}
			else
			{
				GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
				if (ownerDefaultTarget == null)
				{
					return;
				}
				if (ownerDefaultTarget.GetComponent<Renderer>() == null)
				{
					this.LogError("Missing Renderer!");
					return;
				}
				if (ownerDefaultTarget.GetComponent<Renderer>().material == null)
				{
					this.LogError("Missing Material!");
					return;
				}
				if (this.materialIndex.Value == 0)
				{
					if (!ownerDefaultTarget.GetComponent<Renderer>().material.HasProperty(text))
					{
						base.Fsm.Event(this.fail);
						return;
					}
					this.color.Value = ownerDefaultTarget.GetComponent<Renderer>().material.GetColor(text);
				}
				else if (ownerDefaultTarget.GetComponent<Renderer>().materials.Length > this.materialIndex.Value)
				{
					Material[] materials = ownerDefaultTarget.GetComponent<Renderer>().materials;
					if (!materials[this.materialIndex.Value].HasProperty(text))
					{
						base.Fsm.Event(this.fail);
						return;
					}
					this.color.Value = materials[this.materialIndex.Value].GetColor(text);
				}
				return;
			}
		}

		// Token: 0x04000023 RID: 35
		[Tooltip("The GameObject that the material is applied to.")]
		[CheckForComponent(typeof(Renderer))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000024 RID: 36
		[Tooltip("GameObjects can have multiple materials. Specify an index to target a specific material.")]
		public FsmInt materialIndex;

		// Token: 0x04000025 RID: 37
		[Tooltip("Alternatively specify a Material instead of a GameObject and Index.")]
		public FsmMaterial material;

		// Token: 0x04000026 RID: 38
		[UIHint(UIHint.NamedColor)]
		[Tooltip("The named color parameter in the shader.")]
		public FsmString namedColor;

		// Token: 0x04000027 RID: 39
		[RequiredField]
		[Tooltip("Get the parameter value.")]
		[UIHint(UIHint.Variable)]
		public FsmColor color;

		// Token: 0x04000028 RID: 40
		public FsmEvent fail;
	}
}
