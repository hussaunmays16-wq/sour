﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BE RID: 958
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Check if a key exists in a PlayMaker HashTable Proxy component (PlayMakerHashTablePRoxy)")]
	public class HashTableContains : HashTableActions
	{
		// Token: 0x06001032 RID: 4146 RVA: 0x000588C8 File Offset: 0x00056AC8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
			this.containsKey = null;
			this.keyFoundEvent = null;
			this.keyNotFoundEvent = null;
		}

		// Token: 0x06001033 RID: 4147 RVA: 0x00058900 File Offset: 0x00056B00
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.checkIfContainsKey();
			}
			base.Finish();
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x00058940 File Offset: 0x00056B40
		public void checkIfContainsKey()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.containsKey.Value = this.proxy.hashTable.Contains(this.key.Value);
			if (this.containsKey.Value)
			{
				base.Fsm.Event(this.keyFoundEvent);
			}
			else
			{
				base.Fsm.Event(this.keyNotFoundEvent);
			}
		}

		// Token: 0x04001500 RID: 5376
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001501 RID: 5377
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001502 RID: 5378
		[Tooltip("The Key value to check for")]
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		public FsmString key;

		// Token: 0x04001503 RID: 5379
		[Tooltip("Store the result of the test")]
		[UIHint(UIHint.FsmBool)]
		public FsmBool containsKey;

		// Token: 0x04001504 RID: 5380
		[ActionSection("Result")]
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when key is found")]
		public FsmEvent keyFoundEvent;

		// Token: 0x04001505 RID: 5381
		[Tooltip("The event to trigger when key is not found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent keyNotFoundEvent;
	}
}
