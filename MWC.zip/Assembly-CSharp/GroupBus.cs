﻿using System;
using System.Collections.Generic;
using UnityEngine.Audio;

// Token: 0x0200007F RID: 127
[Serializable]
public class GroupBus
{
	// Token: 0x060001CE RID: 462 RVA: 0x0000C394 File Offset: 0x0000A594
	public void AddActiveAudioSourceId(int id)
	{
		if (this._activeAudioSourcesIds.Contains(id))
		{
			return;
		}
		this._activeAudioSourcesIds.Add(id);
	}

	// Token: 0x060001CF RID: 463 RVA: 0x0000C3B4 File Offset: 0x0000A5B4
	public void RemoveActiveAudioSourceId(int id)
	{
		this._activeAudioSourcesIds.Remove(id);
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060001D0 RID: 464 RVA: 0x0000C3C4 File Offset: 0x0000A5C4
	public int ActiveVoices
	{
		get
		{
			return this._activeAudioSourcesIds.Count;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060001D1 RID: 465 RVA: 0x0000C3D4 File Offset: 0x0000A5D4
	public bool BusVoiceLimitReached
	{
		get
		{
			return this.voiceLimit > 0 && this._activeAudioSourcesIds.Count >= this.voiceLimit;
		}
	}

	// Token: 0x040002F4 RID: 756
	public string busName;

	// Token: 0x040002F5 RID: 757
	public float volume = 1f;

	// Token: 0x040002F6 RID: 758
	public bool isSoloed;

	// Token: 0x040002F7 RID: 759
	public bool isMuted;

	// Token: 0x040002F8 RID: 760
	public int voiceLimit = -1;

	// Token: 0x040002F9 RID: 761
	public bool stopOldest;

	// Token: 0x040002FA RID: 762
	public bool isExisting;

	// Token: 0x040002FB RID: 763
	public AudioMixerGroup mixerChannel;

	// Token: 0x040002FC RID: 764
	private readonly List<int> _activeAudioSourcesIds = new List<int>(50);
}
