﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D1 RID: 465
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Clamps the value of Float Variable to a Min/Max range.")]
	public class FloatClamp : FsmStateAction
	{
		// Token: 0x0600082C RID: 2092 RVA: 0x000387D0 File Offset: 0x000369D0
		public override void Reset()
		{
			this.floatVariable = null;
			this.minValue = null;
			this.maxValue = null;
			this.everyFrame = false;
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x000387F0 File Offset: 0x000369F0
		public override void OnEnter()
		{
			this.DoClamp();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x0003880C File Offset: 0x00036A0C
		public override void OnUpdate()
		{
			this.DoClamp();
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x00038814 File Offset: 0x00036A14
		private void DoClamp()
		{
			this.floatVariable.Value = Mathf.Clamp(this.floatVariable.Value, this.minValue.Value, this.maxValue.Value);
		}

		// Token: 0x04000BCC RID: 3020
		[UIHint(UIHint.Variable)]
		[Tooltip("Float variable to clamp.")]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000BCD RID: 3021
		[RequiredField]
		[Tooltip("The minimum value.")]
		public FsmFloat minValue;

		// Token: 0x04000BCE RID: 3022
		[Tooltip("The maximum value.")]
		[RequiredField]
		public FsmFloat maxValue;

		// Token: 0x04000BCF RID: 3023
		[Tooltip("Repeate every frame. Useful if the float variable is changing.")]
		public bool everyFrame;
	}
}
