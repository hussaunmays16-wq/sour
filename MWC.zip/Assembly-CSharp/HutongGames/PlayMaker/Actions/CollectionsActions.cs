﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003F3 RID: 1011
	[Tooltip("Collections base action - don't use!")]
	public abstract class CollectionsActions : FsmStateAction
	{
		// Token: 0x06001112 RID: 4370 RVA: 0x0005E0D0 File Offset: 0x0005C2D0
		protected PlayMakerHashTableProxy GetHashTableProxyPointer(GameObject aProxy, string nameReference, bool silent)
		{
			if (aProxy == null)
			{
				if (!silent)
				{
					Debug.LogError("Null Proxy");
				}
				return null;
			}
			PlayMakerHashTableProxy[] components = aProxy.GetComponents<PlayMakerHashTableProxy>();
			if (components.Length > 1)
			{
				if (nameReference == string.Empty && !silent)
				{
					Debug.LogWarning("Several HashTable Proxies coexists on the same GameObject and no reference is given to find the expected HashTable");
				}
				foreach (PlayMakerHashTableProxy playMakerHashTableProxy in components)
				{
					if (playMakerHashTableProxy.referenceName == nameReference)
					{
						return playMakerHashTableProxy;
					}
				}
				if (nameReference != string.Empty)
				{
					if (!silent)
					{
						Debug.LogError("HashTable Proxy not found for reference <" + nameReference + ">");
					}
					return null;
				}
			}
			else if (components.Length > 0)
			{
				if (nameReference != string.Empty && nameReference != components[0].referenceName)
				{
					if (!silent)
					{
						Debug.LogError("HashTable Proxy reference do not match");
					}
					return null;
				}
				return components[0];
			}
			if (!silent)
			{
				Debug.LogError("HashTable not found");
			}
			return null;
		}

		// Token: 0x06001113 RID: 4371 RVA: 0x0005E1E0 File Offset: 0x0005C3E0
		protected PlayMakerArrayListProxy GetArrayListProxyPointer(GameObject aProxy, string nameReference, bool silent)
		{
			if (aProxy == null)
			{
				if (!silent)
				{
					Debug.LogError("Null Proxy");
				}
				return null;
			}
			PlayMakerArrayListProxy[] components = aProxy.GetComponents<PlayMakerArrayListProxy>();
			if (components.Length > 1)
			{
				if (nameReference == string.Empty && !silent)
				{
					Debug.LogError("Several ArrayList Proxies coexists on the same GameObject and no reference is given to find the expected ArrayList");
				}
				foreach (PlayMakerArrayListProxy playMakerArrayListProxy in components)
				{
					if (playMakerArrayListProxy.referenceName == nameReference)
					{
						return playMakerArrayListProxy;
					}
				}
				if (nameReference != string.Empty)
				{
					if (!silent)
					{
						this.LogError("ArrayList Proxy not found for reference <" + nameReference + ">");
					}
					return null;
				}
			}
			else if (components.Length > 0)
			{
				if (nameReference != string.Empty && nameReference != components[0].referenceName)
				{
					if (!silent)
					{
						Debug.LogError("ArrayList Proxy reference do not match");
					}
					return null;
				}
				return components[0];
			}
			if (!silent)
			{
				this.LogError("ArrayList proxy not found");
			}
			return null;
		}

		// Token: 0x020003F4 RID: 1012
		public enum FsmVariableEnum
		{
			// Token: 0x0400164D RID: 5709
			FsmGameObject,
			// Token: 0x0400164E RID: 5710
			FsmInt,
			// Token: 0x0400164F RID: 5711
			FsmFloat,
			// Token: 0x04001650 RID: 5712
			FsmString,
			// Token: 0x04001651 RID: 5713
			FsmBool,
			// Token: 0x04001652 RID: 5714
			FsmVector2,
			// Token: 0x04001653 RID: 5715
			FsmVector3,
			// Token: 0x04001654 RID: 5716
			FsmRect,
			// Token: 0x04001655 RID: 5717
			FsmQuaternion,
			// Token: 0x04001656 RID: 5718
			FsmColor,
			// Token: 0x04001657 RID: 5719
			FsmMaterial,
			// Token: 0x04001658 RID: 5720
			FsmTexture,
			// Token: 0x04001659 RID: 5721
			FsmObject
		}
	}
}
