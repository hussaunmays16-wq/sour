﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E6 RID: 998
	[Tooltip("Saves a PlayMaker HashTable Proxy component")]
	[ActionCategory("Easy Save 2")]
	public class HashTableEasySaveEncrypted : HashTableActions
	{
		// Token: 0x060010E5 RID: 4325 RVA: 0x0005D008 File Offset: 0x0005B208
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.encryption = false;
			this.password = string.Empty;
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0005D064 File Offset: 0x0005B264
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SaveHashTable();
			}
			base.Finish();
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x0005D0A4 File Offset: 0x0005B2A4
		public void SaveHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = "false";
			if (this.encryption.Value)
			{
				text = "true";
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (object obj in this.proxy.hashTable.Keys)
			{
				dictionary[(string)obj] = PlayMakerUtils.ParseValueToString(this.proxy.hashTable[obj]);
			}
			ES2.Save<string, string>(dictionary, string.Concat(new object[]
			{
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag,
				"&encrypt=",
				text,
				"&password=",
				this.password.Value
			}));
			this.Log(string.Concat(new object[]
			{
				"Saved to ",
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			base.Finish();
		}

		// Token: 0x0400160B RID: 5643
		[RequiredField]
		[ActionSection("Set up")]
		[Tooltip("The Game Object to add the Hashtable Component to.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400160C RID: 5644
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker arrayList proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400160D RID: 5645
		[ActionSection("Easy Save Set Up")]
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x0400160E RID: 5646
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x0400160F RID: 5647
		[Tooltip("the password of the saved item")]
		public FsmString password = string.Empty;

		// Token: 0x04001610 RID: 5648
		[Tooltip("The name of the file that we'll create to store our data.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
