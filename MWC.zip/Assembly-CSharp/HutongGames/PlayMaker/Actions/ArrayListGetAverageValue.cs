﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D6 RID: 982
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Return the average value within an arrayList. It can use float, int, vector2 and vector3 ( uses magnitude), rect ( uses surface), gameobject ( using bounding box volume), and string ( use lenght)")]
	public class ArrayListGetAverageValue : ArrayListActions
	{
		// Token: 0x06001097 RID: 4247 RVA: 0x0005A32C File Offset: 0x0005852C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.averageValue = null;
			this.everyframe = true;
		}

		// Token: 0x06001098 RID: 4248 RVA: 0x0005A34C File Offset: 0x0005854C
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoGetAverageValue();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x06001099 RID: 4249 RVA: 0x0005A3A0 File Offset: 0x000585A0
		public override void OnUpdate()
		{
			this.DoGetAverageValue();
		}

		// Token: 0x0600109A RID: 4250 RVA: 0x0005A3A8 File Offset: 0x000585A8
		private void DoGetAverageValue()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._floats = new List<float>();
			foreach (object value in this.proxy.arrayList)
			{
				try
				{
					this._floats.Add(Convert.ToSingle(value));
				}
				finally
				{
				}
			}
			if (this._floats.Count > 0)
			{
				this.averageValue.Value = this._floats.Aggregate((float acc, float cur) => acc + cur) / (float)this._floats.Count;
			}
			else
			{
				this.averageValue.Value = 0f;
			}
		}

		// Token: 0x04001582 RID: 5506
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001583 RID: 5507
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001584 RID: 5508
		[Tooltip("Performs every frame. WARNING, it could be affecting performances.")]
		public bool everyframe;

		// Token: 0x04001585 RID: 5509
		[RequiredField]
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The average Value")]
		public FsmFloat averageValue;

		// Token: 0x04001586 RID: 5510
		private List<float> _floats;
	}
}
