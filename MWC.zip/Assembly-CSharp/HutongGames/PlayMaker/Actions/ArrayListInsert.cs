﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A6 RID: 934
	[Tooltip("Insert item at a specified index of a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListInsert : ArrayListActions
	{
		// Token: 0x06000FD1 RID: 4049 RVA: 0x00057144 File Offset: 0x00055344
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.variable = null;
			this.failureEvent = null;
			this.index = null;
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x0005716C File Offset: 0x0005536C
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doArrayListInsert();
			}
			base.Finish();
		}

		// Token: 0x06000FD3 RID: 4051 RVA: 0x000571AC File Offset: 0x000553AC
		public void doArrayListInsert()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			try
			{
				this.proxy.arrayList.Insert(this.index.Value, PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable));
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Fsm.Event(this.failureEvent);
			}
		}

		// Token: 0x04001498 RID: 5272
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001499 RID: 5273
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400149A RID: 5274
		[UIHint(UIHint.FsmInt)]
		[Tooltip("The index to remove at")]
		public FsmInt index;

		// Token: 0x0400149B RID: 5275
		[Tooltip("The variable to add.")]
		[RequiredField]
		[ActionSection("Data")]
		public FsmVar variable;

		// Token: 0x0400149C RID: 5276
		[Tooltip("The event to trigger if the removeAt throw errors")]
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Result")]
		public FsmEvent failureEvent;
	}
}
