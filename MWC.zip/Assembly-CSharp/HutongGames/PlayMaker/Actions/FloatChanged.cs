﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D0 RID: 464
	[Tooltip("Tests if the value of a Float variable changed. Use this to send an event on change, or store a bool that can be used in other operations.")]
	[ActionCategory(ActionCategory.Logic)]
	public class FloatChanged : FsmStateAction
	{
		// Token: 0x06000828 RID: 2088 RVA: 0x00038718 File Offset: 0x00036918
		public override void Reset()
		{
			this.floatVariable = null;
			this.changedEvent = null;
			this.storeResult = null;
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00038730 File Offset: 0x00036930
		public override void OnEnter()
		{
			if (this.floatVariable.IsNone)
			{
				base.Finish();
				return;
			}
			this.previousValue = this.floatVariable.Value;
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00038768 File Offset: 0x00036968
		public override void OnUpdate()
		{
			this.storeResult.Value = false;
			if (this.floatVariable.Value != this.previousValue)
			{
				this.previousValue = this.floatVariable.Value;
				this.storeResult.Value = true;
				base.Fsm.Event(this.changedEvent);
			}
		}

		// Token: 0x04000BC8 RID: 3016
		[Tooltip("The Float variable to watch for a change.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x04000BC9 RID: 3017
		[Tooltip("Event to send if the float variable changes.")]
		public FsmEvent changedEvent;

		// Token: 0x04000BCA RID: 3018
		[UIHint(UIHint.Variable)]
		[Tooltip("Set to True if the float variable changes.")]
		public FsmBool storeResult;

		// Token: 0x04000BCB RID: 3019
		private float previousValue;
	}
}
