﻿using System;
using UnityEngine;

// Token: 0x02000470 RID: 1136
[Serializable]
public class Axle
{
	// Token: 0x040018ED RID: 6381
	public Wheel leftWheel;

	// Token: 0x040018EE RID: 6382
	public Wheel rightWheel;

	// Token: 0x040018EF RID: 6383
	[HideInInspector]
	public Wheel[] wheels;

	// Token: 0x040018F0 RID: 6384
	public bool powered;

	// Token: 0x040018F1 RID: 6385
	public float suspensionTravel = 0.2f;

	// Token: 0x040018F2 RID: 6386
	public float suspensionRate = 20000f;

	// Token: 0x040018F3 RID: 6387
	public float bumpRate = 4000f;

	// Token: 0x040018F4 RID: 6388
	public float reboundRate = 4000f;

	// Token: 0x040018F5 RID: 6389
	public float fastBumpFactor = 0.3f;

	// Token: 0x040018F6 RID: 6390
	public float fastReboundFactor = 0.3f;

	// Token: 0x040018F7 RID: 6391
	public float antiRollBarRate = 10000f;

	// Token: 0x040018F8 RID: 6392
	public float brakeFrictionTorque = 1500f;

	// Token: 0x040018F9 RID: 6393
	public float handbrakeFrictionTorque;

	// Token: 0x040018FA RID: 6394
	public float maxSteeringAngle;

	// Token: 0x040018FB RID: 6395
	public float forwardGripFactor = 1f;

	// Token: 0x040018FC RID: 6396
	public float sidewaysGripFactor = 1f;

	// Token: 0x040018FD RID: 6397
	public float camber;

	// Token: 0x040018FE RID: 6398
	public float caster;

	// Token: 0x040018FF RID: 6399
	[HideInInspector]
	public float deltaCamber;

	// Token: 0x04001900 RID: 6400
	[HideInInspector]
	public float oldCamber;

	// Token: 0x04001901 RID: 6401
	public CarDynamics.Tires tires;

	// Token: 0x04001902 RID: 6402
	public float tiresPressure = 200f;

	// Token: 0x04001903 RID: 6403
	public float optimalTiresPressure = 200f;
}
