﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000034 RID: 52
	[ActionCategory("Trigonometry")]
	[Tooltip("Get the cosine. You can use degrees, simply check on the DegToRad conversion")]
	public class GetCosine : FsmStateAction
	{
		// Token: 0x060000B0 RID: 176 RVA: 0x00006720 File Offset: 0x00004920
		public override void Reset()
		{
			this.angle = null;
			this.DegToRad = true;
			this.everyFrame = false;
			this.result = null;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00006744 File Offset: 0x00004944
		public override void OnEnter()
		{
			this.DoCosine();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00006760 File Offset: 0x00004960
		public override void OnUpdate()
		{
			this.DoCosine();
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00006768 File Offset: 0x00004968
		private void DoCosine()
		{
			float num = this.angle.Value;
			if (this.DegToRad.Value)
			{
				num *= 0.017453292f;
			}
			this.result.Value = Mathf.Cos(num);
		}

		// Token: 0x04000108 RID: 264
		[Tooltip("The angle. Note: You can use degrees, simply check DegtoRad if the angle is expressed in degrees.")]
		[RequiredField]
		public FsmFloat angle;

		// Token: 0x04000109 RID: 265
		[Tooltip("Check on if the angle is expressed in degrees.")]
		public FsmBool DegToRad;

		// Token: 0x0400010A RID: 266
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The angle cosinus")]
		public FsmFloat result;

		// Token: 0x0400010B RID: 267
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
