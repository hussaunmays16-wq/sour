﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014D RID: 333
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if the value of a Bool Variable has changed. Use this to send an event on change, or store a bool that can be used in other operations.")]
	public class BoolChanged : FsmStateAction
	{
		// Token: 0x06000630 RID: 1584 RVA: 0x0002EE64 File Offset: 0x0002D064
		public override void Reset()
		{
			this.boolVariable = null;
			this.changedEvent = null;
			this.storeResult = null;
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0002EE7C File Offset: 0x0002D07C
		public override void OnEnter()
		{
			if (this.boolVariable.IsNone)
			{
				base.Finish();
				return;
			}
			this.previousValue = this.boolVariable.Value;
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0002EEB4 File Offset: 0x0002D0B4
		public override void OnUpdate()
		{
			this.storeResult.Value = false;
			if (this.boolVariable.Value != this.previousValue)
			{
				this.storeResult.Value = true;
				base.Fsm.Event(this.changedEvent);
			}
		}

		// Token: 0x04000926 RID: 2342
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variable to watch for changes.")]
		public FsmBool boolVariable;

		// Token: 0x04000927 RID: 2343
		[Tooltip("Event to send if the variable changes.")]
		public FsmEvent changedEvent;

		// Token: 0x04000928 RID: 2344
		[UIHint(UIHint.Variable)]
		[Tooltip("Set to True if changed.")]
		public FsmBool storeResult;

		// Token: 0x04000929 RID: 2345
		private bool previousValue;
	}
}
