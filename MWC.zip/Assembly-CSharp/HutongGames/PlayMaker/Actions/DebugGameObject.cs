﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000176 RID: 374
	[Tooltip("Logs the value of a Game Object Variable in the PlayMaker Log Window.")]
	[ActionCategory(ActionCategory.Debug)]
	public class DebugGameObject : FsmStateAction
	{
		// Token: 0x060006E8 RID: 1768 RVA: 0x00031660 File Offset: 0x0002F860
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.gameObject = null;
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x00031670 File Offset: 0x0002F870
		public override void OnEnter()
		{
			string text = "None";
			if (!this.gameObject.IsNone)
			{
				text = this.gameObject.Name + ": " + this.gameObject;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009E1 RID: 2529
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009E2 RID: 2530
		[Tooltip("Prints the value of a GameObject variable in the PlayMaker log window.")]
		[UIHint(UIHint.Variable)]
		public FsmGameObject gameObject;
	}
}
