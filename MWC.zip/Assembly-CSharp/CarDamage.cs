﻿using System;
using UnityEngine;

// Token: 0x02000477 RID: 1143
public class CarDamage : MonoBehaviour
{
	// Token: 0x06001339 RID: 4921 RVA: 0x0006EBD8 File Offset: 0x0006CDD8
	private void Start()
	{
		this.myTransform = base.transform;
		this.body = base.GetComponent<Rigidbody>();
		if (this.sign < -1f || this.sign > 1f)
		{
			this.sign = 1f;
		}
		if (this.meshFilters.Length == 0)
		{
			this.m_meshFilters = base.GetComponentsInChildren<MeshFilter>();
			int num = 0;
			this.i = 0;
			while (this.i < this.m_meshFilters.Length)
			{
				if (this.m_meshFilters[this.i].GetComponent<Collider>() == null)
				{
					num++;
				}
				this.i++;
			}
			this.meshFilters = new MeshFilter[num];
			num = 0;
			this.i = 0;
			while (this.i < this.m_meshFilters.Length)
			{
				if (this.m_meshFilters[this.i].GetComponent<Collider>() == null)
				{
					this.meshFilters[num] = this.m_meshFilters[this.i];
					num++;
				}
				this.i++;
			}
		}
		if (this.meshCollider != null)
		{
			this.colliderVerts = this.meshCollider.sharedMesh.vertices;
		}
		this.LoadoriginalMeshData();
		foreach (object obj in base.transform)
		{
			Transform transform = (Transform)obj;
			if (transform.gameObject.tag == "Body" || transform.gameObject.name == "Body" || transform.gameObject.name == "body")
			{
				this.GObody = transform.gameObject;
			}
		}
		if (this.GObody)
		{
			if (this.sign == 0f)
			{
				this.sign = Mathf.Cos(this.GObody.transform.localEulerAngles.y * 0.017453292f);
			}
			if (this.GObody.transform.localEulerAngles.x != 0f)
			{
				this.rot = Quaternion.AngleAxis(this.GObody.transform.localEulerAngles.x * 3f, Vector3.right);
			}
		}
		this.carDynamics = base.GetComponent<CarDynamics>();
		this.axles = base.GetComponent<Axles>();
		this.wheelLayer = this.axles.allWheels[0].transform.gameObject.layer;
		this.carLayer = base.transform.gameObject.layer;
	}

	// Token: 0x0600133A RID: 4922 RVA: 0x0006EED0 File Offset: 0x0006D0D0
	private void LoadoriginalMeshData()
	{
		this.originalMeshData = new CarDamage.permaVertsColl[this.meshFilters.Length];
		this.i = 0;
		while (this.i < this.meshFilters.Length)
		{
			this.originalMeshData[this.i].permaVerts = this.meshFilters[this.i].mesh.vertices;
			this.i++;
		}
	}

	// Token: 0x0600133B RID: 4923 RVA: 0x0006EF4C File Offset: 0x0006D14C
	private void Update()
	{
		if (!this.sleep && this.repair && this.bounceBackSpeed > 0f)
		{
			this.sleep = true;
			for (int i = 0; i < this.meshFilters.Length; i++)
			{
				Vector3[] vertices = this.meshFilters[i].mesh.vertices;
				if (this.originalMeshData == null)
				{
					this.LoadoriginalMeshData();
				}
				for (int j = 0; j < vertices.Length; j++)
				{
					vertices[j] += (this.originalMeshData[i].permaVerts[j] - vertices[j]) * (Time.deltaTime * this.bounceBackSpeed);
					if ((this.originalMeshData[i].permaVerts[j] - vertices[j]).magnitude >= this.bounceBackSleepCap)
					{
						this.sleep = false;
					}
				}
				this.meshFilters[i].mesh.vertices = vertices;
				this.meshFilters[i].mesh.RecalculateNormals();
				this.meshFilters[i].mesh.RecalculateBounds();
			}
			if (this.meshCollider != null)
			{
				Mesh mesh = new Mesh();
				mesh.vertices = this.colliderVerts;
				mesh.triangles = this.meshCollider.sharedMesh.triangles;
				mesh.RecalculateNormals();
				mesh.RecalculateBounds();
				this.meshCollider.sharedMesh = mesh;
				this.body.centerOfMass = this.carDynamics.centerOfMass.localPosition;
			}
			if (this.sleep)
			{
				this.repair = false;
			}
		}
		if (Application.isEditor)
		{
			this.YforceDamp = Mathf.Clamp01(this.YforceDamp);
		}
	}

	// Token: 0x0600133C RID: 4924 RVA: 0x0006F144 File Offset: 0x0006D344
	private void OnCollisionEnter(Collision collision)
	{
		if (collision.contacts.Length > 0 && this.myTransform != null)
		{
			Vector3 vector = collision.relativeVelocity;
			vector *= 1f - Mathf.Abs(Vector3.Dot(this.myTransform.up, collision.contacts[0].normal)) * this.YforceDamp;
			float num = Mathf.Abs(Vector3.Dot(collision.contacts[0].normal, vector.normalized));
			if (vector.magnitude * num >= this.minForce)
			{
				this.sleep = false;
				this.vec = this.myTransform.InverseTransformDirection(vector) * this.multiplier * 0.1f;
				if (this.originalMeshData == null)
				{
					this.LoadoriginalMeshData();
				}
				for (int i = 0; i < this.meshFilters.Length; i++)
				{
					if (this.meshFilters[i].gameObject.layer != this.wheelLayer || this.carLayer == this.wheelLayer)
					{
						this.DeformMesh(this.meshFilters[i].mesh, this.originalMeshData[i].permaVerts, collision, num, this.meshFilters[i].transform, this.sign, this.rot);
					}
				}
				if (this.meshCollider != null)
				{
					Mesh mesh = new Mesh();
					mesh.vertices = this.meshCollider.sharedMesh.vertices;
					mesh.triangles = this.meshCollider.sharedMesh.triangles;
					this.DeformMesh(mesh, this.colliderVerts, collision, num, this.meshCollider.transform, 1f, Quaternion.identity);
					this.meshCollider.sharedMesh = mesh;
					this.meshCollider.sharedMesh.RecalculateNormals();
					this.meshCollider.sharedMesh.RecalculateBounds();
					this.body.centerOfMass = this.carDynamics.centerOfMass.localPosition;
				}
			}
		}
	}

	// Token: 0x0600133D RID: 4925 RVA: 0x0006F35C File Offset: 0x0006D55C
	private void DeformMesh(Mesh mesh, Vector3[] originalMesh, Collision collision, float cos, Transform meshTransform, float sign, Quaternion rot)
	{
		Vector3[] vertices = mesh.vertices;
		foreach (ContactPoint contactPoint in collision.contacts)
		{
			Vector3 a = meshTransform.InverseTransformPoint(contactPoint.point);
			for (int j = 0; j < vertices.Length; j++)
			{
				if ((a - vertices[j]).magnitude < this.deformRadius)
				{
					vertices[j] += rot * (this.vec * (this.deformRadius - (a - vertices[j]).magnitude) / this.deformRadius * cos + UnityEngine.Random.onUnitSphere * this.deformNoise) * sign;
					if (this.maxDeform > 0f && (vertices[j] - originalMesh[j]).magnitude > this.maxDeform)
					{
						vertices[j] = originalMesh[j] + (vertices[j] - originalMesh[j]).normalized * this.maxDeform;
					}
				}
			}
		}
		mesh.vertices = vertices;
		mesh.RecalculateNormals();
		mesh.RecalculateBounds();
	}

	// Token: 0x0400196E RID: 6510
	public MeshCollider meshCollider;

	// Token: 0x0400196F RID: 6511
	public MeshFilter[] meshFilters;

	// Token: 0x04001970 RID: 6512
	private MeshFilter[] m_meshFilters;

	// Token: 0x04001971 RID: 6513
	public float deformNoise = 0.005f;

	// Token: 0x04001972 RID: 6514
	public float deformRadius = 0.5f;

	// Token: 0x04001973 RID: 6515
	private float bounceBackSleepCap = 0.002f;

	// Token: 0x04001974 RID: 6516
	public float bounceBackSpeed = 2f;

	// Token: 0x04001975 RID: 6517
	private Vector3[] colliderVerts;

	// Token: 0x04001976 RID: 6518
	private CarDamage.permaVertsColl[] originalMeshData;

	// Token: 0x04001977 RID: 6519
	private bool sleep = true;

	// Token: 0x04001978 RID: 6520
	public float maxDeform = 0.5f;

	// Token: 0x04001979 RID: 6521
	public float minForce = 1f;

	// Token: 0x0400197A RID: 6522
	public float multiplier = 0.1f;

	// Token: 0x0400197B RID: 6523
	public float YforceDamp = 1f;

	// Token: 0x0400197C RID: 6524
	[HideInInspector]
	public bool repair;

	// Token: 0x0400197D RID: 6525
	private Vector3 vec;

	// Token: 0x0400197E RID: 6526
	private Transform trs;

	// Token: 0x0400197F RID: 6527
	private Transform myTransform;

	// Token: 0x04001980 RID: 6528
	private GameObject GObody;

	// Token: 0x04001981 RID: 6529
	private CarDynamics carDynamics;

	// Token: 0x04001982 RID: 6530
	private Axles axles;

	// Token: 0x04001983 RID: 6531
	private Rigidbody body;

	// Token: 0x04001984 RID: 6532
	public float sign = 1f;

	// Token: 0x04001985 RID: 6533
	private Quaternion rot = Quaternion.identity;

	// Token: 0x04001986 RID: 6534
	private int wheelLayer;

	// Token: 0x04001987 RID: 6535
	private int carLayer;

	// Token: 0x04001988 RID: 6536
	private int i;

	// Token: 0x02000478 RID: 1144
	private struct permaVertsColl
	{
		// Token: 0x04001989 RID: 6537
		public Vector3[] permaVerts;
	}
}
