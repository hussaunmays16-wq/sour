﻿using System;
using UnityEngine;

// Token: 0x020000C1 RID: 193
public class Car : MonoBehaviour
{
	// Token: 0x060003B0 RID: 944 RVA: 0x000185CC File Offset: 0x000167CC
	private void FixedUpdate()
	{
		base.GetComponent<Rigidbody>().AddForce(base.transform.forward * Input.GetAxis("Vertical") * Time.deltaTime * 20f, ForceMode.Impulse);
		base.GetComponent<Rigidbody>().AddTorque(Vector3.up * Input.GetAxis("Horizontal") * Time.deltaTime * 12f, ForceMode.Impulse);
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x00018648 File Offset: 0x00016848
	private void OnGUI()
	{
		GUILayout.Label("Arrows to control the car. Click and hold on car to repair damages under mouse cursor.", new GUILayoutOption[0]);
	}
}
