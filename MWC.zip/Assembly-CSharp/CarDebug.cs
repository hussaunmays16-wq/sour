﻿using System;
using UnityEngine;

// Token: 0x02000479 RID: 1145
public class CarDebug : MonoBehaviour
{
	// Token: 0x0600133F RID: 4927 RVA: 0x0006F514 File Offset: 0x0006D714
	private void Start()
	{
		this.drivetrain = base.GetComponent<Drivetrain>();
		this.axles = base.GetComponent<Axles>();
		this.forceFeedback = base.GetComponent<ForceFeedback>();
	}

	// Token: 0x06001340 RID: 4928 RVA: 0x0006F548 File Offset: 0x0006D748
	public float RoundTo(float value, int precision)
	{
		int num = 1;
		for (int i = 1; i <= precision; i++)
		{
			num *= 10;
		}
		return Mathf.Round(value * (float)num) / (float)num;
	}

	// Token: 0x06001341 RID: 4929 RVA: 0x0006F57C File Offset: 0x0006D77C
	private void OnGUI()
	{
		GUILayout.Label("clutch.GetClutchPosition: " + this.drivetrain.clutch.GetClutchPosition(), new GUILayoutOption[0]);
		GUILayout.Label("currentPower: " + Mathf.Round(this.drivetrain.currentPower), new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"engFricTorque: ",
			this.drivetrain.frictionTorque,
			" engineTorque: ",
			this.drivetrain.torque
		}), new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"clutchDrag: ",
			this.drivetrain.clutchDragImpulse / Time.fixedDeltaTime,
			"  torque - frictionTorque: ",
			this.drivetrain.torque - this.drivetrain.frictionTorque
		}), new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"CanShiftAgain: ",
			this.drivetrain.CanShiftAgain,
			" changingGear: ",
			this.drivetrain.changingGear
		}), new GUILayoutOption[0]);
		GUILayout.Label("clutch.speedDiff: " + this.drivetrain.clutch.speedDiff, new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"gear: ",
			this.drivetrain.gear,
			" clutchEngageSpeed: ",
			this.drivetrain.clutchEngageSpeed
		}), new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"maxPowerDriveShaft: ",
			this.drivetrain.maxPowerDriveShaft * this.drivetrain.powerMultiplier,
			" maxNetPower: ",
			this.drivetrain.maxNetPower * this.drivetrain.powerMultiplier,
			" maxTorque: ",
			this.drivetrain.maxTorque,
			" maxNetTorque: ",
			this.drivetrain.maxNetTorque
		}), new GUILayoutOption[0]);
		GUILayout.Label(string.Concat(new object[]
		{
			"startTorque: ",
			this.drivetrain.startTorque,
			" throttle:",
			this.drivetrain.throttle
		}), new GUILayoutOption[0]);
		GUILayout.Label("% loss power: " + (this.drivetrain.maxPowerDriveShaft - this.drivetrain.maxNetPower) / this.drivetrain.maxPowerDriveShaft * 100f + "%", new GUILayoutOption[0]);
		if (this.forceFeedback != null)
		{
			GUILayout.Label("force feedback: " + this.forceFeedback.force, new GUILayoutOption[0]);
		}
		foreach (Wheel wheel in this.axles.allWheels)
		{
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 280f, 600f, 200f), "hitDown.distance - radius : " + wheel.hitDown.distance);
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 300f, 600f, 200f), string.Concat(new object[]
				{
					"hitDown.normal .x         .z ",
					wheel.hitDown.normal.x,
					" ",
					wheel.hitDown.normal.z
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 320f, 600f, 200f), string.Concat(new object[]
				{
					"groundNormal.x groundNormal.z ",
					wheel.groundNormal.x,
					" ",
					wheel.groundNormal.z
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 340f, 600f, 200f), "wheelRoadVeloLatFL: " + wheel.wheelRoadVeloLat);
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 360f, 600f, 200f), "wheelRoadVeloLatFR: " + wheel.wheelRoadVeloLat);
			}
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 380f, 600f, 200f), "absRoadVelo : " + Mathf.Abs(wheel.wheelRoadVelo));
			}
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 400f, 600f, 200f), string.Concat(new object[]
				{
					"idealSlipRatioFL :",
					wheel.idealSlipRatio,
					" idealSlipAngleFL ",
					wheel.idealSlipAngle
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 420f, 600f, 200f), string.Concat(new object[]
				{
					"idealSlipRatioFR :",
					wheel.idealSlipRatio,
					" idealSlipAngleFR ",
					wheel.idealSlipAngle
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_LEFT)
			{
				GUI.Label(new Rect(300f, 440f, 600f, 200f), string.Concat(new object[]
				{
					"idealSlipRatioRL :",
					wheel.idealSlipRatio,
					" idealSlipAngleRL ",
					wheel.idealSlipAngle
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_RIGHT)
			{
				GUI.Label(new Rect(300f, 460f, 600f, 200f), string.Concat(new object[]
				{
					"idealSlipRatioRR :",
					wheel.idealSlipRatio,
					" idealSlipAngleRR ",
					wheel.idealSlipAngle
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 480f, 600f, 200f), string.Concat(new object[]
				{
					"slipRatioFL: ",
					wheel.slipRatio,
					"    Fx: ",
					wheel.Fx,
					" longitudinalSlip:",
					this.RoundTo(wheel.longitudinalSlip, 3),
					" normalForce:",
					wheel.normalForce
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 500f, 600f, 200f), string.Concat(new object[]
				{
					"slipRatioFR: ",
					wheel.slipRatio,
					"    Fx: ",
					wheel.Fx,
					" longitudinalSlip:",
					this.RoundTo(wheel.longitudinalSlip, 3),
					" normalForce:",
					wheel.normalForce
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_LEFT)
			{
				GUI.Label(new Rect(300f, 520f, 600f, 200f), string.Concat(new object[]
				{
					"slipRatioRL: ",
					wheel.slipRatio,
					"    Fx: ",
					wheel.Fx,
					" longitudinalSlip:",
					this.RoundTo(wheel.longitudinalSlip, 3),
					" normalForce:",
					wheel.normalForce
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_RIGHT)
			{
				GUI.Label(new Rect(300f, 540f, 600f, 200f), string.Concat(new object[]
				{
					"slipRatioRR: ",
					wheel.slipRatio,
					"    Fx: ",
					wheel.Fx,
					" longitudinalSlip:",
					this.RoundTo(wheel.longitudinalSlip, 3),
					" normalForce:",
					wheel.normalForce
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_LEFT)
			{
				GUI.Label(new Rect(300f, 560f, 600f, 200f), string.Concat(new object[]
				{
					"slipAngleFL: ",
					wheel.slipAngle,
					"    Fy: ",
					wheel.Fy,
					" lateralSlip:",
					this.RoundTo(wheel.lateralSlip, 3),
					" rho:",
					Mathf.Sqrt(wheel.lateralSlip * wheel.lateralSlip + wheel.longitudinalSlip * wheel.longitudinalSlip)
				}));
			}
			if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
			{
				GUI.Label(new Rect(300f, 580f, 600f, 200f), string.Concat(new object[]
				{
					"slipAngleFR: ",
					wheel.slipAngle,
					"    Fy: ",
					wheel.Fy,
					" lateralSlip:",
					this.RoundTo(wheel.lateralSlip, 3),
					" rho:",
					Mathf.Sqrt(wheel.lateralSlip * wheel.lateralSlip + wheel.longitudinalSlip * wheel.longitudinalSlip)
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_LEFT)
			{
				GUI.Label(new Rect(300f, 600f, 600f, 200f), string.Concat(new object[]
				{
					"slipAngleRL: ",
					wheel.slipAngle,
					"    Fy: ",
					wheel.Fy,
					" lateralSlip:",
					this.RoundTo(wheel.lateralSlip, 3),
					" rho:",
					Mathf.Sqrt(wheel.lateralSlip * wheel.lateralSlip + wheel.longitudinalSlip * wheel.longitudinalSlip)
				}));
			}
			if (wheel.wheelPos == WheelPos.REAR_RIGHT)
			{
				GUI.Label(new Rect(300f, 620f, 600f, 200f), string.Concat(new object[]
				{
					"slipAngleRR: ",
					wheel.slipAngle,
					"    Fy: ",
					wheel.Fy,
					" lateralSlip:",
					this.RoundTo(wheel.lateralSlip, 3),
					" rho:",
					Mathf.Sqrt(wheel.lateralSlip * wheel.lateralSlip + wheel.longitudinalSlip * wheel.longitudinalSlip)
				}));
			}
		}
	}

	// Token: 0x0400198A RID: 6538
	private Drivetrain drivetrain;

	// Token: 0x0400198B RID: 6539
	private Axles axles;

	// Token: 0x0400198C RID: 6540
	private ForceFeedback forceFeedback;
}
