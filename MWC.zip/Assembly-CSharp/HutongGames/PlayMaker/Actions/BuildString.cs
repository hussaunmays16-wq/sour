﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000154 RID: 340
	[ActionCategory(ActionCategory.String)]
	[Tooltip("Builds a String from other Strings.")]
	public class BuildString : FsmStateAction
	{
		// Token: 0x06000648 RID: 1608 RVA: 0x0002F290 File Offset: 0x0002D490
		public override void Reset()
		{
			this.stringParts = new FsmString[3];
			this.separator = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x0002F2B4 File Offset: 0x0002D4B4
		public override void OnEnter()
		{
			this.DoBuildString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x0002F2D0 File Offset: 0x0002D4D0
		public override void OnUpdate()
		{
			this.DoBuildString();
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x0002F2D8 File Offset: 0x0002D4D8
		private void DoBuildString()
		{
			if (this.storeResult == null)
			{
				return;
			}
			this.result = string.Empty;
			foreach (FsmString arg in this.stringParts)
			{
				this.result += arg;
				this.result += this.separator.Value;
			}
			this.storeResult.Value = this.result;
		}

		// Token: 0x04000941 RID: 2369
		[Tooltip("Array of Strings to combine.")]
		[RequiredField]
		public FsmString[] stringParts;

		// Token: 0x04000942 RID: 2370
		[Tooltip("Separator to insert between each String. E.g. space character.")]
		public FsmString separator;

		// Token: 0x04000943 RID: 2371
		[Tooltip("Store the final String in a variable.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString storeResult;

		// Token: 0x04000944 RID: 2372
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x04000945 RID: 2373
		private string result;
	}
}
