﻿using System;
using UnityEngine;

// Token: 0x020000C0 RID: 192
public class Deformable : MonoBehaviour
{
	// Token: 0x060003A5 RID: 933 RVA: 0x00017D6C File Offset: 0x00015F6C
	private void Awake()
	{
		this.meshCollider = base.GetComponent<MeshCollider>();
		if (!this.meshFilter)
		{
			this.meshFilter = base.GetComponent<MeshFilter>();
		}
		if (this.meshFilter)
		{
			this.LoadMesh();
		}
		else
		{
			Debug.LogWarning("Deformable component warning: No mesh filter assigned for object " + base.gameObject.ToString());
		}
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x00017DD8 File Offset: 0x00015FD8
	private void LoadMesh()
	{
		if (this.meshFilter)
		{
			this.mesh = this.meshFilter.mesh;
		}
		else
		{
			this.mesh = null;
		}
		if (!this.mesh)
		{
			Debug.LogWarning("Deformable component warning: Mesh at mesh filter is null " + base.gameObject.ToString());
			return;
		}
		this.vertices = this.mesh.vertices;
		this.colors = this.mesh.colors32;
		this.baseVertices = this.mesh.vertices;
		this.baseColors = this.mesh.colors32;
		Vector3 size = this.mesh.bounds.size;
		this.sizeFactor = Mathf.Max(1f, Mathf.Min(new float[]
		{
			size.x,
			size.y,
			size.z
		}));
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x00017ED0 File Offset: 0x000160D0
	private void LoadMap()
	{
		this.appliedMap = this.HardnessMap;
		if (this.HardnessMap)
		{
			Vector2[] uv = this.mesh.uv;
			this.map = new float[uv.Length];
			int num = 0;
			foreach (Vector2 vector in uv)
			{
				try
				{
					this.map[num] = this.HardnessMap.GetPixelBilinear(vector.x, vector.y).a;
				}
				catch
				{
					Debug.LogWarning("Deformable component warning: Texture at HardnessMap must be readable (check Read/Write Enabled at import settings). Hardness map not applied.");
					this.map = null;
					break;
				}
				num++;
			}
		}
		else
		{
			this.map = null;
		}
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x00017FB4 File Offset: 0x000161B4
	private void Deform(Collision collision)
	{
		if (!this.mesh || !this.meshFilter)
		{
			return;
		}
		float num = Mathf.Min(1f, collision.relativeVelocity.sqrMagnitude / 1000f);
		if ((double)num < 0.01)
		{
			return;
		}
		float num2 = num * (this.sizeFactor * (0.1f / Mathf.Max(0.1f, this.Hardness)));
		foreach (ContactPoint contactPoint in collision.contacts)
		{
			for (int j = 0; j < this.vertices.Length; j++)
			{
				Vector3 b = this.meshFilter.transform.InverseTransformPoint(contactPoint.point);
				float num3 = (this.vertices[j] - b).sqrMagnitude;
				if (num3 <= num2)
				{
					Vector3 vector = this.meshFilter.transform.InverseTransformDirection(contactPoint.normal * (1f - num3 / num2) * num2);
					if (this.map != null)
					{
						vector *= 1f - this.map[j];
					}
					this.vertices[j] += vector;
					if (this.MaxVertexMov > 0f)
					{
						float maxVertexMov = this.MaxVertexMov;
						vector = this.vertices[j] - this.baseVertices[j];
						num3 = vector.magnitude;
						if (num3 > maxVertexMov)
						{
							this.vertices[j] = this.baseVertices[j] + vector * (maxVertexMov / num3);
						}
						if (this.colors.Length > 0)
						{
							num3 /= this.MaxVertexMov;
							this.colors[j] = Color.Lerp(this.baseColors[j], this.DeformedVertexColor, num3);
						}
					}
					else if (this.colors.Length > 0)
					{
						this.colors[j] = Color.Lerp(this.baseColors[j], this.DeformedVertexColor, (this.vertices[j] - this.baseVertices[j]).magnitude / (num2 * 10f));
					}
				}
			}
		}
		this.RequestUpdateMesh();
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000182A8 File Offset: 0x000164A8
	public void Repair(float repair)
	{
		this.Repair(repair, Vector3.zero, 0f);
	}

	// Token: 0x060003AA RID: 938 RVA: 0x000182BC File Offset: 0x000164BC
	public void Repair(float repair, Vector3 point, float radius)
	{
		if (!this.mesh || !this.meshFilter)
		{
			return;
		}
		point = this.meshFilter.transform.InverseTransformPoint(point);
		int num = 0;
		foreach (Vector3 vector in this.vertices)
		{
			try
			{
				if (radius <= 0f || (point - vector).magnitude < radius)
				{
					Vector3 a = vector - this.baseVertices[num];
					this.vertices[num] = this.baseVertices[num] + a * (1f - repair);
					if (this.colors.Length > 0)
					{
						this.colors[num] = Color.Lerp(this.colors[num], this.baseColors[num], repair);
					}
				}
			}
			finally
			{
				num++;
			}
		}
		this.RequestUpdateMesh();
	}

	// Token: 0x060003AB RID: 939 RVA: 0x00018420 File Offset: 0x00016620
	private void RequestUpdateMesh()
	{
		if (this.UpdateFrequency == 0f)
		{
			this.UpdateMesh();
		}
		else
		{
			this.meshUpdate = true;
		}
	}

	// Token: 0x060003AC RID: 940 RVA: 0x00018450 File Offset: 0x00016650
	private void UpdateMesh()
	{
		this.mesh.vertices = this.vertices;
		if (this.colors.Length > 0)
		{
			this.mesh.colors32 = this.colors;
		}
		this.mesh.RecalculateBounds();
		if (this.meshCollider && this.DeformMeshCollider)
		{
			this.meshCollider.sharedMesh = null;
			this.meshCollider.sharedMesh = this.mesh;
		}
		this.lastUpdate = Time.time;
		this.meshUpdate = false;
	}

	// Token: 0x060003AD RID: 941 RVA: 0x000184E4 File Offset: 0x000166E4
	private void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.layer != 19 && collision.gameObject.layer != 20)
		{
			this.Deform(collision);
		}
	}

	// Token: 0x060003AE RID: 942 RVA: 0x0001851C File Offset: 0x0001671C
	private void FixedUpdate()
	{
		if ((this.meshFilter && this.mesh != this.meshFilter.mesh) || (!this.meshFilter && this.mesh))
		{
			this.LoadMesh();
		}
		if (this.HardnessMap != this.appliedMap)
		{
			this.LoadMap();
		}
		if (this.meshUpdate && Time.time - this.lastUpdate >= 1f / this.UpdateFrequency)
		{
			this.UpdateMesh();
		}
	}

	// Token: 0x04000563 RID: 1379
	public MeshFilter meshFilter;

	// Token: 0x04000564 RID: 1380
	public float Hardness = 0.5f;

	// Token: 0x04000565 RID: 1381
	public bool DeformMeshCollider = true;

	// Token: 0x04000566 RID: 1382
	public float UpdateFrequency;

	// Token: 0x04000567 RID: 1383
	public float MaxVertexMov;

	// Token: 0x04000568 RID: 1384
	public Color32 DeformedVertexColor = Color.gray;

	// Token: 0x04000569 RID: 1385
	public Texture2D HardnessMap;

	// Token: 0x0400056A RID: 1386
	private Mesh mesh;

	// Token: 0x0400056B RID: 1387
	private MeshCollider meshCollider;

	// Token: 0x0400056C RID: 1388
	private Vector3[] baseVertices;

	// Token: 0x0400056D RID: 1389
	private Color32[] baseColors;

	// Token: 0x0400056E RID: 1390
	private float sizeFactor;

	// Token: 0x0400056F RID: 1391
	private Vector3[] vertices;

	// Token: 0x04000570 RID: 1392
	private Color32[] colors;

	// Token: 0x04000571 RID: 1393
	private float[] map;

	// Token: 0x04000572 RID: 1394
	private bool meshUpdate;

	// Token: 0x04000573 RID: 1395
	private float lastUpdate;

	// Token: 0x04000574 RID: 1396
	private Texture2D appliedMap;
}
