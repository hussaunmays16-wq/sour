﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B0 RID: 1200
	[Tooltip("Loads external cInput settings from a string.")]
	[ActionCategory("cInput")]
	public class CInputLoadExternal : FsmStateAction
	{
		// Token: 0x0600146B RID: 5227 RVA: 0x00089094 File Offset: 0x00087294
		public override void OnEnter()
		{
			cInput.LoadExternal(this.cInputSettingsString.Value);
			base.Finish();
		}

		// Token: 0x04001CDF RID: 7391
		[Tooltip("The string containing all the cInput settings.")]
		public FsmString cInputSettingsString;
	}
}
