﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000C8 RID: 200
public class ES2UniqueID : MonoBehaviour
{
	// Token: 0x060003C7 RID: 967 RVA: 0x00018D4C File Offset: 0x00016F4C
	public void Awake()
	{
		this.id = ES2UniqueID.GenerateUniqueID();
		ES2UniqueID.uniqueIDList.Add(this);
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x00018D64 File Offset: 0x00016F64
	public void OnDestroy()
	{
		ES2UniqueID.uniqueIDList.Remove(this);
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x00018D74 File Offset: 0x00016F74
	private static int GenerateUniqueID()
	{
		if (ES2UniqueID.uniqueIDList.Count == 0)
		{
			return 0;
		}
		return ES2UniqueID.uniqueIDList[ES2UniqueID.uniqueIDList.Count - 1].id + 1;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00018DB0 File Offset: 0x00016FB0
	public static ES2UniqueID FindUniqueID(Transform t)
	{
		foreach (ES2UniqueID es2UniqueID in ES2UniqueID.uniqueIDList)
		{
			if (es2UniqueID.transform == t)
			{
				return es2UniqueID;
			}
		}
		return null;
	}

	// Token: 0x060003CB RID: 971 RVA: 0x00018E2C File Offset: 0x0001702C
	public static Transform FindTransform(int id)
	{
		foreach (ES2UniqueID es2UniqueID in ES2UniqueID.uniqueIDList)
		{
			if (es2UniqueID.id == id)
			{
				return es2UniqueID.transform;
			}
		}
		return null;
	}

	// Token: 0x0400057D RID: 1405
	[HideInInspector]
	public int id;

	// Token: 0x0400057E RID: 1406
	public string prefabName = string.Empty;

	// Token: 0x0400057F RID: 1407
	private static List<ES2UniqueID> uniqueIDList = new List<ES2UniqueID>();
}
