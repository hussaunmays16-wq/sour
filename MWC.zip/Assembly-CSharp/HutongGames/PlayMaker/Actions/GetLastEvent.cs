﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000239 RID: 569
	[Tooltip("Gets the event that caused the transition to the current state, and stores it in a String Variable.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetLastEvent : FsmStateAction
	{
		// Token: 0x060009BD RID: 2493 RVA: 0x0003E1D8 File Offset: 0x0003C3D8
		public override void Reset()
		{
			this.storeEvent = null;
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x0003E1E4 File Offset: 0x0003C3E4
		public override void OnEnter()
		{
			this.storeEvent.Value = ((base.Fsm.LastTransition != null) ? base.Fsm.LastTransition.EventName : "START");
			base.Finish();
		}

		// Token: 0x04000DBF RID: 3519
		[UIHint(UIHint.Variable)]
		public FsmString storeEvent;
	}
}
