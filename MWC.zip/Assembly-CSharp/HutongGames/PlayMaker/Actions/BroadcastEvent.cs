﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000153 RID: 339
	[Tooltip("Sends an Event to all FSMs in the scene or to all FSMs on a Game Object.\nNOTE: This action won't work on the very first frame of the game...")]
	[ActionCategory(ActionCategory.StateMachine)]
	[Obsolete("This action is obsolete; use Send Event with Event Target instead.")]
	public class BroadcastEvent : FsmStateAction
	{
		// Token: 0x06000645 RID: 1605 RVA: 0x0002F1B8 File Offset: 0x0002D3B8
		public override void Reset()
		{
			this.broadcastEvent = null;
			this.gameObject = null;
			this.sendToChildren = false;
			this.excludeSelf = false;
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x0002F1EC File Offset: 0x0002D3EC
		public override void OnEnter()
		{
			if (!string.IsNullOrEmpty(this.broadcastEvent.Value))
			{
				if (this.gameObject.Value != null)
				{
					base.Fsm.BroadcastEventToGameObject(this.gameObject.Value, this.broadcastEvent.Value, this.sendToChildren.Value, this.excludeSelf.Value);
				}
				else
				{
					base.Fsm.BroadcastEvent(this.broadcastEvent.Value, this.excludeSelf.Value);
				}
			}
			base.Finish();
		}

		// Token: 0x0400093D RID: 2365
		[RequiredField]
		public FsmString broadcastEvent;

		// Token: 0x0400093E RID: 2366
		[Tooltip("Optionally specify a game object to broadcast the event to all FSMs on that game object.")]
		public FsmGameObject gameObject;

		// Token: 0x0400093F RID: 2367
		[Tooltip("Broadcast to all FSMs on the game object's children.")]
		public FsmBool sendToChildren;

		// Token: 0x04000940 RID: 2368
		public FsmBool excludeSelf;
	}
}
