﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C3 RID: 451
	[Tooltip("Enables/Disables a Behaviour on a GameObject. Optionally reset the Behaviour on exit - useful if you only want the Behaviour to be active while this state is active.")]
	[ActionCategory(ActionCategory.ScriptControl)]
	public class EnableBehaviour : FsmStateAction
	{
		// Token: 0x060007ED RID: 2029 RVA: 0x00037B3C File Offset: 0x00035D3C
		public override void Reset()
		{
			this.gameObject = null;
			this.behaviour = null;
			this.component = null;
			this.enable = true;
			this.resetOnExit = true;
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00037B6C File Offset: 0x00035D6C
		public override void OnEnter()
		{
			this.DoEnableBehaviour(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x00037B8C File Offset: 0x00035D8C
		private void DoEnableBehaviour(GameObject go)
		{
			if (go == null)
			{
				return;
			}
			if (this.component != null)
			{
				this.componentTarget = (this.component as Behaviour);
			}
			else
			{
				this.componentTarget = (go.GetComponent(this.behaviour.Value) as Behaviour);
			}
			if (this.componentTarget == null)
			{
				this.LogWarning(" " + go.name + " missing behaviour: " + this.behaviour.Value);
				return;
			}
			this.componentTarget.enabled = this.enable.Value;
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00037C38 File Offset: 0x00035E38
		public override void OnExit()
		{
			if (this.componentTarget == null)
			{
				return;
			}
			if (this.resetOnExit.Value)
			{
				this.componentTarget.enabled = !this.enable.Value;
			}
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00037C80 File Offset: 0x00035E80
		public override string ErrorCheck()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null || this.component != null || this.behaviour.IsNone || string.IsNullOrEmpty(this.behaviour.Value))
			{
				return null;
			}
			Behaviour x = ownerDefaultTarget.GetComponent(this.behaviour.Value) as Behaviour;
			return (!(x != null)) ? "Behaviour missing" : null;
		}

		// Token: 0x04000B94 RID: 2964
		[RequiredField]
		[Tooltip("The GameObject that owns the Behaviour.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000B95 RID: 2965
		[Tooltip("The name of the Behaviour to enable/disable.")]
		[UIHint(UIHint.Behaviour)]
		public FsmString behaviour;

		// Token: 0x04000B96 RID: 2966
		[Tooltip("Optionally drag a component directly into this field (behavior name will be ignored).")]
		public Component component;

		// Token: 0x04000B97 RID: 2967
		[RequiredField]
		[Tooltip("Set to True to enable, False to disable.")]
		public FsmBool enable;

		// Token: 0x04000B98 RID: 2968
		public FsmBool resetOnExit;

		// Token: 0x04000B99 RID: 2969
		private Behaviour componentTarget;
	}
}
