﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000204 RID: 516
	[Tooltip("Makes an on/off Toggle Button and stores the button state in a Bool Variable.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutToggle : GUILayoutAction
	{
		// Token: 0x060008D9 RID: 2265 RVA: 0x0003AF44 File Offset: 0x00039144
		public override void Reset()
		{
			base.Reset();
			this.storeButtonState = null;
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = "Toggle";
			this.changedEvent = null;
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x0003AF9C File Offset: 0x0003919C
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.storeButtonState.Value = GUILayout.Toggle(this.storeButtonState.Value, new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C98 RID: 3224
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmBool storeButtonState;

		// Token: 0x04000C99 RID: 3225
		public FsmTexture image;

		// Token: 0x04000C9A RID: 3226
		public FsmString text;

		// Token: 0x04000C9B RID: 3227
		public FsmString tooltip;

		// Token: 0x04000C9C RID: 3228
		public FsmString style;

		// Token: 0x04000C9D RID: 3229
		public FsmEvent changedEvent;
	}
}
