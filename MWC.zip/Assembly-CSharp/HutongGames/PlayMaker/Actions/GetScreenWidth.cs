﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000254 RID: 596
	[ActionCategory(ActionCategory.Application)]
	[Tooltip("Gets the Width of the Screen in pixels.")]
	public class GetScreenWidth : FsmStateAction
	{
		// Token: 0x06000A2A RID: 2602 RVA: 0x0003F398 File Offset: 0x0003D598
		public override void Reset()
		{
			this.storeScreenWidth = null;
		}

		// Token: 0x06000A2B RID: 2603 RVA: 0x0003F3A4 File Offset: 0x0003D5A4
		public override void OnEnter()
		{
			this.storeScreenWidth.Value = (float)Screen.width;
			base.Finish();
		}

		// Token: 0x04000E1A RID: 3610
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeScreenWidth;
	}
}
