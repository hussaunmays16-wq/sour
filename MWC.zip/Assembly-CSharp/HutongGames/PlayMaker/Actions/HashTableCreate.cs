﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B8 RID: 952
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Adds a PlayMakerHashTableProxy Component to a Game Object. Use this to create arrayList on the fly instead of during authoring.\n Optionally remove the HashTable component on exiting the state.\n Simply point to existing if the reference exists already.")]
	public class HashTableCreate : HashTableActions
	{
		// Token: 0x06001019 RID: 4121 RVA: 0x00058254 File Offset: 0x00056454
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.alreadyExistsEvent = null;
		}

		// Token: 0x0600101A RID: 4122 RVA: 0x0005826C File Offset: 0x0005646C
		public override void OnEnter()
		{
			this.DoAddPlayMakerHashTable();
			base.Finish();
		}

		// Token: 0x0600101B RID: 4123 RVA: 0x0005827C File Offset: 0x0005647C
		public override void OnExit()
		{
			if (this.removeOnExit.Value && this.addedComponent != null)
			{
				UnityEngine.Object.Destroy(this.addedComponent);
			}
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x000582B8 File Offset: 0x000564B8
		private void DoAddPlayMakerHashTable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			PlayMakerHashTableProxy hashTableProxyPointer = base.GetHashTableProxyPointer(ownerDefaultTarget, this.reference.Value, true);
			if (hashTableProxyPointer != null)
			{
				base.Fsm.Event(this.alreadyExistsEvent);
			}
			else
			{
				this.addedComponent = ownerDefaultTarget.AddComponent<PlayMakerHashTableProxy>();
				if (this.addedComponent == null)
				{
					Debug.LogError("Can't add PlayMakerHashTableProxy");
				}
				else
				{
					this.addedComponent.referenceName = this.reference.Value;
				}
			}
		}

		// Token: 0x040014E4 RID: 5348
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The Game Object to add the Hashtable Component to.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014E5 RID: 5349
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker arrayList proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014E6 RID: 5350
		[Tooltip("Remove the Component when this State is exited.")]
		public FsmBool removeOnExit;

		// Token: 0x040014E7 RID: 5351
		[ActionSection("Result")]
		[Tooltip("The event to trigger if the hashtable exists already")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent alreadyExistsEvent;

		// Token: 0x040014E8 RID: 5352
		private PlayMakerHashTableProxy addedComponent;
	}
}
