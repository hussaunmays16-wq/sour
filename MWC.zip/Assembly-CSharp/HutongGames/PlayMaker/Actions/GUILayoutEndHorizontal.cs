﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F5 RID: 501
	[Tooltip("Close a group started with BeginHorizontal.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutEndHorizontal : FsmStateAction
	{
		// Token: 0x060008AD RID: 2221 RVA: 0x0003A608 File Offset: 0x00038808
		public override void Reset()
		{
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x0003A60C File Offset: 0x0003880C
		public override void OnGUI()
		{
			GUILayout.EndHorizontal();
		}
	}
}
