﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B3 RID: 947
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Swap two items at a specified indexes of a PlayMaker ArrayList Proxy component")]
	public class ArrayListSwapItems : ArrayListActions
	{
		// Token: 0x06001005 RID: 4101 RVA: 0x00057DD8 File Offset: 0x00055FD8
		public override void Reset()
		{
			this.gameObject = null;
			this.failureEvent = null;
			this.reference = null;
			this.index1 = null;
			this.index2 = null;
		}

		// Token: 0x06001006 RID: 4102 RVA: 0x00057E00 File Offset: 0x00056000
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doArrayListSwap();
			}
			base.Finish();
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x00057E40 File Offset: 0x00056040
		public void doArrayListSwap()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			try
			{
				object value = this.proxy.arrayList[this.index2.Value];
				this.proxy.arrayList[this.index2.Value] = this.proxy.arrayList[this.index1.Value];
				this.proxy.arrayList[this.index1.Value] = value;
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Fsm.Event(this.failureEvent);
			}
		}

		// Token: 0x040014D0 RID: 5328
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014D1 RID: 5329
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014D2 RID: 5330
		[Tooltip("The first index to swap")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt index1;

		// Token: 0x040014D3 RID: 5331
		[Tooltip("The second index to swap")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt index2;

		// Token: 0x040014D4 RID: 5332
		[ActionSection("Result")]
		[Tooltip("The event to trigger if the removeAt throw errors")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent failureEvent;
	}
}
