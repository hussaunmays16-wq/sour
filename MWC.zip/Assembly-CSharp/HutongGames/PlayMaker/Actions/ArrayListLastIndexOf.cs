﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A8 RID: 936
	[Tooltip("Return the Last index occurence of an item from a PlayMaker Array List Proxy component. Can search within a range")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListLastIndexOf : ArrayListActions
	{
		// Token: 0x06000FD8 RID: 4056 RVA: 0x000572EC File Offset: 0x000554EC
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.startIndex = null;
			this.count = null;
			this.lastIndexOf = null;
			this.itemFound = null;
			this.itemNotFound = null;
			this.failureEvent = null;
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x00057334 File Offset: 0x00055534
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListLastIndex();
			}
			base.Finish();
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x00057374 File Offset: 0x00055574
		public void DoArrayListLastIndex()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			object valueFromFsmVar = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable);
			int num = -1;
			try
			{
				if (this.startIndex.Value == 0 && this.count.Value == 0)
				{
					num = PlayMakerUtils_Extensions.LastIndexOf(this.proxy.arrayList, valueFromFsmVar);
				}
				else if (this.count.Value == 0)
				{
					if (this.startIndex.Value < 0 || this.startIndex.Value >= this.proxy.arrayList.Count)
					{
						Debug.LogError("start index out of range");
						return;
					}
					num = PlayMakerUtils_Extensions.LastIndexOf(this.proxy.arrayList, valueFromFsmVar, this.startIndex.Value);
				}
				else
				{
					if (this.startIndex.Value < 0 || this.startIndex.Value >= this.proxy.arrayList.Count - this.count.Value)
					{
						Debug.LogError("start index and count out of range");
						return;
					}
					num = PlayMakerUtils_Extensions.LastIndexOf(this.proxy.arrayList, valueFromFsmVar, this.startIndex.Value, this.count.Value);
				}
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Fsm.Event(this.failureEvent);
				return;
			}
			this.lastIndexOf.Value = num;
			if (num == -1)
			{
				base.Fsm.Event(this.itemNotFound);
			}
			else
			{
				base.Fsm.Event(this.itemFound);
			}
		}

		// Token: 0x040014A2 RID: 5282
		[RequiredField]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014A3 RID: 5283
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040014A4 RID: 5284
		[Tooltip("Optional start index to search from: set to 0 to ignore")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt startIndex;

		// Token: 0x040014A5 RID: 5285
		[Tooltip("Optional amount of elements to search within: set to 0 to ignore")]
		[UIHint(UIHint.FsmInt)]
		public FsmInt count;

		// Token: 0x040014A6 RID: 5286
		[RequiredField]
		[Tooltip("The variable to get the index of.")]
		[ActionSection("Data")]
		public FsmVar variable;

		// Token: 0x040014A7 RID: 5287
		[ActionSection("Result")]
		[Tooltip("The index of the last item described below")]
		[RequiredField]
		public FsmInt lastIndexOf;

		// Token: 0x040014A8 RID: 5288
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this arraList contains that element ( described below)")]
		public FsmEvent itemFound;

		// Token: 0x040014A9 RID: 5289
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this arraList does not contains that element ( described below)")]
		public FsmEvent itemNotFound;

		// Token: 0x040014AA RID: 5290
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Optional Event to trigger if the action fails ( likely an out of range exception when using wrong values for index and/or count)")]
		public FsmEvent failureEvent;
	}
}
