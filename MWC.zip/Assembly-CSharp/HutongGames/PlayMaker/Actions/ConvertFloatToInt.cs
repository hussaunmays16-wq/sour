﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000166 RID: 358
	[ActionCategory(ActionCategory.Convert)]
	[Tooltip("Converts a Float value to an Integer value.")]
	public class ConvertFloatToInt : FsmStateAction
	{
		// Token: 0x060006AC RID: 1708 RVA: 0x00030BF8 File Offset: 0x0002EDF8
		public override void Reset()
		{
			this.floatVariable = null;
			this.intVariable = null;
			this.rounding = ConvertFloatToInt.FloatRounding.Nearest;
			this.everyFrame = false;
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00030C18 File Offset: 0x0002EE18
		public override void OnEnter()
		{
			this.DoConvertFloatToInt();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00030C34 File Offset: 0x0002EE34
		public override void OnUpdate()
		{
			this.DoConvertFloatToInt();
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x00030C3C File Offset: 0x0002EE3C
		private void DoConvertFloatToInt()
		{
			switch (this.rounding)
			{
			case ConvertFloatToInt.FloatRounding.RoundDown:
				this.intVariable.Value = Mathf.FloorToInt(this.floatVariable.Value);
				break;
			case ConvertFloatToInt.FloatRounding.RoundUp:
				this.intVariable.Value = Mathf.CeilToInt(this.floatVariable.Value);
				break;
			case ConvertFloatToInt.FloatRounding.Nearest:
				this.intVariable.Value = Mathf.RoundToInt(this.floatVariable.Value);
				break;
			}
		}

		// Token: 0x040009A8 RID: 2472
		[RequiredField]
		[Tooltip("The Float variable to convert to an integer.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x040009A9 RID: 2473
		[Tooltip("Store the result in an Integer variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt intVariable;

		// Token: 0x040009AA RID: 2474
		public ConvertFloatToInt.FloatRounding rounding;

		// Token: 0x040009AB RID: 2475
		public bool everyFrame;

		// Token: 0x02000167 RID: 359
		public enum FloatRounding
		{
			// Token: 0x040009AD RID: 2477
			RoundDown,
			// Token: 0x040009AE RID: 2478
			RoundUp,
			// Token: 0x040009AF RID: 2479
			Nearest
		}
	}
}
