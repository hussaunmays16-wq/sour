﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B2 RID: 1202
	[ActionCategory("cInput")]
	[Tooltip("Removes a cInput modifier key.")]
	public class CInputRemoveModifierString : FsmStateAction
	{
		// Token: 0x06001470 RID: 5232 RVA: 0x000890DC File Offset: 0x000872DC
		public override void Reset()
		{
			this.keyName = null;
		}

		// Token: 0x06001471 RID: 5233 RVA: 0x000890E8 File Offset: 0x000872E8
		public override void OnEnter()
		{
			cInput.RemoveModifier(this.keyName.Value);
			base.Finish();
		}

		// Token: 0x04001CE1 RID: 7393
		[Tooltip("The modifier key to add.")]
		public FsmString keyName;
	}
}
