﻿using System;
using UnityEngine;

// Token: 0x02000456 RID: 1110
[AddComponentMenu("Image Effects/Contrast Stretch")]
public class ContrastStretchEffect : MonoBehaviour
{
	// Token: 0x17000089 RID: 137
	// (get) Token: 0x0600129D RID: 4765 RVA: 0x00068B5C File Offset: 0x00066D5C
	protected Material materialLum
	{
		get
		{
			if (this.m_materialLum == null)
			{
				this.m_materialLum = new Material(this.shaderLum);
				this.m_materialLum.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.m_materialLum;
		}
	}

	// Token: 0x1700008A RID: 138
	// (get) Token: 0x0600129E RID: 4766 RVA: 0x00068B94 File Offset: 0x00066D94
	protected Material materialReduce
	{
		get
		{
			if (this.m_materialReduce == null)
			{
				this.m_materialReduce = new Material(this.shaderReduce);
				this.m_materialReduce.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.m_materialReduce;
		}
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x0600129F RID: 4767 RVA: 0x00068BCC File Offset: 0x00066DCC
	protected Material materialAdapt
	{
		get
		{
			if (this.m_materialAdapt == null)
			{
				this.m_materialAdapt = new Material(this.shaderAdapt);
				this.m_materialAdapt.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.m_materialAdapt;
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x060012A0 RID: 4768 RVA: 0x00068C04 File Offset: 0x00066E04
	protected Material materialApply
	{
		get
		{
			if (this.m_materialApply == null)
			{
				this.m_materialApply = new Material(this.shaderApply);
				this.m_materialApply.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.m_materialApply;
		}
	}

	// Token: 0x060012A1 RID: 4769 RVA: 0x00068C3C File Offset: 0x00066E3C
	private void Start()
	{
		if (!SystemInfo.supportsImageEffects)
		{
			base.enabled = false;
			return;
		}
	}

	// Token: 0x060012A2 RID: 4770 RVA: 0x00068C50 File Offset: 0x00066E50
	private void OnEnable()
	{
		for (int i = 0; i < 2; i++)
		{
			if (!this.adaptRenderTex[i])
			{
				this.adaptRenderTex[i] = new RenderTexture(1, 1, 32);
				this.adaptRenderTex[i].hideFlags = HideFlags.HideAndDontSave;
			}
		}
	}

	// Token: 0x060012A3 RID: 4771 RVA: 0x00068CA4 File Offset: 0x00066EA4
	private void OnDisable()
	{
		for (int i = 0; i < 2; i++)
		{
			UnityEngine.Object.DestroyImmediate(this.adaptRenderTex[i]);
			this.adaptRenderTex[i] = null;
		}
		if (this.m_materialLum)
		{
			UnityEngine.Object.DestroyImmediate(this.m_materialLum);
		}
		if (this.m_materialReduce)
		{
			UnityEngine.Object.DestroyImmediate(this.m_materialReduce);
		}
		if (this.m_materialAdapt)
		{
			UnityEngine.Object.DestroyImmediate(this.m_materialAdapt);
		}
		if (this.m_materialApply)
		{
			UnityEngine.Object.DestroyImmediate(this.m_materialApply);
		}
	}

	// Token: 0x060012A4 RID: 4772 RVA: 0x00068D48 File Offset: 0x00066F48
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		RenderTexture renderTexture = RenderTexture.GetTemporary(source.width / 1, source.height / 1);
		Graphics.Blit(source, renderTexture, this.materialLum);
		while (renderTexture.width > 1 || renderTexture.height > 1)
		{
			int num = renderTexture.width / 2;
			if (num < 1)
			{
				num = 1;
			}
			int num2 = renderTexture.height / 2;
			if (num2 < 1)
			{
				num2 = 1;
			}
			RenderTexture temporary = RenderTexture.GetTemporary(num, num2);
			Graphics.Blit(renderTexture, temporary, this.materialReduce);
			RenderTexture.ReleaseTemporary(renderTexture);
			renderTexture = temporary;
		}
		this.CalculateAdaptation(renderTexture);
		this.materialApply.SetTexture("_AdaptTex", this.adaptRenderTex[this.curAdaptIndex]);
		Graphics.Blit(source, destination, this.materialApply);
		RenderTexture.ReleaseTemporary(renderTexture);
	}

	// Token: 0x060012A5 RID: 4773 RVA: 0x00068E18 File Offset: 0x00067018
	private void CalculateAdaptation(Texture curTexture)
	{
		int num = this.curAdaptIndex;
		this.curAdaptIndex = (this.curAdaptIndex + 1) % 2;
		float num2 = 1f - Mathf.Pow(1f - this.adaptationSpeed, 30f * Time.deltaTime);
		num2 = Mathf.Clamp(num2, 0.01f, 1f);
		this.materialAdapt.SetTexture("_CurTex", curTexture);
		this.materialAdapt.SetVector("_AdaptParams", new Vector4(num2, this.limitMinimum, this.limitMaximum, 0f));
		Graphics.Blit(this.adaptRenderTex[num], this.adaptRenderTex[this.curAdaptIndex], this.materialAdapt);
	}

	// Token: 0x0400184B RID: 6219
	public float adaptationSpeed = 0.02f;

	// Token: 0x0400184C RID: 6220
	public float limitMinimum = 0.2f;

	// Token: 0x0400184D RID: 6221
	public float limitMaximum = 0.6f;

	// Token: 0x0400184E RID: 6222
	private RenderTexture[] adaptRenderTex = new RenderTexture[2];

	// Token: 0x0400184F RID: 6223
	private int curAdaptIndex;

	// Token: 0x04001850 RID: 6224
	public Shader shaderLum;

	// Token: 0x04001851 RID: 6225
	private Material m_materialLum;

	// Token: 0x04001852 RID: 6226
	public Shader shaderReduce;

	// Token: 0x04001853 RID: 6227
	private Material m_materialReduce;

	// Token: 0x04001854 RID: 6228
	public Shader shaderAdapt;

	// Token: 0x04001855 RID: 6229
	private Material m_materialAdapt;

	// Token: 0x04001856 RID: 6230
	public Shader shaderApply;

	// Token: 0x04001857 RID: 6231
	private Material m_materialApply;
}
