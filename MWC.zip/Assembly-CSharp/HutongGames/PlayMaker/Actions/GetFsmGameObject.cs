﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000228 RID: 552
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Get the value of a Game Object Variable from another FSM.")]
	public class GetFsmGameObject : FsmStateAction
	{
		// Token: 0x0600096C RID: 2412 RVA: 0x0003D1C8 File Offset: 0x0003B3C8
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x0003D1E8 File Offset: 0x0003B3E8
		public override void OnEnter()
		{
			this.DoGetFsmGameObject();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x0003D204 File Offset: 0x0003B404
		public override void OnUpdate()
		{
			this.DoGetFsmGameObject();
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x0003D20C File Offset: 0x0003B40C
		private void DoGetFsmGameObject()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmGameObject fsmGameObject = this.fsm.FsmVariables.GetFsmGameObject(this.variableName.Value);
			if (fsmGameObject == null)
			{
				return;
			}
			this.storeValue.Value = fsmGameObject.Value;
		}

		// Token: 0x04000D54 RID: 3412
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D55 RID: 3413
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D56 RID: 3414
		[UIHint(UIHint.FsmGameObject)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D57 RID: 3415
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmGameObject storeValue;

		// Token: 0x04000D58 RID: 3416
		public bool everyFrame;

		// Token: 0x04000D59 RID: 3417
		private GameObject goLastFrame;

		// Token: 0x04000D5A RID: 3418
		private PlayMakerFSM fsm;
	}
}
