﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000262 RID: 610
	[Tooltip("Gets info on the last Trigger event and store in variables.")]
	[ActionCategory(ActionCategory.Physics)]
	public class GetTriggerInfo : FsmStateAction
	{
		// Token: 0x06000A66 RID: 2662 RVA: 0x0003FD64 File Offset: 0x0003DF64
		public override void Reset()
		{
			this.gameObjectHit = null;
			this.physicsMaterialName = null;
		}

		// Token: 0x06000A67 RID: 2663 RVA: 0x0003FD74 File Offset: 0x0003DF74
		private void StoreTriggerInfo()
		{
			if (base.Fsm.TriggerCollider == null)
			{
				return;
			}
			this.gameObjectHit.Value = base.Fsm.TriggerCollider.gameObject;
			this.physicsMaterialName.Value = base.Fsm.TriggerCollider.material.name;
		}

		// Token: 0x06000A68 RID: 2664 RVA: 0x0003FDD4 File Offset: 0x0003DFD4
		public override void OnEnter()
		{
			this.StoreTriggerInfo();
			base.Finish();
		}

		// Token: 0x04000E54 RID: 3668
		[UIHint(UIHint.Variable)]
		public FsmGameObject gameObjectHit;

		// Token: 0x04000E55 RID: 3669
		[Tooltip("Useful for triggering different effects. Audio, particles...")]
		[UIHint(UIHint.Variable)]
		public FsmString physicsMaterialName;
	}
}
