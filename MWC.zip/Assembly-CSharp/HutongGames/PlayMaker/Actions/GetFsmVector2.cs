﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000233 RID: 563
	[Tooltip("Get the value of a Vector2 Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmVector2 : FsmStateAction
	{
		// Token: 0x060009A5 RID: 2469 RVA: 0x0003DE84 File Offset: 0x0003C084
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x0003DEA4 File Offset: 0x0003C0A4
		public override void OnEnter()
		{
			this.DoGetFsmVector2();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x0003DEC0 File Offset: 0x0003C0C0
		public override void OnUpdate()
		{
			this.DoGetFsmVector2();
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x0003DEC8 File Offset: 0x0003C0C8
		private void DoGetFsmVector2()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmVector2 fsmVector = this.fsm.FsmVariables.GetFsmVector2(this.variableName.Value);
			if (fsmVector == null)
			{
				return;
			}
			this.storeValue.Value = fsmVector.Value;
		}

		// Token: 0x04000DA2 RID: 3490
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DA3 RID: 3491
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000DA4 RID: 3492
		[UIHint(UIHint.FsmVector2)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000DA5 RID: 3493
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmVector2 storeValue;

		// Token: 0x04000DA6 RID: 3494
		public bool everyFrame;

		// Token: 0x04000DA7 RID: 3495
		private GameObject goLastFrame;

		// Token: 0x04000DA8 RID: 3496
		private PlayMakerFSM fsm;
	}
}
