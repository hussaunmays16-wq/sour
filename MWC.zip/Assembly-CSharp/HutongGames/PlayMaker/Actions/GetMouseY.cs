﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000244 RID: 580
	[Tooltip("Gets the Y Position of the mouse and stores it in a Float Variable.")]
	[ActionCategory(ActionCategory.Input)]
	public class GetMouseY : FsmStateAction
	{
		// Token: 0x060009E6 RID: 2534 RVA: 0x0003E898 File Offset: 0x0003CA98
		public override void Reset()
		{
			this.storeResult = null;
			this.normalize = true;
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x0003E8A8 File Offset: 0x0003CAA8
		public override void OnEnter()
		{
			this.DoGetMouseY();
		}

		// Token: 0x060009E8 RID: 2536 RVA: 0x0003E8B0 File Offset: 0x0003CAB0
		public override void OnUpdate()
		{
			this.DoGetMouseY();
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0003E8B8 File Offset: 0x0003CAB8
		private void DoGetMouseY()
		{
			if (this.storeResult != null)
			{
				float num = Input.mousePosition.y;
				if (this.normalize)
				{
					num /= (float)Screen.height;
				}
				this.storeResult.Value = num;
			}
		}

		// Token: 0x04000DE0 RID: 3552
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeResult;

		// Token: 0x04000DE1 RID: 3553
		public bool normalize;
	}
}
