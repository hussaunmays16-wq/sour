﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200013C RID: 316
	[Tooltip("Ease base action - don't use!")]
	public abstract class EaseFsmAction : FsmStateAction
	{
		// Token: 0x060005D0 RID: 1488 RVA: 0x0002CC5C File Offset: 0x0002AE5C
		public override void Reset()
		{
			this.easeType = EaseFsmAction.EaseType.linear;
			this.time = new FsmFloat
			{
				Value = 1f
			};
			this.delay = new FsmFloat
			{
				UseVariable = true
			};
			this.speed = new FsmFloat
			{
				UseVariable = true
			};
			this.reverse = new FsmBool
			{
				Value = false
			};
			this.realTime = false;
			this.finishEvent = null;
			this.ease = null;
			this.runningTime = 0f;
			this.lastTime = 0f;
			this.percentage = 0f;
			this.fromFloats = new float[0];
			this.toFloats = new float[0];
			this.resultFloats = new float[0];
			this.finishAction = false;
			this.start = false;
			this.finished = false;
			this.isRunning = false;
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x0002CD3C File Offset: 0x0002AF3C
		public override void OnEnter()
		{
			this.finished = false;
			this.isRunning = false;
			this.SetEasingFunction();
			this.runningTime = 0f;
			this.percentage = ((!this.reverse.IsNone) ? ((!this.reverse.Value) ? 0f : 1f) : 0f);
			this.finishAction = false;
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
			this.delayTime = ((!this.delay.IsNone) ? (this.delayTime = this.delay.Value) : 0f);
			this.start = true;
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x0002CE08 File Offset: 0x0002B008
		public override void OnExit()
		{
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x0002CE0C File Offset: 0x0002B00C
		public override void OnUpdate()
		{
			if (this.start && !this.isRunning)
			{
				if (this.delayTime >= 0f)
				{
					if (this.realTime)
					{
						this.deltaTime = FsmTime.RealtimeSinceStartup - this.startTime - this.lastTime;
						this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
						this.delayTime -= this.deltaTime;
					}
					else
					{
						this.delayTime -= Time.deltaTime;
					}
				}
				else
				{
					this.isRunning = true;
					this.start = false;
					this.startTime = FsmTime.RealtimeSinceStartup;
					this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
				}
			}
			if (this.isRunning && !this.finished)
			{
				if (this.reverse.IsNone || !this.reverse.Value)
				{
					this.UpdatePercentage();
					if (this.percentage < 1f)
					{
						for (int i = 0; i < this.fromFloats.Length; i++)
						{
							this.resultFloats[i] = this.ease(this.fromFloats[i], this.toFloats[i], this.percentage);
						}
					}
					else
					{
						this.finishAction = true;
						this.finished = true;
						this.isRunning = false;
					}
				}
				else
				{
					this.UpdatePercentage();
					if (this.percentage > 0f)
					{
						for (int j = 0; j < this.fromFloats.Length; j++)
						{
							this.resultFloats[j] = this.ease(this.fromFloats[j], this.toFloats[j], this.percentage);
						}
					}
					else
					{
						this.finishAction = true;
						this.finished = true;
						this.isRunning = false;
					}
				}
			}
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x0002CFF4 File Offset: 0x0002B1F4
		protected void UpdatePercentage()
		{
			if (this.realTime)
			{
				this.deltaTime = FsmTime.RealtimeSinceStartup - this.startTime - this.lastTime;
				this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
				if (!this.speed.IsNone)
				{
					this.runningTime += this.deltaTime * this.speed.Value;
				}
				else
				{
					this.runningTime += this.deltaTime;
				}
			}
			else if (!this.speed.IsNone)
			{
				this.runningTime += Time.deltaTime * this.speed.Value;
			}
			else
			{
				this.runningTime += Time.deltaTime;
			}
			if (!this.reverse.IsNone && this.reverse.Value)
			{
				this.percentage = 1f - this.runningTime / this.time.Value;
			}
			else
			{
				this.percentage = this.runningTime / this.time.Value;
			}
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x0002D12C File Offset: 0x0002B32C
		protected void SetEasingFunction()
		{
			switch (this.easeType)
			{
			case EaseFsmAction.EaseType.easeInQuad:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInQuad);
				break;
			case EaseFsmAction.EaseType.easeOutQuad:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutQuad);
				break;
			case EaseFsmAction.EaseType.easeInOutQuad:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutQuad);
				break;
			case EaseFsmAction.EaseType.easeInCubic:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInCubic);
				break;
			case EaseFsmAction.EaseType.easeOutCubic:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutCubic);
				break;
			case EaseFsmAction.EaseType.easeInOutCubic:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutCubic);
				break;
			case EaseFsmAction.EaseType.easeInQuart:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInQuart);
				break;
			case EaseFsmAction.EaseType.easeOutQuart:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutQuart);
				break;
			case EaseFsmAction.EaseType.easeInOutQuart:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutQuart);
				break;
			case EaseFsmAction.EaseType.easeInQuint:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInQuint);
				break;
			case EaseFsmAction.EaseType.easeOutQuint:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutQuint);
				break;
			case EaseFsmAction.EaseType.easeInOutQuint:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutQuint);
				break;
			case EaseFsmAction.EaseType.easeInSine:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInSine);
				break;
			case EaseFsmAction.EaseType.easeOutSine:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutSine);
				break;
			case EaseFsmAction.EaseType.easeInOutSine:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutSine);
				break;
			case EaseFsmAction.EaseType.easeInExpo:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInExpo);
				break;
			case EaseFsmAction.EaseType.easeOutExpo:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutExpo);
				break;
			case EaseFsmAction.EaseType.easeInOutExpo:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutExpo);
				break;
			case EaseFsmAction.EaseType.easeInCirc:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInCirc);
				break;
			case EaseFsmAction.EaseType.easeOutCirc:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutCirc);
				break;
			case EaseFsmAction.EaseType.easeInOutCirc:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutCirc);
				break;
			case EaseFsmAction.EaseType.linear:
				this.ease = new EaseFsmAction.EasingFunction(this.linear);
				break;
			case EaseFsmAction.EaseType.spring:
				this.ease = new EaseFsmAction.EasingFunction(this.spring);
				break;
			case EaseFsmAction.EaseType.bounce:
				this.ease = new EaseFsmAction.EasingFunction(this.bounce);
				break;
			case EaseFsmAction.EaseType.easeInBack:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInBack);
				break;
			case EaseFsmAction.EaseType.easeOutBack:
				this.ease = new EaseFsmAction.EasingFunction(this.easeOutBack);
				break;
			case EaseFsmAction.EaseType.easeInOutBack:
				this.ease = new EaseFsmAction.EasingFunction(this.easeInOutBack);
				break;
			case EaseFsmAction.EaseType.elastic:
				this.ease = new EaseFsmAction.EasingFunction(this.elastic);
				break;
			}
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x0002D440 File Offset: 0x0002B640
		protected float linear(float start, float end, float value)
		{
			return Mathf.Lerp(start, end, value);
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x0002D44C File Offset: 0x0002B64C
		protected float clerp(float start, float end, float value)
		{
			float num = 0f;
			float num2 = 360f;
			float num3 = Mathf.Abs((num2 - num) / 2f);
			float result;
			if (end - start < -num3)
			{
				float num4 = (num2 - start + end) * value;
				result = start + num4;
			}
			else if (end - start > num3)
			{
				float num4 = -(num2 - end + start) * value;
				result = start + num4;
			}
			else
			{
				result = start + (end - start) * value;
			}
			return result;
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x0002D4C4 File Offset: 0x0002B6C4
		protected float spring(float start, float end, float value)
		{
			value = Mathf.Clamp01(value);
			value = (Mathf.Sin(value * 3.1415927f * (0.2f + 2.5f * value * value * value)) * Mathf.Pow(1f - value, 2.2f) + value) * (1f + 1.2f * (1f - value));
			return start + (end - start) * value;
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0002D528 File Offset: 0x0002B728
		protected float easeInQuad(float start, float end, float value)
		{
			end -= start;
			return end * value * value + start;
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x0002D538 File Offset: 0x0002B738
		protected float easeOutQuad(float start, float end, float value)
		{
			end -= start;
			return -end * value * (value - 2f) + start;
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x0002D550 File Offset: 0x0002B750
		protected float easeInOutQuad(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end / 2f * value * value + start;
			}
			value -= 1f;
			return -end / 2f * (value * (value - 2f) - 1f) + start;
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x0002D5A8 File Offset: 0x0002B7A8
		protected float easeInCubic(float start, float end, float value)
		{
			end -= start;
			return end * value * value * value + start;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0002D5B8 File Offset: 0x0002B7B8
		protected float easeOutCubic(float start, float end, float value)
		{
			value -= 1f;
			end -= start;
			return end * (value * value * value + 1f) + start;
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x0002D5D8 File Offset: 0x0002B7D8
		protected float easeInOutCubic(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end / 2f * value * value * value + start;
			}
			value -= 2f;
			return end / 2f * (value * value * value + 2f) + start;
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0002D62C File Offset: 0x0002B82C
		protected float easeInQuart(float start, float end, float value)
		{
			end -= start;
			return end * value * value * value * value + start;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x0002D640 File Offset: 0x0002B840
		protected float easeOutQuart(float start, float end, float value)
		{
			value -= 1f;
			end -= start;
			return -end * (value * value * value * value - 1f) + start;
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x0002D670 File Offset: 0x0002B870
		protected float easeInOutQuart(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end / 2f * value * value * value * value + start;
			}
			value -= 2f;
			return -end / 2f * (value * value * value * value - 2f) + start;
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0002D6CC File Offset: 0x0002B8CC
		protected float easeInQuint(float start, float end, float value)
		{
			end -= start;
			return end * value * value * value * value * value + start;
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x0002D6E0 File Offset: 0x0002B8E0
		protected float easeOutQuint(float start, float end, float value)
		{
			value -= 1f;
			end -= start;
			return end * (value * value * value * value * value + 1f) + start;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0002D704 File Offset: 0x0002B904
		protected float easeInOutQuint(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end / 2f * value * value * value * value * value + start;
			}
			value -= 2f;
			return end / 2f * (value * value * value * value * value + 2f) + start;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x0002D760 File Offset: 0x0002B960
		protected float easeInSine(float start, float end, float value)
		{
			end -= start;
			return -end * Mathf.Cos(value / 1f * 1.5707964f) + end + start;
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x0002D780 File Offset: 0x0002B980
		protected float easeOutSine(float start, float end, float value)
		{
			end -= start;
			return end * Mathf.Sin(value / 1f * 1.5707964f) + start;
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x0002D7A0 File Offset: 0x0002B9A0
		protected float easeInOutSine(float start, float end, float value)
		{
			end -= start;
			return -end / 2f * (Mathf.Cos(3.1415927f * value / 1f) - 1f) + start;
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x0002D7D8 File Offset: 0x0002B9D8
		protected float easeInExpo(float start, float end, float value)
		{
			end -= start;
			return end * Mathf.Pow(2f, 10f * (value / 1f - 1f)) + start;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x0002D80C File Offset: 0x0002BA0C
		protected float easeOutExpo(float start, float end, float value)
		{
			end -= start;
			return end * (-Mathf.Pow(2f, -10f * value / 1f) + 1f) + start;
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x0002D838 File Offset: 0x0002BA38
		protected float easeInOutExpo(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end / 2f * Mathf.Pow(2f, 10f * (value - 1f)) + start;
			}
			value -= 1f;
			return end / 2f * (-Mathf.Pow(2f, -10f * value) + 2f) + start;
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x0002D8AC File Offset: 0x0002BAAC
		protected float easeInCirc(float start, float end, float value)
		{
			end -= start;
			return -end * (Mathf.Sqrt(1f - value * value) - 1f) + start;
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x0002D8CC File Offset: 0x0002BACC
		protected float easeOutCirc(float start, float end, float value)
		{
			value -= 1f;
			end -= start;
			return end * Mathf.Sqrt(1f - value * value) + start;
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x0002D8FC File Offset: 0x0002BAFC
		protected float easeInOutCirc(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return -end / 2f * (Mathf.Sqrt(1f - value * value) - 1f) + start;
			}
			value -= 2f;
			return end / 2f * (Mathf.Sqrt(1f - value * value) + 1f) + start;
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x0002D96C File Offset: 0x0002BB6C
		protected float bounce(float start, float end, float value)
		{
			value /= 1f;
			end -= start;
			if (value < 0.36363637f)
			{
				return end * (7.5625f * value * value) + start;
			}
			if (value < 0.72727275f)
			{
				value -= 0.54545456f;
				return end * (7.5625f * value * value + 0.75f) + start;
			}
			if ((double)value < 0.9090909090909091)
			{
				value -= 0.8181818f;
				return end * (7.5625f * value * value + 0.9375f) + start;
			}
			value -= 0.95454544f;
			return end * (7.5625f * value * value + 0.984375f) + start;
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x0002DA14 File Offset: 0x0002BC14
		protected float easeInBack(float start, float end, float value)
		{
			end -= start;
			value /= 1f;
			float num = 1.70158f;
			return end * value * value * ((num + 1f) * value - num) + start;
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0002DA48 File Offset: 0x0002BC48
		protected float easeOutBack(float start, float end, float value)
		{
			float num = 1.70158f;
			end -= start;
			value = value / 1f - 1f;
			return end * (value * value * ((num + 1f) * value + num) + 1f) + start;
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0002DA88 File Offset: 0x0002BC88
		protected float easeInOutBack(float start, float end, float value)
		{
			float num = 1.70158f;
			end -= start;
			value /= 0.5f;
			if (value < 1f)
			{
				num *= 1.525f;
				return end / 2f * (value * value * ((num + 1f) * value - num)) + start;
			}
			value -= 2f;
			num *= 1.525f;
			return end / 2f * (value * value * ((num + 1f) * value + num) + 2f) + start;
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x0002DB08 File Offset: 0x0002BD08
		protected float punch(float amplitude, float value)
		{
			if (value == 0f)
			{
				return 0f;
			}
			if (value == 1f)
			{
				return 0f;
			}
			float num = 0.3f;
			float num2 = num / 6.2831855f * Mathf.Asin(0f);
			return amplitude * Mathf.Pow(2f, -10f * value) * Mathf.Sin((value * 1f - num2) * 6.2831855f / num);
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x0002DB80 File Offset: 0x0002BD80
		protected float elastic(float start, float end, float value)
		{
			end -= start;
			float num = 1f;
			float num2 = num * 0.3f;
			float num3 = 0f;
			if (value == 0f)
			{
				return start;
			}
			if ((value /= num) == 1f)
			{
				return start + end;
			}
			float num4;
			if (num3 == 0f || num3 < Mathf.Abs(end))
			{
				num3 = end;
				num4 = num2 / 4f;
			}
			else
			{
				num4 = num2 / 6.2831855f * Mathf.Asin(end / num3);
			}
			return num3 * Mathf.Pow(2f, -10f * value) * Mathf.Sin((value * num - num4) * 6.2831855f / num2) + end + start;
		}

		// Token: 0x040008BB RID: 2235
		[RequiredField]
		public FsmFloat time;

		// Token: 0x040008BC RID: 2236
		public FsmFloat speed;

		// Token: 0x040008BD RID: 2237
		public FsmFloat delay;

		// Token: 0x040008BE RID: 2238
		public EaseFsmAction.EaseType easeType = EaseFsmAction.EaseType.linear;

		// Token: 0x040008BF RID: 2239
		public FsmBool reverse;

		// Token: 0x040008C0 RID: 2240
		[Tooltip("Optionally send an Event when the animation finishes.")]
		public FsmEvent finishEvent;

		// Token: 0x040008C1 RID: 2241
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x040008C2 RID: 2242
		protected EaseFsmAction.EasingFunction ease;

		// Token: 0x040008C3 RID: 2243
		protected float runningTime;

		// Token: 0x040008C4 RID: 2244
		protected float lastTime;

		// Token: 0x040008C5 RID: 2245
		protected float startTime;

		// Token: 0x040008C6 RID: 2246
		protected float deltaTime;

		// Token: 0x040008C7 RID: 2247
		protected float delayTime;

		// Token: 0x040008C8 RID: 2248
		protected float percentage;

		// Token: 0x040008C9 RID: 2249
		protected float[] fromFloats = new float[0];

		// Token: 0x040008CA RID: 2250
		protected float[] toFloats = new float[0];

		// Token: 0x040008CB RID: 2251
		protected float[] resultFloats = new float[0];

		// Token: 0x040008CC RID: 2252
		protected bool finishAction;

		// Token: 0x040008CD RID: 2253
		protected bool start;

		// Token: 0x040008CE RID: 2254
		protected bool finished;

		// Token: 0x040008CF RID: 2255
		protected bool isRunning;

		// Token: 0x0200013D RID: 317
		public enum EaseType
		{
			// Token: 0x040008D1 RID: 2257
			easeInQuad,
			// Token: 0x040008D2 RID: 2258
			easeOutQuad,
			// Token: 0x040008D3 RID: 2259
			easeInOutQuad,
			// Token: 0x040008D4 RID: 2260
			easeInCubic,
			// Token: 0x040008D5 RID: 2261
			easeOutCubic,
			// Token: 0x040008D6 RID: 2262
			easeInOutCubic,
			// Token: 0x040008D7 RID: 2263
			easeInQuart,
			// Token: 0x040008D8 RID: 2264
			easeOutQuart,
			// Token: 0x040008D9 RID: 2265
			easeInOutQuart,
			// Token: 0x040008DA RID: 2266
			easeInQuint,
			// Token: 0x040008DB RID: 2267
			easeOutQuint,
			// Token: 0x040008DC RID: 2268
			easeInOutQuint,
			// Token: 0x040008DD RID: 2269
			easeInSine,
			// Token: 0x040008DE RID: 2270
			easeOutSine,
			// Token: 0x040008DF RID: 2271
			easeInOutSine,
			// Token: 0x040008E0 RID: 2272
			easeInExpo,
			// Token: 0x040008E1 RID: 2273
			easeOutExpo,
			// Token: 0x040008E2 RID: 2274
			easeInOutExpo,
			// Token: 0x040008E3 RID: 2275
			easeInCirc,
			// Token: 0x040008E4 RID: 2276
			easeOutCirc,
			// Token: 0x040008E5 RID: 2277
			easeInOutCirc,
			// Token: 0x040008E6 RID: 2278
			linear,
			// Token: 0x040008E7 RID: 2279
			spring,
			// Token: 0x040008E8 RID: 2280
			bounce,
			// Token: 0x040008E9 RID: 2281
			easeInBack,
			// Token: 0x040008EA RID: 2282
			easeOutBack,
			// Token: 0x040008EB RID: 2283
			easeInOutBack,
			// Token: 0x040008EC RID: 2284
			elastic,
			// Token: 0x040008ED RID: 2285
			punch
		}

		// Token: 0x020004E4 RID: 1252
		// (Invoke) Token: 0x0600160D RID: 5645
		protected delegate float EasingFunction(float start, float end, float value);
	}
}
