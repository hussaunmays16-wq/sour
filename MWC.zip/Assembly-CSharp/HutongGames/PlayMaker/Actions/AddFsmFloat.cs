﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000129 RID: 297
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Add the value of a Float Variable in another FSM.")]
	public class AddFsmFloat : FsmStateAction
	{
		// Token: 0x0600057E RID: 1406 RVA: 0x00029040 File Offset: 0x00027240
		public override void Reset()
		{
			this.gameObject = null;
			this.perSecond = false;
			this.fsmName = string.Empty;
			this.addValue = null;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00029068 File Offset: 0x00027268
		public override void OnEnter()
		{
			this.DoSubtractFsmFloat();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x00029084 File Offset: 0x00027284
		private void DoSubtractFsmFloat()
		{
			if (this.addValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				this.LogWarning("Could not find FSM: " + this.fsmName.Value);
				return;
			}
			FsmFloat fsmFloat = this.fsm.FsmVariables.GetFsmFloat(this.variableName.Value);
			if (fsmFloat != null && !this.perSecond)
			{
				fsmFloat.Value += this.addValue.Value;
			}
			if (fsmFloat != null && this.perSecond)
			{
				fsmFloat.Value += this.addValue.Value * Time.deltaTime;
			}
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x0002918C File Offset: 0x0002738C
		public override void OnUpdate()
		{
			this.DoSubtractFsmFloat();
		}

		// Token: 0x04000805 RID: 2053
		[Tooltip("The GameObject that owns the FSM.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000806 RID: 2054
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000807 RID: 2055
		[UIHint(UIHint.FsmFloat)]
		[Tooltip("The name of the FSM variable.")]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000808 RID: 2056
		[RequiredField]
		[Tooltip("Add this from the target variable.")]
		public FsmFloat addValue;

		// Token: 0x04000809 RID: 2057
		[Tooltip("Repeat every frame. Useful if the value is changing.")]
		public bool everyFrame;

		// Token: 0x0400080A RID: 2058
		[Tooltip("Use with Every Frame only to continue over time")]
		public bool perSecond;

		// Token: 0x0400080B RID: 2059
		private GameObject goLastFrame;

		// Token: 0x0400080C RID: 2060
		private PlayMakerFSM fsm;
	}
}
