﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000260 RID: 608
	[ActionCategory(ActionCategory.Device)]
	[Tooltip("Gets info on a touch event.")]
	public class GetTouchInfo : FsmStateAction
	{
		// Token: 0x06000A5C RID: 2652 RVA: 0x0003FA30 File Offset: 0x0003DC30
		public override void Reset()
		{
			this.fingerId = new FsmInt
			{
				UseVariable = true
			};
			this.normalize = true;
			this.storePosition = null;
			this.storeDeltaPosition = null;
			this.storeDeltaTime = null;
			this.storeTapCount = null;
			this.everyFrame = true;
		}

		// Token: 0x06000A5D RID: 2653 RVA: 0x0003FA80 File Offset: 0x0003DC80
		public override void OnEnter()
		{
			this.screenWidth = (float)Screen.width;
			this.screenHeight = (float)Screen.height;
			this.DoGetTouchInfo();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A5E RID: 2654 RVA: 0x0003FAB4 File Offset: 0x0003DCB4
		public override void OnUpdate()
		{
			this.DoGetTouchInfo();
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x0003FABC File Offset: 0x0003DCBC
		private void DoGetTouchInfo()
		{
			if (Input.touchCount > 0)
			{
				foreach (Touch touch in Input.touches)
				{
					if (this.fingerId.IsNone || touch.fingerId == this.fingerId.Value)
					{
						float num = this.normalize.Value ? (touch.position.x / this.screenWidth) : touch.position.x;
						float num2 = this.normalize.Value ? (touch.position.y / this.screenHeight) : touch.position.y;
						if (!this.storePosition.IsNone)
						{
							this.storePosition.Value = new Vector3(num, num2, 0f);
						}
						this.storeX.Value = num;
						this.storeY.Value = num2;
						float num3 = this.normalize.Value ? (touch.deltaPosition.x / this.screenWidth) : touch.deltaPosition.x;
						float num4 = this.normalize.Value ? (touch.deltaPosition.y / this.screenHeight) : touch.deltaPosition.y;
						if (!this.storeDeltaPosition.IsNone)
						{
							this.storeDeltaPosition.Value = new Vector3(num3, num4, 0f);
						}
						this.storeDeltaX.Value = num3;
						this.storeDeltaY.Value = num4;
						this.storeDeltaTime.Value = touch.deltaTime;
						this.storeTapCount.Value = touch.tapCount;
					}
				}
			}
		}

		// Token: 0x04000E44 RID: 3652
		[Tooltip("Filter by a Finger ID. You can store a Finger ID in other Touch actions, e.g., Touch Event.")]
		public FsmInt fingerId;

		// Token: 0x04000E45 RID: 3653
		[Tooltip("If true, all screen coordinates are returned normalized (0-1), otherwise in pixels.")]
		public FsmBool normalize;

		// Token: 0x04000E46 RID: 3654
		[UIHint(UIHint.Variable)]
		public FsmVector3 storePosition;

		// Token: 0x04000E47 RID: 3655
		[UIHint(UIHint.Variable)]
		public FsmFloat storeX;

		// Token: 0x04000E48 RID: 3656
		[UIHint(UIHint.Variable)]
		public FsmFloat storeY;

		// Token: 0x04000E49 RID: 3657
		[UIHint(UIHint.Variable)]
		public FsmVector3 storeDeltaPosition;

		// Token: 0x04000E4A RID: 3658
		[UIHint(UIHint.Variable)]
		public FsmFloat storeDeltaX;

		// Token: 0x04000E4B RID: 3659
		[UIHint(UIHint.Variable)]
		public FsmFloat storeDeltaY;

		// Token: 0x04000E4C RID: 3660
		[UIHint(UIHint.Variable)]
		public FsmFloat storeDeltaTime;

		// Token: 0x04000E4D RID: 3661
		[UIHint(UIHint.Variable)]
		public FsmInt storeTapCount;

		// Token: 0x04000E4E RID: 3662
		public bool everyFrame = true;

		// Token: 0x04000E4F RID: 3663
		private float screenWidth;

		// Token: 0x04000E50 RID: 3664
		private float screenHeight;
	}
}
