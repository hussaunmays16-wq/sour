﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001EA RID: 490
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Begin a GUILayout area that follows the specified game object. Useful for overlays (e.g., playerName). NOTE: Block must end with a corresponding GUILayoutEndArea.")]
	public class GUILayoutBeginAreaFollowObject : FsmStateAction
	{
		// Token: 0x0600088B RID: 2187 RVA: 0x00039D98 File Offset: 0x00037F98
		public override void Reset()
		{
			this.gameObject = null;
			this.offsetLeft = 0f;
			this.offsetTop = 0f;
			this.width = 1f;
			this.height = 1f;
			this.normalized = true;
			this.style = string.Empty;
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00039E08 File Offset: 0x00038008
		public override void OnGUI()
		{
			GameObject value = this.gameObject.Value;
			if (value == null || Camera.main == null)
			{
				GUILayoutBeginAreaFollowObject.DummyBeginArea();
				return;
			}
			Vector3 position = value.transform.position;
			if (Camera.main.transform.InverseTransformPoint(position).z < 0f)
			{
				GUILayoutBeginAreaFollowObject.DummyBeginArea();
				return;
			}
			Vector2 vector = Camera.main.WorldToScreenPoint(position);
			float left = vector.x + ((!this.normalized.Value) ? this.offsetLeft.Value : (this.offsetLeft.Value * (float)Screen.width));
			float top = vector.y + ((!this.normalized.Value) ? this.offsetTop.Value : (this.offsetTop.Value * (float)Screen.width));
			Rect screenRect = new Rect(left, top, this.width.Value, this.height.Value);
			if (this.normalized.Value)
			{
				screenRect.width *= (float)Screen.width;
				screenRect.height *= (float)Screen.height;
			}
			screenRect.y = (float)Screen.height - screenRect.y;
			GUILayout.BeginArea(screenRect, this.style.Value);
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x00039F80 File Offset: 0x00038180
		private static void DummyBeginArea()
		{
			GUILayout.BeginArea(default(Rect));
		}

		// Token: 0x04000C46 RID: 3142
		[Tooltip("The GameObject to follow.")]
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000C47 RID: 3143
		[RequiredField]
		public FsmFloat offsetLeft;

		// Token: 0x04000C48 RID: 3144
		[RequiredField]
		public FsmFloat offsetTop;

		// Token: 0x04000C49 RID: 3145
		[RequiredField]
		public FsmFloat width;

		// Token: 0x04000C4A RID: 3146
		[RequiredField]
		public FsmFloat height;

		// Token: 0x04000C4B RID: 3147
		[Tooltip("Use normalized screen coordinates (0-1).")]
		public FsmBool normalized;

		// Token: 0x04000C4C RID: 3148
		[Tooltip("Optional named style in the current GUISkin")]
		public FsmString style;
	}
}
