﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D7 RID: 983
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Return the maximum value within an arrayList. It can use float, int, vector2 and vector3 ( uses magnitude), rect ( uses surface), gameobject ( using bounding box volume), and string ( use lenght)")]
	public class ArrayListGetMaxValue : ArrayListActions
	{
		// Token: 0x0600109E RID: 4254 RVA: 0x0005A4F4 File Offset: 0x000586F4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.maximumValue = null;
			this.maximumValueIndex = null;
			this.everyframe = true;
		}

		// Token: 0x0600109F RID: 4255 RVA: 0x0005A51C File Offset: 0x0005871C
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindMaximumValue();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x060010A0 RID: 4256 RVA: 0x0005A570 File Offset: 0x00058770
		public override void OnUpdate()
		{
			this.DoFindMaximumValue();
		}

		// Token: 0x060010A1 RID: 4257 RVA: 0x0005A578 File Offset: 0x00058778
		private void DoFindMaximumValue()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			VariableType type = this.maximumValue.Type;
			if (!ArrayListGetMaxValue.supportedTypes.Contains(this.maximumValue.Type))
			{
				return;
			}
			float num = float.NegativeInfinity;
			int num2 = 0;
			int num3 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				try
				{
					float floatFromObject = PlayMakerUtils.GetFloatFromObject(obj, type, true);
					if (num < floatFromObject)
					{
						num = floatFromObject;
						num2 = num3;
					}
				}
				finally
				{
				}
				num3++;
			}
			this.maximumValueIndex.Value = num2;
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.maximumValue, this.proxy.arrayList[num2]);
		}

		// Token: 0x060010A2 RID: 4258 RVA: 0x0005A690 File Offset: 0x00058890
		public override string ErrorCheck()
		{
			if (!ArrayListGetMaxValue.supportedTypes.Contains(this.maximumValue.Type))
			{
				return "A " + this.maximumValue.Type + " can not be processed as a minimum";
			}
			return string.Empty;
		}

		// Token: 0x04001588 RID: 5512
		private static VariableType[] supportedTypes = new VariableType[]
		{
			VariableType.Float,
			VariableType.Int,
			VariableType.Rect,
			VariableType.Vector2,
			VariableType.Vector3,
			VariableType.GameObject,
			VariableType.String
		};

		// Token: 0x04001589 RID: 5513
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400158A RID: 5514
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400158B RID: 5515
		[Tooltip("Performs every frame. WARNING, it could be affecting performances.")]
		public bool everyframe;

		// Token: 0x0400158C RID: 5516
		[RequiredField]
		[Tooltip("The Maximum Value")]
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		public FsmVar maximumValue;

		// Token: 0x0400158D RID: 5517
		[UIHint(UIHint.Variable)]
		[Tooltip("The index of the Maximum Value within that arrayList")]
		public FsmInt maximumValueIndex;
	}
}
