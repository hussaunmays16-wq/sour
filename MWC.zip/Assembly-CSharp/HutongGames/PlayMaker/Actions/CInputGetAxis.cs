﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A2 RID: 1186
	[ActionCategory("cInput")]
	[Tooltip("Gets the value of a cInput axis and stores it in a fsm variable.")]
	public class CInputGetAxis : FsmStateAction
	{
		// Token: 0x06001441 RID: 5185 RVA: 0x00088934 File Offset: 0x00086B34
		public override void Reset()
		{
			this.axisName = null;
			this.storeAxisValue = null;
		}

		// Token: 0x06001442 RID: 5186 RVA: 0x00088944 File Offset: 0x00086B44
		public override void OnUpdate()
		{
			if (this.axisName == null)
			{
				return;
			}
			this.storeAxisValue.Value = cInput.GetAxis(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CAA RID: 7338
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CAB RID: 7339
		[Tooltip("The value of the axis.")]
		public FsmFloat storeAxisValue;

		// Token: 0x04001CAC RID: 7340
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
