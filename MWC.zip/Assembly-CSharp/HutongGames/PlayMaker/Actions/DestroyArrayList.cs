﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B6 RID: 950
	[Tooltip("Destroys a PlayMakerArrayListProxy Component of a Game Object.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class DestroyArrayList : ArrayListActions
	{
		// Token: 0x06001012 RID: 4114 RVA: 0x0005808C File Offset: 0x0005628C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.successEvent = null;
			this.notFoundEvent = null;
		}

		// Token: 0x06001013 RID: 4115 RVA: 0x000580AC File Offset: 0x000562AC
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoDestroyArrayList();
			}
			else
			{
				base.Fsm.Event(this.notFoundEvent);
			}
			base.Finish();
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x00058104 File Offset: 0x00056304
		private void DoDestroyArrayList()
		{
			PlayMakerArrayListProxy[] components = this.proxy.GetComponents<PlayMakerArrayListProxy>();
			foreach (PlayMakerArrayListProxy playMakerArrayListProxy in components)
			{
				if (playMakerArrayListProxy.referenceName == this.reference.Value)
				{
					UnityEngine.Object.Destroy(playMakerArrayListProxy);
					base.Fsm.Event(this.successEvent);
					return;
				}
			}
			base.Fsm.Event(this.notFoundEvent);
		}

		// Token: 0x040014DC RID: 5340
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014DD RID: 5341
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014DE RID: 5342
		[Tooltip("The event to trigger if the ArrayList proxy component is destroyed")]
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Result")]
		public FsmEvent successEvent;

		// Token: 0x040014DF RID: 5343
		[Tooltip("The event to trigger if the ArrayList proxy component was not found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent notFoundEvent;
	}
}
