﻿using System;
using UnityEngine;

// Token: 0x020000C4 RID: 196
public class DemoCube : MonoBehaviour
{
	// Token: 0x060003B8 RID: 952 RVA: 0x00018718 File Offset: 0x00016918
	private void Awake()
	{
		this.deformable = base.GetComponent<Deformable>();
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x00018728 File Offset: 0x00016928
	private void OnMouseDown()
	{
		this.deformable.Repair(0.25f);
	}

	// Token: 0x060003BA RID: 954 RVA: 0x0001873C File Offset: 0x0001693C
	private void OnGUI()
	{
		GUILayout.Label("Click on the cube to repair it", new GUILayoutOption[0]);
	}

	// Token: 0x04000577 RID: 1399
	private Deformable deformable;
}
