﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E2 RID: 482
	[ActionCategory(ActionCategory.GUI)]
	[Tooltip("GUI Box.")]
	public class GUIBox : GUIContentAction
	{
		// Token: 0x06000873 RID: 2163 RVA: 0x00039614 File Offset: 0x00037814
		public override void OnGUI()
		{
			base.OnGUI();
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUI.Box(this.rect, this.content);
			}
			else
			{
				GUI.Box(this.rect, this.content, this.style.Value);
			}
		}
	}
}
