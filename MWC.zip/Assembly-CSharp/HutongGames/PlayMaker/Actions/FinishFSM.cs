﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001CB RID: 459
	[ActionCategory(ActionCategory.StateMachine)]
	[Note("Stop this FSM. If this FSM was launched by a Run FSM action, it will trigger a Finish event in that state.")]
	[Tooltip("Stop this FSM. If this FSM was launched by a Run FSM action, it will trigger a Finish event in that state.")]
	public class FinishFSM : FsmStateAction
	{
		// Token: 0x06000813 RID: 2067 RVA: 0x00038438 File Offset: 0x00036638
		public override void OnEnter()
		{
			base.Fsm.Stop();
		}
	}
}
