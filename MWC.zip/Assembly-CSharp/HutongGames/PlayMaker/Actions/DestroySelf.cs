﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200017D RID: 381
	[Tooltip("Destroys the Owner of the Fsm! Useful for spawned Prefabs that need to kill themselves, e.g., a projectile that explodes on impact.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class DestroySelf : FsmStateAction
	{
		// Token: 0x060006FF RID: 1791 RVA: 0x00031A04 File Offset: 0x0002FC04
		public override void Reset()
		{
			this.detachChildren = false;
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00031A14 File Offset: 0x0002FC14
		public override void OnEnter()
		{
			if (base.Owner != null)
			{
				if (this.detachChildren.Value)
				{
					base.Owner.transform.DetachChildren();
				}
				UnityEngine.Object.Destroy(base.Owner);
			}
			base.Finish();
		}

		// Token: 0x040009F1 RID: 2545
		[Tooltip("Detach children before destroying the Owner.")]
		public FsmBool detachChildren;
	}
}
