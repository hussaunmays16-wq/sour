﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E2 RID: 994
	[Tooltip("Loads a PlayMaker HashTable Proxy component From MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class HashTableEasyDownload : HashTableActions
	{
		// Token: 0x060010D4 RID: 4308 RVA: 0x0005C5C4 File Offset: 0x0005A7C4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.localFile = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x0005C64C File Offset: 0x0005A84C
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DownloadHashTable();
			}
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0005C688 File Offset: 0x0005A888
		private void DownloadHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._tag = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(this._tag))
			{
				this._tag = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/hashTable/",
					this.reference.Value
				});
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this._tag,
				"&webfilename=",
				this.saveFile.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new string[]
			{
				"Downloading from ",
				this.urlToPHPFile.Value,
				"?tag=",
				this.uniqueTag.Value,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0005C7F0 File Offset: 0x0005A9F0
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				Dictionary<string, string> dictionary = this.web.LoadDictionary<string, string>(this._tag);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
				this.Log("DownLoaded from " + this.saveFile.Value + "?tag=" + this._tag);
				this.proxy.hashTable.Clear();
				foreach (string key in dictionary.Keys)
				{
					this.proxy.hashTable[key] = PlayMakerUtils.ParseValueFromString(dictionary[key]);
				}
				base.Finish();
			}
		}

		// Token: 0x040015ED RID: 5613
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015EE RID: 5614
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015EF RID: 5615
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + hashtable Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015F0 RID: 5616
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data. Leave as default if unsure.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015F1 RID: 5617
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x040015F2 RID: 5618
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x040015F3 RID: 5619
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x040015F4 RID: 5620
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x040015F5 RID: 5621
		[ActionSection("Result")]
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x040015F6 RID: 5622
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x040015F7 RID: 5623
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x040015F8 RID: 5624
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015F9 RID: 5625
		private ES2Web web;

		// Token: 0x040015FA RID: 5626
		private string _tag;
	}
}
