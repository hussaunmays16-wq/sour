﻿using System;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C5 RID: 965
	[Tooltip("Return the key for a value ofna PlayMaker hashtable Proxy component. It will return the first entry found.")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableGetKeyFromValue : HashTableActions
	{
		// Token: 0x0600104D RID: 4173 RVA: 0x00058F3C File Offset: 0x0005713C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x0600104E RID: 4174 RVA: 0x00058F4C File Offset: 0x0005714C
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SortHashTableByValues();
			}
			base.Finish();
		}

		// Token: 0x0600104F RID: 4175 RVA: 0x00058F8C File Offset: 0x0005718C
		public void SortHashTableByValues()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			object valueFromFsmVar = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.theValue);
			foreach (object obj in this.proxy.hashTable)
			{
				DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
				if (dictionaryEntry.Value.Equals(valueFromFsmVar))
				{
					this.result.Value = (string)dictionaryEntry.Key;
					base.Fsm.Event(this.KeyFoundEvent);
					return;
				}
			}
			base.Fsm.Event(this.KeyNotFoundEvent);
		}

		// Token: 0x04001526 RID: 5414
		[ActionSection("Set up")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001527 RID: 5415
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001528 RID: 5416
		[RequiredField]
		[ActionSection("Value")]
		[Tooltip("The value to search")]
		public FsmVar theValue;

		// Token: 0x04001529 RID: 5417
		[UIHint(UIHint.Variable)]
		[Tooltip("The key of that value")]
		[ActionSection("Result")]
		public FsmString result;

		// Token: 0x0400152A RID: 5418
		[Tooltip("The event to trigger when value is found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent KeyFoundEvent;

		// Token: 0x0400152B RID: 5419
		[Tooltip("The event to trigger when value is not found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent KeyNotFoundEvent;
	}
}
