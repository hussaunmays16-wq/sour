﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F3 RID: 499
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Close a GUILayout group started with BeginArea.")]
	public class GUILayoutEndArea : FsmStateAction
	{
		// Token: 0x060008A7 RID: 2215 RVA: 0x0003A5CC File Offset: 0x000387CC
		public override void Reset()
		{
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x0003A5D0 File Offset: 0x000387D0
		public override void OnGUI()
		{
			GUILayout.EndArea();
		}
	}
}
