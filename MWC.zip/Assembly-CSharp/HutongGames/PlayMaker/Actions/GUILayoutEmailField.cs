﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F2 RID: 498
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("GUILayout Password Field. Optionally send an event if the text has been edited.")]
	public class GUILayoutEmailField : GUILayoutAction
	{
		// Token: 0x060008A4 RID: 2212 RVA: 0x0003A510 File Offset: 0x00038710
		public override void Reset()
		{
			this.text = null;
			this.maxLength = 25;
			this.style = "TextField";
			this.valid = true;
			this.changedEvent = null;
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x0003A54C File Offset: 0x0003874C
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.text.Value = GUILayout.TextField(this.text.Value, this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C6D RID: 3181
		[UIHint(UIHint.Variable)]
		public FsmString text;

		// Token: 0x04000C6E RID: 3182
		public FsmInt maxLength;

		// Token: 0x04000C6F RID: 3183
		public FsmString style;

		// Token: 0x04000C70 RID: 3184
		public FsmEvent changedEvent;

		// Token: 0x04000C71 RID: 3185
		public FsmBool valid;
	}
}
