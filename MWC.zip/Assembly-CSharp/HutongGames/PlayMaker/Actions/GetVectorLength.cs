﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000264 RID: 612
	[Tooltip("Get Vector3 Length.")]
	[ActionCategory(ActionCategory.Vector3)]
	public class GetVectorLength : FsmStateAction
	{
		// Token: 0x06000A6F RID: 2671 RVA: 0x0003FED4 File Offset: 0x0003E0D4
		public override void Reset()
		{
			this.vector3 = null;
			this.storeLength = null;
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x0003FEE4 File Offset: 0x0003E0E4
		public override void OnEnter()
		{
			this.DoVectorLength();
			base.Finish();
		}

		// Token: 0x06000A71 RID: 2673 RVA: 0x0003FEF4 File Offset: 0x0003E0F4
		private void DoVectorLength()
		{
			if (this.vector3 == null)
			{
				return;
			}
			if (this.storeLength == null)
			{
				return;
			}
			this.storeLength.Value = this.vector3.Value.magnitude;
		}

		// Token: 0x04000E5B RID: 3675
		public FsmVector3 vector3;

		// Token: 0x04000E5C RID: 3676
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeLength;
	}
}
