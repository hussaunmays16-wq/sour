﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BA RID: 954
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Add an key/value pair to a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy).")]
	public class HashTableAdd : HashTableActions
	{
		// Token: 0x06001022 RID: 4130 RVA: 0x00058454 File Offset: 0x00056654
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
			this.variable = null;
			this.successEvent = null;
			this.keyExistsAlreadyEvent = null;
		}

		// Token: 0x06001023 RID: 4131 RVA: 0x0005848C File Offset: 0x0005668C
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				if (this.proxy.hashTable.ContainsKey(this.key.Value))
				{
					base.Fsm.Event(this.keyExistsAlreadyEvent);
				}
				else
				{
					this.AddToHashTable();
					base.Fsm.Event(this.successEvent);
				}
			}
			base.Finish();
		}

		// Token: 0x06001024 RID: 4132 RVA: 0x00058514 File Offset: 0x00056714
		public void AddToHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.hashTable.Add(this.key.Value, PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable));
		}

		// Token: 0x040014ED RID: 5357
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014EE RID: 5358
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014EF RID: 5359
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		[ActionSection("Data")]
		[Tooltip("The Key value for that hash set")]
		public FsmString key;

		// Token: 0x040014F0 RID: 5360
		[RequiredField]
		[Tooltip("The variable to add.")]
		public FsmVar variable;

		// Token: 0x040014F1 RID: 5361
		[ActionSection("Result")]
		[Tooltip("The event to trigger when element is added")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent successEvent;

		// Token: 0x040014F2 RID: 5362
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when element exists already")]
		public FsmEvent keyExistsAlreadyEvent;
	}
}
