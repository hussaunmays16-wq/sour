﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B7 RID: 951
	[Tooltip("Finds an ArrayList by reference. Warning: this function can be very slow.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class FindArrayList : CollectionsActions
	{
		// Token: 0x06001016 RID: 4118 RVA: 0x00058184 File Offset: 0x00056384
		public override void Reset()
		{
			this.ArrayListReference = string.Empty;
			this.store = null;
			this.foundEvent = null;
			this.notFoundEvent = null;
		}

		// Token: 0x06001017 RID: 4119 RVA: 0x000581AC File Offset: 0x000563AC
		public override void OnEnter()
		{
			PlayMakerArrayListProxy[] array = UnityEngine.Object.FindObjectsOfType(typeof(PlayMakerArrayListProxy)) as PlayMakerArrayListProxy[];
			foreach (PlayMakerArrayListProxy playMakerArrayListProxy in array)
			{
				if (playMakerArrayListProxy.referenceName == this.ArrayListReference.Value)
				{
					this.store.Value = playMakerArrayListProxy.gameObject;
					base.Fsm.Event(this.foundEvent);
					return;
				}
			}
			this.store.Value = null;
			base.Fsm.Event(this.notFoundEvent);
			base.Finish();
		}

		// Token: 0x040014E0 RID: 5344
		[RequiredField]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[UIHint(UIHint.FsmString)]
		public FsmString ArrayListReference;

		// Token: 0x040014E1 RID: 5345
		[RequiredField]
		[Tooltip("Store the GameObject hosting the PlayMaker ArrayList Proxy component here")]
		[ActionSection("Result")]
		public FsmGameObject store;

		// Token: 0x040014E2 RID: 5346
		public FsmEvent foundEvent;

		// Token: 0x040014E3 RID: 5347
		public FsmEvent notFoundEvent;
	}
}
