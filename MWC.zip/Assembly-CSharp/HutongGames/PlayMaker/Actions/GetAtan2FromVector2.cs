﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000031 RID: 49
	[Tooltip("Get the Arc Tangent 2 as in atan2(y,x) from a vector 2. You can get the result in degrees, simply check on the RadToDeg conversion")]
	[ActionCategory("Trigonometry")]
	public class GetAtan2FromVector2 : FsmStateAction
	{
		// Token: 0x060000A6 RID: 166 RVA: 0x00006520 File Offset: 0x00004720
		public override void Reset()
		{
			this.vector2 = null;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.angle = null;
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00006544 File Offset: 0x00004744
		public override void OnEnter()
		{
			this.DoATan();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x00006560 File Offset: 0x00004760
		public override void OnUpdate()
		{
			this.DoATan();
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00006568 File Offset: 0x00004768
		private void DoATan()
		{
			float num = Mathf.Atan2(this.vector2.Value.y, this.vector2.Value.x);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000FA RID: 250
		[Tooltip("The vector2 of the tan")]
		[RequiredField]
		public FsmVector2 vector2;

		// Token: 0x040000FB RID: 251
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		public FsmFloat angle;

		// Token: 0x040000FC RID: 252
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x040000FD RID: 253
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
