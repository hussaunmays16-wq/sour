﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003EA RID: 1002
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Set a mesh vertex colors based on colors found in an arrayList")]
	public class ArrayListSetVertexColors : ArrayListActions
	{
		// Token: 0x060010F6 RID: 4342 RVA: 0x0005D740 File Offset: 0x0005B940
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.mesh = null;
			this.everyFrame = false;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x0005D760 File Offset: 0x0005B960
		public override void OnEnter()
		{
			GameObject value = this.mesh.Value;
			if (value == null)
			{
				base.Finish();
				return;
			}
			MeshFilter component = value.GetComponent<MeshFilter>();
			if (component == null)
			{
				base.Finish();
				return;
			}
			this._mesh = component.mesh;
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SetVertexColors();
			}
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x0005D7F0 File Offset: 0x0005B9F0
		public override void OnUpdate()
		{
			this.SetVertexColors();
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x0005D7F8 File Offset: 0x0005B9F8
		public void SetVertexColors()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._colors = new Color[this.proxy.arrayList.Count];
			int num = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				Color color = (Color)obj;
				this._colors[num] = color;
				num++;
			}
			this._mesh.colors = this._colors;
		}

		// Token: 0x04001623 RID: 5667
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001624 RID: 5668
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001625 RID: 5669
		[Tooltip("The GameObject to set the mesh colors to")]
		[ActionSection("Target")]
		[CheckForComponent(typeof(MeshFilter))]
		public FsmGameObject mesh;

		// Token: 0x04001626 RID: 5670
		public bool everyFrame;

		// Token: 0x04001627 RID: 5671
		private Mesh _mesh;

		// Token: 0x04001628 RID: 5672
		private Color[] _colors;
	}
}
