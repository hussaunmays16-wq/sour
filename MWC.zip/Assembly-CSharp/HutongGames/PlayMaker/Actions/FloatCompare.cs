﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D2 RID: 466
	[Tooltip("Sends Events based on the comparison of 2 Floats.")]
	[ActionCategory(ActionCategory.Logic)]
	public class FloatCompare : FsmStateAction
	{
		// Token: 0x06000831 RID: 2097 RVA: 0x0003885C File Offset: 0x00036A5C
		public override void Reset()
		{
			this.float1 = 0f;
			this.float2 = 0f;
			this.tolerance = 0f;
			this.equal = null;
			this.lessThan = null;
			this.greaterThan = null;
			this.everyFrame = false;
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x000388B8 File Offset: 0x00036AB8
		public override void OnEnter()
		{
			this.DoCompare();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x000388D4 File Offset: 0x00036AD4
		public override void OnUpdate()
		{
			this.DoCompare();
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x000388DC File Offset: 0x00036ADC
		private void DoCompare()
		{
			if (Mathf.Abs(this.float1.Value - this.float2.Value) <= this.tolerance.Value)
			{
				base.Fsm.Event(this.equal);
				return;
			}
			if (this.float1.Value < this.float2.Value)
			{
				base.Fsm.Event(this.lessThan);
				return;
			}
			if (this.float1.Value > this.float2.Value)
			{
				base.Fsm.Event(this.greaterThan);
			}
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00038980 File Offset: 0x00036B80
		public override string ErrorCheck()
		{
			if (FsmEvent.IsNullOrEmpty(this.equal) && FsmEvent.IsNullOrEmpty(this.lessThan) && FsmEvent.IsNullOrEmpty(this.greaterThan))
			{
				return "Action sends no events!";
			}
			return string.Empty;
		}

		// Token: 0x04000BD0 RID: 3024
		[RequiredField]
		[Tooltip("The first float variable.")]
		public FsmFloat float1;

		// Token: 0x04000BD1 RID: 3025
		[RequiredField]
		[Tooltip("The second float variable.")]
		public FsmFloat float2;

		// Token: 0x04000BD2 RID: 3026
		[Tooltip("Tolerance for the Equal test (almost equal).")]
		[RequiredField]
		public FsmFloat tolerance;

		// Token: 0x04000BD3 RID: 3027
		[Tooltip("Event sent if Float 1 equals Float 2 (within Tolerance)")]
		public FsmEvent equal;

		// Token: 0x04000BD4 RID: 3028
		[Tooltip("Event sent if Float 1 is less than Float 2")]
		public FsmEvent lessThan;

		// Token: 0x04000BD5 RID: 3029
		[Tooltip("Event sent if Float 1 is greater than Float 2")]
		public FsmEvent greaterThan;

		// Token: 0x04000BD6 RID: 3030
		[Tooltip("Repeat every frame. Useful if the variables are changing and you're waiting for a particular result.")]
		public bool everyFrame;
	}
}
