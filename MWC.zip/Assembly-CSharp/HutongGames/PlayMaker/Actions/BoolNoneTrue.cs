﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014F RID: 335
	[Tooltip("Tests if all the Bool Variables are False.\nSend an event or store the result.")]
	[ActionCategory(ActionCategory.Logic)]
	public class BoolNoneTrue : FsmStateAction
	{
		// Token: 0x06000637 RID: 1591 RVA: 0x0002EF40 File Offset: 0x0002D140
		public override void Reset()
		{
			this.boolVariables = null;
			this.sendEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0002EF60 File Offset: 0x0002D160
		public override void OnEnter()
		{
			this.DoNoneTrue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0002EF7C File Offset: 0x0002D17C
		public override void OnUpdate()
		{
			this.DoNoneTrue();
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0002EF84 File Offset: 0x0002D184
		private void DoNoneTrue()
		{
			if (this.boolVariables.Length == 0)
			{
				return;
			}
			bool flag = true;
			for (int i = 0; i < this.boolVariables.Length; i++)
			{
				if (this.boolVariables[i].Value)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = flag;
		}

		// Token: 0x0400092B RID: 2347
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variables to check.")]
		[RequiredField]
		public FsmBool[] boolVariables;

		// Token: 0x0400092C RID: 2348
		[Tooltip("Event to send if none of the Bool variables are True.")]
		public FsmEvent sendEvent;

		// Token: 0x0400092D RID: 2349
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a Bool variable.")]
		public FsmBool storeResult;

		// Token: 0x0400092E RID: 2350
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
