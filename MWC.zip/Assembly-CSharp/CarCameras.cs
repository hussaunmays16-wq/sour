﻿using System;
using UnityEngine;

// Token: 0x02000473 RID: 1139
[RequireComponent(typeof(CarCamerasController))]
public class CarCameras : MonoBehaviour
{
	// Token: 0x06001322 RID: 4898 RVA: 0x0006CB20 File Offset: 0x0006AD20
	private void Start()
	{
		this.myTransform = base.transform;
		this.mtarget = this.target;
		if (this.mtarget)
		{
			this.cardynamics = this.mtarget.GetComponent<CarDynamics>();
		}
	}

	// Token: 0x06001323 RID: 4899 RVA: 0x0006CB5C File Offset: 0x0006AD5C
	private void LateUpdate()
	{
		if (this.target)
		{
			if (this.mycamera == CarCameras.Cameras.MouseOrbit)
			{
				this.x += Input.GetAxis("Mouse X") * this.xSpeed;
				this.y -= Input.GetAxis("Mouse Y") * this.ySpeed;
				this.y = CarCameras.ClampAngle(this.y, this.yMinLimit, this.yMaxLimit);
				this.rotation = Quaternion.Slerp(this.myTransform.rotation, Quaternion.Euler(this.y, this.x, 0f), Time.deltaTime * this.mouseDamping);
				this.distance -= Input.GetAxis("Mouse ScrollWheel") * 5f;
				this.distance = Mathf.Clamp(this.distance, this.distanceMin, this.distanceMax);
				Vector3 point = new Vector3(0f, 0f, -this.distance);
				Vector3 position = this.rotation * point + this.target.position;
				this.myTransform.rotation = this.rotation;
				this.myTransform.position = position;
			}
			else if (this.mycamera == CarCameras.Cameras.Map)
			{
				this.myTransform.position = new Vector3(this.target.position.x, this.myTransform.position.y, this.target.position.z);
				this.myTransform.eulerAngles = new Vector3(this.myTransform.eulerAngles.x, this.target.eulerAngles.y, this.myTransform.eulerAngles.z);
			}
			else if (this.mycamera == CarCameras.Cameras.SmoothLookAt)
			{
				this.wantedYawRotationAngle = this.target.eulerAngles.y + this.yawAngle;
				this.currentYawRotationAngle = this.myTransform.eulerAngles.y;
				this.wantedHeight = this.target.position.y + this.height;
				this.currentHeight = this.myTransform.position.y;
				this.currentYawRotationAngle = Mathf.LerpAngle(this.currentYawRotationAngle, this.wantedYawRotationAngle, this.rotationDamping * Time.deltaTime);
				this.currentHeight = Mathf.Lerp(this.currentHeight, this.wantedHeight, this.heightDamping * Time.deltaTime);
				Quaternion quaternion = Quaternion.Euler(0f, this.currentYawRotationAngle, 0f);
				this.myTransform.position = this.target.position;
				this.myTransform.position -= quaternion * Vector3.forward * this.distance;
				this.myTransform.position = new Vector3(this.myTransform.position.x, this.currentHeight, this.myTransform.position.z);
				this.myTransform.LookAt(new Vector3(this.target.position.x, this.target.position.y + this.height + this.pitchAngle, this.target.position.z));
			}
			else if (this.mycamera == CarCameras.Cameras.FixedTo)
			{
				if (this.mouseOrbitFixedCamera)
				{
					this.x += Input.GetAxis("Mouse X") * this.xSpeed;
					this.y -= Input.GetAxis("Mouse Y") * this.ySpeed;
					this.y = CarCameras.ClampAngle(this.y, this.yMinLimit, this.yMaxLimit);
				}
				else
				{
					this.x = (this.y = 0f);
				}
				this.rotation = Quaternion.Slerp(this.myTransform.rotation, Quaternion.Euler(this.y + this.target.eulerAngles.x + this.pitchAngle + this.deltaPitchAngle, this.x + this.target.eulerAngles.y + this.yawAngle, this.target.eulerAngles.z), Time.time);
				this.myTransform.rotation = this.rotation;
				if (this.dampFixedCamera)
				{
					Vector3 position2 = new Vector3(this.target.position.x, this.target.position.y + this.height, this.target.position.z) - this.myTransform.forward * this.distance - (this.deltaMovement.z * this.target.forward + this.deltaMovement.y * this.target.up + this.deltaMovement.x * this.target.right);
					this.myTransform.position = position2;
				}
				else
				{
					this.myTransform.eulerAngles = new Vector3(this.target.eulerAngles.x + this.pitchAngle, this.target.eulerAngles.y + this.yawAngle, this.target.eulerAngles.z);
					this.myTransform.position = new Vector3(this.target.position.x, this.target.position.y + this.height, this.target.position.z) - this.myTransform.forward * this.distance;
				}
			}
		}
	}

	// Token: 0x06001324 RID: 4900 RVA: 0x0006D1D0 File Offset: 0x0006B3D0
	private void FixedUpdate()
	{
		if (this.dampFixedCamera)
		{
			this.oldVelocity = this.velocity;
			this.velocity = this.mtarget.InverseTransformDirection(this.mtarget.GetComponent<Rigidbody>().velocity);
			this.deltaVelocity = this.velocity - this.oldVelocity;
			if (this.cardynamics != null)
			{
				this.centrifugalAccel = this.cardynamics.GetCentrifugalAccel();
			}
			this.accel = this.deltaVelocity / Time.deltaTime + this.centrifugalAccel * Vector3.right;
			this.deltaMovement = this.accel * Time.deltaTime * Time.deltaTime * 5f;
			this.deltaMovement.z = Mathf.Clamp(this.deltaMovement.z, -0.2f, 0.2f);
			this.deltaMovement.y = Mathf.Clamp(this.deltaMovement.y, -0.1f, 0.1f);
			this.deltaMovement.x = Mathf.Clamp(this.deltaMovement.x, -0.01f, 0.01f);
			this.deltaPitchAngle = this.deltaMovement.y * 20f - this.deltaMovement.z * 20f;
			this.deltaPitchAngle = Mathf.Clamp(this.deltaPitchAngle, -5f, 5f);
		}
	}

	// Token: 0x06001325 RID: 4901 RVA: 0x0006D358 File Offset: 0x0006B558
	private static float ClampAngle(float yawAngle, float min, float max)
	{
		if (yawAngle < -360f)
		{
			yawAngle += 360f;
		}
		else if (yawAngle > 360f)
		{
			yawAngle -= 360f;
		}
		return Mathf.Clamp(yawAngle, min, max);
	}

	// Token: 0x04001909 RID: 6409
	public CarCameras.Cameras mycamera;

	// Token: 0x0400190A RID: 6410
	public Transform target;

	// Token: 0x0400190B RID: 6411
	public float distance = 10f;

	// Token: 0x0400190C RID: 6412
	public float height = 2.5f;

	// Token: 0x0400190D RID: 6413
	public float yawAngle;

	// Token: 0x0400190E RID: 6414
	public float pitchAngle = -2.5f;

	// Token: 0x0400190F RID: 6415
	public float rotationDamping = 3f;

	// Token: 0x04001910 RID: 6416
	public float heightDamping = 2f;

	// Token: 0x04001911 RID: 6417
	[HideInInspector]
	public bool dampFixedCamera;

	// Token: 0x04001912 RID: 6418
	[HideInInspector]
	public bool mouseOrbitFixedCamera;

	// Token: 0x04001913 RID: 6419
	[HideInInspector]
	public bool driverView;

	// Token: 0x04001914 RID: 6420
	private float xSpeed = 10f;

	// Token: 0x04001915 RID: 6421
	private float ySpeed = 10f;

	// Token: 0x04001916 RID: 6422
	private float yMinLimit = -20f;

	// Token: 0x04001917 RID: 6423
	private float yMaxLimit = 80f;

	// Token: 0x04001918 RID: 6424
	[HideInInspector]
	public float distanceMin = 4f;

	// Token: 0x04001919 RID: 6425
	[HideInInspector]
	public float distanceMax = 30f;

	// Token: 0x0400191A RID: 6426
	private float mouseDamping = 10f;

	// Token: 0x0400191B RID: 6427
	[HideInInspector]
	public float x;

	// Token: 0x0400191C RID: 6428
	[HideInInspector]
	public float y;

	// Token: 0x0400191D RID: 6429
	private float currentYawRotationAngle;

	// Token: 0x0400191E RID: 6430
	private float wantedYawRotationAngle;

	// Token: 0x0400191F RID: 6431
	private float currentHeight;

	// Token: 0x04001920 RID: 6432
	private float wantedHeight;

	// Token: 0x04001921 RID: 6433
	private float deltaPitchAngle;

	// Token: 0x04001922 RID: 6434
	private Vector3 deltaMovement;

	// Token: 0x04001923 RID: 6435
	private Vector3 oldVelocity;

	// Token: 0x04001924 RID: 6436
	private Vector3 deltaVelocity;

	// Token: 0x04001925 RID: 6437
	private Vector3 velocity;

	// Token: 0x04001926 RID: 6438
	private Vector3 accel;

	// Token: 0x04001927 RID: 6439
	private float centrifugalAccel;

	// Token: 0x04001928 RID: 6440
	private CarDynamics cardynamics;

	// Token: 0x04001929 RID: 6441
	[HideInInspector]
	public Transform myTransform;

	// Token: 0x0400192A RID: 6442
	[HideInInspector]
	public Transform mtarget;

	// Token: 0x0400192B RID: 6443
	private Quaternion rotation;

	// Token: 0x02000474 RID: 1140
	public enum Cameras
	{
		// Token: 0x0400192D RID: 6445
		SmoothLookAt,
		// Token: 0x0400192E RID: 6446
		MouseOrbit,
		// Token: 0x0400192F RID: 6447
		FixedTo,
		// Token: 0x04001930 RID: 6448
		Map
	}
}
