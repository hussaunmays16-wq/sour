﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014A RID: 330
	[Tooltip("Turns a Game Object on/off in a regular repeating pattern.")]
	[ActionCategory(ActionCategory.Effects)]
	public class Blink : ComponentAction<Renderer>
	{
		// Token: 0x06000621 RID: 1569 RVA: 0x0002EB3C File Offset: 0x0002CD3C
		public override void Reset()
		{
			this.gameObject = null;
			this.timeOff = 0.5f;
			this.timeOn = 0.5f;
			this.rendererOnly = true;
			this.startOn = false;
			this.realTime = false;
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x0002EB8C File Offset: 0x0002CD8C
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.timer = 0f;
			this.UpdateBlinkState(this.startOn.Value);
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0002EBB8 File Offset: 0x0002CDB8
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.timer = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.timer += Time.deltaTime;
			}
			if (this.blinkOn && this.timer > this.timeOn.Value)
			{
				this.UpdateBlinkState(false);
			}
			if (!this.blinkOn && this.timer > this.timeOff.Value)
			{
				this.UpdateBlinkState(true);
			}
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x0002EC4C File Offset: 0x0002CE4C
		private void UpdateBlinkState(bool state)
		{
			GameObject gameObject = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			if (gameObject == null)
			{
				return;
			}
			if (this.rendererOnly)
			{
				if (base.UpdateCache(gameObject))
				{
					base.renderer.enabled = state;
				}
			}
			else
			{
				gameObject.SetActive(state);
			}
			this.blinkOn = state;
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.timer = 0f;
		}

		// Token: 0x04000915 RID: 2325
		[RequiredField]
		[Tooltip("The GameObject to blink on/off.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000916 RID: 2326
		[Tooltip("Time to stay off in seconds.")]
		[HasFloatSlider(0f, 5f)]
		public FsmFloat timeOff;

		// Token: 0x04000917 RID: 2327
		[Tooltip("Time to stay on in seconds.")]
		[HasFloatSlider(0f, 5f)]
		public FsmFloat timeOn;

		// Token: 0x04000918 RID: 2328
		[Tooltip("Should the object start in the active/visible state?")]
		public FsmBool startOn;

		// Token: 0x04000919 RID: 2329
		[Tooltip("Only effect the renderer, keeping other components active.")]
		public bool rendererOnly;

		// Token: 0x0400091A RID: 2330
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x0400091B RID: 2331
		private float startTime;

		// Token: 0x0400091C RID: 2332
		private float timer;

		// Token: 0x0400091D RID: 2333
		private bool blinkOn;
	}
}
