﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000030 RID: 48
	[Tooltip("Get the Arc Tangent 2 as in atan2(y,x). You can get the result in degrees, simply check on the RadToDeg conversion")]
	[ActionCategory("Trigonometry")]
	public class GetAtan2 : FsmStateAction
	{
		// Token: 0x060000A1 RID: 161 RVA: 0x0000646C File Offset: 0x0000466C
		public override void Reset()
		{
			this.xValue = null;
			this.yValue = null;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.angle = null;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x000064A4 File Offset: 0x000046A4
		public override void OnEnter()
		{
			this.DoATan();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000064C0 File Offset: 0x000046C0
		public override void OnUpdate()
		{
			this.DoATan();
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x000064C8 File Offset: 0x000046C8
		private void DoATan()
		{
			float num = Mathf.Atan2(this.yValue.Value, this.xValue.Value);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000F5 RID: 245
		[RequiredField]
		[Tooltip("The x value of the tan")]
		public FsmFloat xValue;

		// Token: 0x040000F6 RID: 246
		[RequiredField]
		[Tooltip("The y value of the tan")]
		public FsmFloat yValue;

		// Token: 0x040000F7 RID: 247
		[RequiredField]
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		[UIHint(UIHint.Variable)]
		public FsmFloat angle;

		// Token: 0x040000F8 RID: 248
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x040000F9 RID: 249
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
