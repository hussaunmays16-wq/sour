﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AC RID: 1196
	[Tooltip("Waits for user to input a sequence of keys like for a Pin or a cheat")]
	[ActionCategory("cInput")]
	public class CInputGetKeySequence : FsmStateAction
	{
		// Token: 0x0600145F RID: 5215 RVA: 0x00088E1C File Offset: 0x0008701C
		public override void Reset()
		{
			this.keyNames = null;
			this.sendSequenceFinished = null;
			this.sendSequenceFailed = null;
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x00088E34 File Offset: 0x00087034
		public override void OnEnter()
		{
			if (this.keyNames.Length == 0)
			{
				base.Finish();
			}
			else
			{
				this.nextKey = this.keyNames[0].Value;
				this.storeExpectingKey.Value = this.nextKey;
				this.currentKeyIndex = 0;
				this.storeMissingKeysCount.Value = this.keyNames.Length;
			}
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x00088E98 File Offset: 0x00087098
		public override void OnLateUpdate()
		{
			if (cInput.GetKeyDown(this.nextKey))
			{
				if (this.currentKeyIndex < this.keyNames.Length - 1)
				{
					this.currentKeyIndex++;
					this.nextKey = this.keyNames[this.currentKeyIndex].Value;
					this.storeExpectingKey.Value = this.nextKey;
				}
				else
				{
					base.Fsm.Event(this.sendSequenceFinished);
					base.Finish();
				}
				this.storeMissingKeysCount.Value--;
				return;
			}
			if (Input.anyKeyDown)
			{
				base.Fsm.Event(this.sendSequenceFailed);
			}
		}

		// Token: 0x04001CCE RID: 7374
		[Tooltip("The names of the keys in sequence.")]
		[RequiredField]
		public FsmString[] keyNames;

		// Token: 0x04001CCF RID: 7375
		[Tooltip("The number of missing keys until done.")]
		public FsmInt storeMissingKeysCount;

		// Token: 0x04001CD0 RID: 7376
		[Tooltip("The key the user has to press.")]
		public FsmString storeExpectingKey;

		// Token: 0x04001CD1 RID: 7377
		[Tooltip("sequence finished.")]
		public FsmEvent sendSequenceFinished;

		// Token: 0x04001CD2 RID: 7378
		[Tooltip("sequence failed because wrong order of input.")]
		public FsmEvent sendSequenceFailed;

		// Token: 0x04001CD3 RID: 7379
		private string nextKey;

		// Token: 0x04001CD4 RID: 7380
		private int currentKeyIndex;
	}
}
