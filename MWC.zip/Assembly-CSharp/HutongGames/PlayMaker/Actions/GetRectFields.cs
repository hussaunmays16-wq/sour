﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024F RID: 591
	[Tooltip("Get the individual fields of a Rect Variable and store them in Float Variables.")]
	[ActionCategory(ActionCategory.Rect)]
	public class GetRectFields : FsmStateAction
	{
		// Token: 0x06000A14 RID: 2580 RVA: 0x0003EF90 File Offset: 0x0003D190
		public override void Reset()
		{
			this.rectVariable = null;
			this.storeX = null;
			this.storeY = null;
			this.storeWidth = null;
			this.storeHeight = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0003EFC8 File Offset: 0x0003D1C8
		public override void OnEnter()
		{
			this.DoGetRectFields();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0003EFE4 File Offset: 0x0003D1E4
		public override void OnUpdate()
		{
			this.DoGetRectFields();
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x0003EFEC File Offset: 0x0003D1EC
		private void DoGetRectFields()
		{
			if (this.rectVariable.IsNone)
			{
				return;
			}
			this.storeX.Value = this.rectVariable.Value.x;
			this.storeY.Value = this.rectVariable.Value.y;
			this.storeWidth.Value = this.rectVariable.Value.width;
			this.storeHeight.Value = this.rectVariable.Value.height;
		}

		// Token: 0x04000E02 RID: 3586
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmRect rectVariable;

		// Token: 0x04000E03 RID: 3587
		[UIHint(UIHint.Variable)]
		public FsmFloat storeX;

		// Token: 0x04000E04 RID: 3588
		[UIHint(UIHint.Variable)]
		public FsmFloat storeY;

		// Token: 0x04000E05 RID: 3589
		[UIHint(UIHint.Variable)]
		public FsmFloat storeWidth;

		// Token: 0x04000E06 RID: 3590
		[UIHint(UIHint.Variable)]
		public FsmFloat storeHeight;

		// Token: 0x04000E07 RID: 3591
		public bool everyFrame;
	}
}
