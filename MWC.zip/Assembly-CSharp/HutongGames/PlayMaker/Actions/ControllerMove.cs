﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015F RID: 351
	[Tooltip("Moves a Game Object with a Character Controller. See also Controller Simple Move. NOTE: It is recommended that you make only one call to Move or SimpleMove per frame.")]
	[ActionCategory(ActionCategory.Character)]
	public class ControllerMove : FsmStateAction
	{
		// Token: 0x0600068D RID: 1677 RVA: 0x00030550 File Offset: 0x0002E750
		public override void Reset()
		{
			this.gameObject = null;
			this.moveVector = new FsmVector3
			{
				UseVariable = true
			};
			this.space = Space.World;
			this.perSecond = true;
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0003058C File Offset: 0x0002E78C
		public override void OnUpdate()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.previousGo)
			{
				this.controller = ownerDefaultTarget.GetComponent<CharacterController>();
				this.previousGo = ownerDefaultTarget;
			}
			if (this.controller != null)
			{
				Vector3 vector = (this.space != Space.World) ? ownerDefaultTarget.transform.TransformDirection(this.moveVector.Value) : this.moveVector.Value;
				if (this.perSecond.Value)
				{
					this.controller.Move(vector * Time.deltaTime);
				}
				else
				{
					this.controller.Move(vector);
				}
			}
		}

		// Token: 0x0400097E RID: 2430
		[CheckForComponent(typeof(CharacterController))]
		[Tooltip("The GameObject to move.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400097F RID: 2431
		[Tooltip("The movement vector.")]
		[RequiredField]
		public FsmVector3 moveVector;

		// Token: 0x04000980 RID: 2432
		[Tooltip("Move in local or word space.")]
		public Space space;

		// Token: 0x04000981 RID: 2433
		[Tooltip("Movement vector is defined in units per second. Makes movement frame rate independent.")]
		public FsmBool perSecond;

		// Token: 0x04000982 RID: 2434
		private GameObject previousGo;

		// Token: 0x04000983 RID: 2435
		private CharacterController controller;
	}
}
