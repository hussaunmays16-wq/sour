﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000170 RID: 368
	[Tooltip("Activates a Camera in the scene.")]
	[ActionCategory(ActionCategory.Camera)]
	public class CutToCamera : FsmStateAction
	{
		// Token: 0x060006D7 RID: 1751 RVA: 0x0003130C File Offset: 0x0002F50C
		public override void Reset()
		{
			this.camera = null;
			this.makeMainCamera = true;
			this.cutBackOnExit = false;
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x00031324 File Offset: 0x0002F524
		public override void OnEnter()
		{
			if (this.camera == null)
			{
				this.LogError("Missing camera!");
				return;
			}
			this.oldCamera = Camera.main;
			CutToCamera.SwitchCamera(Camera.main, this.camera);
			if (this.makeMainCamera)
			{
				this.camera.tag = "MainCamera";
			}
			base.Finish();
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x0003138C File Offset: 0x0002F58C
		public override void OnExit()
		{
			if (this.cutBackOnExit)
			{
				CutToCamera.SwitchCamera(this.camera, this.oldCamera);
			}
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x000313AC File Offset: 0x0002F5AC
		private static void SwitchCamera(Camera camera1, Camera camera2)
		{
			if (camera1 != null)
			{
				camera1.enabled = false;
			}
			if (camera2 != null)
			{
				camera2.enabled = true;
			}
		}

		// Token: 0x040009CD RID: 2509
		[RequiredField]
		public Camera camera;

		// Token: 0x040009CE RID: 2510
		public bool makeMainCamera;

		// Token: 0x040009CF RID: 2511
		public bool cutBackOnExit;

		// Token: 0x040009D0 RID: 2512
		private Camera oldCamera;
	}
}
