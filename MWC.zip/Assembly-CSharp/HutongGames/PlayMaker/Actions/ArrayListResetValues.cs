﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003AD RID: 941
	[Tooltip("Sets all element to to a given value of a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListResetValues : ArrayListActions
	{
		// Token: 0x06000FEC RID: 4076 RVA: 0x00057954 File Offset: 0x00055B54
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.resetValue = null;
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x0005796C File Offset: 0x00055B6C
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.ResetArrayList();
			}
			base.Finish();
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x000579AC File Offset: 0x00055BAC
		public void ResetArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			object valueFromFsmVar = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.resetValue);
			for (int i = 0; i < this.proxy.arrayList.Count; i++)
			{
				this.proxy.arrayList[i] = valueFromFsmVar;
			}
		}

		// Token: 0x040014BE RID: 5310
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014BF RID: 5311
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014C0 RID: 5312
		[Tooltip("The value to reset all the arrayList with")]
		public FsmVar resetValue;
	}
}
