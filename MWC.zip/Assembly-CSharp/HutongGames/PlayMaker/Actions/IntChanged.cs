﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200026C RID: 620
	[Tooltip("Tests if the value of an integer variable changed. Use this to send an event on change, or store a bool that can be used in other operations.")]
	[ActionCategory(ActionCategory.Logic)]
	public class IntChanged : FsmStateAction
	{
		// Token: 0x06000A92 RID: 2706 RVA: 0x00040438 File Offset: 0x0003E638
		public override void Reset()
		{
			this.intVariable = null;
			this.changedEvent = null;
			this.storeResult = null;
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x00040450 File Offset: 0x0003E650
		public override void OnEnter()
		{
			if (this.intVariable.IsNone)
			{
				base.Finish();
				return;
			}
			this.previousValue = this.intVariable.Value;
		}

		// Token: 0x06000A94 RID: 2708 RVA: 0x00040488 File Offset: 0x0003E688
		public override void OnUpdate()
		{
			this.storeResult.Value = false;
			if (this.intVariable.Value != this.previousValue)
			{
				this.previousValue = this.intVariable.Value;
				this.storeResult.Value = true;
				base.Fsm.Event(this.changedEvent);
			}
		}

		// Token: 0x04000E77 RID: 3703
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt intVariable;

		// Token: 0x04000E78 RID: 3704
		public FsmEvent changedEvent;

		// Token: 0x04000E79 RID: 3705
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000E7A RID: 3706
		private int previousValue;
	}
}
