﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000205 RID: 517
	[Tooltip("GUILayout Toolbar. NOTE: Arrays must be the same length as NumButtons or empty.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutToolbar : GUILayoutAction
	{
		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060008DC RID: 2268 RVA: 0x0003B040 File Offset: 0x00039240
		public GUIContent[] Contents
		{
			get
			{
				if (this.contents == null)
				{
					this.contents = new GUIContent[this.numButtons.Value];
					for (int i = 0; i < this.numButtons.Value; i++)
					{
						this.contents[i] = new GUIContent();
					}
					for (int j = 0; j < this.imagesArray.Length; j++)
					{
						this.contents[j].image = this.imagesArray[j].Value;
					}
					for (int k = 0; k < this.textsArray.Length; k++)
					{
						this.contents[k].text = this.textsArray[k].Value;
					}
					for (int l = 0; l < this.tooltipsArray.Length; l++)
					{
						this.contents[l].tooltip = this.tooltipsArray[l].Value;
					}
				}
				return this.contents;
			}
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x0003B138 File Offset: 0x00039338
		public override void Reset()
		{
			base.Reset();
			this.numButtons = 0;
			this.selectedButton = null;
			this.buttonEventsArray = new FsmEvent[0];
			this.imagesArray = new FsmTexture[0];
			this.tooltipsArray = new FsmString[0];
			this.style = "Button";
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x0003B194 File Offset: 0x00039394
		public override void OnEnter()
		{
			string text = this.ErrorCheck();
			if (!string.IsNullOrEmpty(text))
			{
				this.LogError(text);
				base.Finish();
			}
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x0003B1C0 File Offset: 0x000393C0
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.selectedButton.Value = GUILayout.Toolbar(this.selectedButton.Value, this.Contents, this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				if (this.selectedButton.Value < this.buttonEventsArray.Length)
				{
					base.Fsm.Event(this.buttonEventsArray[this.selectedButton.Value]);
					GUIUtility.ExitGUI();
				}
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x0003B260 File Offset: 0x00039460
		public override string ErrorCheck()
		{
			string text = string.Empty;
			if (this.imagesArray.Length > 0 && this.imagesArray.Length != this.numButtons.Value)
			{
				text += "Images array doesn't match NumButtons.\n";
			}
			if (this.textsArray.Length > 0 && this.textsArray.Length != this.numButtons.Value)
			{
				text += "Texts array doesn't match NumButtons.\n";
			}
			if (this.tooltipsArray.Length > 0 && this.tooltipsArray.Length != this.numButtons.Value)
			{
				text += "Tooltips array doesn't match NumButtons.\n";
			}
			return text;
		}

		// Token: 0x04000C9E RID: 3230
		public FsmInt numButtons;

		// Token: 0x04000C9F RID: 3231
		[UIHint(UIHint.Variable)]
		public FsmInt selectedButton;

		// Token: 0x04000CA0 RID: 3232
		public FsmEvent[] buttonEventsArray;

		// Token: 0x04000CA1 RID: 3233
		public FsmTexture[] imagesArray;

		// Token: 0x04000CA2 RID: 3234
		public FsmString[] textsArray;

		// Token: 0x04000CA3 RID: 3235
		public FsmString[] tooltipsArray;

		// Token: 0x04000CA4 RID: 3236
		public FsmString style;

		// Token: 0x04000CA5 RID: 3237
		private GUIContent[] contents;
	}
}
