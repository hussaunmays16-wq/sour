﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000178 RID: 376
	[Tooltip("Sends a log message to the PlayMaker Log Window.")]
	[ActionCategory(ActionCategory.Debug)]
	public class DebugLog : FsmStateAction
	{
		// Token: 0x060006EE RID: 1774 RVA: 0x0003174C File Offset: 0x0002F94C
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.text = string.Empty;
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x00031768 File Offset: 0x0002F968
		public override void OnEnter()
		{
			if (!string.IsNullOrEmpty(this.text.Value))
			{
				ActionHelpers.DebugLog(base.Fsm, this.logLevel, this.text.Value);
			}
			base.Finish();
		}

		// Token: 0x040009E5 RID: 2533
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009E6 RID: 2534
		[Tooltip("Text to print to the PlayMaker log window.")]
		public FsmString text;
	}
}
