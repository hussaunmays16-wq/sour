﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B7 RID: 183
public class DelayBetweenSongs : MonoBehaviour
{
	// Token: 0x0600033C RID: 828 RVA: 0x000154CC File Offset: 0x000136CC
	private void Start()
	{
		this._controller = PlaylistController.InstanceByName(this.playlistControllerName, true);
		this._controller.SongEnded += this.SongEnded;
	}

	// Token: 0x0600033D RID: 829 RVA: 0x000154F8 File Offset: 0x000136F8
	private void OnDisable()
	{
		this._controller.SongEnded -= this.SongEnded;
	}

	// Token: 0x0600033E RID: 830 RVA: 0x00015514 File Offset: 0x00013714
	private void SongEnded(string songName)
	{
		base.StopAllCoroutines();
		base.StartCoroutine(this.PlaySongWithDelay());
	}

	// Token: 0x0600033F RID: 831 RVA: 0x0001552C File Offset: 0x0001372C
	private IEnumerator PlaySongWithDelay()
	{
		float randomTime = UnityEngine.Random.Range(this.minTimeToWait, this.maxTimeToWait);
		if (MasterAudio.IgnoreTimeScale)
		{
			yield return base.StartCoroutine(CoroutineHelper.WaitForActualSeconds(randomTime));
		}
		else
		{
			yield return new WaitForSeconds(randomTime);
		}
		this._controller.PlayNextSong();
		yield break;
	}

	// Token: 0x040004F6 RID: 1270
	public float minTimeToWait = 1f;

	// Token: 0x040004F7 RID: 1271
	public float maxTimeToWait = 2f;

	// Token: 0x040004F8 RID: 1272
	public string playlistControllerName = "PlaylistControllerBass";

	// Token: 0x040004F9 RID: 1273
	private PlaylistController _controller;
}
