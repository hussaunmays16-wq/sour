﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B1 RID: 1201
	[Tooltip("Removes a defined cInput modifier key.")]
	[ActionCategory("cInput")]
	public class CInputRemoveModifierKeyCode : FsmStateAction
	{
		// Token: 0x0600146D RID: 5229 RVA: 0x000890B4 File Offset: 0x000872B4
		public override void Reset()
		{
			this.keyName = KeyCode.None;
		}

		// Token: 0x0600146E RID: 5230 RVA: 0x000890C0 File Offset: 0x000872C0
		public override void OnEnter()
		{
			cInput.RemoveModifier(this.keyName);
			base.Finish();
		}

		// Token: 0x04001CE0 RID: 7392
		[Tooltip("The modifier key to add.")]
		public KeyCode keyName;
	}
}
