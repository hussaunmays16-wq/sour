﻿using System;

// Token: 0x020004DD RID: 1245
public class Achievement_t
{
	// Token: 0x060015F1 RID: 5617 RVA: 0x00096C5C File Offset: 0x00094E5C
	public Achievement_t(string achievementID)
	{
		this.m_strAchievementID = achievementID;
		this.m_strName = string.Empty;
		this.m_strDescription = string.Empty;
		this.m_bAchieved = false;
	}

	// Token: 0x04001DA0 RID: 7584
	public string m_strAchievementID;

	// Token: 0x04001DA1 RID: 7585
	public string m_strName;

	// Token: 0x04001DA2 RID: 7586
	public string m_strDescription;

	// Token: 0x04001DA3 RID: 7587
	public bool m_bAchieved;
}
