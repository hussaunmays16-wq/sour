﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B5 RID: 1205
	[ActionCategory("cInput")]
	[Tooltip("Sets the deadzone of an axis.")]
	public class CInputSetAxisDeadzone : FsmStateAction
	{
		// Token: 0x06001478 RID: 5240 RVA: 0x000891BC File Offset: 0x000873BC
		public override void Reset()
		{
			this.axisName = null;
			this.axisDeadzone = null;
		}

		// Token: 0x06001479 RID: 5241 RVA: 0x000891CC File Offset: 0x000873CC
		public override void OnEnter()
		{
			cInput.SetAxisDeadzone(this.axisName.Value, this.axisDeadzone.Value);
			base.Finish();
		}

		// Token: 0x04001CE8 RID: 7400
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CE9 RID: 7401
		[Tooltip("The name of the axis deadzone.")]
		public FsmFloat axisDeadzone;
	}
}
