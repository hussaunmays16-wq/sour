﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001CD RID: 461
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Sets a Float variable to its absolute value.")]
	public class FloatAbs : FsmStateAction
	{
		// Token: 0x06000819 RID: 2073 RVA: 0x00038584 File Offset: 0x00036784
		public override void Reset()
		{
			this.floatVariable = null;
			this.everyFrame = false;
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00038594 File Offset: 0x00036794
		public override void OnEnter()
		{
			this.DoFloatAbs();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x000385B0 File Offset: 0x000367B0
		public override void OnUpdate()
		{
			this.DoFloatAbs();
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x000385B8 File Offset: 0x000367B8
		private void DoFloatAbs()
		{
			this.floatVariable.Value = Mathf.Abs(this.floatVariable.Value);
		}

		// Token: 0x04000BBF RID: 3007
		[Tooltip("The Float variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x04000BC0 RID: 3008
		[Tooltip("Repeat every frame. Useful if the Float variable is changing.")]
		public bool everyFrame;
	}
}
