﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004BA RID: 1210
	[ActionCategory("cInput")]
	[Tooltip("Sets a cInput key.")]
	public class CInputSetKey : FsmStateAction
	{
		// Token: 0x06001486 RID: 5254 RVA: 0x00089300 File Offset: 0x00087500
		public override void Reset()
		{
			this.actionName = string.Empty;
			this.primary = null;
			this.secondary = null;
			this.primaryModifier = null;
			this.secondaryModifier = null;
		}

		// Token: 0x06001487 RID: 5255 RVA: 0x0008933C File Offset: 0x0008753C
		public override void OnEnter()
		{
			cInput.SetKey(this.actionName.Value, this.primary.Value, this.secondary.Value, this.primaryModifier.Value, this.secondaryModifier.Value);
			base.Finish();
		}

		// Token: 0x04001CF3 RID: 7411
		[Tooltip("The name of the action name.")]
		public FsmString actionName;

		// Token: 0x04001CF4 RID: 7412
		[Tooltip("The name of the primary key.")]
		public FsmString primary;

		// Token: 0x04001CF5 RID: 7413
		[Tooltip("The name of the secondary key.")]
		public FsmString secondary;

		// Token: 0x04001CF6 RID: 7414
		[Tooltip("The name of the primary modifier key.")]
		public FsmString primaryModifier;

		// Token: 0x04001CF7 RID: 7415
		[Tooltip("The name of the secondary modifier key.")]
		public FsmString secondaryModifier;
	}
}
