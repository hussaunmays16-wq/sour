﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015E RID: 350
	[ActionCategory(ActionCategory.Character)]
	[Tooltip("Tests if a Character Controller on a Game Object was touching the ground during the last move.")]
	public class ControllerIsGrounded : FsmStateAction
	{
		// Token: 0x06000688 RID: 1672 RVA: 0x00030460 File Offset: 0x0002E660
		public override void Reset()
		{
			this.gameObject = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00030488 File Offset: 0x0002E688
		public override void OnEnter()
		{
			this.DoControllerIsGrounded();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x000304A4 File Offset: 0x0002E6A4
		public override void OnUpdate()
		{
			this.DoControllerIsGrounded();
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x000304AC File Offset: 0x0002E6AC
		private void DoControllerIsGrounded()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.previousGo)
			{
				this.controller = ownerDefaultTarget.GetComponent<CharacterController>();
				this.previousGo = ownerDefaultTarget;
			}
			if (this.controller == null)
			{
				return;
			}
			bool isGrounded = this.controller.isGrounded;
			this.storeResult.Value = isGrounded;
			base.Fsm.Event((!isGrounded) ? this.falseEvent : this.trueEvent);
		}

		// Token: 0x04000977 RID: 2423
		[RequiredField]
		[CheckForComponent(typeof(CharacterController))]
		[Tooltip("The GameObject to check.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000978 RID: 2424
		[Tooltip("Event to send if touching the ground.")]
		public FsmEvent trueEvent;

		// Token: 0x04000979 RID: 2425
		[Tooltip("Event to send if not touching the ground.")]
		public FsmEvent falseEvent;

		// Token: 0x0400097A RID: 2426
		[UIHint(UIHint.Variable)]
		[Tooltip("Sore the result in a bool variable.")]
		public FsmBool storeResult;

		// Token: 0x0400097B RID: 2427
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x0400097C RID: 2428
		private GameObject previousGo;

		// Token: 0x0400097D RID: 2429
		private CharacterController controller;
	}
}
