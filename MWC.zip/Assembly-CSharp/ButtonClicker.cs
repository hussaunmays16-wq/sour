﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200006A RID: 106
[AddComponentMenu("Dark Tonic/Master Audio/Button Clicker")]
public class ButtonClicker : MonoBehaviour
{
	// Token: 0x06000163 RID: 355 RVA: 0x00008D34 File Offset: 0x00006F34
	private void Awake()
	{
		this._trans = base.transform;
		this._originalSize = this._trans.localScale;
		this._smallerSize = this._originalSize * 0.9f;
		this._largerSize = this._originalSize * 1.1f;
		Transform parent = this._trans.parent;
		if (this.resizeOnClick && this.resizeClickAllSiblings && parent != null)
		{
			for (int i = 0; i < parent.transform.childCount; i++)
			{
				Transform child = parent.transform.GetChild(i);
				this._siblingClickScaleByTransform.Add(child, child.localScale);
			}
		}
		if (!this.resizeOnHover || !this.resizeHoverAllSiblings || parent == null)
		{
			return;
		}
		for (int j = 0; j < parent.transform.childCount; j++)
		{
			Transform child2 = parent.transform.GetChild(j);
			this._siblingHoverScaleByTransform.Add(child2, child2.localScale);
		}
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00008E54 File Offset: 0x00007054
	private void OnPress(bool isDown)
	{
		if (isDown)
		{
			if (!base.enabled)
			{
				return;
			}
			MasterAudio.PlaySoundAndForget(this.mouseDownSound, 1f, null, 0f, null);
			if (!this.resizeOnClick)
			{
				return;
			}
			this._trans.localScale = this._smallerSize;
			foreach (KeyValuePair<Transform, Vector3> keyValuePair in this._siblingClickScaleByTransform)
			{
				Transform key = keyValuePair.Key;
				Dictionary<Transform, Vector3>.Enumerator enumerator;
				KeyValuePair<Transform, Vector3> keyValuePair2 = enumerator.Current;
				key.localScale = keyValuePair2.Value * 0.9f;
			}
		}
		else
		{
			if (base.enabled)
			{
				MasterAudio.PlaySoundAndForget(this.mouseUpSound, 1f, null, 0f, null);
			}
			if (!this.resizeOnClick)
			{
				return;
			}
			this._trans.localScale = this._originalSize;
			foreach (KeyValuePair<Transform, Vector3> keyValuePair3 in this._siblingClickScaleByTransform)
			{
				Transform key2 = keyValuePair3.Key;
				Dictionary<Transform, Vector3>.Enumerator enumerator2;
				KeyValuePair<Transform, Vector3> keyValuePair4 = enumerator2.Current;
				key2.localScale = keyValuePair4.Value;
			}
		}
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00008F8C File Offset: 0x0000718C
	private void OnClick()
	{
		if (base.enabled)
		{
			MasterAudio.PlaySoundAndForget(this.mouseClickSound, 1f, null, 0f, null);
		}
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00008FC4 File Offset: 0x000071C4
	private void OnHover(bool isOver)
	{
		if (isOver)
		{
			if (!base.enabled)
			{
				return;
			}
			MasterAudio.PlaySoundAndForget(this.mouseOverSound, 1f, null, 0f, null);
			if (!this.resizeOnHover)
			{
				return;
			}
			this._trans.localScale = this._largerSize;
			foreach (KeyValuePair<Transform, Vector3> keyValuePair in this._siblingHoverScaleByTransform)
			{
				Transform key = keyValuePair.Key;
				Dictionary<Transform, Vector3>.Enumerator enumerator;
				KeyValuePair<Transform, Vector3> keyValuePair2 = enumerator.Current;
				key.localScale = keyValuePair2.Value * 1.1f;
			}
		}
		else
		{
			if (base.enabled)
			{
				MasterAudio.PlaySoundAndForget(this.mouseOutSound, 1f, null, 0f, null);
			}
			if (!this.resizeOnHover)
			{
				return;
			}
			this._trans.localScale = this._originalSize;
			foreach (KeyValuePair<Transform, Vector3> keyValuePair3 in this._siblingHoverScaleByTransform)
			{
				Transform key2 = keyValuePair3.Key;
				Dictionary<Transform, Vector3>.Enumerator enumerator2;
				KeyValuePair<Transform, Vector3> keyValuePair4 = enumerator2.Current;
				key2.localScale = keyValuePair4.Value;
			}
		}
	}

	// Token: 0x04000189 RID: 393
	public const float SmallSizeMultiplier = 0.9f;

	// Token: 0x0400018A RID: 394
	public const float LargeSizeMultiplier = 1.1f;

	// Token: 0x0400018B RID: 395
	public bool resizeOnClick = true;

	// Token: 0x0400018C RID: 396
	public bool resizeClickAllSiblings;

	// Token: 0x0400018D RID: 397
	public bool resizeOnHover;

	// Token: 0x0400018E RID: 398
	public bool resizeHoverAllSiblings;

	// Token: 0x0400018F RID: 399
	public string mouseDownSound = string.Empty;

	// Token: 0x04000190 RID: 400
	public string mouseUpSound = string.Empty;

	// Token: 0x04000191 RID: 401
	public string mouseClickSound = string.Empty;

	// Token: 0x04000192 RID: 402
	public string mouseOverSound = string.Empty;

	// Token: 0x04000193 RID: 403
	public string mouseOutSound = string.Empty;

	// Token: 0x04000194 RID: 404
	private Vector3 _originalSize;

	// Token: 0x04000195 RID: 405
	private Vector3 _smallerSize;

	// Token: 0x04000196 RID: 406
	private Vector3 _largerSize;

	// Token: 0x04000197 RID: 407
	private Transform _trans;

	// Token: 0x04000198 RID: 408
	private readonly Dictionary<Transform, Vector3> _siblingClickScaleByTransform = new Dictionary<Transform, Vector3>();

	// Token: 0x04000199 RID: 409
	private readonly Dictionary<Transform, Vector3> _siblingHoverScaleByTransform = new Dictionary<Transform, Vector3>();
}
