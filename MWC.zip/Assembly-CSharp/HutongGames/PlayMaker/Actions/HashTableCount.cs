﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C1 RID: 961
	[Tooltip("Count the number of items ( key/value pairs) in a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy).")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableCount : HashTableActions
	{
		// Token: 0x0600103E RID: 4158 RVA: 0x00058BB4 File Offset: 0x00056DB4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.count = null;
		}

		// Token: 0x0600103F RID: 4159 RVA: 0x00058BCC File Offset: 0x00056DCC
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doHashTableCount();
			}
			base.Finish();
		}

		// Token: 0x06001040 RID: 4160 RVA: 0x00058C0C File Offset: 0x00056E0C
		public void doHashTableCount()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.count.Value = this.proxy.hashTable.Count;
		}

		// Token: 0x04001512 RID: 5394
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001513 RID: 5395
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001514 RID: 5396
		[RequiredField]
		[Tooltip("The number of items in that hashTable")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmInt count;
	}
}
