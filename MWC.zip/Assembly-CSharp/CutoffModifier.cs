﻿using System;
using UnityEngine;

// Token: 0x02000002 RID: 2
public class CutoffModifier : MonoBehaviour
{
	// Token: 0x06000002 RID: 2 RVA: 0x000020F4 File Offset: 0x000002F4
	private void Update()
	{
		base.GetComponent<Renderer>().material.SetFloat("_Cutoff", this.cutoff);
	}

	// Token: 0x04000001 RID: 1
	public float cutoff;
}
