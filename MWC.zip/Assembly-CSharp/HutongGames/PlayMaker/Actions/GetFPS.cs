﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200000B RID: 11
	[Tooltip("It calculates frames/second over each updateInterval.It is also fairly accurate at very low FPS counts (<10).We do this not by simply counting frames per interval, butby accumulating FPS for each frame. This way we end up withcorrect overall FPS even if the interval renders something like 5.5 frames. credits: http://unifycommunity.com/wiki/index.php?title=FramesPerSecond")]
	[ActionCategory(ActionCategory.Time)]
	public class GetFPS : FsmStateAction
	{
		// Token: 0x06000021 RID: 33 RVA: 0x00002834 File Offset: 0x00000A34
		public override void Reset()
		{
			this.updateInterval = 0.5f;
			this.FPS = null;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00002850 File Offset: 0x00000A50
		public override void OnUpdate()
		{
			this.timeleft -= Time.deltaTime;
			this.accum += Time.timeScale / Time.deltaTime;
			this.frames++;
			if ((double)this.timeleft <= 0.0)
			{
				this.FPS.Value = this.accum / (float)this.frames;
				this.FPS_asString.Value = string.Empty + (this.accum / (float)this.frames).ToString("f2");
				this.timeleft = this.updateInterval.Value;
				this.accum = 0f;
				this.frames = 0;
			}
		}

		// Token: 0x0400001D RID: 29
		[Tooltip("Interval sampling")]
		public FsmFloat updateInterval = 0.5f;

		// Token: 0x0400001E RID: 30
		private float accum;

		// Token: 0x0400001F RID: 31
		private int frames;

		// Token: 0x04000020 RID: 32
		private float timeleft;

		// Token: 0x04000021 RID: 33
		[Tooltip("The current Frame per second")]
		public FsmFloat FPS;

		// Token: 0x04000022 RID: 34
		[Tooltip("The current Frame per second formated as string")]
		public FsmString FPS_asString;
	}
}
