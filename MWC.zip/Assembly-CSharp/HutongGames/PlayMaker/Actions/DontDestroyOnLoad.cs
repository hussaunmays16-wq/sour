﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000183 RID: 387
	[ActionCategory(ActionCategory.Level)]
	[Tooltip("Makes the Game Object not be destroyed automatically when loading a new scene.")]
	public class DontDestroyOnLoad : FsmStateAction
	{
		// Token: 0x06000714 RID: 1812 RVA: 0x00031BD0 File Offset: 0x0002FDD0
		public override void Reset()
		{
			this.gameObject = null;
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x00031BDC File Offset: 0x0002FDDC
		public override void OnEnter()
		{
			UnityEngine.Object.DontDestroyOnLoad(base.Owner.transform.root.gameObject);
			base.Finish();
		}

		// Token: 0x040009FB RID: 2555
		[Tooltip("GameObject to mark as DontDestroyOnLoad.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;
	}
}
