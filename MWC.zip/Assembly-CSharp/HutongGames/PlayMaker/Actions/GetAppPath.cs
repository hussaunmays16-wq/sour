﻿using System;
using System.IO;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003FA RID: 1018
	[Tooltip("Get Data Path, Application Folder and persistentDataPath.")]
	[ActionCategory(ActionCategory.Application)]
	public class GetAppPath : FsmStateAction
	{
		// Token: 0x06001131 RID: 4401 RVA: 0x0005F180 File Offset: 0x0005D380
		public override void OnEnter()
		{
			string text = Application.dataPath;
			string text2 = Application.persistentDataPath;
			string text3 = Path.GetFullPath(".");
			text += "/";
			text2 += "/";
			text3 += "/";
			this.DataPathResult.Value = text;
			this.AppFolderResult.Value = text3;
			this.PersistentPathResult.Value = text2;
			this.PlaformResult.Value = Application.platform.ToString();
			base.Finish();
		}

		// Token: 0x0400168C RID: 5772
		[Tooltip("Path Result")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString DataPathResult;

		// Token: 0x0400168D RID: 5773
		public FsmString AppFolderResult;

		// Token: 0x0400168E RID: 5774
		public FsmString PersistentPathResult;

		// Token: 0x0400168F RID: 5775
		[UIHint(UIHint.Variable)]
		[Tooltip("Platform Result Result")]
		public FsmString PlaformResult;
	}
}
