﻿using System;
using UnityEngine;

// Token: 0x0200007C RID: 124
public class DynamicGroupVariation : MonoBehaviour
{
	// Token: 0x17000008 RID: 8
	// (get) Token: 0x060001C1 RID: 449 RVA: 0x0000BF44 File Offset: 0x0000A144
	public AudioDistortionFilter DistortionFilter
	{
		get
		{
			if (this._distFilter != null)
			{
				return this._distFilter;
			}
			this._distFilter = base.GetComponent<AudioDistortionFilter>();
			return this._distFilter;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x060001C2 RID: 450 RVA: 0x0000BF7C File Offset: 0x0000A17C
	public AudioReverbFilter ReverbFilter
	{
		get
		{
			if (this._reverbFilter != null)
			{
				return this._reverbFilter;
			}
			this._reverbFilter = base.GetComponent<AudioReverbFilter>();
			return this._reverbFilter;
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x060001C3 RID: 451 RVA: 0x0000BFB4 File Offset: 0x0000A1B4
	public AudioChorusFilter ChorusFilter
	{
		get
		{
			if (this._chorusFilter != null)
			{
				return this._chorusFilter;
			}
			this._chorusFilter = base.GetComponent<AudioChorusFilter>();
			return this._chorusFilter;
		}
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x060001C4 RID: 452 RVA: 0x0000BFEC File Offset: 0x0000A1EC
	public AudioEchoFilter EchoFilter
	{
		get
		{
			if (this._echoFilter != null)
			{
				return this._echoFilter;
			}
			this._echoFilter = base.GetComponent<AudioEchoFilter>();
			return this._echoFilter;
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x060001C5 RID: 453 RVA: 0x0000C024 File Offset: 0x0000A224
	public AudioLowPassFilter LowPassFilter
	{
		get
		{
			if (this._lpFilter != null)
			{
				return this._lpFilter;
			}
			this._lpFilter = base.GetComponent<AudioLowPassFilter>();
			return this._lpFilter;
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x060001C6 RID: 454 RVA: 0x0000C05C File Offset: 0x0000A25C
	public AudioHighPassFilter HighPassFilter
	{
		get
		{
			if (this._hpFilter != null)
			{
				return this._hpFilter;
			}
			this._hpFilter = base.GetComponent<AudioHighPassFilter>();
			return this._hpFilter;
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x060001C7 RID: 455 RVA: 0x0000C094 File Offset: 0x0000A294
	public DynamicSoundGroup ParentGroup
	{
		get
		{
			if (this._parentGroupScript == null)
			{
				this._parentGroupScript = this.Trans.parent.GetComponent<DynamicSoundGroup>();
			}
			if (this._parentGroupScript == null)
			{
				Debug.LogError("The Group that Dynamic Sound Variation '" + base.name + "' is in does not have a DynamicSoundGroup script in it!");
			}
			return this._parentGroupScript;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x060001C8 RID: 456 RVA: 0x0000C0FC File Offset: 0x0000A2FC
	public Transform Trans
	{
		get
		{
			if (this._trans != null)
			{
				return this._trans;
			}
			this._trans = base.transform;
			return this._trans;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x060001C9 RID: 457 RVA: 0x0000C134 File Offset: 0x0000A334
	public bool HasActiveFXFilter
	{
		get
		{
			return (this.HighPassFilter != null && this.HighPassFilter.enabled) || (this.LowPassFilter != null && this.LowPassFilter.enabled) || (this.ReverbFilter != null && this.ReverbFilter.enabled) || (this.DistortionFilter != null && this.DistortionFilter.enabled) || (this.EchoFilter != null && this.EchoFilter.enabled) || (this.ChorusFilter != null && this.ChorusFilter.enabled);
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x060001CA RID: 458 RVA: 0x0000C214 File Offset: 0x0000A414
	public AudioSource VarAudio
	{
		get
		{
			if (this._aud != null)
			{
				return this._aud;
			}
			this._aud = base.GetComponent<AudioSource>();
			return this._aud;
		}
	}

	// Token: 0x040002A6 RID: 678
	public bool useLocalization;

	// Token: 0x040002A7 RID: 679
	public bool useRandomPitch;

	// Token: 0x040002A8 RID: 680
	public SoundGroupVariation.RandomPitchMode randomPitchMode;

	// Token: 0x040002A9 RID: 681
	public float randomPitchMin;

	// Token: 0x040002AA RID: 682
	public float randomPitchMax;

	// Token: 0x040002AB RID: 683
	public bool useRandomVolume;

	// Token: 0x040002AC RID: 684
	public SoundGroupVariation.RandomVolumeMode randomVolumeMode;

	// Token: 0x040002AD RID: 685
	public float randomVolumeMin;

	// Token: 0x040002AE RID: 686
	public float randomVolumeMax;

	// Token: 0x040002AF RID: 687
	public int weight = 1;

	// Token: 0x040002B0 RID: 688
	public MasterAudio.AudioLocation audLocation;

	// Token: 0x040002B1 RID: 689
	public string resourceFileName;

	// Token: 0x040002B2 RID: 690
	public bool isExpanded = true;

	// Token: 0x040002B3 RID: 691
	public bool isChecked = true;

	// Token: 0x040002B4 RID: 692
	public float fxTailTime;

	// Token: 0x040002B5 RID: 693
	public bool useFades;

	// Token: 0x040002B6 RID: 694
	public float fadeInTime;

	// Token: 0x040002B7 RID: 695
	public float fadeOutTime;

	// Token: 0x040002B8 RID: 696
	public bool useIntroSilence;

	// Token: 0x040002B9 RID: 697
	public float introSilenceMin;

	// Token: 0x040002BA RID: 698
	public float introSilenceMax;

	// Token: 0x040002BB RID: 699
	public bool useRandomStartTime;

	// Token: 0x040002BC RID: 700
	public float randomStartMinPercent;

	// Token: 0x040002BD RID: 701
	public float randomStartMaxPercent;

	// Token: 0x040002BE RID: 702
	private AudioDistortionFilter _distFilter;

	// Token: 0x040002BF RID: 703
	private AudioEchoFilter _echoFilter;

	// Token: 0x040002C0 RID: 704
	private AudioHighPassFilter _hpFilter;

	// Token: 0x040002C1 RID: 705
	private AudioLowPassFilter _lpFilter;

	// Token: 0x040002C2 RID: 706
	private AudioReverbFilter _reverbFilter;

	// Token: 0x040002C3 RID: 707
	private AudioChorusFilter _chorusFilter;

	// Token: 0x040002C4 RID: 708
	private DynamicSoundGroup _parentGroupScript;

	// Token: 0x040002C5 RID: 709
	private Transform _trans;

	// Token: 0x040002C6 RID: 710
	private AudioSource _aud;
}
