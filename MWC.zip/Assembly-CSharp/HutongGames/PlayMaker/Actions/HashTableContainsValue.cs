﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C0 RID: 960
	[Tooltip("Check if a value exists in a PlayMaker HashTable Proxy component (PlayMakerHashTablePRoxy)")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableContainsValue : HashTableActions
	{
		// Token: 0x0600103A RID: 4154 RVA: 0x00058AB8 File Offset: 0x00056CB8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.containsValue = null;
			this.valueFoundEvent = null;
			this.valueNotFoundEvent = null;
			this.variable = null;
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x00058AF0 File Offset: 0x00056CF0
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doContainsValue();
			}
			base.Finish();
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x00058B30 File Offset: 0x00056D30
		public void doContainsValue()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.containsValue.Value = this.proxy.hashTable.ContainsValue(PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable));
			if (this.containsValue.Value)
			{
				base.Fsm.Event(this.valueFoundEvent);
			}
			else
			{
				base.Fsm.Event(this.valueNotFoundEvent);
			}
		}

		// Token: 0x0400150C RID: 5388
		[ActionSection("Set up")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400150D RID: 5389
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x0400150E RID: 5390
		[Tooltip("The variable to check for.")]
		public FsmVar variable;

		// Token: 0x0400150F RID: 5391
		[Tooltip("Store the result of the test")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmBool containsValue;

		// Token: 0x04001510 RID: 5392
		[Tooltip("The event to trigger when value is found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent valueFoundEvent;

		// Token: 0x04001511 RID: 5393
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when value is not found")]
		public FsmEvent valueNotFoundEvent;
	}
}
