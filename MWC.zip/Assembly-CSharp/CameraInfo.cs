﻿using System;
using UnityEngine;

// Token: 0x02000468 RID: 1128
[AddComponentMenu("Camera/CameraInfo")]
[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class CameraInfo : MonoBehaviour
{
	// Token: 0x17000095 RID: 149
	// (get) Token: 0x060012F7 RID: 4855 RVA: 0x0006BB70 File Offset: 0x00069D70
	// (set) Token: 0x060012F8 RID: 4856 RVA: 0x0006BB78 File Offset: 0x00069D78
	public static Matrix4x4 ViewMatrix { get; private set; }

	// Token: 0x17000096 RID: 150
	// (get) Token: 0x060012F9 RID: 4857 RVA: 0x0006BB80 File Offset: 0x00069D80
	// (set) Token: 0x060012FA RID: 4858 RVA: 0x0006BB88 File Offset: 0x00069D88
	public static Matrix4x4 ProjectionMatrix { get; private set; }

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x060012FB RID: 4859 RVA: 0x0006BB90 File Offset: 0x00069D90
	// (set) Token: 0x060012FC RID: 4860 RVA: 0x0006BB98 File Offset: 0x00069D98
	public static Matrix4x4 ViewProjectionMatrix { get; private set; }

	// Token: 0x17000098 RID: 152
	// (get) Token: 0x060012FD RID: 4861 RVA: 0x0006BBA0 File Offset: 0x00069DA0
	// (set) Token: 0x060012FE RID: 4862 RVA: 0x0006BBA8 File Offset: 0x00069DA8
	public static Matrix4x4 PrevViewMatrix { get; private set; }

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x060012FF RID: 4863 RVA: 0x0006BBB0 File Offset: 0x00069DB0
	// (set) Token: 0x06001300 RID: 4864 RVA: 0x0006BBB8 File Offset: 0x00069DB8
	public static Matrix4x4 PrevProjectionMatrix { get; private set; }

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x06001301 RID: 4865 RVA: 0x0006BBC0 File Offset: 0x00069DC0
	// (set) Token: 0x06001302 RID: 4866 RVA: 0x0006BBC8 File Offset: 0x00069DC8
	public static Matrix4x4 PrevViewProjMatrix { get; private set; }

	// Token: 0x06001303 RID: 4867 RVA: 0x0006BBD0 File Offset: 0x00069DD0
	protected void Awake()
	{
		this.m_d3d = (SystemInfo.graphicsDeviceVersion.IndexOf("Direct3D") > -1);
		CameraInfo.ViewMatrix = Matrix4x4.identity;
		CameraInfo.ProjectionMatrix = Matrix4x4.identity;
		CameraInfo.ViewProjectionMatrix = Matrix4x4.identity;
		CameraInfo.PrevViewMatrix = Matrix4x4.identity;
		CameraInfo.PrevProjectionMatrix = Matrix4x4.identity;
		CameraInfo.PrevViewProjMatrix = Matrix4x4.identity;
		this.UpdateCurrentMatrices();
	}

	// Token: 0x06001304 RID: 4868 RVA: 0x0006BC38 File Offset: 0x00069E38
	protected void Update()
	{
		CameraInfo.PrevViewMatrix = CameraInfo.ViewMatrix;
		CameraInfo.PrevProjectionMatrix = CameraInfo.ProjectionMatrix;
		CameraInfo.PrevViewProjMatrix = CameraInfo.ViewProjectionMatrix;
		this.UpdateCurrentMatrices();
	}

	// Token: 0x06001305 RID: 4869 RVA: 0x0006BC6C File Offset: 0x00069E6C
	private void UpdateCurrentMatrices()
	{
		CameraInfo.ViewMatrix = base.GetComponent<Camera>().worldToCameraMatrix;
		Matrix4x4 projectionMatrix = base.GetComponent<Camera>().projectionMatrix;
		if (this.m_d3d)
		{
			for (int i = 0; i < 4; i++)
			{
				projectionMatrix[1, i] = -projectionMatrix[1, i];
			}
			for (int j = 0; j < 4; j++)
			{
				projectionMatrix[2, j] = projectionMatrix[2, j] * 0.5f + projectionMatrix[3, j] * 0.5f;
			}
		}
		CameraInfo.ProjectionMatrix = projectionMatrix;
		CameraInfo.ViewProjectionMatrix = CameraInfo.ProjectionMatrix * CameraInfo.ViewMatrix;
	}

	// Token: 0x040018C7 RID: 6343
	private bool m_d3d;
}
