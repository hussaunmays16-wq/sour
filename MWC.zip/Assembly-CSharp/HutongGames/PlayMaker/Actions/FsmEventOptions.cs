﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DE RID: 478
	[Tooltip("Sets how subsequent events sent in this state are handled.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class FsmEventOptions : FsmStateAction
	{
		// Token: 0x06000863 RID: 2147 RVA: 0x000391E4 File Offset: 0x000373E4
		public override void Reset()
		{
			this.sendToFsmComponent = null;
			this.sendToGameObject = null;
			this.fsmName = string.Empty;
			this.sendToChildren = false;
			this.broadcastToAll = false;
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x00039228 File Offset: 0x00037428
		public override void OnUpdate()
		{
		}

		// Token: 0x04000C09 RID: 3081
		public PlayMakerFSM sendToFsmComponent;

		// Token: 0x04000C0A RID: 3082
		public FsmGameObject sendToGameObject;

		// Token: 0x04000C0B RID: 3083
		public FsmString fsmName;

		// Token: 0x04000C0C RID: 3084
		public FsmBool sendToChildren;

		// Token: 0x04000C0D RID: 3085
		public FsmBool broadcastToAll;
	}
}
