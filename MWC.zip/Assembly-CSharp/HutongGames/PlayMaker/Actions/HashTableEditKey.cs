﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C2 RID: 962
	[Tooltip("Edit a key from a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy)")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableEditKey : HashTableActions
	{
		// Token: 0x06001042 RID: 4162 RVA: 0x00058C48 File Offset: 0x00056E48
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
			this.newKey = null;
			this.keyNotFoundEvent = null;
			this.newKeyExistsAlreadyEvent = null;
		}

		// Token: 0x06001043 RID: 4163 RVA: 0x00058C80 File Offset: 0x00056E80
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.EditHashTableKey();
			}
			base.Finish();
		}

		// Token: 0x06001044 RID: 4164 RVA: 0x00058CC0 File Offset: 0x00056EC0
		public void EditHashTableKey()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			if (!this.proxy.hashTable.ContainsKey(this.key.Value))
			{
				base.Fsm.Event(this.keyNotFoundEvent);
				return;
			}
			if (this.proxy.hashTable.ContainsKey(this.newKey.Value))
			{
				base.Fsm.Event(this.newKeyExistsAlreadyEvent);
				return;
			}
			object value = this.proxy.hashTable[this.key.Value];
			this.proxy.hashTable[this.newKey.Value] = value;
			this.proxy.hashTable.Remove(this.key.Value);
		}

		// Token: 0x04001515 RID: 5397
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[ActionSection("Set up")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001516 RID: 5398
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001517 RID: 5399
		[RequiredField]
		[Tooltip("The Key value to edit")]
		[UIHint(UIHint.FsmString)]
		public FsmString key;

		// Token: 0x04001518 RID: 5400
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		[Tooltip("The Key value to edit")]
		public FsmString newKey;

		// Token: 0x04001519 RID: 5401
		[Tooltip("Event sent if this HashTable key does not exists")]
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Result")]
		public FsmEvent keyNotFoundEvent;

		// Token: 0x0400151A RID: 5402
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this HashTable already contains the new key")]
		public FsmEvent newKeyExistsAlreadyEvent;
	}
}
