﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000238 RID: 568
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when a Key is released.")]
	public class GetKeyUp : FsmStateAction
	{
		// Token: 0x060009BA RID: 2490 RVA: 0x0003E17C File Offset: 0x0003C37C
		public override void Reset()
		{
			this.sendEvent = null;
			this.key = KeyCode.None;
			this.storeResult = null;
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x0003E194 File Offset: 0x0003C394
		public override void OnUpdate()
		{
			bool keyUp = Input.GetKeyUp(this.key);
			if (keyUp)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = keyUp;
		}

		// Token: 0x04000DBC RID: 3516
		[RequiredField]
		public KeyCode key;

		// Token: 0x04000DBD RID: 3517
		public FsmEvent sendEvent;

		// Token: 0x04000DBE RID: 3518
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;
	}
}
