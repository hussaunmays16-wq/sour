﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AB RID: 1195
	[ActionCategory("cInput")]
	[Tooltip("Waits for key inputs and sends events in hierarchy keyDown -> keyUp -> any key pressed")]
	public class CInputGetKey : FsmStateAction
	{
		// Token: 0x0600145C RID: 5212 RVA: 0x00088D4C File Offset: 0x00086F4C
		public override void Reset()
		{
			this.keyName = null;
			this.keyDownEvent = null;
			this.keyUpEvent = null;
			this.keyPressedEvent = null;
			this.everyFrame = null;
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x00088D74 File Offset: 0x00086F74
		public override void OnLateUpdate()
		{
			if (cInput.GetKeyDown(this.keyName.Value))
			{
				base.Fsm.Event(this.keyDownEvent);
			}
			else if (cInput.GetKeyUp(this.keyName.Value))
			{
				base.Fsm.Event(this.keyUpEvent);
			}
			else if (cInput.GetKey(this.keyName.Value))
			{
				base.Fsm.Event(this.keyPressedEvent);
			}
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CC9 RID: 7369
		[RequiredField]
		[Tooltip("The name of the key.")]
		public FsmString keyName;

		// Token: 0x04001CCA RID: 7370
		[Tooltip("key gets down.")]
		public FsmEvent keyDownEvent;

		// Token: 0x04001CCB RID: 7371
		[Tooltip("Key gets up.")]
		public FsmEvent keyUpEvent;

		// Token: 0x04001CCC RID: 7372
		[Tooltip("Key is still pressed.")]
		public FsmEvent keyPressedEvent;

		// Token: 0x04001CCD RID: 7373
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
