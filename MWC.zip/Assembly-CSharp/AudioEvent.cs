﻿using System;
using System.Collections.Generic;
using UnityEngine.Audio;

// Token: 0x02000075 RID: 117
[Serializable]
public class AudioEvent
{
	// Token: 0x17000007 RID: 7
	// (get) Token: 0x060001BA RID: 442 RVA: 0x0000BDAC File Offset: 0x00009FAC
	public bool IsFadeCommand
	{
		get
		{
			return (this.currentSoundFunctionType == MasterAudio.EventSoundFunctionType.PlaylistControl && this.currentPlaylistCommand == MasterAudio.PlaylistCommand.FadeToVolume) || (this.currentSoundFunctionType == MasterAudio.EventSoundFunctionType.BusControl && this.currentBusCommand == MasterAudio.BusCommand.FadeToVolume) || (this.currentSoundFunctionType == MasterAudio.EventSoundFunctionType.GroupControl && (this.currentSoundGroupCommand == MasterAudio.SoundGroupCommand.FadeToVolume || this.currentSoundGroupCommand == MasterAudio.SoundGroupCommand.FadeOutAllOfSound || this.currentSoundGroupCommand == MasterAudio.SoundGroupCommand.FadeOutSoundGroupOfTransform));
		}
	}

	// Token: 0x0400025C RID: 604
	public string actionName = "Your action name";

	// Token: 0x0400025D RID: 605
	public bool isExpanded = true;

	// Token: 0x0400025E RID: 606
	public string soundType = string.Empty;

	// Token: 0x0400025F RID: 607
	public bool allPlaylistControllersForGroupCmd;

	// Token: 0x04000260 RID: 608
	public bool allSoundTypesForGroupCmd;

	// Token: 0x04000261 RID: 609
	public bool allSoundTypesForBusCmd;

	// Token: 0x04000262 RID: 610
	public float volume = 1f;

	// Token: 0x04000263 RID: 611
	public bool useFixedPitch;

	// Token: 0x04000264 RID: 612
	public float pitch = 1f;

	// Token: 0x04000265 RID: 613
	public bool emitParticles;

	// Token: 0x04000266 RID: 614
	public int particleCountToEmit = 1;

	// Token: 0x04000267 RID: 615
	public float delaySound;

	// Token: 0x04000268 RID: 616
	public MasterAudio.EventSoundFunctionType currentSoundFunctionType;

	// Token: 0x04000269 RID: 617
	public MasterAudio.PlaylistCommand currentPlaylistCommand;

	// Token: 0x0400026A RID: 618
	public MasterAudio.SoundGroupCommand currentSoundGroupCommand;

	// Token: 0x0400026B RID: 619
	public MasterAudio.BusCommand currentBusCommand;

	// Token: 0x0400026C RID: 620
	public MasterAudio.CustomEventCommand currentCustomEventCommand;

	// Token: 0x0400026D RID: 621
	public MasterAudio.GlobalCommand currentGlobalCommand;

	// Token: 0x0400026E RID: 622
	public MasterAudio.UnityMixerCommand currentMixerCommand;

	// Token: 0x0400026F RID: 623
	public AudioMixerSnapshot snapshotToTransitionTo;

	// Token: 0x04000270 RID: 624
	public float snapshotTransitionTime = 1f;

	// Token: 0x04000271 RID: 625
	public List<AudioEvent.MA_SnapshotInfo> snapshotsToBlend = new List<AudioEvent.MA_SnapshotInfo>
	{
		new AudioEvent.MA_SnapshotInfo(null, 1f)
	};

	// Token: 0x04000272 RID: 626
	public MasterAudio.PersistentSettingsCommand currentPersistentSettingsCommand;

	// Token: 0x04000273 RID: 627
	public string busName = string.Empty;

	// Token: 0x04000274 RID: 628
	public string playlistName = string.Empty;

	// Token: 0x04000275 RID: 629
	public string playlistControllerName = string.Empty;

	// Token: 0x04000276 RID: 630
	public bool startPlaylist = true;

	// Token: 0x04000277 RID: 631
	public float fadeVolume;

	// Token: 0x04000278 RID: 632
	public float fadeTime = 1f;

	// Token: 0x04000279 RID: 633
	public AudioEvent.TargetVolumeMode targetVolMode;

	// Token: 0x0400027A RID: 634
	public string clipName = "[None]";

	// Token: 0x0400027B RID: 635
	public EventSounds.VariationType variationType = EventSounds.VariationType.PlayRandom;

	// Token: 0x0400027C RID: 636
	public string variationName = string.Empty;

	// Token: 0x0400027D RID: 637
	public string theCustomEventName = string.Empty;

	// Token: 0x02000076 RID: 118
	public enum TargetVolumeMode
	{
		// Token: 0x0400027F RID: 639
		UseSliderValue,
		// Token: 0x04000280 RID: 640
		UseSpecificValue
	}

	// Token: 0x02000077 RID: 119
	[Serializable]
	public class MA_SnapshotInfo
	{
		// Token: 0x060001BB RID: 443 RVA: 0x0000BE24 File Offset: 0x0000A024
		public MA_SnapshotInfo(AudioMixerSnapshot snap, float wt)
		{
			this.snapshot = snap;
			this.weight = wt;
		}

		// Token: 0x04000281 RID: 641
		public AudioMixerSnapshot snapshot;

		// Token: 0x04000282 RID: 642
		public float weight;
	}
}
