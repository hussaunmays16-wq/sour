﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A4 RID: 932
	[Tooltip("Gets a random item from a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetRandom : ArrayListActions
	{
		// Token: 0x06000FC9 RID: 4041 RVA: 0x00056DD8 File Offset: 0x00054FD8
		public override void Reset()
		{
			this.gameObject = null;
			this.failureEvent = null;
			this.randomItem = null;
			this.randomIndex = null;
		}

		// Token: 0x06000FCA RID: 4042 RVA: 0x00056DF8 File Offset: 0x00054FF8
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.GetRandomItem();
			}
			base.Finish();
		}

		// Token: 0x06000FCB RID: 4043 RVA: 0x00056E38 File Offset: 0x00055038
		public void GetRandomItem()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			int num = UnityEngine.Random.Range(0, this.proxy.arrayList.Count);
			object value = null;
			try
			{
				value = this.proxy.arrayList[num];
			}
			catch (Exception ex)
			{
				Debug.LogWarning(ex.Message);
				base.Fsm.Event(this.failureEvent);
				return;
			}
			this.randomIndex.Value = num;
			if (!PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.randomItem, value))
			{
				Debug.LogWarning("ApplyValueToFsmVar failed");
				base.Fsm.Event(this.failureEvent);
				return;
			}
		}

		// Token: 0x0400148A RID: 5258
		[ActionSection("Set up")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400148B RID: 5259
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400148C RID: 5260
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The random item data picked from the array")]
		public FsmVar randomItem;

		// Token: 0x0400148D RID: 5261
		[Tooltip("The random item index picked from the array")]
		[UIHint(UIHint.Variable)]
		public FsmInt randomIndex;

		// Token: 0x0400148E RID: 5262
		[Tooltip("The event to trigger if the action fails ( likely and index is out of range exception)")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent failureEvent;
	}
}
