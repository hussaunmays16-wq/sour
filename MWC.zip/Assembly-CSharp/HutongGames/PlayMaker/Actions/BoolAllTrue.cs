﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014B RID: 331
	[Tooltip("Tests if all the given Bool Variables are True.")]
	[ActionCategory(ActionCategory.Logic)]
	public class BoolAllTrue : FsmStateAction
	{
		// Token: 0x06000626 RID: 1574 RVA: 0x0002ECE8 File Offset: 0x0002CEE8
		public override void Reset()
		{
			this.boolVariables = null;
			this.sendEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002ED08 File Offset: 0x0002CF08
		public override void OnEnter()
		{
			this.DoAllTrue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0002ED24 File Offset: 0x0002CF24
		public override void OnUpdate()
		{
			this.DoAllTrue();
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0002ED2C File Offset: 0x0002CF2C
		private void DoAllTrue()
		{
			if (this.boolVariables.Length == 0)
			{
				return;
			}
			bool flag = true;
			for (int i = 0; i < this.boolVariables.Length; i++)
			{
				if (!this.boolVariables[i].Value)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = flag;
		}

		// Token: 0x0400091E RID: 2334
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variables to check.")]
		public FsmBool[] boolVariables;

		// Token: 0x0400091F RID: 2335
		[Tooltip("Event to send if all the Bool variables are True.")]
		public FsmEvent sendEvent;

		// Token: 0x04000920 RID: 2336
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a Bool variable.")]
		public FsmBool storeResult;

		// Token: 0x04000921 RID: 2337
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
