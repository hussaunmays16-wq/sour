﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000145 RID: 325
	[ActionCategory(ActionCategory.Audio)]
	[Tooltip("Pauses playing the Audio Clip played by an Audio Source component on a Game Object.")]
	public class AudioPause : FsmStateAction
	{
		// Token: 0x0600060F RID: 1551 RVA: 0x0002E55C File Offset: 0x0002C75C
		public override void Reset()
		{
			this.gameObject = null;
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0002E568 File Offset: 0x0002C768
		public override void OnEnter()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget != null)
			{
				AudioSource component = ownerDefaultTarget.GetComponent<AudioSource>();
				if (component != null)
				{
					component.Pause();
				}
			}
			base.Finish();
		}

		// Token: 0x04000900 RID: 2304
		[CheckForComponent(typeof(AudioSource))]
		[RequiredField]
		[Tooltip("The GameObject with an Audio Source component.")]
		public FsmOwnerDefault gameObject;
	}
}
