﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000203 RID: 515
	[Tooltip("GUILayout Label for simple text.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutTextLabel : GUILayoutAction
	{
		// Token: 0x060008D6 RID: 2262 RVA: 0x0003AE98 File Offset: 0x00039098
		public override void Reset()
		{
			base.Reset();
			this.text = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x0003AECC File Offset: 0x000390CC
		public override void OnGUI()
		{
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUILayout.Label(new GUIContent(this.text.Value), base.LayoutOptions);
			}
			else
			{
				GUILayout.Label(new GUIContent(this.text.Value), this.style.Value, base.LayoutOptions);
			}
		}

		// Token: 0x04000C96 RID: 3222
		[Tooltip("Text to display.")]
		public FsmString text;

		// Token: 0x04000C97 RID: 3223
		[Tooltip("Optional GUIStyle in the active GUISkin.")]
		public FsmString style;
	}
}
