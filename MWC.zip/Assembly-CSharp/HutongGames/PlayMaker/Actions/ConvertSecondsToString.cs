﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200000A RID: 10
	[Tooltip("Converts Seconds to a String value representing the time.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertSecondsToString : FsmStateAction
	{
		// Token: 0x0600001C RID: 28 RVA: 0x000026CC File Offset: 0x000008CC
		public override void Reset()
		{
			this.secondsVariable = null;
			this.stringVariable = null;
			this.everyFrame = false;
			this.format = "{1:D2}h:{2:D2}m:{3:D2}s:{10}ms";
		}

		// Token: 0x0600001D RID: 29 RVA: 0x000026F4 File Offset: 0x000008F4
		public override void OnEnter()
		{
			this.DoConvertSecondsToString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002710 File Offset: 0x00000910
		public override void OnUpdate()
		{
			this.DoConvertSecondsToString();
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002718 File Offset: 0x00000918
		private void DoConvertSecondsToString()
		{
			TimeSpan timeSpan = TimeSpan.FromSeconds((double)this.secondsVariable.Value);
			string text = timeSpan.Milliseconds.ToString("D3").PadLeft(2, '0');
			text = text.Substring(0, 2);
			this.stringVariable.Value = string.Format(this.format.Value, new object[]
			{
				timeSpan.Days,
				timeSpan.Hours,
				timeSpan.Minutes,
				timeSpan.Seconds,
				timeSpan.Milliseconds,
				timeSpan.TotalDays,
				timeSpan.TotalHours,
				timeSpan.TotalMinutes,
				timeSpan.TotalSeconds,
				timeSpan.TotalMilliseconds,
				text
			});
		}

		// Token: 0x04000019 RID: 25
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The seconds variable to convert.")]
		public FsmFloat secondsVariable;

		// Token: 0x0400001A RID: 26
		[UIHint(UIHint.Variable)]
		[Tooltip("A string variable to store the time value.")]
		[RequiredField]
		public FsmString stringVariable;

		// Token: 0x0400001B RID: 27
		[Tooltip("Format. 0 for days, 1 is for hours, 2 for minutes, 3 for seconds and 4 for milliseconds. 5 for total days, 6 for total hours, 7 for total minutes, 8 for total seconds, 9 for total milliseconds, 10 for two digits milliseconds. so {2:D2} would just show the seconds of the current time, NOT the grand total number of seconds, the grand total of seconds would be {8:F0}")]
		[RequiredField]
		public FsmString format;

		// Token: 0x0400001C RID: 28
		[Tooltip("Repeat every frame. Useful if the seconds variable is changing.")]
		public bool everyFrame;
	}
}
