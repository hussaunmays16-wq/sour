﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200001C RID: 28
	[Tooltip("Get material mass from the rigidbody")]
	[ActionCategory("♥ Caligula ♥")]
	public class GetRigidbodyMass : FsmStateAction
	{
		// Token: 0x0600005C RID: 92 RVA: 0x0000448C File Offset: 0x0000268C
		public override void Reset()
		{
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00004490 File Offset: 0x00002690
		public override void OnEnter()
		{
			this.mass.Value = this.getMass(this.go.Value);
			base.Finish();
		}

		// Token: 0x0600005E RID: 94 RVA: 0x000044C0 File Offset: 0x000026C0
		public override void OnUpdate()
		{
		}

		// Token: 0x0600005F RID: 95 RVA: 0x000044C4 File Offset: 0x000026C4
		private float getMass(GameObject go)
		{
			float result = 0f;
			if (go.GetComponent<Rigidbody>() != null)
			{
				result = go.GetComponent<Rigidbody>().mass;
			}
			return result;
		}

		// Token: 0x0400009A RID: 154
		[Tooltip("Object")]
		public FsmGameObject go;

		// Token: 0x0400009B RID: 155
		[Tooltip("Mass of the rigidbody")]
		public FsmFloat mass;
	}
}
