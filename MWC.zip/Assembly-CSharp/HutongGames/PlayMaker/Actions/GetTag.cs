﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200025B RID: 603
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets a Game Object's Tag and stores it in a String Variable.")]
	public class GetTag : FsmStateAction
	{
		// Token: 0x06000A4A RID: 2634 RVA: 0x0003F790 File Offset: 0x0003D990
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A4B RID: 2635 RVA: 0x0003F7A8 File Offset: 0x0003D9A8
		public override void OnEnter()
		{
			this.DoGetTag();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A4C RID: 2636 RVA: 0x0003F7C4 File Offset: 0x0003D9C4
		public override void OnUpdate()
		{
			this.DoGetTag();
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0003F7CC File Offset: 0x0003D9CC
		private void DoGetTag()
		{
			if (this.gameObject.Value == null)
			{
				return;
			}
			this.storeResult.Value = this.gameObject.Value.tag;
		}

		// Token: 0x04000E31 RID: 3633
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000E32 RID: 3634
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;

		// Token: 0x04000E33 RID: 3635
		public bool everyFrame;
	}
}
