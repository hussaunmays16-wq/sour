﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200012B RID: 299
	[ActionCategory(ActionCategory.ScriptControl)]
	[Tooltip("Adds a Script to a Game Object. Use this to change the behaviour of objects on the fly. Optionally remove the Script on exiting the state.")]
	public class AddScript : FsmStateAction
	{
		// Token: 0x06000587 RID: 1415 RVA: 0x00029274 File Offset: 0x00027474
		public override void Reset()
		{
			this.gameObject = null;
			this.script = null;
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x00029284 File Offset: 0x00027484
		public override void OnEnter()
		{
			this.DoAddComponent((this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner);
			base.Finish();
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x000292C8 File Offset: 0x000274C8
		public override void OnExit()
		{
			if (this.removeOnExit.Value && this.addedComponent != null)
			{
				UnityEngine.Object.Destroy(this.addedComponent);
			}
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x00029304 File Offset: 0x00027504
		private void DoAddComponent(GameObject go)
		{
			if (go == null)
			{
				return;
			}
			this.addedComponent = go.AddComponent(AddScript.GetType(this.script.Value));
			if (this.addedComponent == null)
			{
				this.LogError("Can't add script: " + this.script.Value);
			}
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x00029368 File Offset: 0x00027568
		private static Type GetType(string name)
		{
			Type globalType = ReflectionUtils.GetGlobalType(name);
			if (globalType != null)
			{
				return globalType;
			}
			globalType = ReflectionUtils.GetGlobalType("UnityEngine." + name);
			if (globalType != null)
			{
				return globalType;
			}
			return ReflectionUtils.GetGlobalType("HutongGames.PlayMaker." + name);
		}

		// Token: 0x04000811 RID: 2065
		[RequiredField]
		[Tooltip("The GameObject to add the script to.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000812 RID: 2066
		[RequiredField]
		[Tooltip("The Script to add to the GameObject.")]
		[UIHint(UIHint.ScriptComponent)]
		public FsmString script;

		// Token: 0x04000813 RID: 2067
		[Tooltip("Remove the script from the GameObject when this State is exited.")]
		public FsmBool removeOnExit;

		// Token: 0x04000814 RID: 2068
		private Component addedComponent;
	}
}
