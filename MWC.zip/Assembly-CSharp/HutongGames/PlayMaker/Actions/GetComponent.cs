﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021D RID: 541
	[Tooltip("Gets a Component attached to a GameObject and stores it in an Object variable. NOTE: Set the Object variable's Object Type to get a component of that type. E.g., set Object Type to UnityEngine.AudioListener to get the AudioListener component on the camera.")]
	[ActionCategory(ActionCategory.UnityObject)]
	public class GetComponent : FsmStateAction
	{
		// Token: 0x0600093E RID: 2366 RVA: 0x0003C684 File Offset: 0x0003A884
		public override void Reset()
		{
			this.gameObject = null;
			this.storeComponent = null;
			this.everyFrame = false;
		}

		// Token: 0x0600093F RID: 2367 RVA: 0x0003C69C File Offset: 0x0003A89C
		public override void OnEnter()
		{
			this.DoGetComponent();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x0003C6B8 File Offset: 0x0003A8B8
		public override void OnUpdate()
		{
			this.DoGetComponent();
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x0003C6C0 File Offset: 0x0003A8C0
		private void DoGetComponent()
		{
			if (this.storeComponent == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			this.storeComponent.Value = ownerDefaultTarget.GetComponent(this.storeComponent.ObjectType);
		}

		// Token: 0x04000D0B RID: 3339
		[Tooltip("The GameObject that owns the component.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D0C RID: 3340
		[Tooltip("Store the component in an Object variable.\nNOTE: Set theObject variable's Object Type to get a component of that type. E.g., set Object Type to UnityEngine.AudioListener to get the AudioListener component on the camera.")]
		[UIHint(UIHint.Variable)]
		public FsmObject storeComponent;

		// Token: 0x04000D0D RID: 3341
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
