﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000236 RID: 566
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Gets the pressed state of a Key.")]
	public class GetKey : FsmStateAction
	{
		// Token: 0x060009B2 RID: 2482 RVA: 0x0003E0C4 File Offset: 0x0003C2C4
		public override void Reset()
		{
			this.key = KeyCode.None;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0003E0DC File Offset: 0x0003C2DC
		public override void OnEnter()
		{
			this.DoGetKey();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0003E0F8 File Offset: 0x0003C2F8
		public override void OnUpdate()
		{
			this.DoGetKey();
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x0003E100 File Offset: 0x0003C300
		private void DoGetKey()
		{
			this.storeResult.Value = Input.GetKey(this.key);
		}

		// Token: 0x04000DB6 RID: 3510
		[Tooltip("The key to test.")]
		[RequiredField]
		public KeyCode key;

		// Token: 0x04000DB7 RID: 3511
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store if the key is down (True) or up (False).")]
		public FsmBool storeResult;

		// Token: 0x04000DB8 RID: 3512
		[Tooltip("Repeat every frame. Useful if you're waiting for a key press/release.")]
		public bool everyFrame;
	}
}
