﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000253 RID: 595
	[Tooltip("Gets the Height of the Screen in pixels.")]
	[ActionCategory(ActionCategory.Application)]
	public class GetScreenHeight : FsmStateAction
	{
		// Token: 0x06000A27 RID: 2599 RVA: 0x0003F368 File Offset: 0x0003D568
		public override void Reset()
		{
			this.storeScreenHeight = null;
		}

		// Token: 0x06000A28 RID: 2600 RVA: 0x0003F374 File Offset: 0x0003D574
		public override void OnEnter()
		{
			this.storeScreenHeight.Value = (float)Screen.height;
			base.Finish();
		}

		// Token: 0x04000E19 RID: 3609
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeScreenHeight;
	}
}
