﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000261 RID: 609
	[Tooltip("Gets a Game Object's Transform and stores it in an Object Variable.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetTransform : FsmStateAction
	{
		// Token: 0x06000A61 RID: 2657 RVA: 0x0003FCCC File Offset: 0x0003DECC
		public override void Reset()
		{
			this.gameObject = new FsmGameObject
			{
				UseVariable = true
			};
			this.storeTransform = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x0003FCFC File Offset: 0x0003DEFC
		public override void OnEnter()
		{
			this.DoGetGameObjectName();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A63 RID: 2659 RVA: 0x0003FD18 File Offset: 0x0003DF18
		public override void OnUpdate()
		{
			this.DoGetGameObjectName();
		}

		// Token: 0x06000A64 RID: 2660 RVA: 0x0003FD20 File Offset: 0x0003DF20
		private void DoGetGameObjectName()
		{
			GameObject value = this.gameObject.Value;
			this.storeTransform.Value = ((!(value != null)) ? null : value.transform);
		}

		// Token: 0x04000E51 RID: 3665
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000E52 RID: 3666
		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(Transform))]
		[RequiredField]
		public FsmObject storeTransform;

		// Token: 0x04000E53 RID: 3667
		public bool everyFrame;
	}
}
