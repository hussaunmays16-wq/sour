﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000127 RID: 295
	[ActionCategory(ActionCategory.Physics)]
	[Tooltip("Applies a force to a Game Object that simulates explosion effects. The explosion force will fall off linearly with distance. Hint: Use the Explosion Action instead to apply an explosion force to all objects in a blast radius.")]
	public class AddExplosionForce : ComponentAction<Rigidbody>
	{
		// Token: 0x06000572 RID: 1394 RVA: 0x00028D30 File Offset: 0x00026F30
		public override void Reset()
		{
			this.gameObject = null;
			this.center = new FsmVector3
			{
				UseVariable = true
			};
			this.upwardsModifier = 0f;
			this.forceMode = ForceMode.Force;
			this.everyFrame = false;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x00028D78 File Offset: 0x00026F78
		public override void Awake()
		{
			base.Fsm.HandleFixedUpdate = true;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x00028D88 File Offset: 0x00026F88
		public override void OnEnter()
		{
			this.DoAddExplosionForce();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x00028DA4 File Offset: 0x00026FA4
		public override void OnFixedUpdate()
		{
			this.DoAddExplosionForce();
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x00028DAC File Offset: 0x00026FAC
		private void DoAddExplosionForce()
		{
			GameObject go = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			if (this.center == null || !base.UpdateCache(go))
			{
				return;
			}
			base.rigidbody.AddExplosionForce(this.force.Value, this.center.Value, this.radius.Value, this.upwardsModifier.Value, this.forceMode);
		}

		// Token: 0x040007F5 RID: 2037
		[RequiredField]
		[Tooltip("The GameObject to add the explosion force to.")]
		[CheckForComponent(typeof(Rigidbody))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040007F6 RID: 2038
		[Tooltip("The center of the explosion. Hint: this is often the position returned from a GetCollisionInfo action.")]
		[RequiredField]
		public FsmVector3 center;

		// Token: 0x040007F7 RID: 2039
		[Tooltip("The strength of the explosion.")]
		[RequiredField]
		public FsmFloat force;

		// Token: 0x040007F8 RID: 2040
		[Tooltip("The radius of the explosion. Force falls off linearly with distance.")]
		[RequiredField]
		public FsmFloat radius;

		// Token: 0x040007F9 RID: 2041
		[Tooltip("Applies the force as if it was applied from beneath the object. This is useful since explosions that throw things up instead of pushing things to the side look cooler. A value of 2 will apply a force as if it is applied from 2 meters below while not changing the actual explosion position.")]
		public FsmFloat upwardsModifier;

		// Token: 0x040007FA RID: 2042
		[Tooltip("The type of force to apply. See Unity Physics docs.")]
		public ForceMode forceMode;

		// Token: 0x040007FB RID: 2043
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
