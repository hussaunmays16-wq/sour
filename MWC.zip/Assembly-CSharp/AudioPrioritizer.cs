﻿using System;
using UnityEngine;

// Token: 0x02000093 RID: 147
public static class AudioPrioritizer
{
	// Token: 0x06000234 RID: 564 RVA: 0x0000E388 File Offset: 0x0000C588
	public static void Set2DSoundPriority(AudioSource audio)
	{
		audio.priority = 16;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x0000E394 File Offset: 0x0000C594
	public static void SetSoundGroupInitialPriority(AudioSource audio)
	{
		audio.priority = 128;
	}

	// Token: 0x06000236 RID: 566 RVA: 0x0000E3A4 File Offset: 0x0000C5A4
	public static void SetPreviewPriority(AudioSource audio)
	{
		audio.priority = 0;
	}

	// Token: 0x06000237 RID: 567 RVA: 0x0000E3B0 File Offset: 0x0000C5B0
	public static void Set3DPriority(AudioSource audio, bool useClipAgePriority)
	{
		float num = Vector3.Distance(audio.transform.position, MasterAudio.AudioListenerTransform.position);
		AudioRolloffMode rolloffMode = audio.rolloffMode;
		float num2;
		if (rolloffMode != AudioRolloffMode.Logarithmic)
		{
			if (rolloffMode != AudioRolloffMode.Linear)
			{
				num2 = Mathf.Lerp(audio.volume, 0f, Mathf.Max(0f, num - audio.minDistance) / (audio.maxDistance - audio.minDistance));
			}
			else
			{
				num2 = Mathf.Lerp(audio.volume, 0f, Mathf.Max(0f, num - audio.minDistance) / (audio.maxDistance - audio.minDistance));
			}
		}
		else
		{
			num2 = audio.volume / Mathf.Max(audio.minDistance, num - audio.minDistance);
		}
		if (useClipAgePriority && !audio.loop)
		{
			num2 = Mathf.Lerp(num2, num2 * 0.1f, AudioUtil.GetAudioPlayedPercentage(audio) * 0.01f);
		}
		audio.priority = (int)Mathf.Lerp(16f, 128f, Mathf.InverseLerp(1f, 0f, num2));
	}

	// Token: 0x040003C0 RID: 960
	private const int MaxPriority = 0;

	// Token: 0x040003C1 RID: 961
	private const int HighestPriority = 16;

	// Token: 0x040003C2 RID: 962
	private const int LowestPriority = 128;
}
