﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000247 RID: 583
	[Tooltip("Gets the Game Object that owns the FSM and stores it in a game object variable.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetOwner : FsmStateAction
	{
		// Token: 0x060009F4 RID: 2548 RVA: 0x0003EAD8 File Offset: 0x0003CCD8
		public override void Reset()
		{
			this.storeGameObject = null;
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0003EAE4 File Offset: 0x0003CCE4
		public override void OnEnter()
		{
			this.storeGameObject.Value = base.Owner;
			base.Finish();
		}

		// Token: 0x04000DEB RID: 3563
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmGameObject storeGameObject;
	}
}
