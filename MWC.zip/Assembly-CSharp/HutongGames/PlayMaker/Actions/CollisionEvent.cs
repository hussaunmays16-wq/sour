﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000159 RID: 345
	[Tooltip("Detect collisions between the Owner of this FSM and other Game Objects that have RigidBody components.\nNOTE: The system events, COLLISION ENTER, COLLISION STAY, and COLLISION EXIT are sent automatically on collisions with any object. Use this action to filter collisions by Tag.")]
	[ActionCategory(ActionCategory.Physics)]
	public class CollisionEvent : FsmStateAction
	{
		// Token: 0x06000666 RID: 1638 RVA: 0x0002FCD4 File Offset: 0x0002DED4
		public override void Reset()
		{
			this.collision = CollisionType.OnCollisionEnter;
			this.collideTag = "Untagged";
			this.sendEvent = null;
			this.storeCollider = null;
			this.storeForce = null;
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x0002FD10 File Offset: 0x0002DF10
		public override void Awake()
		{
			switch (this.collision)
			{
			case CollisionType.OnCollisionEnter:
				base.Fsm.HandleCollisionEnter = true;
				break;
			case CollisionType.OnCollisionStay:
				base.Fsm.HandleCollisionStay = true;
				break;
			case CollisionType.OnCollisionExit:
				base.Fsm.HandleCollisionExit = true;
				break;
			}
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x0002FD70 File Offset: 0x0002DF70
		private void StoreCollisionInfo(Collision collisionInfo)
		{
			this.storeCollider.Value = collisionInfo.gameObject;
			this.storeForce.Value = collisionInfo.relativeVelocity.magnitude;
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x0002FDA8 File Offset: 0x0002DFA8
		public override void DoCollisionEnter(Collision collisionInfo)
		{
			if (this.collision == CollisionType.OnCollisionEnter && collisionInfo.collider.gameObject.tag == this.collideTag.Value)
			{
				this.StoreCollisionInfo(collisionInfo);
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x0002FE00 File Offset: 0x0002E000
		public override void DoCollisionStay(Collision collisionInfo)
		{
			if (this.collision == CollisionType.OnCollisionStay && collisionInfo.collider.gameObject.tag == this.collideTag.Value)
			{
				this.StoreCollisionInfo(collisionInfo);
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x0002FE58 File Offset: 0x0002E058
		public override void DoCollisionExit(Collision collisionInfo)
		{
			if (this.collision == CollisionType.OnCollisionExit && collisionInfo.collider.gameObject.tag == this.collideTag.Value)
			{
				this.StoreCollisionInfo(collisionInfo);
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x0002FEB0 File Offset: 0x0002E0B0
		public override void DoControllerColliderHit(ControllerColliderHit collisionInfo)
		{
			if (this.collision == CollisionType.OnControllerColliderHit && collisionInfo.collider.gameObject.tag == this.collideTag.Value)
			{
				if (this.storeCollider != null)
				{
					this.storeCollider.Value = collisionInfo.gameObject;
				}
				this.storeForce.Value = 0f;
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x0002FF2C File Offset: 0x0002E12C
		public override string ErrorCheck()
		{
			return ActionHelpers.CheckOwnerPhysicsSetup(base.Owner);
		}

		// Token: 0x04000964 RID: 2404
		[Tooltip("The type of collision to detect.")]
		public CollisionType collision;

		// Token: 0x04000965 RID: 2405
		[UIHint(UIHint.Tag)]
		[Tooltip("Filter by Tag.")]
		public FsmString collideTag;

		// Token: 0x04000966 RID: 2406
		[Tooltip("Event to send if a collision is detected.")]
		public FsmEvent sendEvent;

		// Token: 0x04000967 RID: 2407
		[Tooltip("Store the GameObject that collided with the Owner of this FSM.")]
		[UIHint(UIHint.Variable)]
		public FsmGameObject storeCollider;

		// Token: 0x04000968 RID: 2408
		[Tooltip("Store the force of the collision. NOTE: Use Get Collision Info to get more info about the collision.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeForce;
	}
}
