﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000220 RID: 544
	[Tooltip("Gets the last measured linear acceleration of a device and stores it in a Vector3 Variable.")]
	[ActionCategory(ActionCategory.Device)]
	public class GetDeviceAcceleration : FsmStateAction
	{
		// Token: 0x0600094B RID: 2379 RVA: 0x0003C974 File Offset: 0x0003AB74
		public override void Reset()
		{
			this.storeVector = null;
			this.storeX = null;
			this.storeY = null;
			this.storeZ = null;
			this.multiplier = 1f;
			this.everyFrame = false;
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x0003C9AC File Offset: 0x0003ABAC
		public override void OnEnter()
		{
			this.DoGetDeviceAcceleration();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x0003C9C8 File Offset: 0x0003ABC8
		public override void OnUpdate()
		{
			this.DoGetDeviceAcceleration();
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x0003C9D0 File Offset: 0x0003ABD0
		private void DoGetDeviceAcceleration()
		{
			Vector3 vector = new Vector3(Input.acceleration.x, Input.acceleration.y, Input.acceleration.z);
			if (!this.multiplier.IsNone)
			{
				vector *= this.multiplier.Value;
			}
			this.storeVector.Value = vector;
			this.storeX.Value = vector.x;
			this.storeY.Value = vector.y;
			this.storeZ.Value = vector.z;
		}

		// Token: 0x04000D1C RID: 3356
		[UIHint(UIHint.Variable)]
		public FsmVector3 storeVector;

		// Token: 0x04000D1D RID: 3357
		[UIHint(UIHint.Variable)]
		public FsmFloat storeX;

		// Token: 0x04000D1E RID: 3358
		[UIHint(UIHint.Variable)]
		public FsmFloat storeY;

		// Token: 0x04000D1F RID: 3359
		[UIHint(UIHint.Variable)]
		public FsmFloat storeZ;

		// Token: 0x04000D20 RID: 3360
		public FsmFloat multiplier;

		// Token: 0x04000D21 RID: 3361
		public bool everyFrame;
	}
}
