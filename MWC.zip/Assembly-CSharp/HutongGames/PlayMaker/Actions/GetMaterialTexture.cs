﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200023F RID: 575
	[Tooltip("Get a texture from a material on a GameObject")]
	[ActionCategory(ActionCategory.Material)]
	public class GetMaterialTexture : ComponentAction<Renderer>
	{
		// Token: 0x060009D4 RID: 2516 RVA: 0x0003E558 File Offset: 0x0003C758
		public override void Reset()
		{
			this.gameObject = null;
			this.materialIndex = 0;
			this.namedTexture = "_MainTex";
			this.storedTexture = null;
			this.getFromSharedMaterial = false;
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0003E58C File Offset: 0x0003C78C
		public override void OnEnter()
		{
			this.DoGetMaterialTexture();
			base.Finish();
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0003E59C File Offset: 0x0003C79C
		private void DoGetMaterialTexture()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (!base.UpdateCache(ownerDefaultTarget))
			{
				return;
			}
			string text = this.namedTexture.Value;
			if (text == string.Empty)
			{
				text = "_MainTex";
			}
			if (this.materialIndex.Value == 0 && !this.getFromSharedMaterial)
			{
				this.storedTexture.Value = base.renderer.material.GetTexture(text);
			}
			else if (this.materialIndex.Value == 0 && this.getFromSharedMaterial)
			{
				this.storedTexture.Value = base.renderer.sharedMaterial.GetTexture(text);
			}
			else if (base.renderer.materials.Length > this.materialIndex.Value && !this.getFromSharedMaterial)
			{
				Material[] materials = base.renderer.materials;
				this.storedTexture.Value = base.renderer.materials[this.materialIndex.Value].GetTexture(text);
				base.renderer.materials = materials;
			}
			else if (base.renderer.materials.Length > this.materialIndex.Value && this.getFromSharedMaterial)
			{
				Material[] sharedMaterials = base.renderer.sharedMaterials;
				this.storedTexture.Value = base.renderer.sharedMaterials[this.materialIndex.Value].GetTexture(text);
				base.renderer.materials = sharedMaterials;
			}
		}

		// Token: 0x04000DD1 RID: 3537
		[Tooltip("The GameObject the Material is applied to.")]
		[RequiredField]
		[CheckForComponent(typeof(Renderer))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DD2 RID: 3538
		[Tooltip("The index of the Material in the Materials array.")]
		public FsmInt materialIndex;

		// Token: 0x04000DD3 RID: 3539
		[Tooltip("The texture to get. See Unity Shader docs for names.")]
		[UIHint(UIHint.NamedTexture)]
		public FsmString namedTexture;

		// Token: 0x04000DD4 RID: 3540
		[UIHint(UIHint.Variable)]
		[Title("StoreTexture")]
		[RequiredField]
		[Tooltip("Store the texture in a variable.")]
		public FsmTexture storedTexture;

		// Token: 0x04000DD5 RID: 3541
		[Tooltip("Get the shared version of the texture.")]
		public bool getFromSharedMaterial;
	}
}
