﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000196 RID: 406
	[Tooltip("Downloads a Color from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class DownloadColor : FsmStateAction
	{
		// Token: 0x0600075A RID: 1882 RVA: 0x000340EC File Offset: 0x000322EC
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.loadValue = null;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00034158 File Offset: 0x00032358
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new object[]
			{
				"Downloading from ",
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile
			}));
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0003422C File Offset: 0x0003242C
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				this.loadValue.Value = this.web.Load<Color>(this.uniqueTag.Value);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
			}
		}

		// Token: 0x04000AA7 RID: 2727
		[Tooltip("The variable we want to load our data into.")]
		[RequiredField]
		public FsmColor loadValue;

		// Token: 0x04000AA8 RID: 2728
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[RequiredField]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000AA9 RID: 2729
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04000AAA RID: 2730
		[RequiredField]
		[Tooltip("The password that you have specified in your ES2.php file.")]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000AAB RID: 2731
		[RequiredField]
		[Tooltip("The unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000AAC RID: 2732
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04000AAD RID: 2733
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04000AAE RID: 2734
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x04000AAF RID: 2735
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x04000AB0 RID: 2736
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000AB1 RID: 2737
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000AB2 RID: 2738
		private ES2Web web;
	}
}
