﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000126 RID: 294
	[Tooltip("Adds a Component to a Game Object. Use this to change the behaviour of objects on the fly. Optionally remove the Component on exiting the state.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class AddComponent : FsmStateAction
	{
		// Token: 0x0600056C RID: 1388 RVA: 0x00028BF4 File Offset: 0x00026DF4
		public override void Reset()
		{
			this.gameObject = null;
			this.component = null;
			this.storeComponent = null;
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x00028C0C File Offset: 0x00026E0C
		public override void OnEnter()
		{
			this.DoAddComponent();
			base.Finish();
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x00028C1C File Offset: 0x00026E1C
		public override void OnExit()
		{
			if (this.removeOnExit.Value && this.addedComponent != null)
			{
				UnityEngine.Object.Destroy(this.addedComponent);
			}
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x00028C58 File Offset: 0x00026E58
		private void DoAddComponent()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			this.addedComponent = ownerDefaultTarget.AddComponent(AddComponent.GetType(this.component.Value));
			this.storeComponent.Value = this.addedComponent;
			if (this.addedComponent == null)
			{
				this.LogError("Can't add component: " + this.component.Value);
			}
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x00028CE0 File Offset: 0x00026EE0
		private static Type GetType(string name)
		{
			Type globalType = ReflectionUtils.GetGlobalType(name);
			if (globalType != null)
			{
				return globalType;
			}
			globalType = ReflectionUtils.GetGlobalType("UnityEngine." + name);
			if (globalType != null)
			{
				return globalType;
			}
			return ReflectionUtils.GetGlobalType("HutongGames.PlayMaker." + name);
		}

		// Token: 0x040007F0 RID: 2032
		[RequiredField]
		[Tooltip("The GameObject to add the Component to.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040007F1 RID: 2033
		[RequiredField]
		[UIHint(UIHint.ScriptComponent)]
		[Title("Component Type")]
		[Tooltip("The type of Component to add to the Game Object.")]
		public FsmString component;

		// Token: 0x040007F2 RID: 2034
		[Tooltip("Store the component in an Object variable. E.g., to use with Set Property.")]
		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(Component))]
		public FsmObject storeComponent;

		// Token: 0x040007F3 RID: 2035
		[Tooltip("Remove the Component when this State is exited.")]
		public FsmBool removeOnExit;

		// Token: 0x040007F4 RID: 2036
		private Component addedComponent;
	}
}
