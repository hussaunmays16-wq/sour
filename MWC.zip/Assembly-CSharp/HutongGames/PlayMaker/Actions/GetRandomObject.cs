﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024D RID: 589
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets a Random Game Object from the scene.\nOptionally filter by Tag.")]
	public class GetRandomObject : FsmStateAction
	{
		// Token: 0x06000A0A RID: 2570 RVA: 0x0003EDC4 File Offset: 0x0003CFC4
		public override void Reset()
		{
			this.withTag = "Untagged";
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0003EDE4 File Offset: 0x0003CFE4
		public override void OnEnter()
		{
			this.DoGetRandomObject();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x0003EE00 File Offset: 0x0003D000
		public override void OnUpdate()
		{
			this.DoGetRandomObject();
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0003EE08 File Offset: 0x0003D008
		private void DoGetRandomObject()
		{
			GameObject[] array;
			if (this.withTag.Value != "Untagged")
			{
				array = GameObject.FindGameObjectsWithTag(this.withTag.Value);
			}
			else
			{
				array = (GameObject[])UnityEngine.Object.FindObjectsOfType(typeof(GameObject));
			}
			if (array.Length > 0)
			{
				this.storeResult.Value = array[UnityEngine.Random.Range(0, array.Length)];
				return;
			}
			this.storeResult.Value = null;
		}

		// Token: 0x04000DFA RID: 3578
		[UIHint(UIHint.Tag)]
		public FsmString withTag;

		// Token: 0x04000DFB RID: 3579
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmGameObject storeResult;

		// Token: 0x04000DFC RID: 3580
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
