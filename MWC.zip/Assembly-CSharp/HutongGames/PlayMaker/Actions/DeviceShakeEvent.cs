﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000181 RID: 385
	[Tooltip("Sends an Event when the mobile device is shaken.")]
	[ActionCategory(ActionCategory.Device)]
	public class DeviceShakeEvent : FsmStateAction
	{
		// Token: 0x0600070E RID: 1806 RVA: 0x00031B50 File Offset: 0x0002FD50
		public override void Reset()
		{
			this.shakeThreshold = 3f;
			this.sendEvent = null;
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x00031B6C File Offset: 0x0002FD6C
		public override void OnUpdate()
		{
			if (Input.acceleration.sqrMagnitude > this.shakeThreshold.Value * this.shakeThreshold.Value)
			{
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x040009F9 RID: 2553
		[RequiredField]
		[Tooltip("Amount of acceleration required to trigger the event. Higher numbers require a harder shake.")]
		public FsmFloat shakeThreshold;

		// Token: 0x040009FA RID: 2554
		[Tooltip("Event to send when Shake Threshold is exceded.")]
		[RequiredField]
		public FsmEvent sendEvent;
	}
}
