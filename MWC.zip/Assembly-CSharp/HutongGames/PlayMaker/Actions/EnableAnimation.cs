﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C2 RID: 450
	[Tooltip("Enables/Disables an Animation on a GameObject.\nAnimation time is paused while disabled. Animation must also have a non zero weight to play.")]
	[ActionCategory(ActionCategory.Animation)]
	public class EnableAnimation : FsmStateAction
	{
		// Token: 0x060007E8 RID: 2024 RVA: 0x00037A20 File Offset: 0x00035C20
		public override void Reset()
		{
			this.gameObject = null;
			this.animName = null;
			this.enable = true;
			this.resetOnExit = false;
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x00037A54 File Offset: 0x00035C54
		public override void OnEnter()
		{
			this.DoEnableAnimation(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00037A74 File Offset: 0x00035C74
		private void DoEnableAnimation(GameObject go)
		{
			if (go == null)
			{
				return;
			}
			Animation component = go.GetComponent<Animation>();
			if (component == null)
			{
				this.LogError("Missing animation component!");
				return;
			}
			this.anim = component[this.animName.Value];
			if (this.anim != null)
			{
				this.anim.enabled = this.enable.Value;
			}
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00037AEC File Offset: 0x00035CEC
		public override void OnExit()
		{
			if (this.resetOnExit.Value && this.anim != null)
			{
				this.anim.enabled = !this.enable.Value;
			}
		}

		// Token: 0x04000B8F RID: 2959
		[Tooltip("The GameObject playing the animation.")]
		[CheckForComponent(typeof(Animation))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000B90 RID: 2960
		[Tooltip("The name of the animation to enable/disable.")]
		[RequiredField]
		[UIHint(UIHint.Animation)]
		public FsmString animName;

		// Token: 0x04000B91 RID: 2961
		[RequiredField]
		[Tooltip("Set to True to enable, False to disable.")]
		public FsmBool enable;

		// Token: 0x04000B92 RID: 2962
		[Tooltip("Reset the initial enabled state when exiting the state.")]
		public FsmBool resetOnExit;

		// Token: 0x04000B93 RID: 2963
		private AnimationState anim;
	}
}
