﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000130 RID: 304
	[Tooltip("Animate base action - DON'T USE IT!")]
	public abstract class AnimateFsmAction : FsmStateAction
	{
		// Token: 0x060005A0 RID: 1440 RVA: 0x00029BA0 File Offset: 0x00027DA0
		public override void Reset()
		{
			this.finishEvent = null;
			this.realTime = false;
			this.time = new FsmFloat
			{
				UseVariable = true
			};
			this.speed = new FsmFloat
			{
				UseVariable = true
			};
			this.delay = new FsmFloat
			{
				UseVariable = true
			};
			this.ignoreCurveOffset = new FsmBool
			{
				Value = true
			};
			this.resultFloats = new float[0];
			this.fromFloats = new float[0];
			this.toFloats = new float[0];
			this.endTimes = new float[0];
			this.keyOffsets = new float[0];
			this.curves = new AnimationCurve[0];
			this.finishAction = false;
			this.start = false;
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00029C64 File Offset: 0x00027E64
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
			this.deltaTime = 0f;
			this.currentTime = 0f;
			this.isRunning = false;
			this.finishAction = false;
			this.looping = false;
			this.delayTime = ((!this.delay.IsNone) ? (this.delayTime = this.delay.Value) : 0f);
			this.start = true;
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x00029CF4 File Offset: 0x00027EF4
		protected void Init()
		{
			this.endTimes = new float[this.curves.Length];
			this.keyOffsets = new float[this.curves.Length];
			this.largestEndTime = 0f;
			for (int i = 0; i < this.curves.Length; i++)
			{
				if (this.curves[i] != null && this.curves[i].keys.Length > 0)
				{
					this.keyOffsets[i] = ((this.curves[i].keys.Length <= 0) ? 0f : ((!this.time.IsNone) ? (this.time.Value / this.curves[i].keys[this.curves[i].length - 1].time * this.curves[i].keys[0].time) : this.curves[i].keys[0].time));
					this.currentTime = ((!this.ignoreCurveOffset.IsNone) ? ((!this.ignoreCurveOffset.Value) ? 0f : this.keyOffsets[i]) : 0f);
					if (!this.time.IsNone)
					{
						this.endTimes[i] = this.time.Value;
					}
					else
					{
						this.endTimes[i] = this.curves[i].keys[this.curves[i].length - 1].time;
					}
					if (this.largestEndTime < this.endTimes[i])
					{
						this.largestEndTime = this.endTimes[i];
					}
					if (!this.looping)
					{
						this.looping = ActionHelpers.IsLoopingWrapMode(this.curves[i].postWrapMode);
					}
				}
				else
				{
					this.endTimes[i] = -1f;
				}
			}
			for (int j = 0; j < this.curves.Length; j++)
			{
				if (this.largestEndTime > 0f && this.endTimes[j] == -1f)
				{
					this.endTimes[j] = this.largestEndTime;
				}
				else if (this.largestEndTime == 0f && this.endTimes[j] == -1f)
				{
					if (this.time.IsNone)
					{
						this.endTimes[j] = 1f;
					}
					else
					{
						this.endTimes[j] = this.time.Value;
					}
				}
			}
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00029FA0 File Offset: 0x000281A0
		public override void OnUpdate()
		{
			if (!this.isRunning && this.start)
			{
				if (this.delayTime >= 0f)
				{
					if (this.realTime)
					{
						this.deltaTime = FsmTime.RealtimeSinceStartup - this.startTime - this.lastTime;
						this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
						this.delayTime -= this.deltaTime;
					}
					else
					{
						this.delayTime -= Time.deltaTime;
					}
				}
				else
				{
					this.isRunning = true;
					this.start = false;
				}
			}
			if (this.isRunning)
			{
				if (this.realTime)
				{
					this.deltaTime = FsmTime.RealtimeSinceStartup - this.startTime - this.lastTime;
					this.lastTime = FsmTime.RealtimeSinceStartup - this.startTime;
					if (!this.speed.IsNone)
					{
						this.currentTime += this.deltaTime * this.speed.Value;
					}
					else
					{
						this.currentTime += this.deltaTime;
					}
				}
				else if (!this.speed.IsNone)
				{
					this.currentTime += Time.deltaTime * this.speed.Value;
				}
				else
				{
					this.currentTime += Time.deltaTime;
				}
				for (int i = 0; i < this.curves.Length; i++)
				{
					if (this.curves[i] != null && this.curves[i].keys.Length > 0)
					{
						if (this.calculations[i] != AnimateFsmAction.Calculation.None)
						{
							switch (this.calculations[i])
							{
							case AnimateFsmAction.Calculation.SetValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time);
								}
								else
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime);
								}
								break;
							case AnimateFsmAction.Calculation.AddToValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = this.fromFloats[i] + this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time);
								}
								else
								{
									this.resultFloats[i] = this.fromFloats[i] + this.curves[i].Evaluate(this.currentTime);
								}
								break;
							case AnimateFsmAction.Calculation.SubtractFromValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = this.fromFloats[i] - this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time);
								}
								else
								{
									this.resultFloats[i] = this.fromFloats[i] - this.curves[i].Evaluate(this.currentTime);
								}
								break;
							case AnimateFsmAction.Calculation.SubtractValueFromCurve:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time) - this.fromFloats[i];
								}
								else
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime) - this.fromFloats[i];
								}
								break;
							case AnimateFsmAction.Calculation.MultiplyValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time) * this.fromFloats[i];
								}
								else
								{
									this.resultFloats[i] = this.curves[i].Evaluate(this.currentTime) * this.fromFloats[i];
								}
								break;
							case AnimateFsmAction.Calculation.DivideValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = ((this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time) == 0f) ? float.MaxValue : (this.fromFloats[i] / this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time)));
								}
								else
								{
									this.resultFloats[i] = ((this.curves[i].Evaluate(this.currentTime) == 0f) ? float.MaxValue : (this.fromFloats[i] / this.curves[i].Evaluate(this.currentTime)));
								}
								break;
							case AnimateFsmAction.Calculation.DivideCurveByValue:
								if (!this.time.IsNone)
								{
									this.resultFloats[i] = ((this.fromFloats[i] == 0f) ? float.MaxValue : (this.curves[i].Evaluate(this.currentTime / this.time.Value * this.curves[i].keys[this.curves[i].length - 1].time) / this.fromFloats[i]));
								}
								else
								{
									this.resultFloats[i] = ((this.fromFloats[i] == 0f) ? float.MaxValue : (this.curves[i].Evaluate(this.currentTime) / this.fromFloats[i]));
								}
								break;
							}
						}
						else
						{
							this.resultFloats[i] = this.fromFloats[i];
						}
					}
					else
					{
						this.resultFloats[i] = this.fromFloats[i];
					}
				}
				if (this.isRunning && !this.looping)
				{
					this.finishAction = true;
					for (int j = 0; j < this.endTimes.Length; j++)
					{
						if (this.currentTime < this.endTimes[j])
						{
							this.finishAction = false;
						}
					}
					this.isRunning = !this.finishAction;
				}
			}
		}

		// Token: 0x04000834 RID: 2100
		[Tooltip("Define time to use your curve scaled to be stretched or shrinked.")]
		public FsmFloat time;

		// Token: 0x04000835 RID: 2101
		[Tooltip("If you define speed, your animation will be speeded up or slowed down.")]
		public FsmFloat speed;

		// Token: 0x04000836 RID: 2102
		[Tooltip("Delayed animimation start.")]
		public FsmFloat delay;

		// Token: 0x04000837 RID: 2103
		[Tooltip("Animation curve start from any time. If IgnoreCurveOffset is true the animation starts right after the state become entered.")]
		public FsmBool ignoreCurveOffset;

		// Token: 0x04000838 RID: 2104
		[Tooltip("Optionally send an Event when the animation finishes.")]
		public FsmEvent finishEvent;

		// Token: 0x04000839 RID: 2105
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x0400083A RID: 2106
		private float startTime;

		// Token: 0x0400083B RID: 2107
		private float currentTime;

		// Token: 0x0400083C RID: 2108
		private float[] endTimes;

		// Token: 0x0400083D RID: 2109
		private float lastTime;

		// Token: 0x0400083E RID: 2110
		private float deltaTime;

		// Token: 0x0400083F RID: 2111
		private float delayTime;

		// Token: 0x04000840 RID: 2112
		private float[] keyOffsets;

		// Token: 0x04000841 RID: 2113
		protected AnimationCurve[] curves;

		// Token: 0x04000842 RID: 2114
		protected AnimateFsmAction.Calculation[] calculations;

		// Token: 0x04000843 RID: 2115
		protected float[] resultFloats;

		// Token: 0x04000844 RID: 2116
		protected float[] fromFloats;

		// Token: 0x04000845 RID: 2117
		protected float[] toFloats;

		// Token: 0x04000846 RID: 2118
		protected bool finishAction;

		// Token: 0x04000847 RID: 2119
		protected bool isRunning;

		// Token: 0x04000848 RID: 2120
		protected bool looping;

		// Token: 0x04000849 RID: 2121
		private bool start;

		// Token: 0x0400084A RID: 2122
		private float largestEndTime;

		// Token: 0x02000131 RID: 305
		public enum Calculation
		{
			// Token: 0x0400084C RID: 2124
			None,
			// Token: 0x0400084D RID: 2125
			SetValue,
			// Token: 0x0400084E RID: 2126
			AddToValue,
			// Token: 0x0400084F RID: 2127
			SubtractFromValue,
			// Token: 0x04000850 RID: 2128
			SubtractValueFromCurve,
			// Token: 0x04000851 RID: 2129
			MultiplyValue,
			// Token: 0x04000852 RID: 2130
			DivideValue,
			// Token: 0x04000853 RID: 2131
			DivideCurveByValue
		}
	}
}
