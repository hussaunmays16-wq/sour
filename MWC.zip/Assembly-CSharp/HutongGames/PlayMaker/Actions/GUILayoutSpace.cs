﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000201 RID: 513
	[Tooltip("Inserts a space in the current layout group.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutSpace : FsmStateAction
	{
		// Token: 0x060008D0 RID: 2256 RVA: 0x0003ADAC File Offset: 0x00038FAC
		public override void Reset()
		{
			this.space = 10f;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x0003ADC0 File Offset: 0x00038FC0
		public override void OnGUI()
		{
			GUILayout.Space(this.space.Value);
		}

		// Token: 0x04000C91 RID: 3217
		public FsmFloat space;
	}
}
