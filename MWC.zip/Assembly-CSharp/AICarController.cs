﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D3 RID: 211
public class AICarController : MonoBehaviour
{
	// Token: 0x060003FA RID: 1018 RVA: 0x0001A1F8 File Offset: 0x000183F8
	private void Start()
	{
		this.moottori = base.GetComponent<ArcadeCarNoPhysics>();
		if (this.moottori != null)
		{
			this.moottori.onAI = true;
		}
		this.viimeSijainti = base.transform.position;
		if (this.checkpointKansio != null)
		{
			List<Transform> list = new List<Transform>();
			foreach (Transform transform in this.checkpointKansio.GetComponentsInChildren<Transform>())
			{
				if (transform != this.checkpointKansio)
				{
					list.Add(transform);
				}
			}
			this.reittipisteet = list.ToArray();
			Array.Sort<Transform>(this.reittipisteet, (Transform a, Transform b) => string.Compare(a.name, b.name));
		}
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x0001A2C8 File Offset: 0x000184C8
	private void Update()
	{
		if (this.reittipisteet == null || this.reittipisteet.Length == 0)
		{
			return;
		}
		this.Aja();
		this.TarkistaJumiutuminen();
		if (this.reittipisteet.Length > 0)
		{
			Vector3 position = this.reittipisteet[this.nykyinenIndex].position;
			Vector3 end = position;
			end.y = base.transform.position.y;
			Debug.DrawLine(base.transform.position, end, Color.red);
			Debug.DrawRay(base.transform.position, base.transform.up * 5f, Color.green);
			this.menossaKohti = this.reittipisteet[this.nykyinenIndex].name;
		}
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x0001A390 File Offset: 0x00018590
	private void Aja()
	{
		Vector3 position = this.reittipisteet[this.nykyinenIndex].position;
		position.y = base.transform.position.y;
		Vector3 normalized = (position - base.transform.position).normalized;
		float num = Vector3.Distance(base.transform.position, position);
		float num2 = this.LaskeSuuntaKulma(base.transform.up, normalized, Vector3.up);
		float num3 = Mathf.Clamp(num2 / 45f, -1f, 1f);
		float num4 = 1f - Mathf.Abs(num3) * 0.5f;
		if (num4 < 0.3f)
		{
			num4 = 0.3f;
		}
		if (this.moottori != null)
		{
			this.moottori.ulkoinenKaanto = num3 * this.kaantymisHerkkyys;
			this.moottori.ulkoinenKaasu = num4;
		}
		if (num < this.etaisyysVaihtoon)
		{
			this.nykyinenIndex++;
			if (this.nykyinenIndex >= this.reittipisteet.Length)
			{
				this.nykyinenIndex = 0;
			}
		}
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x0001A4B8 File Offset: 0x000186B8
	private void TarkistaJumiutuminen()
	{
		this.tarkistusAjastin += Time.deltaTime;
		if (this.tarkistusAjastin > 1f)
		{
			float num = Vector3.Distance(base.transform.position, this.viimeSijainti);
			if (num < this.minimiLiike)
			{
				this.jumiAjastin += 1f;
			}
			else
			{
				this.jumiAjastin = 0f;
			}
			this.viimeSijainti = base.transform.position;
			this.tarkistusAjastin = 0f;
		}
		if (this.jumiAjastin > this.respawnAika)
		{
			this.RespawnAuto();
		}
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x0001A560 File Offset: 0x00018760
	private void RespawnAuto()
	{
		int num = this.nykyinenIndex - 1;
		if (num < 0)
		{
			num = this.reittipisteet.Length - 1;
		}
		Transform transform = this.reittipisteet[num];
		Vector3 position = transform.position;
		position.y = base.transform.position.y;
		base.transform.position = position;
		base.transform.rotation = transform.rotation;
		if (this.moottori != null)
		{
			this.moottori.tormaysTyonto = Vector3.zero;
			this.moottori.NollaaVauhti();
		}
		this.jumiAjastin = 0f;
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x0001A608 File Offset: 0x00018808
	private float LaskeSuuntaKulma(Vector3 eteenpain, Vector3 kohdeSuunta, Vector3 kiertoAkseli)
	{
		float num = Vector3.Angle(eteenpain, kohdeSuunta);
		Vector3 rhs = Vector3.Cross(eteenpain, kohdeSuunta);
		if (Vector3.Dot(kiertoAkseli, rhs) < 0f)
		{
			num = -num;
		}
		return num;
	}

	// Token: 0x040005AE RID: 1454
	[Header("Asetukset")]
	public Transform checkpointKansio;

	// Token: 0x040005AF RID: 1455
	public float kaantymisHerkkyys = 1f;

	// Token: 0x040005B0 RID: 1456
	public float etaisyysVaihtoon = 4f;

	// Token: 0x040005B1 RID: 1457
	[Header("Jumiutumisen Esto")]
	public float respawnAika = 4f;

	// Token: 0x040005B2 RID: 1458
	public float minimiLiike = 0.5f;

	// Token: 0x040005B3 RID: 1459
	[Header("Debug")]
	public string menossaKohti = string.Empty;

	// Token: 0x040005B4 RID: 1460
	private Transform[] reittipisteet;

	// Token: 0x040005B5 RID: 1461
	private int nykyinenIndex;

	// Token: 0x040005B6 RID: 1462
	private ArcadeCarNoPhysics moottori;

	// Token: 0x040005B7 RID: 1463
	private float jumiAjastin;

	// Token: 0x040005B8 RID: 1464
	private Vector3 viimeSijainti;

	// Token: 0x040005B9 RID: 1465
	private float tarkistusAjastin;
}
