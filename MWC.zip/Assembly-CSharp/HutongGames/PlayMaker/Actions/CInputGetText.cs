﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AE RID: 1198
	[ActionCategory("cInput")]
	[Tooltip("Gets the input name of an cInput action and puts it into a fsm variable.")]
	public class CInputGetText : FsmStateAction
	{
		// Token: 0x06001466 RID: 5222 RVA: 0x00088FF8 File Offset: 0x000871F8
		public override void Reset()
		{
			this.actionName = null;
			this.input = null;
			this.returnBlank = null;
			this.storeInputName = null;
			this.everyFrame = null;
		}

		// Token: 0x06001467 RID: 5223 RVA: 0x00089020 File Offset: 0x00087220
		public override void OnLateUpdate()
		{
			this.storeInputName.Value = cInput.GetText(this.actionName.Value, this.input.Value, this.returnBlank.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CDA RID: 7386
		[Tooltip("The name of the action.")]
		[RequiredField]
		public FsmString actionName;

		// Token: 0x04001CDB RID: 7387
		[Tooltip("0 = actionName, 1 = primary, 2 = secondary")]
		public FsmInt input;

		// Token: 0x04001CDC RID: 7388
		public FsmBool returnBlank;

		// Token: 0x04001CDD RID: 7389
		[Tooltip("The input name to store.")]
		public FsmString storeInputName;

		// Token: 0x04001CDE RID: 7390
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
