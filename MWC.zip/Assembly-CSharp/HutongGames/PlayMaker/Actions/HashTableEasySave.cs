﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E5 RID: 997
	[Tooltip("Saves a PlayMaker HashTable Proxy component")]
	[ActionCategory("Easy Save 2")]
	public class HashTableEasySave : HashTableActions
	{
		// Token: 0x060010E1 RID: 4321 RVA: 0x0005CE04 File Offset: 0x0005B004
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0005CE44 File Offset: 0x0005B044
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SaveHashTable();
			}
			base.Finish();
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x0005CE84 File Offset: 0x0005B084
		public void SaveHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text))
			{
				text = string.Concat(new object[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/hashTable/",
					this.reference
				});
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (object obj in this.proxy.hashTable.Keys)
			{
				dictionary[(string)obj] = PlayMakerUtils.ParseValueToString(this.proxy.hashTable[obj]);
			}
			ES2.Save<string, string>(dictionary, this.saveFile.Value + "?tag=" + text);
			this.Log("Saved to " + this.saveFile.Value + "?tag=" + text);
			base.Finish();
		}

		// Token: 0x04001607 RID: 5639
		[ActionSection("Set up")]
		[Tooltip("The Game Object to add the Hashtable Component to.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001608 RID: 5640
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker arrayList proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001609 RID: 5641
		[ActionSection("Easy Save Set Up")]
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x0400160A RID: 5642
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data.")]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
