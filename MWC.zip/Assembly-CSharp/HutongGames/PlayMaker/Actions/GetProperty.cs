﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024B RID: 587
	[Tooltip("Gets the value of any public property or field on the targeted Unity Object and stores it in a variable. E.g., Drag and drop any component attached to a Game Object to access its properties.")]
	[ActionCategory(ActionCategory.UnityObject)]
	public class GetProperty : FsmStateAction
	{
		// Token: 0x06000A02 RID: 2562 RVA: 0x0003ECEC File Offset: 0x0003CEEC
		public override void Reset()
		{
			this.targetProperty = new FsmProperty();
			this.everyFrame = false;
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x0003ED00 File Offset: 0x0003CF00
		public override void OnEnter()
		{
			this.targetProperty.GetValue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0003ED20 File Offset: 0x0003CF20
		public override void OnUpdate()
		{
			this.targetProperty.GetValue();
		}

		// Token: 0x04000DF6 RID: 3574
		public FsmProperty targetProperty;

		// Token: 0x04000DF7 RID: 3575
		public bool everyFrame;
	}
}
