﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B3 RID: 1203
	[ActionCategory("cInput")]
	[Tooltip("Resets all cInput settings; keys, axis, modifier keys etc.")]
	public class CInputResetInputs : FsmStateAction
	{
		// Token: 0x06001473 RID: 5235 RVA: 0x00089108 File Offset: 0x00087308
		public override void OnEnter()
		{
			cInput.ResetInputs();
			base.Finish();
		}
	}
}
