﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021A RID: 538
	[Tooltip("Gets the Child of a GameObject by Index.\nE.g., O to get the first child. HINT: Use this with an integer variable to iterate through children.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetChildNum : FsmStateAction
	{
		// Token: 0x06000931 RID: 2353 RVA: 0x0003C37C File Offset: 0x0003A57C
		public override void Reset()
		{
			this.gameObject = null;
			this.childIndex = 0;
			this.store = null;
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x0003C398 File Offset: 0x0003A598
		public override void OnEnter()
		{
			this.store.Value = this.DoGetChildNum(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x0003C3D0 File Offset: 0x0003A5D0
		private GameObject DoGetChildNum(GameObject go)
		{
			return (!(go == null)) ? go.transform.GetChild(this.childIndex.Value % go.transform.childCount).gameObject : null;
		}

		// Token: 0x04000CFC RID: 3324
		[Tooltip("The GameObject to search.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CFD RID: 3325
		[Tooltip("The index of the child to find.")]
		[RequiredField]
		public FsmInt childIndex;

		// Token: 0x04000CFE RID: 3326
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store the child in a GameObject variable.")]
		public FsmGameObject store;
	}
}
