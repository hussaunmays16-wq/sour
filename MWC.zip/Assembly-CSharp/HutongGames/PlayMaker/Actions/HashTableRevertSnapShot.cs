﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003CB RID: 971
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Revert a PlayMaker HashTable Proxy component to the prefill data, either defined at runtime or when the action HashTableTakeSnapShot was used.")]
	public class HashTableRevertSnapShot : HashTableActions
	{
		// Token: 0x06001065 RID: 4197 RVA: 0x00059628 File Offset: 0x00057828
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x00059638 File Offset: 0x00057838
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoHashTableRevertToSnapShot();
			}
			base.Finish();
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x00059678 File Offset: 0x00057878
		public void DoHashTableRevertToSnapShot()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.RevertToSnapShot();
		}

		// Token: 0x04001548 RID: 5448
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001549 RID: 5449
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
