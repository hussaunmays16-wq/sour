﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200012C RID: 300
	[ActionCategory(ActionCategory.Physics)]
	[Tooltip("Adds torque (rotational force) to a Game Object.")]
	public class AddTorque : ComponentAction<Rigidbody>
	{
		// Token: 0x0600058D RID: 1421 RVA: 0x000293B8 File Offset: 0x000275B8
		public override void Reset()
		{
			this.gameObject = null;
			this.x = new FsmFloat
			{
				UseVariable = true
			};
			this.y = new FsmFloat
			{
				UseVariable = true
			};
			this.z = new FsmFloat
			{
				UseVariable = true
			};
			this.space = Space.World;
			this.forceMode = ForceMode.Force;
			this.everyFrame = false;
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x00029420 File Offset: 0x00027620
		public override void Awake()
		{
			base.Fsm.HandleFixedUpdate = true;
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x00029430 File Offset: 0x00027630
		public override void OnEnter()
		{
			this.DoAddTorque();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x0002944C File Offset: 0x0002764C
		public override void OnFixedUpdate()
		{
			this.DoAddTorque();
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x00029454 File Offset: 0x00027654
		private void DoAddTorque()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (!base.UpdateCache(ownerDefaultTarget))
			{
				return;
			}
			Vector3 torque = (!this.vector.IsNone) ? this.vector.Value : new Vector3(this.x.Value, this.y.Value, this.z.Value);
			if (!this.x.IsNone)
			{
				torque.x = this.x.Value;
			}
			if (!this.y.IsNone)
			{
				torque.y = this.y.Value;
			}
			if (!this.z.IsNone)
			{
				torque.z = this.z.Value;
			}
			if (this.space == Space.World)
			{
				base.rigidbody.AddTorque(torque, this.forceMode);
			}
			else
			{
				base.rigidbody.AddRelativeTorque(torque, this.forceMode);
			}
		}

		// Token: 0x04000815 RID: 2069
		[Tooltip("The GameObject to add torque to.")]
		[CheckForComponent(typeof(Rigidbody))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000816 RID: 2070
		[Tooltip("A Vector3 torque. Optionally override any axis with the X, Y, Z parameters.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector;

		// Token: 0x04000817 RID: 2071
		[Tooltip("Torque around the X axis. To leave unchanged, set to 'None'.")]
		public FsmFloat x;

		// Token: 0x04000818 RID: 2072
		[Tooltip("Torque around the Y axis. To leave unchanged, set to 'None'.")]
		public FsmFloat y;

		// Token: 0x04000819 RID: 2073
		[Tooltip("Torque around the Z axis. To leave unchanged, set to 'None'.")]
		public FsmFloat z;

		// Token: 0x0400081A RID: 2074
		[Tooltip("Apply the force in world or local space.")]
		public Space space;

		// Token: 0x0400081B RID: 2075
		[Tooltip("The type of force to apply. See Unity Physics docs.")]
		public ForceMode forceMode;

		// Token: 0x0400081C RID: 2076
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
