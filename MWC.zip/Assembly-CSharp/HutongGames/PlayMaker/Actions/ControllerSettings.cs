﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000160 RID: 352
	[Tooltip("Modify various character controller settings.\n'None' leaves the setting unchanged.")]
	[ActionCategory(ActionCategory.Character)]
	public class ControllerSettings : FsmStateAction
	{
		// Token: 0x06000690 RID: 1680 RVA: 0x00030660 File Offset: 0x0002E860
		public override void Reset()
		{
			this.gameObject = null;
			this.height = new FsmFloat
			{
				UseVariable = true
			};
			this.radius = new FsmFloat
			{
				UseVariable = true
			};
			this.slopeLimit = new FsmFloat
			{
				UseVariable = true
			};
			this.stepOffset = new FsmFloat
			{
				UseVariable = true
			};
			this.center = new FsmVector3
			{
				UseVariable = true
			};
			this.detectCollisions = new FsmBool
			{
				UseVariable = true
			};
			this.everyFrame = false;
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x000306F4 File Offset: 0x0002E8F4
		public override void OnEnter()
		{
			this.DoControllerSettings();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00030710 File Offset: 0x0002E910
		public override void OnUpdate()
		{
			this.DoControllerSettings();
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x00030718 File Offset: 0x0002E918
		private void DoControllerSettings()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.previousGo)
			{
				this.controller = ownerDefaultTarget.GetComponent<CharacterController>();
				this.previousGo = ownerDefaultTarget;
			}
			if (this.controller != null)
			{
				if (!this.height.IsNone)
				{
					this.controller.height = this.height.Value;
				}
				if (!this.radius.IsNone)
				{
					this.controller.radius = this.radius.Value;
				}
				if (!this.slopeLimit.IsNone)
				{
					this.controller.slopeLimit = this.slopeLimit.Value;
				}
				if (!this.stepOffset.IsNone)
				{
					this.controller.stepOffset = this.stepOffset.Value;
				}
				if (!this.center.IsNone)
				{
					this.controller.center = this.center.Value;
				}
				if (!this.detectCollisions.IsNone)
				{
					this.controller.detectCollisions = this.detectCollisions.Value;
				}
			}
		}

		// Token: 0x04000984 RID: 2436
		[CheckForComponent(typeof(CharacterController))]
		[Tooltip("The GameObject that owns the CharacterController.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000985 RID: 2437
		[Tooltip("The height of the character's capsule.")]
		public FsmFloat height;

		// Token: 0x04000986 RID: 2438
		[Tooltip("The radius of the character's capsule.")]
		public FsmFloat radius;

		// Token: 0x04000987 RID: 2439
		[Tooltip("The character controllers slope limit in degrees.")]
		public FsmFloat slopeLimit;

		// Token: 0x04000988 RID: 2440
		[Tooltip("The character controllers step offset in meters.")]
		public FsmFloat stepOffset;

		// Token: 0x04000989 RID: 2441
		[Tooltip("The center of the character's capsule relative to the transform's position")]
		public FsmVector3 center;

		// Token: 0x0400098A RID: 2442
		[Tooltip("Should other rigidbodies or character controllers collide with this character controller (By default always enabled).")]
		public FsmBool detectCollisions;

		// Token: 0x0400098B RID: 2443
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x0400098C RID: 2444
		private GameObject previousGo;

		// Token: 0x0400098D RID: 2445
		private CharacterController controller;
	}
}
