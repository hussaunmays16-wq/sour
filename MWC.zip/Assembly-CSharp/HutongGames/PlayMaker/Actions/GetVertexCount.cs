﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000266 RID: 614
	[Tooltip("Gets the number of vertices in a GameObject's mesh. Useful in conjunction with GetVertexPosition.")]
	[ActionCategory("Mesh")]
	public class GetVertexCount : FsmStateAction
	{
		// Token: 0x06000A78 RID: 2680 RVA: 0x00040034 File Offset: 0x0003E234
		public override void Reset()
		{
			this.gameObject = null;
			this.storeCount = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0004004C File Offset: 0x0003E24C
		public override void OnEnter()
		{
			this.DoGetVertexCount();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x00040068 File Offset: 0x0003E268
		public override void OnUpdate()
		{
			this.DoGetVertexCount();
		}

		// Token: 0x06000A7B RID: 2683 RVA: 0x00040070 File Offset: 0x0003E270
		private void DoGetVertexCount()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget != null)
			{
				MeshFilter component = ownerDefaultTarget.GetComponent<MeshFilter>();
				if (component == null)
				{
					this.LogError("Missing MeshFilter!");
					return;
				}
				this.storeCount.Value = component.mesh.vertexCount;
			}
		}

		// Token: 0x04000E64 RID: 3684
		[CheckForComponent(typeof(MeshFilter))]
		[Tooltip("The GameObject to check.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E65 RID: 3685
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the vertex count in a variable.")]
		public FsmInt storeCount;

		// Token: 0x04000E66 RID: 3686
		public bool everyFrame;
	}
}
