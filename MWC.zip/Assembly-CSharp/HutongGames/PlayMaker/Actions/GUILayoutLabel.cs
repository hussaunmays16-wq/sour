﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FE RID: 510
	[Tooltip("GUILayout Label.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutLabel : GUILayoutAction
	{
		// Token: 0x060008C7 RID: 2247 RVA: 0x0003AAD8 File Offset: 0x00038CD8
		public override void Reset()
		{
			base.Reset();
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x0003AB18 File Offset: 0x00038D18
		public override void OnGUI()
		{
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUILayout.Label(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), base.LayoutOptions);
			}
			else
			{
				GUILayout.Label(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
			}
		}

		// Token: 0x04000C82 RID: 3202
		public FsmTexture image;

		// Token: 0x04000C83 RID: 3203
		public FsmString text;

		// Token: 0x04000C84 RID: 3204
		public FsmString tooltip;

		// Token: 0x04000C85 RID: 3205
		public FsmString style;
	}
}
