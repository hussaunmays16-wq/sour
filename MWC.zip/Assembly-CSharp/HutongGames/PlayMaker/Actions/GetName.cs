﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000245 RID: 581
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets the name of a Game Object and stores it in a String Variable.")]
	public class GetName : FsmStateAction
	{
		// Token: 0x060009EB RID: 2539 RVA: 0x0003E908 File Offset: 0x0003CB08
		public override void Reset()
		{
			this.gameObject = new FsmGameObject
			{
				UseVariable = true
			};
			this.storeName = null;
			this.everyFrame = false;
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0003E938 File Offset: 0x0003CB38
		public override void OnEnter()
		{
			this.DoGetGameObjectName();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0003E954 File Offset: 0x0003CB54
		public override void OnUpdate()
		{
			this.DoGetGameObjectName();
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x0003E95C File Offset: 0x0003CB5C
		private void DoGetGameObjectName()
		{
			GameObject value = this.gameObject.Value;
			this.storeName.Value = ((!(value != null)) ? string.Empty : value.name);
		}

		// Token: 0x04000DE2 RID: 3554
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000DE3 RID: 3555
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeName;

		// Token: 0x04000DE4 RID: 3556
		public bool everyFrame;
	}
}
