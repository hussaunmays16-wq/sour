﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A1 RID: 1185
	[ActionCategory("cInput")]
	[Tooltip("Forbids a mapped cInput key.")]
	public class CInputForbidKeyString : FsmStateAction
	{
		// Token: 0x0600143F RID: 5183 RVA: 0x00088914 File Offset: 0x00086B14
		public override void OnEnter()
		{
			cInput.ForbidKey(this.keyName.Value);
			base.Finish();
		}

		// Token: 0x04001CA9 RID: 7337
		[Tooltip("The name of the key to forbid.")]
		public FsmString keyName;
	}
}
