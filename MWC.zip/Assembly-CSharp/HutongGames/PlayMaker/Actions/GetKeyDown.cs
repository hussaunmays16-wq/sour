﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000237 RID: 567
	[Tooltip("Sends an Event when a Key is pressed.")]
	[ActionCategory(ActionCategory.Input)]
	public class GetKeyDown : FsmStateAction
	{
		// Token: 0x060009B7 RID: 2487 RVA: 0x0003E120 File Offset: 0x0003C320
		public override void Reset()
		{
			this.sendEvent = null;
			this.key = KeyCode.None;
			this.storeResult = null;
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x0003E138 File Offset: 0x0003C338
		public override void OnUpdate()
		{
			bool keyDown = Input.GetKeyDown(this.key);
			if (keyDown)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = keyDown;
		}

		// Token: 0x04000DB9 RID: 3513
		[RequiredField]
		public KeyCode key;

		// Token: 0x04000DBA RID: 3514
		public FsmEvent sendEvent;

		// Token: 0x04000DBB RID: 3515
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;
	}
}
