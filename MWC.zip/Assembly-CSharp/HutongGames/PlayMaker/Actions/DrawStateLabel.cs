﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000187 RID: 391
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Draws a state label for this FSM in the Game View. The label is drawn on the game object that owns the FSM. Use this to override the global setting in the PlayMaker Debug menu.")]
	public class DrawStateLabel : FsmStateAction
	{
		// Token: 0x06000720 RID: 1824 RVA: 0x00031DDC File Offset: 0x0002FFDC
		public override void Reset()
		{
			this.showLabel = true;
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x00031DEC File Offset: 0x0002FFEC
		public override void OnEnter()
		{
			base.Fsm.ShowStateLabel = this.showLabel.Value;
			base.Finish();
		}

		// Token: 0x04000A06 RID: 2566
		[Tooltip("Set to True to show State labels, or Fals to hide them.")]
		[RequiredField]
		public FsmBool showLabel;
	}
}
