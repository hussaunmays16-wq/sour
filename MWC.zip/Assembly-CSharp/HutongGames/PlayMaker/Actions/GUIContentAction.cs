﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E4 RID: 484
	[Tooltip("GUI base action - don't use!")]
	public abstract class GUIContentAction : GUIAction
	{
		// Token: 0x06000878 RID: 2168 RVA: 0x00039720 File Offset: 0x00037920
		public override void Reset()
		{
			base.Reset();
			this.image = null;
			this.text = string.Empty;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x00039760 File Offset: 0x00037960
		public override void OnGUI()
		{
			base.OnGUI();
			this.content = new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value);
		}

		// Token: 0x04000C27 RID: 3111
		public FsmTexture image;

		// Token: 0x04000C28 RID: 3112
		public FsmString text;

		// Token: 0x04000C29 RID: 3113
		public FsmString tooltip;

		// Token: 0x04000C2A RID: 3114
		public FsmString style;

		// Token: 0x04000C2B RID: 3115
		internal GUIContent content;
	}
}
