﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E4 RID: 996
	[ActionCategory("Easy Save 2")]
	[Tooltip("Loads a PlayMaker HashTable Proxy component using EasySave")]
	public class HashTableEasyLoadEncrypted : HashTableActions
	{
		// Token: 0x060010DD RID: 4317 RVA: 0x0005CBBC File Offset: 0x0005ADBC
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.encryption = false;
			this.password = string.Empty;
			this.loadFile = "defaultES2File.txt";
			this.loadFromResources = false;
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x0005CC24 File Offset: 0x0005AE24
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.LoadHashTable();
			}
			base.Finish();
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x0005CC64 File Offset: 0x0005AE64
		public void LoadHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = "false";
			if (this.encryption.Value)
			{
				text = "true";
			}
			string text2 = "&savelocation=file";
			if (this.loadFromResources.Value)
			{
				text2 = "&savelocation=resources";
			}
			Dictionary<string, string> dictionary = ES2.LoadDictionary<string, string>(string.Concat(new string[]
			{
				this.loadFile.Value,
				"?tag=",
				this.uniqueTag.Value,
				"&encrypt=",
				text,
				"&password=",
				this.password.Value,
				text2
			}));
			this.Log(string.Concat(new object[]
			{
				"Loaded from ",
				this.loadFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			this.proxy.hashTable.Clear();
			foreach (string key in dictionary.Keys)
			{
				this.proxy.hashTable[key] = PlayMakerUtils.ParseValueFromString(dictionary[key]);
			}
			base.Finish();
		}

		// Token: 0x04001600 RID: 5632
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001601 RID: 5633
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001602 RID: 5634
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		[ActionSection("Easy Save Set Up")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04001603 RID: 5635
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x04001604 RID: 5636
		[Tooltip("the password of the saved item")]
		public FsmString password = string.Empty;

		// Token: 0x04001605 RID: 5637
		[Tooltip("The name of the file that we'll create to store our data.")]
		[RequiredField]
		public FsmString loadFile = "defaultES2File.txt";

		// Token: 0x04001606 RID: 5638
		[Tooltip("Whether the data we are loading is stored in the Resources folder.")]
		public FsmBool loadFromResources;
	}
}
