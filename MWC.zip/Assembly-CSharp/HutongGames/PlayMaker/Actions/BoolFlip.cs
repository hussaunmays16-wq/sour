﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200014E RID: 334
	[Tooltip("Flips the value of a Bool Variable.")]
	[ActionCategory(ActionCategory.Math)]
	public class BoolFlip : FsmStateAction
	{
		// Token: 0x06000634 RID: 1588 RVA: 0x0002EF08 File Offset: 0x0002D108
		public override void Reset()
		{
			this.boolVariable = null;
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0002EF14 File Offset: 0x0002D114
		public override void OnEnter()
		{
			this.boolVariable.Value = !this.boolVariable.Value;
			base.Finish();
		}

		// Token: 0x0400092A RID: 2346
		[UIHint(UIHint.Variable)]
		[Tooltip("Bool variable to flip.")]
		[RequiredField]
		public FsmBool boolVariable;
	}
}
