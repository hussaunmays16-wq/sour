﻿using System;
using UnityEngine.Audio;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000009 RID: 9
	[Tooltip("Sets the float value of an exposed parameter for a Unity Audio Mixer.")]
	[ActionCategory(ActionCategory.Audio)]
	public class AudioMixerSetFloatValue : FsmStateAction
	{
		// Token: 0x06000017 RID: 23 RVA: 0x00002620 File Offset: 0x00000820
		public override void Reset()
		{
			this.theMixer = null;
			this.exposedFloatName = null;
			this.floatvalue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002640 File Offset: 0x00000840
		public override void OnEnter()
		{
			this.DoSetMixerFloatValue();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000265C File Offset: 0x0000085C
		public override void OnUpdate()
		{
			this.DoSetMixerFloatValue();
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002664 File Offset: 0x00000864
		public void DoSetMixerFloatValue()
		{
			AudioMixer audioMixer = this.theMixer.Value as AudioMixer;
			if (audioMixer != null && !string.IsNullOrEmpty(this.exposedFloatName.Value))
			{
				string value = this.exposedFloatName.Value;
				float value2 = this.floatvalue.Value;
				audioMixer.SetFloat(value, value2);
			}
		}

		// Token: 0x04000015 RID: 21
		[ObjectType(typeof(AudioMixer))]
		[RequiredField]
		[Tooltip("The Audio Mixer with the exposed parameter.")]
		public FsmObject theMixer;

		// Token: 0x04000016 RID: 22
		[RequiredField]
		[Tooltip("The name of the exposed parameter.")]
		[Title("Name of Parameter")]
		public FsmString exposedFloatName;

		// Token: 0x04000017 RID: 23
		[Title("Float Value")]
		public FsmFloat floatvalue;

		// Token: 0x04000018 RID: 24
		public bool everyFrame;
	}
}
