﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001EC RID: 492
	[Tooltip("GUILayout BeginHorizontal.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutBeginHorizontal : GUILayoutAction
	{
		// Token: 0x06000892 RID: 2194 RVA: 0x00039FE0 File Offset: 0x000381E0
		public override void Reset()
		{
			base.Reset();
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x0003A020 File Offset: 0x00038220
		public override void OnGUI()
		{
			GUILayout.BeginHorizontal(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
		}

		// Token: 0x04000C4D RID: 3149
		public FsmTexture image;

		// Token: 0x04000C4E RID: 3150
		public FsmString text;

		// Token: 0x04000C4F RID: 3151
		public FsmString tooltip;

		// Token: 0x04000C50 RID: 3152
		public FsmString style;
	}
}
