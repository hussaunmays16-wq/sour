﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000216 RID: 534
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when a Button is pressed.")]
	public class GetButtonDown : FsmStateAction
	{
		// Token: 0x06000922 RID: 2338 RVA: 0x0003C054 File Offset: 0x0003A254
		public override void Reset()
		{
			this.buttonName = "Fire1";
			this.sendEvent = null;
			this.storeResult = null;
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x0003C074 File Offset: 0x0003A274
		public override void OnUpdate()
		{
			bool keyDown = cInput.GetKeyDown(this.buttonName.Value);
			if (keyDown)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = keyDown;
		}

		// Token: 0x04000CF0 RID: 3312
		[Tooltip("The name of the button. Set in the Unity Input Manager.")]
		[RequiredField]
		public FsmString buttonName;

		// Token: 0x04000CF1 RID: 3313
		[Tooltip("Event to send if the button is pressed.")]
		public FsmEvent sendEvent;

		// Token: 0x04000CF2 RID: 3314
		[Tooltip("Set to True if the button is pressed.")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;
	}
}
