﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000006 RID: 6
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when the user hits any Key or Mouse Button.")]
	public class AnyKeyStoreString : FsmStateAction
	{
		// Token: 0x0600000A RID: 10 RVA: 0x00002204 File Offset: 0x00000404
		public override void Reset()
		{
			this.sendEvent = null;
			this.storeResult = null;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002214 File Offset: 0x00000414
		public override void OnUpdate()
		{
			this.storeResult.Value = Input.inputString;
			if (Input.anyKey)
			{
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x04000003 RID: 3
		[RequiredField]
		public FsmEvent sendEvent;

		// Token: 0x04000004 RID: 4
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;
	}
}
