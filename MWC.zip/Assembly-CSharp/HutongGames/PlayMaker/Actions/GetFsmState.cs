﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022E RID: 558
	[Tooltip("Gets the name of the specified FSMs current state. Either reference the fsm component directly, or find it on a game object.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmState : FsmStateAction
	{
		// Token: 0x0600098A RID: 2442 RVA: 0x0003D800 File Offset: 0x0003BA00
		public override void Reset()
		{
			this.fsmComponent = null;
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x0003D83C File Offset: 0x0003BA3C
		public override void OnEnter()
		{
			this.DoGetFsmState();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600098C RID: 2444 RVA: 0x0003D858 File Offset: 0x0003BA58
		public override void OnUpdate()
		{
			this.DoGetFsmState();
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x0003D860 File Offset: 0x0003BA60
		private void DoGetFsmState()
		{
			if (this.fsm == null)
			{
				if (this.fsmComponent != null)
				{
					this.fsm = this.fsmComponent;
				}
				else
				{
					GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
					if (ownerDefaultTarget != null)
					{
						this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
					}
				}
				if (this.fsm == null)
				{
					this.storeResult.Value = string.Empty;
					return;
				}
			}
			this.storeResult.Value = this.fsm.ActiveStateName;
		}

		// Token: 0x04000D7E RID: 3454
		[Tooltip("Drag a PlayMakerFSM component here.")]
		public PlayMakerFSM fsmComponent;

		// Token: 0x04000D7F RID: 3455
		[Tooltip("If not specifyng the component above, specify the GameObject that owns the FSM")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D80 RID: 3456
		[Tooltip("Optional name of Fsm on Game Object. If left blank it will find the first PlayMakerFSM on the GameObject.")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000D81 RID: 3457
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the state name in a string variable.")]
		public FsmString storeResult;

		// Token: 0x04000D82 RID: 3458
		[Tooltip("Repeat every frame. E.g.,  useful if you're waiting for the state to change.")]
		public bool everyFrame;

		// Token: 0x04000D83 RID: 3459
		private PlayMakerFSM fsm;
	}
}
