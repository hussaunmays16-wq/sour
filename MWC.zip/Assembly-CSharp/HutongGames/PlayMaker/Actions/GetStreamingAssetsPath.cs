﻿using System;
using System.IO;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003FB RID: 1019
	[ActionCategory(ActionCategory.Application)]
	[Tooltip("Get Streaming Assets Path, Application Folder and persistentDataPath.")]
	public class GetStreamingAssetsPath : FsmStateAction
	{
		// Token: 0x06001133 RID: 4403 RVA: 0x0005F214 File Offset: 0x0005D414
		public override void OnEnter()
		{
			string text = Application.dataPath;
			string text2 = Application.streamingAssetsPath;
			string text3 = Path.GetFullPath(".");
			text += "/";
			text2 += "/";
			text3 += "/";
			this.DataPathResult.Value = text;
			this.AppFolderResult.Value = text3;
			this.PersistentPathResult.Value = text2;
			this.PlaformResult.Value = Application.platform.ToString();
			base.Finish();
		}

		// Token: 0x04001690 RID: 5776
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Path Result")]
		public FsmString DataPathResult;

		// Token: 0x04001691 RID: 5777
		public FsmString AppFolderResult;

		// Token: 0x04001692 RID: 5778
		public FsmString PersistentPathResult;

		// Token: 0x04001693 RID: 5779
		[UIHint(UIHint.Variable)]
		[Tooltip("Platform Result Result")]
		public FsmString PlaformResult;
	}
}
