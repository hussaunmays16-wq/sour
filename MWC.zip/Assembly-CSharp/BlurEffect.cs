﻿using System;
using UnityEngine;

// Token: 0x02000453 RID: 1107
[ExecuteInEditMode]
[AddComponentMenu("Image Effects/Blur")]
public class BlurEffect : MonoBehaviour
{
	// Token: 0x17000088 RID: 136
	// (get) Token: 0x06001292 RID: 4754 RVA: 0x000687A8 File Offset: 0x000669A8
	protected static Material material
	{
		get
		{
			if (BlurEffect.m_Material == null)
			{
				BlurEffect.m_Material = new Material(BlurEffect.blurMatString);
				BlurEffect.m_Material.hideFlags = HideFlags.HideAndDontSave;
				BlurEffect.m_Material.shader.hideFlags = HideFlags.HideAndDontSave;
			}
			return BlurEffect.m_Material;
		}
	}

	// Token: 0x06001293 RID: 4755 RVA: 0x000687F8 File Offset: 0x000669F8
	protected void OnDisable()
	{
		if (BlurEffect.m_Material)
		{
			UnityEngine.Object.DestroyImmediate(BlurEffect.m_Material.shader);
			UnityEngine.Object.DestroyImmediate(BlurEffect.m_Material);
		}
	}

	// Token: 0x06001294 RID: 4756 RVA: 0x00068830 File Offset: 0x00066A30
	protected void Start()
	{
		if (!SystemInfo.supportsImageEffects)
		{
			base.enabled = false;
			return;
		}
		if (!BlurEffect.material.shader.isSupported)
		{
			base.enabled = false;
			return;
		}
	}

	// Token: 0x06001295 RID: 4757 RVA: 0x0006886C File Offset: 0x00066A6C
	public void FourTapCone(RenderTexture source, RenderTexture dest, int iteration)
	{
		float num = 0.5f + (float)iteration * this.blurSpread;
		Graphics.BlitMultiTap(source, dest, BlurEffect.material, new Vector2[]
		{
			new Vector2(-num, -num),
			new Vector2(-num, num),
			new Vector2(num, num),
			new Vector2(num, -num)
		});
	}

	// Token: 0x06001296 RID: 4758 RVA: 0x000688EC File Offset: 0x00066AEC
	private void DownSample4x(RenderTexture source, RenderTexture dest)
	{
		float num = 1f;
		Graphics.BlitMultiTap(source, dest, BlurEffect.material, new Vector2[]
		{
			new Vector2(-num, -num),
			new Vector2(-num, num),
			new Vector2(num, num),
			new Vector2(num, -num)
		});
	}

	// Token: 0x06001297 RID: 4759 RVA: 0x00068964 File Offset: 0x00066B64
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		RenderTexture temporary = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0);
		RenderTexture temporary2 = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0);
		this.DownSample4x(source, temporary);
		bool flag = true;
		for (int i = 0; i < this.iterations; i++)
		{
			if (flag)
			{
				this.FourTapCone(temporary, temporary2, i);
			}
			else
			{
				this.FourTapCone(temporary2, temporary, i);
			}
			flag = !flag;
		}
		if (flag)
		{
			ImageEffects.Blit(temporary, destination);
		}
		else
		{
			ImageEffects.Blit(temporary2, destination);
		}
		RenderTexture.ReleaseTemporary(temporary);
		RenderTexture.ReleaseTemporary(temporary2);
	}

	// Token: 0x0400183E RID: 6206
	public int iterations = 3;

	// Token: 0x0400183F RID: 6207
	public float blurSpread = 0.6f;

	// Token: 0x04001840 RID: 6208
	private static string blurMatString = "Shader \"BlurConeTap\" {\n\tProperties { _MainTex (\"\", any) = \"\" {} }\n\tSubShader {\n\t\tPass {\n\t\t\tZTest Always Cull Off ZWrite Off Fog { Mode Off }\n\t\t\tSetTexture [_MainTex] {constantColor (0,0,0,0.25) combine texture * constant alpha}\n\t\t\tSetTexture [_MainTex] {constantColor (0,0,0,0.25) combine texture * constant + previous}\n\t\t\tSetTexture [_MainTex] {constantColor (0,0,0,0.25) combine texture * constant + previous}\n\t\t\tSetTexture [_MainTex] {constantColor (0,0,0,0.25) combine texture * constant + previous}\n\t\t}\n\t}\n\tFallback off\n}";

	// Token: 0x04001841 RID: 6209
	private static Material m_Material;
}
