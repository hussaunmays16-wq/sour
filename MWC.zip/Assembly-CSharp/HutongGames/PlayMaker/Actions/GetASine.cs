﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200002E RID: 46
	[Tooltip("Get the Arc sine. You can get the result in degrees, simply check on the RadToDeg conversion")]
	[ActionCategory("Trigonometry")]
	public class GetASine : FsmStateAction
	{
		// Token: 0x06000097 RID: 151 RVA: 0x00006344 File Offset: 0x00004544
		public override void Reset()
		{
			this.angle = null;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.Value = null;
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00006368 File Offset: 0x00004568
		public override void OnEnter()
		{
			this.DoASine();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00006384 File Offset: 0x00004584
		public override void OnUpdate()
		{
			this.DoASine();
		}

		// Token: 0x0600009A RID: 154 RVA: 0x0000638C File Offset: 0x0000458C
		private void DoASine()
		{
			float num = Mathf.Asin(this.Value.Value);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000ED RID: 237
		[RequiredField]
		[Tooltip("The value of the sine")]
		public FsmFloat Value;

		// Token: 0x040000EE RID: 238
		[RequiredField]
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		[UIHint(UIHint.Variable)]
		public FsmFloat angle;

		// Token: 0x040000EF RID: 239
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x040000F0 RID: 240
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
