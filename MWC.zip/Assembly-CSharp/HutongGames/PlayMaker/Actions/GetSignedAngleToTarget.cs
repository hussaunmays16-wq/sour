﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200000D RID: 13
	[Tooltip("Gets the signed Angle (in degrees, clockwise, -180 to 180) between a Game Object's forward axis and a Target. The Target can be defined as a Game Object or a world Position. If you specify both, then the Position will be used as a local offset from the Object's position.")]
	[ActionCategory(ActionCategory.Transform)]
	public class GetSignedAngleToTarget : FsmStateAction
	{
		// Token: 0x06000028 RID: 40 RVA: 0x00002B44 File Offset: 0x00000D44
		public override void Reset()
		{
			this.gameObject = null;
			this.targetObject = null;
			this.targetPosition = new FsmVector3
			{
				UseVariable = true
			};
			this.ignoreHeight = true;
			this.storeAngle = null;
			this.everyFrame = false;
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00002B90 File Offset: 0x00000D90
		public override void OnLateUpdate()
		{
			this.DoGetAngleToTarget();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00002BAC File Offset: 0x00000DAC
		private void DoGetAngleToTarget()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			GameObject value = this.targetObject.Value;
			if (value == null && this.targetPosition.IsNone)
			{
				return;
			}
			Vector3 position;
			if (value != null)
			{
				position = (this.targetPosition.IsNone ? value.transform.position : value.transform.TransformPoint(this.targetPosition.Value));
			}
			else
			{
				position = this.targetPosition.Value;
			}
			if (this.ignoreHeight.Value)
			{
				position.y = ownerDefaultTarget.transform.position.y;
			}
			Vector3 vector = ownerDefaultTarget.transform.InverseTransformPoint(position);
			this.storeAngle.Value = Mathf.Atan2(vector.x, vector.z) * 57.29578f;
		}

		// Token: 0x04000029 RID: 41
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400002A RID: 42
		public FsmGameObject targetObject;

		// Token: 0x0400002B RID: 43
		public FsmVector3 targetPosition;

		// Token: 0x0400002C RID: 44
		public FsmBool ignoreHeight;

		// Token: 0x0400002D RID: 45
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeAngle;

		// Token: 0x0400002E RID: 46
		public bool everyFrame;
	}
}
