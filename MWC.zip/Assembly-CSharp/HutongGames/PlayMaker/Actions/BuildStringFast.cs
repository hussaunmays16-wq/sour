﻿using System;
using System.Text;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200040E RID: 1038
	[ActionCategory(ActionCategory.String)]
	[HelpUrl("")]
	[Tooltip("Builds a String from other Strings with less memory allocations.")]
	public class BuildStringFast : FsmStateAction
	{
		// Token: 0x06001184 RID: 4484 RVA: 0x000609EC File Offset: 0x0005EBEC
		public override void Reset()
		{
			this.stringParts = new FsmString[3];
			this.separator = null;
			this.addToEnd = true;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06001185 RID: 4485 RVA: 0x00060A2C File Offset: 0x0005EC2C
		public override void OnEnter()
		{
			this.DoBuildString();
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x06001186 RID: 4486 RVA: 0x00060A4C File Offset: 0x0005EC4C
		public override void OnUpdate()
		{
			this.DoBuildString();
		}

		// Token: 0x06001187 RID: 4487 RVA: 0x00060A54 File Offset: 0x0005EC54
		private void DoBuildString()
		{
			if (this.storeResult == null)
			{
				return;
			}
			StringBuilder stringBuilder = new StringBuilder(32);
			this.m_chars = new char[this.m_charsCapacity = 32];
			this.Clear();
			for (int i = 0; i < this.stringParts.Length - 1; i++)
			{
				this.Append(this.stringParts[i].Value);
				this.Append(this.separator.Value);
			}
			this.ToString();
			this.Append(this.stringParts[this.stringParts.Length - 1].Value);
			if (this.addToEnd.Value)
			{
				this.Append(this.separator.Value);
			}
			this.storeResult.Value = this.ToString();
		}

		// Token: 0x06001188 RID: 4488 RVA: 0x00060B28 File Offset: 0x0005ED28
		public void Append(string value)
		{
			this.ReallocateIFN(value.Length);
			int length = value.Length;
			for (int i = 0; i < length; i++)
			{
				this.m_chars[this.m_charsCount + i] = value[i];
			}
			this.m_charsCount += length;
			this.m_isStringGenerated = false;
		}

		// Token: 0x06001189 RID: 4489 RVA: 0x00060B88 File Offset: 0x0005ED88
		private void ReallocateIFN(int nbCharsToAdd)
		{
			if (this.m_charsCount + nbCharsToAdd > this.m_charsCapacity)
			{
				this.m_charsCapacity = Math.Max(this.m_charsCapacity + nbCharsToAdd, this.m_charsCapacity * 2);
				char[] array = new char[this.m_charsCapacity];
				this.m_chars.CopyTo(array, 0);
				this.m_chars = array;
			}
		}

		// Token: 0x0600118A RID: 4490 RVA: 0x00060BE4 File Offset: 0x0005EDE4
		public bool IsEmpty()
		{
			return (!this.m_isStringGenerated) ? (this.m_charsCount == 0) : (this.m_stringGenerated == null);
		}

		// Token: 0x0600118B RID: 4491 RVA: 0x00060C14 File Offset: 0x0005EE14
		public void Clear()
		{
			this.m_charsCount = 0;
			this.m_isStringGenerated = false;
		}

		// Token: 0x0600118C RID: 4492 RVA: 0x00060C24 File Offset: 0x0005EE24
		public override string ToString()
		{
			if (!this.m_isStringGenerated)
			{
				this.m_stringGenerated = new string(this.m_chars, 0, this.m_charsCount);
				this.m_isStringGenerated = true;
			}
			return this.m_stringGenerated;
		}

		// Token: 0x04001702 RID: 5890
		[RequiredField]
		[Tooltip("Array of Strings to combine.")]
		public FsmString[] stringParts;

		// Token: 0x04001703 RID: 5891
		[Tooltip("Separator to insert between each String. E.g. space character.")]
		public FsmString separator;

		// Token: 0x04001704 RID: 5892
		[Tooltip("Add Separator to end of built string.")]
		public FsmBool addToEnd;

		// Token: 0x04001705 RID: 5893
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the final String in a variable.")]
		public FsmString storeResult;

		// Token: 0x04001706 RID: 5894
		[Tooltip("Repeat every frame while the state is active.")]
		public FsmBool everyFrame;

		// Token: 0x04001707 RID: 5895
		private string result;

		// Token: 0x04001708 RID: 5896
		private char[] m_chars;

		// Token: 0x04001709 RID: 5897
		private string m_stringGenerated = string.Empty;

		// Token: 0x0400170A RID: 5898
		private bool m_isStringGenerated;

		// Token: 0x0400170B RID: 5899
		private int m_charsCount;

		// Token: 0x0400170C RID: 5900
		private int m_charsCapacity;
	}
}
