﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000209 RID: 521
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if the value of a GameObject variable changed. Use this to send an event on change, or store a bool that can be used in other operations.")]
	public class GameObjectChanged : FsmStateAction
	{
		// Token: 0x060008EB RID: 2283 RVA: 0x0003B544 File Offset: 0x00039744
		public override void Reset()
		{
			this.gameObjectVariable = null;
			this.changedEvent = null;
			this.storeResult = null;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x0003B55C File Offset: 0x0003975C
		public override void OnEnter()
		{
			if (this.gameObjectVariable.IsNone)
			{
				base.Finish();
				return;
			}
			this.previousValue = this.gameObjectVariable.Value;
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x0003B594 File Offset: 0x00039794
		public override void OnUpdate()
		{
			this.storeResult.Value = false;
			if (this.gameObjectVariable.Value != this.previousValue)
			{
				this.storeResult.Value = true;
				base.Fsm.Event(this.changedEvent);
			}
		}

		// Token: 0x04000CB0 RID: 3248
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The GameObject variable to watch for a change.")]
		public FsmGameObject gameObjectVariable;

		// Token: 0x04000CB1 RID: 3249
		[Tooltip("Event to send if the variable changes.")]
		public FsmEvent changedEvent;

		// Token: 0x04000CB2 RID: 3250
		[Tooltip("Set to True if the variable changes.")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000CB3 RID: 3251
		private GameObject previousValue;
	}
}
