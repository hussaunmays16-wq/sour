﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200016B RID: 363
	[Tooltip("Converts a Material variable to an Object variable. Useful if you want to use Set Property (which only works on Object variables).")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertMaterialToObject : FsmStateAction
	{
		// Token: 0x060006C0 RID: 1728 RVA: 0x00030EC8 File Offset: 0x0002F0C8
		public override void Reset()
		{
			this.materialVariable = null;
			this.objectVariable = null;
			this.everyFrame = false;
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00030EE0 File Offset: 0x0002F0E0
		public override void OnEnter()
		{
			this.DoConvertMaterialToObject();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00030EFC File Offset: 0x0002F0FC
		public override void OnUpdate()
		{
			this.DoConvertMaterialToObject();
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00030F04 File Offset: 0x0002F104
		private void DoConvertMaterialToObject()
		{
			this.objectVariable.Value = this.materialVariable.Value;
		}

		// Token: 0x040009BB RID: 2491
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The Material variable to convert to an Object.")]
		public FsmMaterial materialVariable;

		// Token: 0x040009BC RID: 2492
		[Tooltip("Store the result in an Object variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmObject objectVariable;

		// Token: 0x040009BD RID: 2493
		[Tooltip("Repeat every frame. Useful if the Material variable is changing.")]
		public bool everyFrame;
	}
}
