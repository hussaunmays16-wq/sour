﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E0 RID: 480
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if an FSM is in the specified State.")]
	public class FsmStateTest : FsmStateAction
	{
		// Token: 0x0600086B RID: 2155 RVA: 0x00039348 File Offset: 0x00037548
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = null;
			this.stateName = null;
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x0003937C File Offset: 0x0003757C
		public override void OnEnter()
		{
			this.DoFsmStateTest();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x00039398 File Offset: 0x00037598
		public override void OnUpdate()
		{
			this.DoFsmStateTest();
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x000393A0 File Offset: 0x000375A0
		private void DoFsmStateTest()
		{
			GameObject value = this.gameObject.Value;
			if (value == null)
			{
				return;
			}
			if (value != this.previousGo)
			{
				this.fsm = ActionHelpers.GetGameObjectFsm(value, this.fsmName.Value);
				this.previousGo = value;
			}
			if (this.fsm == null)
			{
				return;
			}
			bool value2 = false;
			if (this.fsm.ActiveStateName == this.stateName.Value)
			{
				base.Fsm.Event(this.trueEvent);
				value2 = true;
			}
			else
			{
				base.Fsm.Event(this.falseEvent);
			}
			this.storeResult.Value = value2;
		}

		// Token: 0x04000C15 RID: 3093
		[RequiredField]
		[Tooltip("The GameObject that owns the FSM.")]
		public FsmGameObject gameObject;

		// Token: 0x04000C16 RID: 3094
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of Fsm on Game Object. Useful if there is more than one FSM on the GameObject.")]
		public FsmString fsmName;

		// Token: 0x04000C17 RID: 3095
		[Tooltip("Check to see if the FSM is in this state.")]
		[RequiredField]
		public FsmString stateName;

		// Token: 0x04000C18 RID: 3096
		[Tooltip("Event to send if the FSM is in the specified state.")]
		public FsmEvent trueEvent;

		// Token: 0x04000C19 RID: 3097
		[Tooltip("Event to send if the FSM is NOT in the specified state.")]
		public FsmEvent falseEvent;

		// Token: 0x04000C1A RID: 3098
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result of this test in a bool variable. Useful if other actions depend on this test.")]
		public FsmBool storeResult;

		// Token: 0x04000C1B RID: 3099
		[Tooltip("Repeat every frame. Useful if you're waiting for a particular state.")]
		public bool everyFrame;

		// Token: 0x04000C1C RID: 3100
		private GameObject previousGo;

		// Token: 0x04000C1D RID: 3101
		private PlayMakerFSM fsm;
	}
}
