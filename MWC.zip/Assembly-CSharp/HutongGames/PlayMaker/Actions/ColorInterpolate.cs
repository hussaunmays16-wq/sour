﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015A RID: 346
	[ActionCategory(ActionCategory.Color)]
	[Tooltip("Interpolate through an array of Colors over a specified amount of Time.")]
	public class ColorInterpolate : FsmStateAction
	{
		// Token: 0x0600066F RID: 1647 RVA: 0x0002FF44 File Offset: 0x0002E144
		public override void Reset()
		{
			this.colors = new FsmColor[3];
			this.time = 1f;
			this.storeColor = null;
			this.finishEvent = null;
			this.realTime = false;
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x0002FF78 File Offset: 0x0002E178
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.currentTime = 0f;
			if (this.colors.Length < 2)
			{
				if (this.colors.Length == 1)
				{
					this.storeColor.Value = this.colors[0].Value;
				}
				base.Finish();
			}
			else
			{
				this.storeColor.Value = this.colors[0].Value;
			}
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0002FFF4 File Offset: 0x0002E1F4
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.currentTime = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.currentTime += Time.deltaTime;
			}
			if (this.currentTime > this.time.Value)
			{
				base.Finish();
				this.storeColor.Value = this.colors[this.colors.Length - 1].Value;
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
				return;
			}
			float num = (float)(this.colors.Length - 1) * this.currentTime / this.time.Value;
			Color value;
			if (num.Equals(0f))
			{
				value = this.colors[0].Value;
			}
			else if (num.Equals((float)(this.colors.Length - 1)))
			{
				value = this.colors[this.colors.Length - 1].Value;
			}
			else
			{
				Color value2 = this.colors[Mathf.FloorToInt(num)].Value;
				Color value3 = this.colors[Mathf.CeilToInt(num)].Value;
				num -= Mathf.Floor(num);
				value = Color.Lerp(value2, value3, num);
			}
			this.storeColor.Value = value;
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0003014C File Offset: 0x0002E34C
		public override string ErrorCheck()
		{
			return (this.colors.Length >= 2) ? null : "Define at least 2 colors to make a gradient.";
		}

		// Token: 0x04000969 RID: 2409
		[RequiredField]
		[Tooltip("Array of colors to interpolate through.")]
		public FsmColor[] colors;

		// Token: 0x0400096A RID: 2410
		[RequiredField]
		[Tooltip("Interpolation time.")]
		public FsmFloat time;

		// Token: 0x0400096B RID: 2411
		[Tooltip("Store the interpolated color in a Color variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmColor storeColor;

		// Token: 0x0400096C RID: 2412
		[Tooltip("Event to send when the interpolation finishes.")]
		public FsmEvent finishEvent;

		// Token: 0x0400096D RID: 2413
		[Tooltip("Ignore TimeScale")]
		public bool realTime;

		// Token: 0x0400096E RID: 2414
		private float startTime;

		// Token: 0x0400096F RID: 2415
		private float currentTime;
	}
}
