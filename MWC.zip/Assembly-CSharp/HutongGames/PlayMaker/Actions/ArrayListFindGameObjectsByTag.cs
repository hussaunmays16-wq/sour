﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039F RID: 927
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Store all active GameObjects with a specific tag. Tags must be declared in the tag manager before using them")]
	public class ArrayListFindGameObjectsByTag : ArrayListActions
	{
		// Token: 0x06000FB2 RID: 4018 RVA: 0x00056558 File Offset: 0x00054758
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.tag = null;
		}

		// Token: 0x06000FB3 RID: 4019 RVA: 0x00056570 File Offset: 0x00054770
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.FindGOByTag();
			}
			base.Finish();
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x000565B0 File Offset: 0x000547B0
		public void FindGOByTag()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.arrayList.Clear();
			GameObject[] c = GameObject.FindGameObjectsWithTag(this.tag.Value);
			this.proxy.arrayList.InsertRange(0, c);
		}

		// Token: 0x04001464 RID: 5220
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001465 RID: 5221
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001466 RID: 5222
		[Tooltip("the tag")]
		public FsmString tag;
	}
}
