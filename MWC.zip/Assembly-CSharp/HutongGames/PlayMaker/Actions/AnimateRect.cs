﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000132 RID: 306
	[Tooltip("Animates the value of a Rect Variable using an Animation Curve.")]
	[ActionCategory("AnimateVariables")]
	public class AnimateRect : AnimateFsmAction
	{
		// Token: 0x060005A5 RID: 1445 RVA: 0x0002A6E0 File Offset: 0x000288E0
		public override void Reset()
		{
			base.Reset();
			this.rectVariable = new FsmRect
			{
				UseVariable = true
			};
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x0002A708 File Offset: 0x00028908
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[4];
			this.fromFloats = new float[4];
			this.fromFloats[0] = ((!this.rectVariable.IsNone) ? this.rectVariable.Value.x : 0f);
			this.fromFloats[1] = ((!this.rectVariable.IsNone) ? this.rectVariable.Value.y : 0f);
			this.fromFloats[2] = ((!this.rectVariable.IsNone) ? this.rectVariable.Value.width : 0f);
			this.fromFloats[3] = ((!this.rectVariable.IsNone) ? this.rectVariable.Value.height : 0f);
			this.curves = new AnimationCurve[4];
			this.curves[0] = this.curveX.curve;
			this.curves[1] = this.curveY.curve;
			this.curves[2] = this.curveW.curve;
			this.curves[3] = this.curveH.curve;
			this.calculations = new AnimateFsmAction.Calculation[4];
			this.calculations[0] = this.calculationX;
			this.calculations[1] = this.calculationY;
			this.calculations[2] = this.calculationW;
			this.calculations[3] = this.calculationH;
			base.Init();
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x0002A8B0 File Offset: 0x00028AB0
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.rectVariable.IsNone && this.isRunning)
			{
				this.rct = new Rect(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
				this.rectVariable.Value = this.rct;
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.rectVariable.IsNone)
				{
					this.rct = new Rect(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
					this.rectVariable.Value = this.rct;
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x04000854 RID: 2132
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmRect rectVariable;

		// Token: 0x04000855 RID: 2133
		[RequiredField]
		public FsmAnimationCurve curveX;

		// Token: 0x04000856 RID: 2134
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to rectVariable.x.")]
		public AnimateFsmAction.Calculation calculationX;

		// Token: 0x04000857 RID: 2135
		[RequiredField]
		public FsmAnimationCurve curveY;

		// Token: 0x04000858 RID: 2136
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to rectVariable.y.")]
		public AnimateFsmAction.Calculation calculationY;

		// Token: 0x04000859 RID: 2137
		[RequiredField]
		public FsmAnimationCurve curveW;

		// Token: 0x0400085A RID: 2138
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to rectVariable.width.")]
		public AnimateFsmAction.Calculation calculationW;

		// Token: 0x0400085B RID: 2139
		[RequiredField]
		public FsmAnimationCurve curveH;

		// Token: 0x0400085C RID: 2140
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to rectVariable.height.")]
		public AnimateFsmAction.Calculation calculationH;

		// Token: 0x0400085D RID: 2141
		private bool finishInNextStep;

		// Token: 0x0400085E RID: 2142
		private Rect rct;
	}
}
