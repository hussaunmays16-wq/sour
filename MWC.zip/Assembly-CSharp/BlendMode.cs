﻿using System;

// Token: 0x0200045C RID: 1116
public enum BlendMode
{
	// Token: 0x04001873 RID: 6259
	Copy,
	// Token: 0x04001874 RID: 6260
	Multiply,
	// Token: 0x04001875 RID: 6261
	MultiplyDouble,
	// Token: 0x04001876 RID: 6262
	Add,
	// Token: 0x04001877 RID: 6263
	AddSmoooth,
	// Token: 0x04001878 RID: 6264
	Blend
}
