﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021E RID: 542
	[ActionCategory(ActionCategory.Character)]
	[Tooltip("Gets the Collision Flags from a Character Controller on a Game Object. Collision flags give you a broad overview of where the character collided with any other object.")]
	public class GetControllerCollisionFlags : FsmStateAction
	{
		// Token: 0x06000943 RID: 2371 RVA: 0x0003C71C File Offset: 0x0003A91C
		public override void Reset()
		{
			this.gameObject = null;
			this.isGrounded = null;
			this.none = null;
			this.sides = null;
			this.above = null;
			this.below = null;
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x0003C754 File Offset: 0x0003A954
		public override void OnUpdate()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.previousGo)
			{
				this.controller = ownerDefaultTarget.GetComponent<CharacterController>();
				this.previousGo = ownerDefaultTarget;
			}
			if (this.controller != null)
			{
				this.isGrounded.Value = this.controller.isGrounded;
				FsmBool fsmBool = this.none;
				CollisionFlags collisionFlags = this.controller.collisionFlags;
				fsmBool.Value = false;
				this.sides.Value = ((this.controller.collisionFlags & CollisionFlags.Sides) != CollisionFlags.None);
				this.above.Value = ((this.controller.collisionFlags & CollisionFlags.Above) != CollisionFlags.None);
				this.below.Value = ((this.controller.collisionFlags & CollisionFlags.Below) != CollisionFlags.None);
			}
		}

		// Token: 0x04000D0E RID: 3342
		[CheckForComponent(typeof(CharacterController))]
		[RequiredField]
		[Tooltip("The GameObject with a Character Controller component.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D0F RID: 3343
		[Tooltip("True if the Character Controller capsule is on the ground")]
		[UIHint(UIHint.Variable)]
		public FsmBool isGrounded;

		// Token: 0x04000D10 RID: 3344
		[Tooltip("True if no collisions in last move.")]
		[UIHint(UIHint.Variable)]
		public FsmBool none;

		// Token: 0x04000D11 RID: 3345
		[UIHint(UIHint.Variable)]
		[Tooltip("True if the Character Controller capsule was hit on the sides.")]
		public FsmBool sides;

		// Token: 0x04000D12 RID: 3346
		[UIHint(UIHint.Variable)]
		[Tooltip("True if the Character Controller capsule was hit from above.")]
		public FsmBool above;

		// Token: 0x04000D13 RID: 3347
		[Tooltip("True if the Character Controller capsule was hit from below.")]
		[UIHint(UIHint.Variable)]
		public FsmBool below;

		// Token: 0x04000D14 RID: 3348
		private GameObject previousGo;

		// Token: 0x04000D15 RID: 3349
		private CharacterController controller;
	}
}
