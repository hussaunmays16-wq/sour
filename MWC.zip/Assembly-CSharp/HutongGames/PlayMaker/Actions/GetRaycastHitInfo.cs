﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024E RID: 590
	[Tooltip("Gets info on the last Raycast and store in variables.")]
	[ActionCategory(ActionCategory.Physics)]
	public class GetRaycastHitInfo : FsmStateAction
	{
		// Token: 0x06000A0F RID: 2575 RVA: 0x0003EE90 File Offset: 0x0003D090
		public override void Reset()
		{
			this.gameObjectHit = null;
			this.point = null;
			this.normal = null;
			this.distance = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0003EEB8 File Offset: 0x0003D0B8
		private void StoreRaycastInfo()
		{
			if (base.Fsm.RaycastHitInfo.collider != null)
			{
				this.gameObjectHit.Value = base.Fsm.RaycastHitInfo.collider.gameObject;
				this.point.Value = base.Fsm.RaycastHitInfo.point;
				this.normal.Value = base.Fsm.RaycastHitInfo.normal;
				this.distance.Value = base.Fsm.RaycastHitInfo.distance;
			}
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0003EF64 File Offset: 0x0003D164
		public override void OnEnter()
		{
			this.StoreRaycastInfo();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0003EF80 File Offset: 0x0003D180
		public override void OnUpdate()
		{
			this.StoreRaycastInfo();
		}

		// Token: 0x04000DFD RID: 3581
		[UIHint(UIHint.Variable)]
		[Tooltip("Get the GameObject hit by the last Raycast and store it in a variable.")]
		public FsmGameObject gameObjectHit;

		// Token: 0x04000DFE RID: 3582
		[UIHint(UIHint.Variable)]
		[Title("Hit Point")]
		[Tooltip("Get the world position of the ray hit point and store it in a variable.")]
		public FsmVector3 point;

		// Token: 0x04000DFF RID: 3583
		[UIHint(UIHint.Variable)]
		[Tooltip("Get the normal at the hit point and store it in a variable.")]
		public FsmVector3 normal;

		// Token: 0x04000E00 RID: 3584
		[Tooltip("Get the distance along the ray to the hit point and store it in a variable.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat distance;

		// Token: 0x04000E01 RID: 3585
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
