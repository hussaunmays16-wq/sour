﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000230 RID: 560
	[Tooltip("Get the value of a Texture Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmTexture : FsmStateAction
	{
		// Token: 0x06000994 RID: 2452 RVA: 0x0003DA14 File Offset: 0x0003BC14
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.variableName = string.Empty;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x0003DA4C File Offset: 0x0003BC4C
		public override void OnEnter()
		{
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x0003DA68 File Offset: 0x0003BC68
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x0003DA70 File Offset: 0x0003BC70
		private void DoGetFsmVariable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null || this.storeValue == null)
			{
				return;
			}
			FsmTexture fsmTexture = this.fsm.FsmVariables.GetFsmTexture(this.variableName.Value);
			if (fsmTexture != null)
			{
				this.storeValue.Value = fsmTexture.Value;
			}
		}

		// Token: 0x04000D8B RID: 3467
		[RequiredField]
		[Tooltip("The GameObject that owns the FSM.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D8C RID: 3468
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000D8D RID: 3469
		[RequiredField]
		[UIHint(UIHint.FsmTexture)]
		public FsmString variableName;

		// Token: 0x04000D8E RID: 3470
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmTexture storeValue;

		// Token: 0x04000D8F RID: 3471
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D90 RID: 3472
		private GameObject goLastFrame;

		// Token: 0x04000D91 RID: 3473
		protected PlayMakerFSM fsm;
	}
}
