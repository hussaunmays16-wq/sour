﻿using System;
using SWS;
using UnityEngine;

// Token: 0x0200041A RID: 1050
public class CameraInputDemo : MonoBehaviour
{
	// Token: 0x060011BB RID: 4539 RVA: 0x00064248 File Offset: 0x00062448
	private void Start()
	{
		this.myMove = base.gameObject.GetComponent<splineMove>();
		this.myMove.StartMove();
		this.myMove.Pause();
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x00064274 File Offset: 0x00062474
	private void Update()
	{
		if (this.myMove.tween == null || !this.myMove.tween.isPaused)
		{
			return;
		}
		if (Input.GetKeyDown(KeyCode.UpArrow))
		{
			this.myMove.Resume();
		}
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x000642C4 File Offset: 0x000624C4
	private void OnGUI()
	{
		if (this.myMove.tween != null && !this.myMove.tween.isPaused)
		{
			return;
		}
		GUI.Box(new Rect((float)(Screen.width - 150), (float)(Screen.height / 2), 150f, 100f), string.Empty);
		Rect position = new Rect((float)(Screen.width - 130), (float)(Screen.height / 2 + 10), 110f, 90f);
		GUI.Label(position, this.infoText);
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x00064358 File Offset: 0x00062558
	public void ShowInformation(string text)
	{
		this.infoText = text;
	}

	// Token: 0x0400172C RID: 5932
	public string infoText = "Welcome to this customized input example";

	// Token: 0x0400172D RID: 5933
	private splineMove myMove;
}
