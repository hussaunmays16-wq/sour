﻿using System;
using UnityEngine;

// Token: 0x020000B6 RID: 182
public static class DTMonoHelper
{
	// Token: 0x06000339 RID: 825 RVA: 0x0001548C File Offset: 0x0001368C
	public static bool IsActive(GameObject go)
	{
		return go.activeInHierarchy;
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00015494 File Offset: 0x00013694
	public static void SetActive(GameObject go, bool isActive)
	{
		go.SetActive(isActive);
	}
}
