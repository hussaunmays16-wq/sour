﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003EB RID: 1003
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Set mesh vertex positions based on vector3 found in an arrayList")]
	public class ArrayListSetVertexPositions : ArrayListActions
	{
		// Token: 0x060010FB RID: 4347 RVA: 0x0005D8C0 File Offset: 0x0005BAC0
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.mesh = null;
			this.everyFrame = false;
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x0005D8E0 File Offset: 0x0005BAE0
		public override void OnEnter()
		{
			GameObject value = this.mesh.Value;
			if (value == null)
			{
				base.Finish();
				return;
			}
			MeshFilter component = value.GetComponent<MeshFilter>();
			if (component == null)
			{
				base.Finish();
				return;
			}
			this._mesh = component.mesh;
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SetVertexPositions();
			}
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060010FD RID: 4349 RVA: 0x0005D970 File Offset: 0x0005BB70
		public override void OnUpdate()
		{
			this.SetVertexPositions();
		}

		// Token: 0x060010FE RID: 4350 RVA: 0x0005D978 File Offset: 0x0005BB78
		public void SetVertexPositions()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._vertices = new Vector3[this.proxy.arrayList.Count];
			int num = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				Vector3 vector = (Vector3)obj;
				this._vertices[num] = vector;
				num++;
			}
			this._mesh.vertices = this._vertices;
		}

		// Token: 0x04001629 RID: 5673
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400162A RID: 5674
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400162B RID: 5675
		[ActionSection("Target")]
		[CheckForComponent(typeof(MeshFilter))]
		[Tooltip("The GameObject to set the mesh vertex positions to")]
		public FsmGameObject mesh;

		// Token: 0x0400162C RID: 5676
		public bool everyFrame;

		// Token: 0x0400162D RID: 5677
		private Mesh _mesh;

		// Token: 0x0400162E RID: 5678
		private Vector3[] _vertices;
	}
}
