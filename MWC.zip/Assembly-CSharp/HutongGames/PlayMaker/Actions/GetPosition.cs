﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000249 RID: 585
	[Tooltip("Gets the Position of a Game Object and stores it in a Vector3 Variable or each Axis in a Float Variable")]
	[ActionCategory(ActionCategory.Transform)]
	public class GetPosition : FsmStateAction
	{
		// Token: 0x060009FA RID: 2554 RVA: 0x0003EB9C File Offset: 0x0003CD9C
		public override void Reset()
		{
			this.gameObject = null;
			this.vector = null;
			this.x = null;
			this.y = null;
			this.z = null;
			this.space = Space.World;
			this.everyFrame = false;
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0003EBD0 File Offset: 0x0003CDD0
		public override void OnEnter()
		{
			this.DoGetPosition();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0003EBEC File Offset: 0x0003CDEC
		public override void OnUpdate()
		{
			this.DoGetPosition();
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0003EBF4 File Offset: 0x0003CDF4
		private void DoGetPosition()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			Vector3 value = (this.space != Space.World) ? ownerDefaultTarget.transform.localPosition : ownerDefaultTarget.transform.position;
			this.vector.Value = value;
			this.x.Value = value.x;
			this.y.Value = value.y;
			this.z.Value = value.z;
		}

		// Token: 0x04000DEE RID: 3566
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DEF RID: 3567
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector;

		// Token: 0x04000DF0 RID: 3568
		[UIHint(UIHint.Variable)]
		public FsmFloat x;

		// Token: 0x04000DF1 RID: 3569
		[UIHint(UIHint.Variable)]
		public FsmFloat y;

		// Token: 0x04000DF2 RID: 3570
		[UIHint(UIHint.Variable)]
		public FsmFloat z;

		// Token: 0x04000DF3 RID: 3571
		public Space space;

		// Token: 0x04000DF4 RID: 3572
		public bool everyFrame;
	}
}
