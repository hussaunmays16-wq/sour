﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200025C RID: 604
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets the number of Game Objects in the scene with the specified Tag.")]
	public class GetTagCount : FsmStateAction
	{
		// Token: 0x06000A4F RID: 2639 RVA: 0x0003F814 File Offset: 0x0003DA14
		public override void Reset()
		{
			this.tag = "Untagged";
			this.storeResult = null;
		}

		// Token: 0x06000A50 RID: 2640 RVA: 0x0003F830 File Offset: 0x0003DA30
		public override void OnEnter()
		{
			GameObject[] array = GameObject.FindGameObjectsWithTag(this.tag.Value);
			if (this.storeResult != null)
			{
				this.storeResult.Value = ((array == null) ? 0 : array.Length);
			}
			base.Finish();
		}

		// Token: 0x04000E34 RID: 3636
		[UIHint(UIHint.Tag)]
		public FsmString tag;

		// Token: 0x04000E35 RID: 3637
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt storeResult;
	}
}
