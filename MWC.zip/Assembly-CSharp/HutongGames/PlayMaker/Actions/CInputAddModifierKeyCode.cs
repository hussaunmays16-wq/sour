﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049A RID: 1178
	[ActionCategory("cInput")]
	[Tooltip("Adds a modifier key to cInput keys.")]
	public class CInputAddModifierKeyCode : FsmStateAction
	{
		// Token: 0x0600142C RID: 5164 RVA: 0x000886C0 File Offset: 0x000868C0
		public override void Reset()
		{
			this.keyName = KeyCode.None;
		}

		// Token: 0x0600142D RID: 5165 RVA: 0x000886CC File Offset: 0x000868CC
		public override void OnEnter()
		{
			cInput.AddModifier(this.keyName);
			base.Finish();
		}

		// Token: 0x04001C9A RID: 7322
		[Tooltip("The modifier key to add.")]
		public KeyCode keyName;
	}
}
