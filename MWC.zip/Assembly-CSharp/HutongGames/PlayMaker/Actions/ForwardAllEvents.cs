﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DC RID: 476
	[Tooltip("Forwards all event recieved by this FSM to another target. Optionally specify a list of events to ignore.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class ForwardAllEvents : FsmStateAction
	{
		// Token: 0x0600085D RID: 2141 RVA: 0x000390B8 File Offset: 0x000372B8
		public override void Reset()
		{
			this.forwardTo = new FsmEventTarget
			{
				target = FsmEventTarget.EventTarget.FSMComponent
			};
			this.exceptThese = new FsmEvent[]
			{
				FsmEvent.Finished
			};
			this.eatEvents = true;
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x000390F4 File Offset: 0x000372F4
		public override bool Event(FsmEvent fsmEvent)
		{
			if (this.exceptThese != null)
			{
				foreach (FsmEvent fsmEvent2 in this.exceptThese)
				{
					if (fsmEvent2 == fsmEvent)
					{
						return false;
					}
				}
			}
			base.Fsm.Event(this.forwardTo, fsmEvent);
			return this.eatEvents;
		}

		// Token: 0x04000C03 RID: 3075
		[Tooltip("Forward to this target.")]
		public FsmEventTarget forwardTo;

		// Token: 0x04000C04 RID: 3076
		[Tooltip("Don't forward these events.")]
		public FsmEvent[] exceptThese;

		// Token: 0x04000C05 RID: 3077
		[Tooltip("Should this action eat the events or pass them on.")]
		public bool eatEvents;
	}
}
