﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049B RID: 1179
	[Tooltip("Adds a modifier key to cInput keys.")]
	[ActionCategory("cInput")]
	public class CInputAddModifierString : FsmStateAction
	{
		// Token: 0x0600142F RID: 5167 RVA: 0x000886E8 File Offset: 0x000868E8
		public override void Reset()
		{
			this.keyName = null;
		}

		// Token: 0x06001430 RID: 5168 RVA: 0x000886F4 File Offset: 0x000868F4
		public override void OnEnter()
		{
			cInput.AddModifier(this.keyName.Value);
			base.Finish();
		}

		// Token: 0x04001C9B RID: 7323
		[Tooltip("The modifier key to add.")]
		public FsmString keyName;
	}
}
