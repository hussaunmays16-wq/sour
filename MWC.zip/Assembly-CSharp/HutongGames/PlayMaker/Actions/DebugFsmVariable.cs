﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000175 RID: 373
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Print the value of an FSM Variable in the PlayMaker Log Window.")]
	public class DebugFsmVariable : FsmStateAction
	{
		// Token: 0x060006E5 RID: 1765 RVA: 0x00031618 File Offset: 0x0002F818
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.fsmVar = null;
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00031628 File Offset: 0x0002F828
		public override void OnEnter()
		{
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, this.fsmVar.DebugString());
			base.Finish();
		}

		// Token: 0x040009DF RID: 2527
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009E0 RID: 2528
		[Tooltip("Variable to print to the PlayMaker log window.")]
		[HideTypeFilter]
		[UIHint(UIHint.Variable)]
		public FsmVar fsmVar;
	}
}
