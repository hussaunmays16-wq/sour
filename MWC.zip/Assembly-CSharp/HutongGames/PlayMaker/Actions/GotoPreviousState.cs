﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000268 RID: 616
	[Tooltip("Immediately return to the previously active state.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GotoPreviousState : FsmStateAction
	{
		// Token: 0x06000A82 RID: 2690 RVA: 0x000401F4 File Offset: 0x0003E3F4
		public override void Reset()
		{
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x000401F8 File Offset: 0x0003E3F8
		public override void OnEnter()
		{
			if (base.Fsm.PreviousActiveState != null)
			{
				this.Log("Goto Previous State: " + base.Fsm.PreviousActiveState.Name);
				base.Fsm.GotoPreviousState();
			}
			base.Finish();
		}
	}
}
