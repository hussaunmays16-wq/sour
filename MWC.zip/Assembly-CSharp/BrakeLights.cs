﻿using System;
using UnityEngine;

// Token: 0x02000472 RID: 1138
public class BrakeLights : MonoBehaviour
{
	// Token: 0x0600131F RID: 4895 RVA: 0x0006C98C File Offset: 0x0006AB8C
	private void Awake()
	{
		this.carController = base.transform.GetComponent<CarController>();
		if (this.brakeLights)
		{
			this.startValue = this.brakeLights.GetFloat("_Intensity");
		}
	}

	// Token: 0x06001320 RID: 4896 RVA: 0x0006C9D0 File Offset: 0x0006ABD0
	private void FixedUpdate()
	{
		if (this.brakeLights)
		{
			if (this.carController.brakeKey)
			{
				if (this.intensityValue < this.startValue + 1f)
				{
					this.intensityValue += Time.deltaTime / 0.1f;
					this.brakeLights.SetFloat("_Intensity", this.intensityValue);
				}
			}
			else if (this.intensityValue > this.startValue)
			{
				this.intensityValue -= Time.deltaTime / 0.1f;
				this.brakeLights.SetFloat("_Intensity", this.intensityValue);
			}
		}
	}

	// Token: 0x04001905 RID: 6405
	[HideInInspector]
	public CarController carController;

	// Token: 0x04001906 RID: 6406
	public Material brakeLights;

	// Token: 0x04001907 RID: 6407
	private float startValue;

	// Token: 0x04001908 RID: 6408
	private float intensityValue;
}
