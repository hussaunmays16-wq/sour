﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DD RID: 989
	[ActionCategory("Easy Save 2")]
	[Tooltip("Saves a PlayMaker Array List Proxy component")]
	public class ArrayListEasySave : ArrayListActions
	{
		// Token: 0x060010BD RID: 4285 RVA: 0x0005B748 File Offset: 0x00059948
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x0005B788 File Offset: 0x00059988
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SaveArrayList();
			}
			base.Finish();
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x0005B7C8 File Offset: 0x000599C8
		public void SaveArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string value = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(value))
			{
				value = string.Concat(new object[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference
				});
			}
			List<string> list = new List<string>();
			foreach (object item in this.proxy.arrayList)
			{
				list.Add(PlayMakerUtils.ParseValueToString(item));
			}
			ES2.Save<string>(list, this.saveFile.Value + "?tag=" + this.uniqueTag);
			this.Log(string.Concat(new object[]
			{
				"Saved to ",
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			base.Finish();
		}

		// Token: 0x040015BE RID: 5566
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015BF RID: 5567
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015C0 RID: 5568
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name.")]
		[ActionSection("Easy Save Set Up")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015C1 RID: 5569
		[Tooltip("The name of the file that we'll create to store our data.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
