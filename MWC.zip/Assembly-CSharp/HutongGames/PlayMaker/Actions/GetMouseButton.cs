﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000240 RID: 576
	[Tooltip("Gets the pressed state of the specified Mouse Button and stores it in a Bool Variable. See Unity Input Manager doc.")]
	[ActionCategory(ActionCategory.Input)]
	public class GetMouseButton : FsmStateAction
	{
		// Token: 0x060009D8 RID: 2520 RVA: 0x0003E740 File Offset: 0x0003C940
		public override void Reset()
		{
			this.button = MouseButton.Left;
			this.storeResult = null;
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x0003E750 File Offset: 0x0003C950
		public override void OnUpdate()
		{
			this.storeResult.Value = Input.GetMouseButton((int)this.button);
		}

		// Token: 0x04000DD6 RID: 3542
		[RequiredField]
		public MouseButton button;

		// Token: 0x04000DD7 RID: 3543
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmBool storeResult;
	}
}
