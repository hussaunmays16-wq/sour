﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001EE RID: 494
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Begins a vertical control group. The group must be closed with GUILayoutEndVertical action.")]
	public class GUILayoutBeginVertical : GUILayoutAction
	{
		// Token: 0x06000898 RID: 2200 RVA: 0x0003A17C File Offset: 0x0003837C
		public override void Reset()
		{
			base.Reset();
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x0003A1BC File Offset: 0x000383BC
		public override void OnGUI()
		{
			GUILayout.BeginVertical(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
		}

		// Token: 0x04000C58 RID: 3160
		public FsmTexture image;

		// Token: 0x04000C59 RID: 3161
		public FsmString text;

		// Token: 0x04000C5A RID: 3162
		public FsmString tooltip;

		// Token: 0x04000C5B RID: 3163
		public FsmString style;
	}
}
