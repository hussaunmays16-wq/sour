﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020B RID: 523
	[Tooltip("Tests if a Game Object has a tag.")]
	[ActionCategory(ActionCategory.Logic)]
	public class GameObjectCompareTag : FsmStateAction
	{
		// Token: 0x060008F4 RID: 2292 RVA: 0x0003B6D8 File Offset: 0x000398D8
		public override void Reset()
		{
			this.gameObject = null;
			this.tag = "Untagged";
			this.trueEvent = null;
			this.falseEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0003B710 File Offset: 0x00039910
		public override void OnEnter()
		{
			this.DoCompareTag();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0003B72C File Offset: 0x0003992C
		public override void OnUpdate()
		{
			this.DoCompareTag();
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x0003B734 File Offset: 0x00039934
		private void DoCompareTag()
		{
			bool flag = false;
			if (this.gameObject.Value != null)
			{
				flag = this.gameObject.Value.CompareTag(this.tag.Value);
			}
			this.storeResult.Value = flag;
			base.Fsm.Event((!flag) ? this.falseEvent : this.trueEvent);
		}

		// Token: 0x04000CBA RID: 3258
		[RequiredField]
		[Tooltip("The GameObject to test.")]
		public FsmGameObject gameObject;

		// Token: 0x04000CBB RID: 3259
		[UIHint(UIHint.Tag)]
		[Tooltip("The Tag to check for.")]
		[RequiredField]
		public FsmString tag;

		// Token: 0x04000CBC RID: 3260
		[Tooltip("Event to send if the GameObject has the Tag.")]
		public FsmEvent trueEvent;

		// Token: 0x04000CBD RID: 3261
		[Tooltip("Event to send if the GameObject does not have the Tag.")]
		public FsmEvent falseEvent;

		// Token: 0x04000CBE RID: 3262
		[Tooltip("Store the result in a Bool variable.")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000CBF RID: 3263
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
