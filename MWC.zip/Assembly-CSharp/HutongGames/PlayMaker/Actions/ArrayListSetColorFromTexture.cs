﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000400 RID: 1024
	[HelpUrl("http://hutonggames.com/playmakerforum/index.php?topic=11929.0")]
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Create color palette from texture for Array. Texture has to be read/write enabled.")]
	public class ArrayListSetColorFromTexture : ArrayListActions
	{
		// Token: 0x06001142 RID: 4418 RVA: 0x0005F5C4 File Offset: 0x0005D7C4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.failureEvent = null;
			this.doneEvent = null;
			this.texture = null;
			this.disableAlpha = false;
		}

		// Token: 0x06001143 RID: 4419 RVA: 0x0005F5F8 File Offset: 0x0005D7F8
		public override void OnEnter()
		{
			bool flag = false;
			if (this.texture.IsNone)
			{
				Debug.LogWarning("<color=#6B8E23ff>No texture. Please review!</color>", base.Owner);
				flag = true;
			}
			this.targetmaskedTexture = null;
			this.targetmaskedTexture = (Texture2D)this.texture.Value;
			try
			{
				this.targetmaskedTexture.GetPixel(0, 0);
			}
			catch (UnityException)
			{
				Debug.LogWarning("<color=#6B8E23ff>Please enable read/write on texture  </color>[" + this.texture.Value.name + "]", base.Owner);
				flag = true;
			}
			if (flag)
			{
				base.Fsm.Event(this.failureEvent);
				base.Finish();
			}
			else if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArraySetColor();
			}
			base.Fsm.Event(this.doneEvent);
			base.Finish();
		}

		// Token: 0x06001144 RID: 4420 RVA: 0x0005F710 File Offset: 0x0005D910
		public void DoArraySetColor()
		{
			if (!base.isProxyValid())
			{
				base.Fsm.Event(this.failureEvent);
				return;
			}
			this.pix = this.targetmaskedTexture.GetPixels(0);
			if (this.disableAlpha.Value)
			{
				for (int i = 0; i < this.pix.Length; i++)
				{
					this.pix[i].a = 1f;
				}
			}
			this.finalPix = new List<Color>();
			this.finalPix.Add(this.pix[0]);
			for (int j = 0; j < this.pix.Length; j++)
			{
				if (!this.disableAlpha.Value)
				{
					this.colorAtSource = ArrayListSetColorFromTexture.ClearRGBIfNoAlpha(this.pix[j]);
				}
				else
				{
					this.colorAtSource = this.pix[j];
				}
				if (!this.ContainsColor(this.colorAtSource))
				{
					this.finalPix.Add(this.colorAtSource);
				}
			}
			this.proxy.arrayList.Clear();
			for (int k = 0; k < this.finalPix.Count; k++)
			{
				this.proxy.arrayList.Add(this.finalPix[k]);
			}
			this.finalPix = new List<Color>();
			this.pix = new Color[0];
			base.Fsm.Event(this.doneEvent);
		}

		// Token: 0x06001145 RID: 4421 RVA: 0x0005F8AC File Offset: 0x0005DAAC
		private static Color ClearRGBIfNoAlpha(Color colorToClear)
		{
			Color result = colorToClear;
			if (Mathf.Approximately(result.a, 0f))
			{
				result = Color.clear;
			}
			return result;
		}

		// Token: 0x06001146 RID: 4422 RVA: 0x0005F8D8 File Offset: 0x0005DAD8
		public bool ContainsColor(Color colorToFind)
		{
			return this.IndexOf(colorToFind) >= 0;
		}

		// Token: 0x06001147 RID: 4423 RVA: 0x0005F8E8 File Offset: 0x0005DAE8
		public int IndexOf(Color colorToFind)
		{
			int result = -1;
			for (int i = 0; i < this.finalPix.Count; i++)
			{
				bool flag = Mathf.Approximately(colorToFind.a, 0f);
				bool flag2 = Mathf.Approximately(this.finalPix[i].a, 0f);
				if ((flag && flag2) || this.finalPix[i] == colorToFind)
				{
					result = i;
					break;
				}
			}
			return result;
		}

		// Token: 0x040016A4 RID: 5796
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040016A5 RID: 5797
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040016A6 RID: 5798
		[ActionSection("Option")]
		[HasFloatSlider(0f, 1f)]
		[Tooltip("set alpha")]
		public FsmBool disableAlpha;

		// Token: 0x040016A7 RID: 5799
		[ActionSection("Input")]
		public FsmTexture texture;

		// Token: 0x040016A8 RID: 5800
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Event")]
		public FsmEvent doneEvent;

		// Token: 0x040016A9 RID: 5801
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event if error")]
		public FsmEvent failureEvent;

		// Token: 0x040016AA RID: 5802
		private Color colorSet;

		// Token: 0x040016AB RID: 5803
		private Color colorTemp;

		// Token: 0x040016AC RID: 5804
		private Color[] pix;

		// Token: 0x040016AD RID: 5805
		private List<Color> finalPix;

		// Token: 0x040016AE RID: 5806
		private Texture2D targetmaskedTexture;

		// Token: 0x040016AF RID: 5807
		private Color colorAtSource;
	}
}
