﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B0 RID: 944
	[Tooltip("Set an item at a specified index to a PlayMaker array List component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListSet : ArrayListActions
	{
		// Token: 0x06000FF8 RID: 4088 RVA: 0x00057B00 File Offset: 0x00055D00
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.variable = null;
			this.everyFrame = false;
		}

		// Token: 0x06000FF9 RID: 4089 RVA: 0x00057B20 File Offset: 0x00055D20
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SetToArrayList();
			}
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x00057B6C File Offset: 0x00055D6C
		public override void OnUpdate()
		{
			this.SetToArrayList();
		}

		// Token: 0x06000FFB RID: 4091 RVA: 0x00057B74 File Offset: 0x00055D74
		public void SetToArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.Set(this.atIndex.Value, PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable), this.variable.Type.ToString());
		}

		// Token: 0x040014C5 RID: 5317
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014C6 RID: 5318
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040014C7 RID: 5319
		[UIHint(UIHint.FsmString)]
		[Tooltip("The index of the Data in the ArrayList")]
		public FsmInt atIndex;

		// Token: 0x040014C8 RID: 5320
		public bool everyFrame;

		// Token: 0x040014C9 RID: 5321
		[ActionSection("Data")]
		[Tooltip("The variable to add.")]
		public FsmVar variable;
	}
}
