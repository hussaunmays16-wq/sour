﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000172 RID: 370
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Draw gizmos shape")]
	public class DebugDrawShape : FsmStateAction
	{
		// Token: 0x060006DF RID: 1759 RVA: 0x00031464 File Offset: 0x0002F664
		public override void Reset()
		{
			this.gameObject = null;
			this.shape = DebugDrawShape.ShapeType.Sphere;
			this.color = Color.grey;
			this.radius = 1f;
			this.size = new Vector3(1f, 1f, 1f);
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x000314C0 File Offset: 0x0002F6C0
		public override void OnDrawGizmos()
		{
			Transform transform = base.Fsm.GetOwnerDefaultTarget(this.gameObject).transform;
			if (transform == null)
			{
				return;
			}
			Gizmos.color = this.color.Value;
			switch (this.shape)
			{
			case DebugDrawShape.ShapeType.Sphere:
				Gizmos.DrawSphere(transform.position, this.radius.Value);
				break;
			case DebugDrawShape.ShapeType.Cube:
				Gizmos.DrawCube(transform.position, this.size.Value);
				break;
			case DebugDrawShape.ShapeType.WireSphere:
				Gizmos.DrawWireSphere(transform.position, this.radius.Value);
				break;
			case DebugDrawShape.ShapeType.WireCube:
				Gizmos.DrawWireCube(transform.position, this.size.Value);
				break;
			}
		}

		// Token: 0x040009D3 RID: 2515
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040009D4 RID: 2516
		public DebugDrawShape.ShapeType shape;

		// Token: 0x040009D5 RID: 2517
		public FsmColor color;

		// Token: 0x040009D6 RID: 2518
		[Tooltip("Use this for sphere gizmos")]
		public FsmFloat radius;

		// Token: 0x040009D7 RID: 2519
		[Tooltip("Use this for cube gizmos")]
		public FsmVector3 size;

		// Token: 0x02000173 RID: 371
		public enum ShapeType
		{
			// Token: 0x040009D9 RID: 2521
			Sphere,
			// Token: 0x040009DA RID: 2522
			Cube,
			// Token: 0x040009DB RID: 2523
			WireSphere,
			// Token: 0x040009DC RID: 2524
			WireCube
		}
	}
}
