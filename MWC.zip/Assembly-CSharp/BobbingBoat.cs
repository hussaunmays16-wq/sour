﻿using System;
using UnityEngine;

// Token: 0x020000C6 RID: 198
public class BobbingBoat : MonoBehaviour
{
	// Token: 0x060003C1 RID: 961 RVA: 0x00018908 File Offset: 0x00016B08
	private void Update()
	{
		Vector3 position = base.transform.position;
		position.y = Mathf.Cos(Time.time) * 0.06f - 0.15f;
		base.transform.position = position;
		Vector3 eulerAngles = base.transform.eulerAngles;
		eulerAngles.x = Mathf.Sin(Time.time) * 5f;
		eulerAngles.z = Mathf.Sin(Time.time * 0.8f) * 5f;
		base.transform.eulerAngles = eulerAngles;
	}
}
