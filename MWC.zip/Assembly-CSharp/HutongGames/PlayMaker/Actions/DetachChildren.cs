﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200017E RID: 382
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Unparents all children from the Game Object.")]
	public class DetachChildren : FsmStateAction
	{
		// Token: 0x06000702 RID: 1794 RVA: 0x00031A6C File Offset: 0x0002FC6C
		public override void Reset()
		{
			this.gameObject = null;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00031A78 File Offset: 0x0002FC78
		public override void OnEnter()
		{
			DetachChildren.DoDetachChildren(base.Fsm.GetOwnerDefaultTarget(this.gameObject));
			base.Finish();
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00031A98 File Offset: 0x0002FC98
		private static void DoDetachChildren(GameObject go)
		{
			if (go != null)
			{
				go.transform.DetachChildren();
			}
		}

		// Token: 0x040009F2 RID: 2546
		[RequiredField]
		[Tooltip("GameObject to unparent children from.")]
		public FsmOwnerDefault gameObject;
	}
}
