﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000141 RID: 321
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when the user hits any Key or Mouse Button.")]
	public class AnyKey : FsmStateAction
	{
		// Token: 0x06000603 RID: 1539 RVA: 0x0002E464 File Offset: 0x0002C664
		public override void Reset()
		{
			this.sendEvent = null;
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0002E470 File Offset: 0x0002C670
		public override void OnUpdate()
		{
			if (Input.anyKeyDown)
			{
				base.Fsm.Event(this.sendEvent);
			}
		}

		// Token: 0x040008FC RID: 2300
		[Tooltip("Event to send when any Key or Mouse Button is pressed.")]
		[RequiredField]
		public FsmEvent sendEvent;
	}
}
