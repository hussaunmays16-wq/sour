﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200001A RID: 26
	[Tooltip("Action removes a character from last position.")]
	[ActionCategory("♥ Caligula ♥")]
	public class BuildStringFix : FsmStateAction
	{
		// Token: 0x06000055 RID: 85 RVA: 0x000043DC File Offset: 0x000025DC
		public override void Reset()
		{
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000043E0 File Offset: 0x000025E0
		public override void OnEnter()
		{
			if (this.variable.Value.Length > 0)
			{
				int length = this.variable.Value.Length;
				this.variable.Value = this.variable.Value.Remove(length - 1);
				base.Finish();
			}
			else
			{
				this.LogWarning("Variable is empty!");
			}
			base.Finish();
		}

		// Token: 0x04000096 RID: 150
		[RequiredField]
		[Tooltip("A variable to be changed.")]
		public FsmString variable;
	}
}
