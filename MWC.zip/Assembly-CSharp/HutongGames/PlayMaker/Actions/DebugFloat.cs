﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000174 RID: 372
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Logs the value of a Float Variable in the PlayMaker Log Window.")]
	public class DebugFloat : FsmStateAction
	{
		// Token: 0x060006E2 RID: 1762 RVA: 0x0003159C File Offset: 0x0002F79C
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.floatVariable = null;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x000315AC File Offset: 0x0002F7AC
		public override void OnEnter()
		{
			string text = "None";
			if (!this.floatVariable.IsNone)
			{
				text = this.floatVariable.Name + ": " + this.floatVariable.Value;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009DD RID: 2525
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009DE RID: 2526
		[Tooltip("Prints the value of a Float variable in the PlayMaker log window.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;
	}
}
