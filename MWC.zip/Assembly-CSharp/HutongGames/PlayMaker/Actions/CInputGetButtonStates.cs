﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A8 RID: 1192
	[ActionCategory("cInput")]
	[Tooltip("Gets cInput button states to store them.")]
	public class CInputGetButtonStates : FsmStateAction
	{
		// Token: 0x06001453 RID: 5203 RVA: 0x00088BE8 File Offset: 0x00086DE8
		public override void Reset()
		{
			this.buttonName = null;
			this.storeButtonDown = null;
			this.storeButtonUp = null;
			this.storeButtonPressed = null;
			this.everyFrame = null;
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x00088C10 File Offset: 0x00086E10
		public override void OnLateUpdate()
		{
			this.storeButtonDown.Value = cInput.GetKeyDown(this.buttonName.Value);
			this.storeButtonUp.Value = cInput.GetButtonUp(this.buttonName.Value);
			this.storeButtonPressed.Value = cInput.GetButton(this.buttonName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CBE RID: 7358
		[Tooltip("The name of the button.")]
		[RequiredField]
		public FsmString buttonName;

		// Token: 0x04001CBF RID: 7359
		[Tooltip("store if the button is down.")]
		public FsmBool storeButtonDown;

		// Token: 0x04001CC0 RID: 7360
		[Tooltip("store if the button is up.")]
		public FsmBool storeButtonUp;

		// Token: 0x04001CC1 RID: 7361
		[Tooltip("store if the button is pressed.")]
		public FsmBool storeButtonPressed;

		// Token: 0x04001CC2 RID: 7362
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
