﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000225 RID: 549
	[Tooltip("Get the value of a Bool Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmBool : FsmStateAction
	{
		// Token: 0x0600095D RID: 2397 RVA: 0x0003CED0 File Offset: 0x0003B0D0
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x0003CEF0 File Offset: 0x0003B0F0
		public override void OnEnter()
		{
			this.DoGetFsmBool();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x0003CF0C File Offset: 0x0003B10C
		public override void OnUpdate()
		{
			this.DoGetFsmBool();
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x0003CF14 File Offset: 0x0003B114
		private void DoGetFsmBool()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmBool fsmBool = this.fsm.FsmVariables.GetFsmBool(this.variableName.Value);
			if (fsmBool == null)
			{
				return;
			}
			this.storeValue.Value = fsmBool.Value;
		}

		// Token: 0x04000D3F RID: 3391
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D40 RID: 3392
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D41 RID: 3393
		[UIHint(UIHint.FsmBool)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D42 RID: 3394
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmBool storeValue;

		// Token: 0x04000D43 RID: 3395
		public bool everyFrame;

		// Token: 0x04000D44 RID: 3396
		private GameObject goLastFrame;

		// Token: 0x04000D45 RID: 3397
		private PlayMakerFSM fsm;
	}
}
