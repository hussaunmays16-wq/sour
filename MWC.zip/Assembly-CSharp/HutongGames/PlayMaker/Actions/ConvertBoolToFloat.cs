﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000163 RID: 355
	[ActionCategory(ActionCategory.Convert)]
	[Tooltip("Converts a Bool value to a Float value.")]
	public class ConvertBoolToFloat : FsmStateAction
	{
		// Token: 0x0600069D RID: 1693 RVA: 0x00030A08 File Offset: 0x0002EC08
		public override void Reset()
		{
			this.boolVariable = null;
			this.floatVariable = null;
			this.falseValue = 0f;
			this.trueValue = 1f;
			this.everyFrame = false;
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x00030A40 File Offset: 0x0002EC40
		public override void OnEnter()
		{
			this.DoConvertBoolToFloat();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00030A5C File Offset: 0x0002EC5C
		public override void OnUpdate()
		{
			this.DoConvertBoolToFloat();
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00030A64 File Offset: 0x0002EC64
		private void DoConvertBoolToFloat()
		{
			this.floatVariable.Value = ((!this.boolVariable.Value) ? this.falseValue.Value : this.trueValue.Value);
		}

		// Token: 0x04000999 RID: 2457
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variable to test.")]
		public FsmBool boolVariable;

		// Token: 0x0400099A RID: 2458
		[UIHint(UIHint.Variable)]
		[Tooltip("The Float variable to set based on the Bool variable value.")]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x0400099B RID: 2459
		[Tooltip("Float value if Bool variable is false.")]
		public FsmFloat falseValue;

		// Token: 0x0400099C RID: 2460
		[Tooltip("Float value if Bool variable is true.")]
		public FsmFloat trueValue;

		// Token: 0x0400099D RID: 2461
		[Tooltip("Repeat every frame. Useful if the Bool variable is changing.")]
		public bool everyFrame;
	}
}
