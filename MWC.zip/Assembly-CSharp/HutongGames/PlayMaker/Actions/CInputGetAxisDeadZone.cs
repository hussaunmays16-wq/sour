﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A3 RID: 1187
	[Tooltip("Gets the axis deadzone and puts it into a fsm variable.")]
	[ActionCategory("cInput")]
	public class CInputGetAxisDeadZone : FsmStateAction
	{
		// Token: 0x06001444 RID: 5188 RVA: 0x00088998 File Offset: 0x00086B98
		public override void Reset()
		{
			this.axisName = null;
			this.storeAxisDeadzone = null;
			this.everyFrame = null;
		}

		// Token: 0x06001445 RID: 5189 RVA: 0x000889B0 File Offset: 0x00086BB0
		public override void OnUpdate()
		{
			this.storeAxisDeadzone.Value = cInput.GetAxisDeadzone(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CAD RID: 7341
		[RequiredField]
		[Tooltip("The axis name.")]
		public FsmString axisName;

		// Token: 0x04001CAE RID: 7342
		[Tooltip("Store the result")]
		public FsmFloat storeAxisDeadzone;

		// Token: 0x04001CAF RID: 7343
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
