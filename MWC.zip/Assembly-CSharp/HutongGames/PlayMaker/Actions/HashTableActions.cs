﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003F5 RID: 1013
	public abstract class HashTableActions : CollectionsActions
	{
		// Token: 0x06001115 RID: 4373 RVA: 0x0005E2F8 File Offset: 0x0005C4F8
		protected bool SetUpHashTableProxyPointer(GameObject aProxyGO, string nameReference)
		{
			Debug.Log(aProxyGO);
			if (aProxyGO == null)
			{
				return false;
			}
			this.proxy = base.GetHashTableProxyPointer(aProxyGO, nameReference, false);
			return this.proxy != null;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x0005E334 File Offset: 0x0005C534
		protected bool SetUpHashTableProxyPointer(PlayMakerHashTableProxy aProxy, string nameReference)
		{
			if (aProxy == null)
			{
				return false;
			}
			this.proxy = base.GetHashTableProxyPointer(aProxy.gameObject, nameReference, false);
			return this.proxy != null;
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x0005E370 File Offset: 0x0005C570
		protected bool isProxyValid()
		{
			if (this.proxy == null)
			{
				Debug.LogError("HashTable proxy is null");
				return false;
			}
			if (this.proxy.hashTable == null)
			{
				Debug.LogError("HashTable undefined");
				return false;
			}
			return true;
		}

		// Token: 0x0400165A RID: 5722
		internal PlayMakerHashTableProxy proxy;
	}
}
