﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000142 RID: 322
	[Tooltip("Quits the player application.")]
	[ActionCategory(ActionCategory.Application)]
	public class ApplicationQuit : FsmStateAction
	{
		// Token: 0x06000606 RID: 1542 RVA: 0x0002E498 File Offset: 0x0002C698
		public override void Reset()
		{
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x0002E49C File Offset: 0x0002C69C
		public override void OnEnter()
		{
			Application.Quit();
			base.Finish();
		}
	}
}
