﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D6 RID: 470
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Performs math operations on 2 Floats: Add, Subtract, Multiply, Divide, Min, Max.")]
	public class FloatOperator : FsmStateAction
	{
		// Token: 0x06000843 RID: 2115 RVA: 0x00038C54 File Offset: 0x00036E54
		public override void Reset()
		{
			this.float1 = null;
			this.float2 = null;
			this.operation = FloatOperator.Operation.Add;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00038C7C File Offset: 0x00036E7C
		public override void OnEnter()
		{
			this.DoFloatOperator();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00038C98 File Offset: 0x00036E98
		public override void OnUpdate()
		{
			this.DoFloatOperator();
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00038CA0 File Offset: 0x00036EA0
		private void DoFloatOperator()
		{
			float value = this.float1.Value;
			float value2 = this.float2.Value;
			switch (this.operation)
			{
			case FloatOperator.Operation.Add:
				this.storeResult.Value = value + value2;
				break;
			case FloatOperator.Operation.Subtract:
				this.storeResult.Value = value - value2;
				break;
			case FloatOperator.Operation.Multiply:
				this.storeResult.Value = value * value2;
				break;
			case FloatOperator.Operation.Divide:
				this.storeResult.Value = value / value2;
				break;
			case FloatOperator.Operation.Min:
				this.storeResult.Value = Mathf.Min(value, value2);
				break;
			case FloatOperator.Operation.Max:
				this.storeResult.Value = Mathf.Max(value, value2);
				break;
			}
		}

		// Token: 0x04000BE6 RID: 3046
		[Tooltip("The first float.")]
		[RequiredField]
		public FsmFloat float1;

		// Token: 0x04000BE7 RID: 3047
		[Tooltip("The second float.")]
		[RequiredField]
		public FsmFloat float2;

		// Token: 0x04000BE8 RID: 3048
		[Tooltip("The math operation to perform on the floats.")]
		public FloatOperator.Operation operation;

		// Token: 0x04000BE9 RID: 3049
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store the result of the operation in a float variable.")]
		public FsmFloat storeResult;

		// Token: 0x04000BEA RID: 3050
		[Tooltip("Repeat every frame. Useful if the variables are changing.")]
		public bool everyFrame;

		// Token: 0x020001D7 RID: 471
		public enum Operation
		{
			// Token: 0x04000BEC RID: 3052
			Add,
			// Token: 0x04000BED RID: 3053
			Subtract,
			// Token: 0x04000BEE RID: 3054
			Multiply,
			// Token: 0x04000BEF RID: 3055
			Divide,
			// Token: 0x04000BF0 RID: 3056
			Min,
			// Token: 0x04000BF1 RID: 3057
			Max
		}
	}
}
