﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B6 RID: 1206
	[ActionCategory("cInput")]
	[Tooltip("Set the sensitivity of a axis.")]
	public class CInputSetAxisGravity : FsmStateAction
	{
		// Token: 0x0600147B RID: 5243 RVA: 0x000891F8 File Offset: 0x000873F8
		public override void Reset()
		{
			this.axisName = null;
			this.axisGravity = null;
		}

		// Token: 0x0600147C RID: 5244 RVA: 0x00089208 File Offset: 0x00087408
		public override void OnEnter()
		{
			cInput.SetAxisGravity(this.axisName.Value, this.axisGravity.Value);
			base.Finish();
		}

		// Token: 0x04001CEA RID: 7402
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CEB RID: 7403
		[Tooltip("The name of the axis deadzone.")]
		public FsmFloat axisGravity;
	}
}
