﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200023C RID: 572
	[ActionCategory(ActionCategory.Camera)]
	[Tooltip("Gets the camera tagged MainCamera from the scene")]
	public class GetMainCamera : FsmStateAction
	{
		// Token: 0x060009C9 RID: 2505 RVA: 0x0003E30C File Offset: 0x0003C50C
		public override void Reset()
		{
			this.storeGameObject = null;
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x0003E318 File Offset: 0x0003C518
		public override void OnEnter()
		{
			this.storeGameObject.Value = ((!(Camera.main != null)) ? null : Camera.main.gameObject);
			base.Finish();
		}

		// Token: 0x04000DCA RID: 3530
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmGameObject storeGameObject;
	}
}
