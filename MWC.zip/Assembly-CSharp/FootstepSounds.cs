﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000072 RID: 114
[AddComponentMenu("Dark Tonic/Master Audio/Footstep Sounds")]
public class FootstepSounds : MonoBehaviour
{
	// Token: 0x060001AB RID: 427 RVA: 0x0000B9C4 File Offset: 0x00009BC4
	private void OnTriggerEnter(Collider other)
	{
		if (this.footstepEvent != FootstepSounds.FootstepTriggerMode.OnTriggerEnter)
		{
			return;
		}
		this.PlaySoundsIfMatch(other.gameObject);
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0000B9E0 File Offset: 0x00009BE0
	private void OnCollisionEnter(Collision collision)
	{
		if (this.footstepEvent != FootstepSounds.FootstepTriggerMode.OnCollision)
		{
			return;
		}
		this.PlaySoundsIfMatch(collision.gameObject);
	}

	// Token: 0x060001AD RID: 429 RVA: 0x0000B9FC File Offset: 0x00009BFC
	private void OnCollisionEnter2D(Collision2D collision)
	{
		if (this.footstepEvent != FootstepSounds.FootstepTriggerMode.OnCollision2D)
		{
			return;
		}
		this.PlaySoundsIfMatch(collision.gameObject);
	}

	// Token: 0x060001AE RID: 430 RVA: 0x0000BA18 File Offset: 0x00009C18
	private void OnTriggerEnter2D(Collider2D other)
	{
		if (this.footstepEvent != FootstepSounds.FootstepTriggerMode.OnTriggerEnter2D)
		{
			return;
		}
		this.PlaySoundsIfMatch(other.gameObject);
	}

	// Token: 0x060001AF RID: 431 RVA: 0x0000BA34 File Offset: 0x00009C34
	private bool CheckForRetriggerLimit()
	{
		EventSounds.RetriggerLimMode retriggerLimMode = this.retriggerLimitMode;
		if (retriggerLimMode != EventSounds.RetriggerLimMode.FrameBased)
		{
			if (retriggerLimMode == EventSounds.RetriggerLimMode.TimeBased)
			{
				if (this.triggeredLastTime > 0f && Time.time - this.triggeredLastTime < this.limitPerXSec)
				{
					return false;
				}
			}
		}
		else if (this.triggeredLastFrame > 0 && Time.frameCount - this.triggeredLastFrame < this.limitPerXFrm)
		{
			return false;
		}
		return true;
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x0000BAB4 File Offset: 0x00009CB4
	private void PlaySoundsIfMatch(GameObject go)
	{
		if (!this.CheckForRetriggerLimit())
		{
			return;
		}
		EventSounds.RetriggerLimMode retriggerLimMode = this.retriggerLimitMode;
		if (retriggerLimMode != EventSounds.RetriggerLimMode.FrameBased)
		{
			if (retriggerLimMode == EventSounds.RetriggerLimMode.TimeBased)
			{
				this.triggeredLastTime = Time.time;
			}
		}
		else
		{
			this.triggeredLastFrame = Time.frameCount;
		}
		for (int i = 0; i < this.footstepGroups.Count; i++)
		{
			FootstepGroup footstepGroup = this.footstepGroups[i];
			if (footstepGroup.useLayerFilter && !footstepGroup.matchingLayers.Contains(go.layer))
			{
				return;
			}
			if (footstepGroup.useTagFilter && !footstepGroup.matchingTags.Contains(go.tag))
			{
				return;
			}
			float volume = footstepGroup.volume;
			float? pitch = new float?(footstepGroup.pitch);
			if (!footstepGroup.useFixedPitch)
			{
				pitch = null;
			}
			string variationName = null;
			if (footstepGroup.variationType == EventSounds.VariationType.PlaySpecific)
			{
				variationName = footstepGroup.variationName;
			}
			switch (this.soundSpawnMode)
			{
			case MasterAudio.SoundSpawnLocationMode.MasterAudioLocation:
				MasterAudio.PlaySound(footstepGroup.soundType, volume, pitch, footstepGroup.delaySound, variationName, false, false);
				break;
			case MasterAudio.SoundSpawnLocationMode.CallerLocation:
				MasterAudio.PlaySound3DAtTransform(footstepGroup.soundType, this.Trans, volume, pitch, footstepGroup.delaySound, variationName, false, false);
				break;
			case MasterAudio.SoundSpawnLocationMode.AttachToCaller:
				MasterAudio.PlaySound3DFollowTransform(footstepGroup.soundType, this.Trans, volume, pitch, footstepGroup.delaySound, variationName, false, false);
				break;
			}
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x060001B1 RID: 433 RVA: 0x0000BC3C File Offset: 0x00009E3C
	private Transform Trans
	{
		get
		{
			if (this._trans != null)
			{
				return this._trans;
			}
			this._trans = base.transform;
			return this._trans;
		}
	}

	// Token: 0x0400024A RID: 586
	public MasterAudio.SoundSpawnLocationMode soundSpawnMode = MasterAudio.SoundSpawnLocationMode.AttachToCaller;

	// Token: 0x0400024B RID: 587
	public FootstepSounds.FootstepTriggerMode footstepEvent;

	// Token: 0x0400024C RID: 588
	public List<FootstepGroup> footstepGroups = new List<FootstepGroup>();

	// Token: 0x0400024D RID: 589
	public EventSounds.RetriggerLimMode retriggerLimitMode;

	// Token: 0x0400024E RID: 590
	public int limitPerXFrm;

	// Token: 0x0400024F RID: 591
	public float limitPerXSec;

	// Token: 0x04000250 RID: 592
	public int triggeredLastFrame = -100;

	// Token: 0x04000251 RID: 593
	public float triggeredLastTime = -100f;

	// Token: 0x04000252 RID: 594
	private Transform _trans;

	// Token: 0x02000073 RID: 115
	public enum FootstepTriggerMode
	{
		// Token: 0x04000254 RID: 596
		None,
		// Token: 0x04000255 RID: 597
		OnCollision,
		// Token: 0x04000256 RID: 598
		OnTriggerEnter,
		// Token: 0x04000257 RID: 599
		OnCollision2D,
		// Token: 0x04000258 RID: 600
		OnTriggerEnter2D
	}
}
