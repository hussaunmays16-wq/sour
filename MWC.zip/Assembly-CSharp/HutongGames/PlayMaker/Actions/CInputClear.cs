﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049F RID: 1183
	[Tooltip("Clears all data stored by cInput from PlayerPrefs.")]
	[ActionCategory("cInput")]
	public class CInputClear : FsmStateAction
	{
		// Token: 0x0600143B RID: 5179 RVA: 0x000888E0 File Offset: 0x00086AE0
		public override void OnEnter()
		{
			cInput.Clear();
			base.Finish();
		}
	}
}
