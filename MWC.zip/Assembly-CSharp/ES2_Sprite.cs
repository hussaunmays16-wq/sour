﻿using System;
using System.ComponentModel;
using UnityEngine;

// Token: 0x020000D0 RID: 208
[EditorBrowsable(EditorBrowsableState.Never)]
public sealed class ES2_Sprite : ES2Type
{
	// Token: 0x060003F2 RID: 1010 RVA: 0x000198A8 File Offset: 0x00017AA8
	public ES2_Sprite() : base(typeof(Sprite))
	{
		this.key = 31;
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x000198C4 File Offset: 0x00017AC4
	public override void Write(object data, ES2Writer writer)
	{
		Sprite sprite = (Sprite)data;
		writer.Write(sprite.texture);
		writer.Write(sprite.rect);
		float x = -sprite.bounds.center.x / sprite.bounds.extents.x / 2f + 0.5f;
		float y = -sprite.bounds.center.y / sprite.bounds.extents.y / 2f + 0.5f;
		writer.Write(new Vector2(x, y));
		writer.Write(sprite.textureRect.width / sprite.bounds.size.x);
		writer.Write(sprite.name);
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x000199B4 File Offset: 0x00017BB4
	public override object Read(ES2Reader reader)
	{
		Sprite sprite = Sprite.Create(reader.Read<Texture2D>(), reader.Read<Rect>(), reader.Read<Vector2>(), reader.Read<float>());
		sprite.name = reader.Read<string>();
		return sprite;
	}
}
