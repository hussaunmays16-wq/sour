﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022C RID: 556
	[Tooltip("Get the value of a Quaternion Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmQuaternion : FsmStateAction
	{
		// Token: 0x06000980 RID: 2432 RVA: 0x0003D5E0 File Offset: 0x0003B7E0
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.variableName = string.Empty;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x0003D618 File Offset: 0x0003B818
		public override void OnEnter()
		{
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x0003D634 File Offset: 0x0003B834
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x0003D63C File Offset: 0x0003B83C
		private void DoGetFsmVariable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null || this.storeValue == null)
			{
				return;
			}
			FsmQuaternion fsmQuaternion = this.fsm.FsmVariables.GetFsmQuaternion(this.variableName.Value);
			if (fsmQuaternion != null)
			{
				this.storeValue.Value = fsmQuaternion.Value;
			}
		}

		// Token: 0x04000D70 RID: 3440
		[RequiredField]
		[Tooltip("The GameObject that owns the FSM.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D71 RID: 3441
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D72 RID: 3442
		[UIHint(UIHint.FsmQuaternion)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D73 RID: 3443
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmQuaternion storeValue;

		// Token: 0x04000D74 RID: 3444
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D75 RID: 3445
		private GameObject goLastFrame;

		// Token: 0x04000D76 RID: 3446
		protected PlayMakerFSM fsm;
	}
}
