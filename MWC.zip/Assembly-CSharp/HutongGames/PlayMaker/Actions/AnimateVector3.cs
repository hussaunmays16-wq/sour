﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000133 RID: 307
	[Tooltip("Animates the value of a Vector3 Variable using an Animation Curve.")]
	[ActionCategory(ActionCategory.AnimateVariables)]
	public class AnimateVector3 : AnimateFsmAction
	{
		// Token: 0x060005A9 RID: 1449 RVA: 0x0002A9C4 File Offset: 0x00028BC4
		public override void Reset()
		{
			base.Reset();
			this.vectorVariable = new FsmVector3
			{
				UseVariable = true
			};
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0002A9EC File Offset: 0x00028BEC
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[3];
			this.fromFloats = new float[3];
			this.fromFloats[0] = ((!this.vectorVariable.IsNone) ? this.vectorVariable.Value.x : 0f);
			this.fromFloats[1] = ((!this.vectorVariable.IsNone) ? this.vectorVariable.Value.y : 0f);
			this.fromFloats[2] = ((!this.vectorVariable.IsNone) ? this.vectorVariable.Value.z : 0f);
			this.curves = new AnimationCurve[3];
			this.curves[0] = this.curveX.curve;
			this.curves[1] = this.curveY.curve;
			this.curves[2] = this.curveZ.curve;
			this.calculations = new AnimateFsmAction.Calculation[3];
			this.calculations[0] = this.calculationX;
			this.calculations[1] = this.calculationY;
			this.calculations[2] = this.calculationZ;
			base.Init();
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0002AB40 File Offset: 0x00028D40
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.vectorVariable.IsNone && this.isRunning)
			{
				this.vct = new Vector3(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2]);
				this.vectorVariable.Value = this.vct;
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.vectorVariable.IsNone)
				{
					this.vct = new Vector3(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2]);
					this.vectorVariable.Value = this.vct;
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x0400085F RID: 2143
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmVector3 vectorVariable;

		// Token: 0x04000860 RID: 2144
		[RequiredField]
		public FsmAnimationCurve curveX;

		// Token: 0x04000861 RID: 2145
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to vectorVariable.x.")]
		public AnimateFsmAction.Calculation calculationX;

		// Token: 0x04000862 RID: 2146
		[RequiredField]
		public FsmAnimationCurve curveY;

		// Token: 0x04000863 RID: 2147
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to vectorVariable.y.")]
		public AnimateFsmAction.Calculation calculationY;

		// Token: 0x04000864 RID: 2148
		[RequiredField]
		public FsmAnimationCurve curveZ;

		// Token: 0x04000865 RID: 2149
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to vectorVariable.z.")]
		public AnimateFsmAction.Calculation calculationZ;

		// Token: 0x04000866 RID: 2150
		private bool finishInNextStep;

		// Token: 0x04000867 RID: 2151
		private Vector3 vct;
	}
}
