﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B9 RID: 953
	[Tooltip("Destroys a PlayMakerHashTableProxy Component of a Game Object.")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class DestroyHashTable : HashTableActions
	{
		// Token: 0x0600101E RID: 4126 RVA: 0x00058358 File Offset: 0x00056558
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.successEvent = null;
			this.notFoundEvent = null;
		}

		// Token: 0x0600101F RID: 4127 RVA: 0x00058378 File Offset: 0x00056578
		public override void OnEnter()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (base.SetUpHashTableProxyPointer(ownerDefaultTarget, this.reference.Value))
			{
				this.DoDestroyHashTable(ownerDefaultTarget);
			}
			else
			{
				base.Fsm.Event(this.notFoundEvent);
			}
			base.Finish();
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x000583D4 File Offset: 0x000565D4
		private void DoDestroyHashTable(GameObject go)
		{
			PlayMakerHashTableProxy[] components = this.proxy.GetComponents<PlayMakerHashTableProxy>();
			foreach (PlayMakerHashTableProxy playMakerHashTableProxy in components)
			{
				if (playMakerHashTableProxy.referenceName == this.reference.Value)
				{
					UnityEngine.Object.Destroy(playMakerHashTableProxy);
					base.Fsm.Event(this.successEvent);
					return;
				}
			}
			base.Fsm.Event(this.notFoundEvent);
		}

		// Token: 0x040014E9 RID: 5353
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014EA RID: 5354
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker HashTable proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014EB RID: 5355
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger if the HashTable proxy component is destroyed")]
		[ActionSection("Result")]
		public FsmEvent successEvent;

		// Token: 0x040014EC RID: 5356
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger if the HashTable proxy component was not found")]
		public FsmEvent notFoundEvent;
	}
}
