﻿using System;

// Token: 0x0200007B RID: 123
[Serializable]
public class DuckGroupInfo
{
	// Token: 0x040002A4 RID: 676
	public string soundType = "[None]";

	// Token: 0x040002A5 RID: 677
	public float riseVolStart = 0.5f;
}
