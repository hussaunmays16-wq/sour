﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000231 RID: 561
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Get the value of a variable in another FSM and store it in a variable of the same name in this FSM.")]
	public class GetFsmVariable : FsmStateAction
	{
		// Token: 0x06000999 RID: 2457 RVA: 0x0003DB24 File Offset: 0x0003BD24
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = new FsmVar();
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x0003DB54 File Offset: 0x0003BD54
		public override void OnEnter()
		{
			this.InitFsmVar();
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x0003DB74 File Offset: 0x0003BD74
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x0003DB7C File Offset: 0x0003BD7C
		private void InitFsmVar()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.cachedGO)
			{
				this.sourceFsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
				this.sourceVariable = this.sourceFsm.FsmVariables.GetVariable(this.storeValue.variableName);
				this.targetVariable = base.Fsm.Variables.GetVariable(this.storeValue.variableName);
				this.storeValue.Type = FsmUtility.GetVariableType(this.targetVariable);
				if (!string.IsNullOrEmpty(this.storeValue.variableName) && this.sourceVariable == null)
				{
					this.LogWarning("Missing Variable: " + this.storeValue.variableName);
				}
				this.cachedGO = ownerDefaultTarget;
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x0003DC6C File Offset: 0x0003BE6C
		private void DoGetFsmVariable()
		{
			if (this.storeValue.IsNone)
			{
				return;
			}
			this.InitFsmVar();
			this.storeValue.GetValueFrom(this.sourceVariable);
			this.storeValue.ApplyValueTo(this.targetVariable);
		}

		// Token: 0x04000D92 RID: 3474
		[Tooltip("The GameObject that owns the FSM")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D93 RID: 3475
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000D94 RID: 3476
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[HideTypeFilter]
		public FsmVar storeValue;

		// Token: 0x04000D95 RID: 3477
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D96 RID: 3478
		private GameObject cachedGO;

		// Token: 0x04000D97 RID: 3479
		private PlayMakerFSM sourceFsm;

		// Token: 0x04000D98 RID: 3480
		private INamedVariable sourceVariable;

		// Token: 0x04000D99 RID: 3481
		private NamedVariable targetVariable;
	}
}
