﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BC RID: 956
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Remove all content of a PlayMaker hashtable Proxy component")]
	public class HashTableClear : HashTableActions
	{
		// Token: 0x0600102A RID: 4138 RVA: 0x000586B8 File Offset: 0x000568B8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x0600102B RID: 4139 RVA: 0x000586C8 File Offset: 0x000568C8
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.ClearHashTable();
			}
			base.Finish();
		}

		// Token: 0x0600102C RID: 4140 RVA: 0x00058708 File Offset: 0x00056908
		public void ClearHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.hashTable.Clear();
		}

		// Token: 0x040014F9 RID: 5369
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014FA RID: 5370
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
