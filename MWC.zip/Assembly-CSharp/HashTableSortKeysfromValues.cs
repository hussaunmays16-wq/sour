﻿using System;
using UnityEngine;

// Token: 0x020003CE RID: 974
public class HashTableSortKeysfromValues : MonoBehaviour
{
	// Token: 0x06001071 RID: 4209 RVA: 0x00059818 File Offset: 0x00057A18
	private void Start()
	{
	}

	// Token: 0x06001072 RID: 4210 RVA: 0x0005981C File Offset: 0x00057A1C
	private void Update()
	{
	}
}
