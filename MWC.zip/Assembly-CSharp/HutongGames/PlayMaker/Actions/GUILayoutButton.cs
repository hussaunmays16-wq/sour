﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F0 RID: 496
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("GUILayout Button. Sends an Event when pressed. Optionally stores the button state in a Bool Variable.")]
	public class GUILayoutButton : GUILayoutAction
	{
		// Token: 0x0600089E RID: 2206 RVA: 0x0003A2F8 File Offset: 0x000384F8
		public override void Reset()
		{
			base.Reset();
			this.sendEvent = null;
			this.storeButtonState = null;
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x0003A350 File Offset: 0x00038550
		public override void OnGUI()
		{
			bool flag;
			if (string.IsNullOrEmpty(this.style.Value))
			{
				flag = GUILayout.Button(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), base.LayoutOptions);
			}
			else
			{
				flag = GUILayout.Button(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
			}
			if (flag)
			{
				base.Fsm.Event(this.sendEvent);
			}
			if (this.storeButtonState != null)
			{
				this.storeButtonState.Value = flag;
			}
		}

		// Token: 0x04000C60 RID: 3168
		public FsmEvent sendEvent;

		// Token: 0x04000C61 RID: 3169
		[UIHint(UIHint.Variable)]
		public FsmBool storeButtonState;

		// Token: 0x04000C62 RID: 3170
		public FsmTexture image;

		// Token: 0x04000C63 RID: 3171
		public FsmString text;

		// Token: 0x04000C64 RID: 3172
		public FsmString tooltip;

		// Token: 0x04000C65 RID: 3173
		public FsmString style;
	}
}
