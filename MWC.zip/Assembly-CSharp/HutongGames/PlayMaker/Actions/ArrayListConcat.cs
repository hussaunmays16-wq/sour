﻿using System;
using System.Collections;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039A RID: 922
	[Tooltip("Concat joins two or more arrayList proxy components. if a target is specified, the method use the target store the concatenation, else the ")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListConcat : ArrayListActions
	{
		// Token: 0x06000F9F RID: 3999 RVA: 0x00055E10 File Offset: 0x00054010
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.arrayListGameObjectTargets = null;
			this.referenceTargets = null;
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x00055E30 File Offset: 0x00054030
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListConcat(this.proxy.arrayList);
			}
			base.Finish();
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x00055E7C File Offset: 0x0005407C
		public void DoArrayListConcat(ArrayList source)
		{
			if (!base.isProxyValid())
			{
				return;
			}
			for (int i = 0; i < this.arrayListGameObjectTargets.Length; i++)
			{
				if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.arrayListGameObjectTargets[i]), this.referenceTargets[i].Value) && base.isProxyValid())
				{
					foreach (object value in this.proxy.arrayList)
					{
						source.Add(value);
						Debug.Log("count " + source.Count);
					}
				}
			}
		}

		// Token: 0x0400144C RID: 5196
		[ActionSection("Storage")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400144D RID: 5197
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to store the concatenation ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400144E RID: 5198
		[Tooltip("The GameObject with the PlayMaker ArrayList Proxy component to copy to")]
		[RequiredField]
		[CompoundArray("ArrayLists", "ArrayList GameObject", "Reference")]
		[ObjectType(typeof(PlayMakerArrayListProxy))]
		[ActionSection("ArrayLists to concatenate")]
		public FsmOwnerDefault[] arrayListGameObjectTargets;

		// Token: 0x0400144F RID: 5199
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to copy to ( necessary if several component coexists on the same GameObject")]
		public FsmString[] referenceTargets;
	}
}
