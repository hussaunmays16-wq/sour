﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A1 RID: 929
	[Tooltip("Return the closest GameObject within an arrayList from a transform or position.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetClosestGameObject : ArrayListActions
	{
		// Token: 0x06000FBA RID: 4026 RVA: 0x00056700 File Offset: 0x00054900
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.distanceFrom = null;
			this.orDistanceFromVector3 = null;
			this.closestGameObject = null;
			this.closestIndex = null;
			this.everyframe = true;
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x00056734 File Offset: 0x00054934
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindClosestGo();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x00056788 File Offset: 0x00054988
		public override void OnUpdate()
		{
			this.DoFindClosestGo();
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x00056790 File Offset: 0x00054990
		private void DoFindClosestGo()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			Vector3 vector = this.orDistanceFromVector3.Value;
			GameObject value = this.distanceFrom.Value;
			if (value != null)
			{
				vector += value.transform.position;
			}
			float num = float.PositiveInfinity;
			int num2 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject gameObject = (GameObject)obj;
				if (gameObject != null)
				{
					float sqrMagnitude = (gameObject.transform.position - vector).sqrMagnitude;
					if (sqrMagnitude <= num)
					{
						num = sqrMagnitude;
						this.closestGameObject.Value = gameObject;
						this.closestIndex.Value = num2;
					}
				}
				num2++;
			}
		}

		// Token: 0x0400146C RID: 5228
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400146D RID: 5229
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400146E RID: 5230
		[Tooltip("Compare the distance of the items in the list to the position of this gameObject")]
		public FsmGameObject distanceFrom;

		// Token: 0x0400146F RID: 5231
		[Tooltip("If DistanceFrom declared, use OrDistanceFromVector3 as an offset")]
		public FsmVector3 orDistanceFromVector3;

		// Token: 0x04001470 RID: 5232
		public bool everyframe;

		// Token: 0x04001471 RID: 5233
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmGameObject closestGameObject;

		// Token: 0x04001472 RID: 5234
		[UIHint(UIHint.Variable)]
		public FsmInt closestIndex;
	}
}
