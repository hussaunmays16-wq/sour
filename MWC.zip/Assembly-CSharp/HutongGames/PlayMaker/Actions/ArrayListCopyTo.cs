﻿using System;
using System.Collections;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039C RID: 924
	[Tooltip("Copy elements from one PlayMaker ArrayList Proxy component to another")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListCopyTo : ArrayListActions
	{
		// Token: 0x06000FA7 RID: 4007 RVA: 0x00056278 File Offset: 0x00054478
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.gameObjectTarget = null;
			this.referenceTarget = null;
			this.startIndex = new FsmInt
			{
				UseVariable = true
			};
			this.count = new FsmInt
			{
				UseVariable = true
			};
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x000562CC File Offset: 0x000544CC
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListCopyTo(this.proxy.arrayList);
			}
			base.Finish();
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x00056318 File Offset: 0x00054518
		public void DoArrayListCopyTo(ArrayList source)
		{
			if (!base.isProxyValid())
			{
				return;
			}
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObjectTarget), this.referenceTarget.Value))
			{
				return;
			}
			if (!base.isProxyValid())
			{
				return;
			}
			int value = this.startIndex.Value;
			int num = source.Count;
			int value2 = source.Count;
			if (!this.count.IsNone)
			{
				value2 = this.count.Value;
			}
			if (value < 0 || value >= source.Count)
			{
				this.LogError("start index out of range");
				return;
			}
			if (this.count.Value < 0)
			{
				this.LogError("count can not be negative");
				return;
			}
			num = Mathf.Min(value + value2, source.Count);
			for (int i = value; i < num; i++)
			{
				this.proxy.arrayList.Add(source[i]);
			}
		}

		// Token: 0x04001456 RID: 5206
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component to copy from")]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001457 RID: 5207
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to copy from ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001458 RID: 5208
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Result")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component to copy to")]
		public FsmOwnerDefault gameObjectTarget;

		// Token: 0x04001459 RID: 5209
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to copy to ( necessary if several component coexists on the same GameObject")]
		public FsmString referenceTarget;

		// Token: 0x0400145A RID: 5210
		[Tooltip("Optional start index to copy from the source, if not set, starts from the beginning")]
		public FsmInt startIndex;

		// Token: 0x0400145B RID: 5211
		[Tooltip("Optional amount of elements to copy, If not set, will copy all from start index.")]
		public FsmInt count;
	}
}
