﻿using System;

// Token: 0x02000080 RID: 128
[Serializable]
public class GroupFadeInfo
{
	// Token: 0x040002FD RID: 765
	public MasterAudioGroup ActingGroup;

	// Token: 0x040002FE RID: 766
	public string NameOfGroup;

	// Token: 0x040002FF RID: 767
	public float TargetVolume;

	// Token: 0x04000300 RID: 768
	public float VolumeStep;

	// Token: 0x04000301 RID: 769
	public bool IsActive = true;

	// Token: 0x04000302 RID: 770
	public Action completionAction;
}
