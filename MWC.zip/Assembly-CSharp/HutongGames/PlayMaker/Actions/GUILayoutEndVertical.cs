﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F7 RID: 503
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Close a group started with BeginVertical.")]
	public class GUILayoutEndVertical : FsmStateAction
	{
		// Token: 0x060008B2 RID: 2226 RVA: 0x0003A62C File Offset: 0x0003882C
		public override void Reset()
		{
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x0003A630 File Offset: 0x00038830
		public override void OnGUI()
		{
			GUILayout.EndVertical();
		}
	}
}
