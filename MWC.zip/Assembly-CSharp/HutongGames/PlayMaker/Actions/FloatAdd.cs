﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001CE RID: 462
	[Tooltip("Adds a value to a Float Variable.")]
	[ActionCategory(ActionCategory.Math)]
	public class FloatAdd : FsmStateAction
	{
		// Token: 0x0600081E RID: 2078 RVA: 0x000385E0 File Offset: 0x000367E0
		public override void Reset()
		{
			this.floatVariable = null;
			this.add = null;
			this.everyFrame = false;
			this.perSecond = false;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00038600 File Offset: 0x00036800
		public override void OnEnter()
		{
			this.DoFloatAdd();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x0003861C File Offset: 0x0003681C
		public override void OnUpdate()
		{
			this.DoFloatAdd();
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00038624 File Offset: 0x00036824
		private void DoFloatAdd()
		{
			if (!this.perSecond)
			{
				this.floatVariable.Value += this.add.Value;
			}
			else
			{
				this.floatVariable.Value += this.add.Value * Time.deltaTime;
			}
		}

		// Token: 0x04000BC1 RID: 3009
		[UIHint(UIHint.Variable)]
		[Tooltip("The Float variable to add to.")]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000BC2 RID: 3010
		[RequiredField]
		[Tooltip("Amount to add.")]
		public FsmFloat add;

		// Token: 0x04000BC3 RID: 3011
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x04000BC4 RID: 3012
		[Tooltip("Used with Every Frame. Adds the value over one second to make the operation frame rate independent.")]
		public bool perSecond;
	}
}
