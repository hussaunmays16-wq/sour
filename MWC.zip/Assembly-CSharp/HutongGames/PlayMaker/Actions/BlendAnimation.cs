﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000149 RID: 329
	[Tooltip("Blends an Animation towards a Target Weight over a specified Time.\nOptionally sends an Event when finished.")]
	[ActionCategory(ActionCategory.Animation)]
	public class BlendAnimation : FsmStateAction
	{
		// Token: 0x0600061C RID: 1564 RVA: 0x0002E9BC File Offset: 0x0002CBBC
		public override void Reset()
		{
			this.gameObject = null;
			this.animName = null;
			this.targetWeight = 1f;
			this.time = 0.3f;
			this.finishEvent = null;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x0002E9F4 File Offset: 0x0002CBF4
		public override void OnEnter()
		{
			this.DoBlendAnimation((this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner);
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x0002EA34 File Offset: 0x0002CC34
		public override void OnUpdate()
		{
			if (DelayedEvent.WasSent(this.delayedFinishEvent))
			{
				base.Finish();
			}
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x0002EA4C File Offset: 0x0002CC4C
		private void DoBlendAnimation(GameObject go)
		{
			if (go == null)
			{
				return;
			}
			Animation component = go.GetComponent<Animation>();
			if (component == null)
			{
				this.LogWarning("Missing Animation component on GameObject: " + go.name);
				base.Finish();
				return;
			}
			AnimationState animationState = component[this.animName.Value];
			if (animationState == null)
			{
				this.LogWarning("Missing animation: " + this.animName.Value);
				base.Finish();
				return;
			}
			float value = this.time.Value;
			component.Blend(this.animName.Value, this.targetWeight.Value, value);
			if (this.finishEvent != null)
			{
				this.delayedFinishEvent = base.Fsm.DelayedEvent(this.finishEvent, animationState.length);
			}
			else
			{
				base.Finish();
			}
		}

		// Token: 0x0400090F RID: 2319
		[RequiredField]
		[CheckForComponent(typeof(Animation))]
		[Tooltip("The GameObject to animate.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000910 RID: 2320
		[Tooltip("The name of the animation to blend.")]
		[RequiredField]
		[UIHint(UIHint.Animation)]
		public FsmString animName;

		// Token: 0x04000911 RID: 2321
		[HasFloatSlider(0f, 1f)]
		[Tooltip("Target weight to blend to.")]
		[RequiredField]
		public FsmFloat targetWeight;

		// Token: 0x04000912 RID: 2322
		[RequiredField]
		[Tooltip("How long should the blend take.")]
		[HasFloatSlider(0f, 5f)]
		public FsmFloat time;

		// Token: 0x04000913 RID: 2323
		[Tooltip("Event to send when the blend has finished.")]
		public FsmEvent finishEvent;

		// Token: 0x04000914 RID: 2324
		private DelayedEvent delayedFinishEvent;
	}
}
