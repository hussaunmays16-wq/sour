﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049E RID: 1182
	[Tooltip("Changes the key mapping for cInput keys. If you press Escape the action finishes, because cInput doesn't allow to bind it.")]
	[ActionCategory("cInput")]
	public class CInputChangeKey : FsmStateAction
	{
		// Token: 0x06001437 RID: 5175 RVA: 0x00088760 File Offset: 0x00086960
		public override void OnEnter()
		{
			cInput.allowDuplicates = this.allowDuplicates.Value;
			if (string.IsNullOrEmpty(this.actionName.Value))
			{
				cInput.ChangeKey(this.index.Value, this.input.Value, this.allowMouseAxis.Value, this.allowMouseButtons.Value, this.allowGamepadAxis.Value, this.allowGamepadButtons.Value, this.allowKeyboard.Value);
			}
			else
			{
				cInput.ChangeKey(this.actionName.Value, this.input.Value, this.allowMouseAxis.Value, this.allowMouseButtons.Value, this.allowGamepadAxis.Value, this.allowGamepadButtons.Value, this.allowKeyboard.Value);
			}
		}

		// Token: 0x06001438 RID: 5176 RVA: 0x0008883C File Offset: 0x00086A3C
		public override void OnLateUpdate()
		{
			if (cInput.GetKey(this.actionName.Value))
			{
				base.Fsm.Event(this.keyChangedEvent);
				base.Finish();
			}
			else if (Input.GetKey(KeyCode.Escape))
			{
				base.Finish();
			}
		}

		// Token: 0x06001439 RID: 5177 RVA: 0x0008888C File Offset: 0x00086A8C
		public override void Reset()
		{
			this.actionName = null;
			this.index = null;
			this.input = null;
			this.allowDuplicates = null;
			this.allowMouseAxis = null;
			this.allowMouseButtons = null;
			this.allowGamepadAxis = null;
			this.allowGamepadButtons = null;
			this.allowKeyboard = null;
		}

		// Token: 0x04001C9E RID: 7326
		[Tooltip("The action you want to change the key for. If this field is empty, the index value will be taken.")]
		public FsmString actionName;

		// Token: 0x04001C9F RID: 7327
		[Tooltip("If Action Name is empty, the index will be taken.")]
		public FsmInt index;

		// Token: 0x04001CA0 RID: 7328
		[Tooltip("change mapping for 1 = primary, 2 = secondary")]
		public FsmInt input;

		// Token: 0x04001CA1 RID: 7329
		[Tooltip("If checked you are able to bind multiple actions to this key")]
		public FsmBool allowDuplicates;

		// Token: 0x04001CA2 RID: 7330
		public FsmBool allowMouseAxis;

		// Token: 0x04001CA3 RID: 7331
		public FsmBool allowMouseButtons;

		// Token: 0x04001CA4 RID: 7332
		public FsmBool allowGamepadAxis;

		// Token: 0x04001CA5 RID: 7333
		public FsmBool allowGamepadButtons;

		// Token: 0x04001CA6 RID: 7334
		public FsmBool allowKeyboard;

		// Token: 0x04001CA7 RID: 7335
		[Tooltip("Sends after a key has pressed.")]
		public FsmEvent keyChangedEvent;
	}
}
