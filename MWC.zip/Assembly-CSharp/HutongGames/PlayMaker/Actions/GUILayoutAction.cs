﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E8 RID: 488
	[Tooltip("GUILayout base action - don't use!")]
	public abstract class GUILayoutAction : FsmStateAction
	{
		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000885 RID: 2181 RVA: 0x00039B44 File Offset: 0x00037D44
		public GUILayoutOption[] LayoutOptions
		{
			get
			{
				if (this.options == null)
				{
					this.options = new GUILayoutOption[this.layoutOptions.Length];
					for (int i = 0; i < this.layoutOptions.Length; i++)
					{
						this.options[i] = this.layoutOptions[i].GetGUILayoutOption();
					}
				}
				return this.options;
			}
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00039BA4 File Offset: 0x00037DA4
		public override void Reset()
		{
			this.layoutOptions = new LayoutOption[0];
		}

		// Token: 0x04000C3C RID: 3132
		public LayoutOption[] layoutOptions;

		// Token: 0x04000C3D RID: 3133
		private GUILayoutOption[] options;
	}
}
