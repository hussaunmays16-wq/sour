﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C4 RID: 452
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Enables/Disables an FSM component on a GameObject.")]
	public class EnableFSM : FsmStateAction
	{
		// Token: 0x060007F3 RID: 2035 RVA: 0x00037D1C File Offset: 0x00035F1C
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.enable = true;
			this.resetOnExit = true;
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00037D50 File Offset: 0x00035F50
		public override void OnEnter()
		{
			this.DoEnableFSM();
			base.Finish();
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00037D60 File Offset: 0x00035F60
		private void DoEnableFSM()
		{
			GameObject gameObject = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			if (gameObject == null)
			{
				return;
			}
			if (!string.IsNullOrEmpty(this.fsmName.Value))
			{
				PlayMakerFSM[] components = gameObject.GetComponents<PlayMakerFSM>();
				foreach (PlayMakerFSM playMakerFSM in components)
				{
					if (playMakerFSM.FsmName == this.fsmName.Value)
					{
						this.fsmComponent = playMakerFSM;
						break;
					}
				}
			}
			else
			{
				this.fsmComponent = gameObject.GetComponent<PlayMakerFSM>();
			}
			if (this.fsmComponent == null)
			{
				this.LogError("Missing FsmComponent!");
				return;
			}
			this.fsmComponent.enabled = this.enable.Value;
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00037E4C File Offset: 0x0003604C
		public override void OnExit()
		{
			if (this.fsmComponent == null)
			{
				return;
			}
			if (this.resetOnExit.Value)
			{
				this.fsmComponent.enabled = !this.enable.Value;
			}
		}

		// Token: 0x04000B9A RID: 2970
		[Tooltip("The GameObject that owns the FSM component.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000B9B RID: 2971
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on GameObject. Useful if you have more than one FSM on a GameObject.")]
		public FsmString fsmName;

		// Token: 0x04000B9C RID: 2972
		[Tooltip("Set to True to enable, False to disable.")]
		public FsmBool enable;

		// Token: 0x04000B9D RID: 2973
		[Tooltip("Reset the initial enabled state when exiting the state.")]
		public FsmBool resetOnExit;

		// Token: 0x04000B9E RID: 2974
		private PlayMakerFSM fsmComponent;
	}
}
