﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000E1 RID: 225
public class Hull
{
	// Token: 0x06000461 RID: 1121 RVA: 0x0001D5A0 File Offset: 0x0001B7A0
	public Hull(Mesh mesh)
	{
		this.m_Vertices = new List<Vector3>(mesh.vertices);
		this.m_Triangles = new List<int>(mesh.triangles);
		if (mesh.normals.Length > 0)
		{
			this.m_Normals = new List<Vector3>(mesh.normals);
		}
		if (mesh.tangents.Length > 0)
		{
			this.m_Tangents = new List<Vector4>(mesh.tangents);
		}
		if (mesh.uv.Length > 0)
		{
			this.m_Uvs = new List<Vector2>(mesh.uv);
		}
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x0001D634 File Offset: 0x0001B834
	public void Impact(Vector3 impactPoint, Vector3 impactForce, Meshinator.ImpactShapes impactShape, Meshinator.ImpactTypes impactType)
	{
		Dictionary<int, float> dictionary = new Dictionary<int, float>();
		foreach (int num in this.GetIntersectedTriangleIndices(impactPoint, impactForce.magnitude))
		{
			float areaOfTriangle = this.GetAreaOfTriangle(num);
			dictionary.Add(num, areaOfTriangle);
		}
		while (dictionary.Keys.Count < 48)
		{
			if (this.m_Vertices.Count > 64988)
			{
				break;
			}
			int indexOfLargestTriangle = this.GetIndexOfLargestTriangle(dictionary);
			List<int> list = this.BreakDownTriangle(indexOfLargestTriangle);
			dictionary.Remove(indexOfLargestTriangle);
			foreach (int num2 in list)
			{
				if (this.IsTriangleIndexIntersected(num2, impactPoint, impactForce.magnitude))
				{
					float areaOfTriangle2 = this.GetAreaOfTriangle(num2);
					dictionary.Add(num2, areaOfTriangle2);
				}
			}
		}
		this.AdjustVerticesForImpact(impactPoint, impactForce, impactShape, impactType);
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x0001D780 File Offset: 0x0001B980
	private void AdjustVerticesForImpact(Vector3 impactPoint, Vector3 impactForce, Meshinator.ImpactShapes impactShape, Meshinator.ImpactTypes impactType)
	{
		float magnitude = impactForce.magnitude;
		Dictionary<int, float> dictionary = new Dictionary<int, float>();
		for (int i = 0; i < this.m_Vertices.Count; i++)
		{
			Vector3 a = this.m_Vertices[i];
			Vector3 vector = Vector3.zero;
			if (impactShape != Meshinator.ImpactShapes.FlatImpact)
			{
				if (impactShape == Meshinator.ImpactShapes.SphericalImpact)
				{
					vector = a - impactPoint;
				}
			}
			else
			{
				vector = Vector3.Project(a - impactPoint, impactForce.normalized);
			}
			float num = vector.magnitude;
			if (impactShape == Meshinator.ImpactShapes.FlatImpact && Vector3.Angle(a - impactPoint, impactForce) > 90f)
			{
				num = -num;
			}
			float num2 = Mathf.Max(0f, magnitude - num) * 0.95f;
			if (num < magnitude && num2 > 0f)
			{
				dictionary.Add(i, num2);
			}
		}
		if (impactType != Meshinator.ImpactTypes.Compression)
		{
			if (impactType == Meshinator.ImpactTypes.Fracture)
			{
				this.FractureMeshVertices(dictionary, impactForce);
			}
		}
		else
		{
			this.CompressMeshVertices(dictionary, impactForce);
		}
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x0001D89C File Offset: 0x0001BA9C
	private void CompressMeshVertices(Dictionary<int, float> movedVertexToForceMagnitudeMap, Vector3 impactForce)
	{
		foreach (int num in movedVertexToForceMagnitudeMap.Keys)
		{
			Vector3 a = this.m_Vertices[num];
			float d = movedVertexToForceMagnitudeMap[num];
			Vector3 b = impactForce.normalized * d;
			this.m_Vertices[num] = a + b;
		}
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x0001D934 File Offset: 0x0001BB34
	private void FractureMeshVertices(Dictionary<int, float> movedVertexToForceMagnitudeMap, Vector3 impactForce)
	{
		if (movedVertexToForceMagnitudeMap.Keys.Count >= this.m_Vertices.Count)
		{
			return;
		}
		this.SetupSubHulls(movedVertexToForceMagnitudeMap);
		this.FixUpSubHulls(impactForce);
		this.m_Vertices = this.m_FirstSubHull.m_Vertices;
		this.m_Normals = this.m_FirstSubHull.m_Normals;
		this.m_Tangents = this.m_FirstSubHull.m_Tangents;
		this.m_Uvs = this.m_FirstSubHull.m_Uvs;
		this.m_Triangles = this.m_FirstSubHull.m_Triangles;
		this.m_FirstSubHull = null;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x0001D9C8 File Offset: 0x0001BBC8
	public void SetupSubHulls(Dictionary<int, float> movedVertexToForceMagnitudeMap)
	{
		this.m_FirstSubHull = new SubHull();
		this.m_SecondSubHull = new SubHull();
		Dictionary<SubHull, Dictionary<int, int>> dictionary = new Dictionary<SubHull, Dictionary<int, int>>();
		for (int i = 0; i < this.m_Vertices.Count; i++)
		{
			SubHull subHull = this.m_FirstSubHull;
			if (movedVertexToForceMagnitudeMap.ContainsKey(i))
			{
				subHull = this.m_SecondSubHull;
			}
			subHull.m_Vertices.Add(this.m_Vertices[i]);
			if (this.m_Normals.Count > i)
			{
				subHull.m_Normals.Add(this.m_Normals[i]);
			}
			if (this.m_Tangents.Count > i)
			{
				subHull.m_Tangents.Add(this.m_Tangents[i]);
			}
			if (this.m_Uvs.Count > i)
			{
				subHull.m_Uvs.Add(this.m_Uvs[i]);
			}
			if (!dictionary.ContainsKey(subHull))
			{
				dictionary.Add(subHull, new Dictionary<int, int>());
			}
			dictionary[subHull].Add(i, subHull.m_Vertices.Count - 1);
		}
		Dictionary<Vector3, List<int>> dictionary2 = new Dictionary<Vector3, List<int>>();
		for (int j = 0; j < this.m_Vertices.Count; j++)
		{
			Vector3 key = this.m_Vertices[j];
			if (!dictionary2.ContainsKey(key))
			{
				dictionary2.Add(key, new List<int>());
			}
			List<int> list = dictionary2[key];
			list.Add(j);
		}
		for (int k = 0; k < this.m_Triangles.Count; k += 3)
		{
			List<int> list2 = new List<int>();
			for (int l = k; l < k + 3; l++)
			{
				if (movedVertexToForceMagnitudeMap.ContainsKey(this.m_Triangles[l]))
				{
					list2.Add(this.m_Triangles[l]);
				}
			}
			if (list2.Count != 3 && list2.Count != 0)
			{
				for (int m = k; m < k + 3; m++)
				{
					int num = this.m_Triangles[m];
					SubHull subHull2 = this.m_FirstSubHull;
					if (list2.Contains(num))
					{
						subHull2 = this.m_SecondSubHull;
					}
					Dictionary<int, int> dictionary3 = dictionary[subHull2];
					foreach (int key2 in dictionary2[this.m_Vertices[num]])
					{
						subHull2.m_EdgeVertexIndices.Add(dictionary3[key2]);
					}
				}
			}
			else
			{
				SubHull subHull3 = this.m_FirstSubHull;
				if (list2.Count == 3)
				{
					subHull3 = this.m_SecondSubHull;
				}
				for (int n = k; n < k + 3; n++)
				{
					int key3 = this.m_Triangles[n];
					Dictionary<int, int> dictionary4 = dictionary[subHull3];
					if (dictionary4.ContainsKey(key3))
					{
						subHull3.m_Triangles.Add(dictionary4[key3]);
					}
				}
			}
		}
		this.m_FirstSubHull.CalculateEdges();
		this.m_SecondSubHull.CalculateEdges();
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x0001DD28 File Offset: 0x0001BF28
	public void FixUpSubHulls(Vector3 impactForce)
	{
		for (int i = 0; i < 2; i++)
		{
			SubHull subHull;
			if (i == 0)
			{
				subHull = this.m_FirstSubHull;
			}
			else
			{
				subHull = this.m_SecondSubHull;
			}
			Vector3 vector = Vector3.zero;
			Vector4 vector2 = Vector4.zero;
			Vector2 vector3 = Vector2.zero;
			foreach (int index in subHull.m_EdgeVertexIndexToOtherEdgeVertexIndices.Keys)
			{
				vector += subHull.m_Vertices[index];
				vector2 += subHull.m_Tangents[index];
				vector3 += subHull.m_Uvs[index];
			}
			int count = subHull.m_EdgeVertexIndexToOtherEdgeVertexIndices.Count;
			vector /= (float)count;
			vector2 /= (float)count;
			vector3 /= (float)count;
			subHull.m_Vertices.Add(vector);
			subHull.m_Tangents.Add(vector2);
			subHull.m_Uvs.Add(vector3);
			if (i == 0)
			{
				subHull.m_Normals.Add(-impactForce.normalized);
			}
			else
			{
				subHull.m_Normals.Add(impactForce.normalized);
			}
			foreach (int num in subHull.m_EdgeVertexIndexToOtherEdgeVertexIndices.Keys)
			{
				List<int> list = subHull.m_EdgeVertexIndexToOtherEdgeVertexIndices[num];
				foreach (int item in list)
				{
					subHull.m_Triangles.Add(subHull.m_Vertices.Count - 1);
					subHull.m_Triangles.Add(item);
					subHull.m_Triangles.Add(num);
				}
			}
		}
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x0001DF78 File Offset: 0x0001C178
	private List<int> GetIntersectedTriangleIndices(Vector3 impactPoint, float impactRadius)
	{
		List<int> list = new List<int>();
		for (int i = 0; i < this.m_Triangles.Count; i += 3)
		{
			if (this.IsTriangleIndexIntersected(i, impactPoint, impactRadius))
			{
				list.Add(i);
			}
		}
		return list;
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x0001DFC0 File Offset: 0x0001C1C0
	private bool IsTriangleIndexIntersected(int triangleIndex, Vector3 impactPoint, float impactRadius)
	{
		if (triangleIndex % 3 != 0)
		{
			Debug.LogError("Invalid Triangle index: " + triangleIndex + "  Must be a multiple of 3!");
			return false;
		}
		Vector3 vector = this.m_Vertices[this.m_Triangles[triangleIndex]] - impactPoint;
		Vector3 vector2 = this.m_Vertices[this.m_Triangles[triangleIndex + 1]] - impactPoint;
		Vector3 vector3 = this.m_Vertices[this.m_Triangles[triangleIndex + 2]] - impactPoint;
		float num = impactRadius * impactRadius;
		Vector3 vector4 = Vector3.Cross(vector2 - vector, vector3 - vector);
		float num2 = Vector3.Dot(vector, vector4);
		float num3 = Vector3.Dot(vector4, vector4);
		bool flag = num2 * num2 > num * num3;
		if (flag)
		{
			return false;
		}
		float num4 = Vector3.Dot(vector, vector);
		float num5 = Vector3.Dot(vector, vector2);
		float num6 = Vector3.Dot(vector, vector3);
		float num7 = Vector3.Dot(vector2, vector2);
		float num8 = Vector3.Dot(vector2, vector3);
		float num9 = Vector3.Dot(vector3, vector3);
		bool flag2 = num4 > num && num5 > num4 && num6 > num4;
		bool flag3 = num7 > num && num5 > num7 && num8 > num7;
		bool flag4 = num9 > num && num6 > num9 && num8 > num9;
		if (flag2 || flag3 || flag4)
		{
			return false;
		}
		Vector3 vector5 = vector2 - vector;
		Vector3 vector6 = vector3 - vector2;
		Vector3 vector7 = vector - vector3;
		float d = num5 - num4;
		float d2 = num8 - num7;
		float d3 = num6 - num9;
		float num10 = Vector3.Dot(vector5, vector5);
		float num11 = Vector3.Dot(vector6, vector6);
		float num12 = Vector3.Dot(vector7, vector7);
		Vector3 vector8 = vector5 * num10 - d * vector5;
		Vector3 vector9 = vector6 * num11 - d2 * vector6;
		Vector3 vector10 = vector7 * num12 - d3 * vector7;
		Vector3 rhs = vector3 * num10 - vector8;
		Vector3 rhs2 = vector * num11 - vector9;
		Vector3 rhs3 = vector2 * num12 - vector10;
		bool flag5 = Vector3.Dot(vector8, vector8) > num * num10 * num10 && Vector3.Dot(vector8, rhs) > 0f;
		bool flag6 = Vector3.Dot(vector9, vector9) > num * num11 * num11 && Vector3.Dot(vector9, rhs2) > 0f;
		bool flag7 = Vector3.Dot(vector10, vector10) > num * num12 * num12 && Vector3.Dot(vector10, rhs3) > 0f;
		return !flag5 && !flag6 && !flag7;
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x0001E29C File Offset: 0x0001C49C
	private List<int> BreakDownTriangle(int triangleIndex)
	{
		List<int> list = new List<int>();
		list.Add(triangleIndex);
		if (this.m_Vertices.Count > 64988)
		{
			return list;
		}
		int index = this.m_Triangles[triangleIndex];
		int index2 = this.m_Triangles[triangleIndex + 1];
		int index3 = this.m_Triangles[triangleIndex + 2];
		Vector3 a = this.m_Vertices[index];
		Vector3 vector = this.m_Vertices[index2];
		Vector3 vector2 = this.m_Vertices[index3];
		Vector3 item = (a + vector) / 2f;
		Vector3 item2 = (a + vector2) / 2f;
		Vector3 item3 = (vector + vector2) / 2f;
		this.m_Vertices.Add(item);
		this.m_Vertices.Add(item2);
		this.m_Triangles[triangleIndex + 1] = this.m_Vertices.Count - 2;
		this.m_Triangles[triangleIndex + 2] = this.m_Vertices.Count - 1;
		this.m_Vertices.Add(item2);
		this.m_Vertices.Add(item3);
		this.m_Vertices.Add(vector2);
		this.m_Triangles.Add(this.m_Vertices.Count - 2);
		this.m_Triangles.Add(this.m_Vertices.Count - 1);
		this.m_Triangles.Add(this.m_Vertices.Count - 3);
		list.Add(this.m_Triangles.Count - 3);
		this.m_Vertices.Add(item);
		this.m_Vertices.Add(item3);
		this.m_Vertices.Add(vector);
		this.m_Triangles.Add(this.m_Vertices.Count - 1);
		this.m_Triangles.Add(this.m_Vertices.Count - 2);
		this.m_Triangles.Add(this.m_Vertices.Count - 3);
		list.Add(this.m_Triangles.Count - 3);
		this.m_Vertices.Add(item);
		this.m_Vertices.Add(item3);
		this.m_Vertices.Add(item2);
		this.m_Triangles.Add(this.m_Vertices.Count - 2);
		this.m_Triangles.Add(this.m_Vertices.Count - 1);
		this.m_Triangles.Add(this.m_Vertices.Count - 3);
		list.Add(this.m_Triangles.Count - 3);
		if (this.m_Normals.Count > 0)
		{
			Vector3 a2 = this.m_Normals[index];
			Vector3 vector3 = this.m_Normals[index2];
			Vector3 vector4 = this.m_Normals[index3];
			Vector3 item4 = (a2 + vector3) / 2f;
			Vector3 item5 = (a2 + vector4) / 2f;
			Vector3 item6 = (vector3 + vector4) / 2f;
			this.m_Normals.Add(item4);
			this.m_Normals.Add(item5);
			this.m_Normals.Add(item5);
			this.m_Normals.Add(item6);
			this.m_Normals.Add(vector4);
			this.m_Normals.Add(item4);
			this.m_Normals.Add(item6);
			this.m_Normals.Add(vector3);
			this.m_Normals.Add(item4);
			this.m_Normals.Add(item6);
			this.m_Normals.Add(item5);
		}
		if (this.m_Tangents.Count > 0)
		{
			Vector4 a3 = this.m_Tangents[index];
			Vector4 vector5 = this.m_Tangents[index2];
			Vector4 vector6 = this.m_Tangents[index3];
			Vector4 item7 = (a3 + vector5) / 2f;
			Vector4 item8 = (a3 + vector6) / 2f;
			Vector4 item9 = (vector5 + vector6) / 2f;
			this.m_Tangents.Add(item7);
			this.m_Tangents.Add(item8);
			this.m_Tangents.Add(item8);
			this.m_Tangents.Add(item9);
			this.m_Tangents.Add(vector6);
			this.m_Tangents.Add(item7);
			this.m_Tangents.Add(item9);
			this.m_Tangents.Add(vector5);
			this.m_Tangents.Add(item7);
			this.m_Tangents.Add(item9);
			this.m_Tangents.Add(item8);
		}
		if (this.m_Uvs.Count > 0)
		{
			Vector2 a4 = this.m_Uvs[index];
			Vector2 vector7 = this.m_Uvs[index2];
			Vector2 vector8 = this.m_Uvs[index3];
			Vector2 item10 = (a4 + vector7) / 2f;
			Vector2 item11 = (a4 + vector8) / 2f;
			Vector2 item12 = (vector7 + vector8) / 2f;
			this.m_Uvs.Add(item10);
			this.m_Uvs.Add(item11);
			this.m_Uvs.Add(item11);
			this.m_Uvs.Add(item12);
			this.m_Uvs.Add(vector8);
			this.m_Uvs.Add(item10);
			this.m_Uvs.Add(item12);
			this.m_Uvs.Add(vector7);
			this.m_Uvs.Add(item10);
			this.m_Uvs.Add(item12);
			this.m_Uvs.Add(item11);
		}
		return list;
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x0001E854 File Offset: 0x0001CA54
	private float GetAreaOfTriangle(int triangleIndex)
	{
		Vector3 a = this.m_Vertices[this.m_Triangles[triangleIndex]];
		Vector3 b = this.m_Vertices[this.m_Triangles[triangleIndex + 1]];
		Vector3 b2 = this.m_Vertices[this.m_Triangles[triangleIndex + 2]];
		return Vector3.Cross(a - b, a - b2).magnitude * 0.5f;
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x0001E8D0 File Offset: 0x0001CAD0
	private int GetIndexOfLargestTriangle(Dictionary<int, float> triangleIndexToTriangleArea)
	{
		int result = 0;
		float num = 0f;
		foreach (int num2 in triangleIndexToTriangleArea.Keys)
		{
			float num3 = triangleIndexToTriangleArea[num2];
			if (num3 > num)
			{
				result = num2;
				num = num3;
			}
		}
		return result;
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x0001E950 File Offset: 0x0001CB50
	public bool IsEmpty()
	{
		return this.m_Vertices.Count < 3 || this.m_Triangles.Count < 3;
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x0001E980 File Offset: 0x0001CB80
	public Mesh GetMesh()
	{
		if (!this.IsEmpty())
		{
			Mesh mesh = new Mesh();
			mesh.vertices = this.m_Vertices.ToArray();
			mesh.triangles = this.m_Triangles.ToArray();
			if (this.m_Normals != null)
			{
				mesh.normals = this.m_Normals.ToArray();
			}
			if (this.m_Tangents != null)
			{
				mesh.tangents = this.m_Tangents.ToArray();
			}
			if (this.m_Uvs != null)
			{
				mesh.uv = this.m_Uvs.ToArray();
			}
			mesh.RecalculateBounds();
			return mesh;
		}
		return null;
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x0001EA20 File Offset: 0x0001CC20
	public Mesh GetSubHullMesh()
	{
		if (this.m_SecondSubHull != null && !this.m_SecondSubHull.IsEmpty())
		{
			return this.m_SecondSubHull.GetMesh();
		}
		return null;
	}

	// Token: 0x04000685 RID: 1669
	private const int c_MinTrianglesPerImpact = 48;

	// Token: 0x04000686 RID: 1670
	private const float c_CompressionResistance = 0.95f;

	// Token: 0x04000687 RID: 1671
	private List<Vector3> m_Vertices;

	// Token: 0x04000688 RID: 1672
	private List<Vector3> m_Normals;

	// Token: 0x04000689 RID: 1673
	private List<Vector4> m_Tangents;

	// Token: 0x0400068A RID: 1674
	private List<Vector2> m_Uvs;

	// Token: 0x0400068B RID: 1675
	private List<int> m_Triangles;

	// Token: 0x0400068C RID: 1676
	private SubHull m_FirstSubHull;

	// Token: 0x0400068D RID: 1677
	private SubHull m_SecondSubHull;
}
