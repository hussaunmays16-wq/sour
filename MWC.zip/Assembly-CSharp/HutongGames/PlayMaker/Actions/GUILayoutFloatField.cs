﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F9 RID: 505
	[Tooltip("GUILayout Text Field to edit a Float Variable. Optionally send an event if the text has been edited.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutFloatField : GUILayoutAction
	{
		// Token: 0x060008B8 RID: 2232 RVA: 0x0003A654 File Offset: 0x00038854
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.style = string.Empty;
			this.changedEvent = null;
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x0003A688 File Offset: 0x00038888
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			if (!string.IsNullOrEmpty(this.style.Value))
			{
				this.floatVariable.Value = float.Parse(GUILayout.TextField(this.floatVariable.Value.ToString(), this.style.Value, base.LayoutOptions));
			}
			else
			{
				this.floatVariable.Value = float.Parse(GUILayout.TextField(this.floatVariable.Value.ToString(), base.LayoutOptions));
			}
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C72 RID: 3186
		[Tooltip("Float Variable to show in the edit field.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x04000C73 RID: 3187
		[Tooltip("Optional GUIStyle in the active GUISKin.")]
		public FsmString style;

		// Token: 0x04000C74 RID: 3188
		[Tooltip("Optional event to send when the value changes.")]
		public FsmEvent changedEvent;
	}
}
