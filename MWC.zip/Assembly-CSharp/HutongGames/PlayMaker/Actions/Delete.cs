﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200019F RID: 415
	[ActionCategory("Easy Save 2")]
	[Tooltip("Checks if data Delete at the specified path.")]
	public class Delete : FsmStateAction
	{
		// Token: 0x0600077E RID: 1918 RVA: 0x00035714 File Offset: 0x00033914
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x00035744 File Offset: 0x00033944
		public override void OnEnter()
		{
			string text;
			if (this.uniqueTag.Value != string.Empty)
			{
				text = this.saveFile.Value + "?tag=" + this.uniqueTag.Value;
			}
			else
			{
				text = this.saveFile.Value;
			}
			ES2.Delete(text);
			this.Log("Deleted " + text);
			base.Finish();
		}

		// Token: 0x04000B0F RID: 2831
		[Tooltip("The tag that we want to delete (Optional).")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000B10 RID: 2832
		[Tooltip("The file we want to delete, or delete the tag from.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
