﻿using System;
using UnityEngine;

// Token: 0x02000454 RID: 1108
[AddComponentMenu("Image Effects/Color Correction")]
[ExecuteInEditMode]
public class ColorCorrectionEffect : ImageEffectBase
{
	// Token: 0x06001299 RID: 4761 RVA: 0x00068A10 File Offset: 0x00066C10
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		base.material.SetTexture("_RampTex", this.textureRamp);
		base.material.SetVector("_RampOffset", new Vector4(this.rampOffsetR, this.rampOffsetG, this.rampOffsetB, 0f));
		Graphics.Blit(source, destination, base.material);
	}

	// Token: 0x04001842 RID: 6210
	public Texture textureRamp;

	// Token: 0x04001843 RID: 6211
	public float rampOffsetR;

	// Token: 0x04001844 RID: 6212
	public float rampOffsetG;

	// Token: 0x04001845 RID: 6213
	public float rampOffsetB;
}
