﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E1 RID: 993
	[Tooltip("Loads all filenames the SQL database contains into a PlayMaker Array List Proxy component. http://docs.moodkie.com/easy-save-2/api/es2web-getfilenames/. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class ArrayListGetDatabaseEntries : ArrayListActions
	{
		// Token: 0x060010CF RID: 4303 RVA: 0x0005C308 File Offset: 0x0005A508
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.username = string.Empty;
			this.password = string.Empty;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010D0 RID: 4304 RVA: 0x0005C37C File Offset: 0x0005A57C
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DownloadArrayList();
			}
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x0005C3B8 File Offset: 0x0005A5B8
		private void DownloadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.DownloadFilenames());
			Debug.Log("Downloading from" + this.urlToPHPFile.Value);
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x0005C454 File Offset: 0x0005A654
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				string[] filenames = this.web.GetFilenames();
				this.proxy.arrayList.Clear();
				foreach (string text in filenames)
				{
					this.proxy.arrayList.Add(text);
					Debug.LogWarning(text);
				}
				base.Finish();
			}
		}

		// Token: 0x040015E2 RID: 5602
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015E3 RID: 5603
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015E4 RID: 5604
		[ActionSection("Download Set up")]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[RequiredField]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x040015E5 RID: 5605
		[RequiredField]
		[Tooltip("The username that you have specified in your ES2.php file.")]
		public FsmString username = "ES2";

		// Token: 0x040015E6 RID: 5606
		[RequiredField]
		[Tooltip("The password that you have specified in your ES2.php file.")]
		public FsmString password = string.Empty;

		// Token: 0x040015E7 RID: 5607
		[ActionSection("Result")]
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x040015E8 RID: 5608
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x040015E9 RID: 5609
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x040015EA RID: 5610
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015EB RID: 5611
		private ES2Web web;

		// Token: 0x040015EC RID: 5612
		private string _tag;
	}
}
