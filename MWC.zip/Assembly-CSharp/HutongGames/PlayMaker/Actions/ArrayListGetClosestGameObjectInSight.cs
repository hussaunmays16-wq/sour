﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D4 RID: 980
	[Tooltip("Return the closest GameObject within an arrayList from a transform or position which does not have a collider between itself and another GameObject")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetClosestGameObjectInSight : ArrayListActions
	{
		// Token: 0x0600108C RID: 4236 RVA: 0x00059EF4 File Offset: 0x000580F4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.distanceFrom = null;
			this.orDistanceFromVector3 = null;
			this.closestGameObject = null;
			this.closestIndex = null;
			this.everyframe = true;
			this.fromGameObject = null;
			this.layerMask = new FsmInt[0];
			this.invertMask = false;
		}

		// Token: 0x0600108D RID: 4237 RVA: 0x00059F54 File Offset: 0x00058154
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindClosestGo();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x0600108E RID: 4238 RVA: 0x00059FA8 File Offset: 0x000581A8
		public override void OnUpdate()
		{
			this.DoFindClosestGo();
		}

		// Token: 0x0600108F RID: 4239 RVA: 0x00059FB0 File Offset: 0x000581B0
		private void DoFindClosestGo()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			Vector3 vector = this.orDistanceFromVector3.Value;
			GameObject value = this.distanceFrom.Value;
			if (value != null)
			{
				vector += value.transform.position;
			}
			float num = float.PositiveInfinity;
			int num2 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject gameObject = (GameObject)obj;
				if (gameObject != null && this.DoLineCast(gameObject))
				{
					float sqrMagnitude = (gameObject.transform.position - vector).sqrMagnitude;
					if (sqrMagnitude <= num)
					{
						num = sqrMagnitude;
						this.closestGameObject.Value = gameObject;
						this.closestIndex.Value = num2;
					}
				}
				num2++;
			}
		}

		// Token: 0x06001090 RID: 4240 RVA: 0x0005A0D0 File Offset: 0x000582D0
		private bool DoLineCast(GameObject toGameObject)
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.fromGameObject);
			Vector3 position = ownerDefaultTarget.transform.position;
			Vector3 position2 = toGameObject.transform.position;
			RaycastHit raycastHitInfo;
			bool result = !Physics.Linecast(position, position2, out raycastHitInfo, ActionHelpers.LayerArrayToLayerMask(this.layerMask, this.invertMask.Value));
			base.Fsm.RaycastHitInfo = raycastHitInfo;
			return result;
		}

		// Token: 0x0400156E RID: 5486
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400156F RID: 5487
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001570 RID: 5488
		[Tooltip("Compare the distance of the items in the list to the position of this gameObject")]
		public FsmGameObject distanceFrom;

		// Token: 0x04001571 RID: 5489
		[Tooltip("If DistanceFrom declared, use OrDistanceFromVector3 as an offset")]
		public FsmVector3 orDistanceFromVector3;

		// Token: 0x04001572 RID: 5490
		public bool everyframe;

		// Token: 0x04001573 RID: 5491
		[ActionSection("Raycast Settings")]
		[Tooltip("The line start of the sweep.")]
		public FsmOwnerDefault fromGameObject;

		// Token: 0x04001574 RID: 5492
		[UIHint(UIHint.Layer)]
		[Tooltip("Pick only from these layers.")]
		public FsmInt[] layerMask;

		// Token: 0x04001575 RID: 5493
		[Tooltip("Invert the mask, so you pick from all layers except those defined above.")]
		public FsmBool invertMask;

		// Token: 0x04001576 RID: 5494
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmGameObject closestGameObject;

		// Token: 0x04001577 RID: 5495
		[UIHint(UIHint.Variable)]
		public FsmInt closestIndex;
	}
}
