﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D4 RID: 468
	[Tooltip("Interpolates between 2 Float values over a specified Time.")]
	[ActionCategory(ActionCategory.Math)]
	public class FloatInterpolate : FsmStateAction
	{
		// Token: 0x0600083B RID: 2107 RVA: 0x00038A44 File Offset: 0x00036C44
		public override void Reset()
		{
			this.mode = InterpolationType.Linear;
			this.fromFloat = null;
			this.toFloat = null;
			this.time = 1f;
			this.storeResult = null;
			this.finishEvent = null;
			this.realTime = false;
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00038A8C File Offset: 0x00036C8C
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.currentTime = 0f;
			if (this.storeResult == null)
			{
				base.Finish();
			}
			else
			{
				this.storeResult.Value = this.fromFloat.Value;
			}
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00038ADC File Offset: 0x00036CDC
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.currentTime = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.currentTime += Time.deltaTime;
			}
			float num = this.currentTime / this.time.Value;
			InterpolationType interpolationType = this.mode;
			if (interpolationType != InterpolationType.Linear)
			{
				if (interpolationType == InterpolationType.EaseInOut)
				{
					this.storeResult.Value = Mathf.SmoothStep(this.fromFloat.Value, this.toFloat.Value, num);
				}
			}
			else
			{
				this.storeResult.Value = Mathf.Lerp(this.fromFloat.Value, this.toFloat.Value, num);
			}
			if (num > 1f)
			{
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
				base.Finish();
			}
		}

		// Token: 0x04000BDA RID: 3034
		[Tooltip("Interpolation mode: Linear or EaseInOut.")]
		public InterpolationType mode;

		// Token: 0x04000BDB RID: 3035
		[RequiredField]
		[Tooltip("Interpolate from this value.")]
		public FsmFloat fromFloat;

		// Token: 0x04000BDC RID: 3036
		[RequiredField]
		[Tooltip("Interpolate to this value.")]
		public FsmFloat toFloat;

		// Token: 0x04000BDD RID: 3037
		[RequiredField]
		[Tooltip("Interpolate over this amount of time in seconds.")]
		public FsmFloat time;

		// Token: 0x04000BDE RID: 3038
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store the current value in a float variable.")]
		public FsmFloat storeResult;

		// Token: 0x04000BDF RID: 3039
		[Tooltip("Event to send when the interpolation is finished.")]
		public FsmEvent finishEvent;

		// Token: 0x04000BE0 RID: 3040
		[Tooltip("Ignore TimeScale. Useful if the game is paused (Time scaled to 0).")]
		public bool realTime;

		// Token: 0x04000BE1 RID: 3041
		private float startTime;

		// Token: 0x04000BE2 RID: 3042
		private float currentTime;
	}
}
