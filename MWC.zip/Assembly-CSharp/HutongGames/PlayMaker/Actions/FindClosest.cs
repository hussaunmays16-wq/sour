﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C9 RID: 457
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Finds the closest object to the specified Game Object.\nOptionally filter by Tag and Visibility.")]
	public class FindClosest : FsmStateAction
	{
		// Token: 0x0600080A RID: 2058 RVA: 0x0003810C File Offset: 0x0003630C
		public override void Reset()
		{
			this.gameObject = null;
			this.withTag = "Untagged";
			this.ignoreOwner = true;
			this.mustBeVisible = false;
			this.storeObject = null;
			this.storeDistance = null;
			this.everyFrame = false;
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00038160 File Offset: 0x00036360
		public override void OnEnter()
		{
			this.DoFindClosest();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x0003817C File Offset: 0x0003637C
		public override void OnUpdate()
		{
			this.DoFindClosest();
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00038184 File Offset: 0x00036384
		private void DoFindClosest()
		{
			GameObject gameObject = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			GameObject[] array;
			if (string.IsNullOrEmpty(this.withTag.Value) || this.withTag.Value == "Untagged")
			{
				array = (GameObject[])UnityEngine.Object.FindObjectsOfType(typeof(GameObject));
			}
			else
			{
				array = GameObject.FindGameObjectsWithTag(this.withTag.Value);
			}
			GameObject value = null;
			float num = float.PositiveInfinity;
			foreach (GameObject gameObject2 in array)
			{
				if (!this.ignoreOwner.Value || !(gameObject2 == base.Owner))
				{
					if (!this.mustBeVisible.Value || ActionHelpers.IsVisible(gameObject2))
					{
						float sqrMagnitude = (gameObject.transform.position - gameObject2.transform.position).sqrMagnitude;
						if (sqrMagnitude < num)
						{
							num = sqrMagnitude;
							value = gameObject2;
						}
					}
				}
			}
			this.storeObject.Value = value;
			if (!this.storeDistance.IsNone)
			{
				this.storeDistance.Value = Mathf.Sqrt(num);
			}
		}

		// Token: 0x04000BAE RID: 2990
		[RequiredField]
		[Tooltip("The GameObject to measure from.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000BAF RID: 2991
		[RequiredField]
		[UIHint(UIHint.Tag)]
		[Tooltip("Only consider objects with this Tag. NOTE: It's generally a lot quicker to find objects with a Tag!")]
		public FsmString withTag;

		// Token: 0x04000BB0 RID: 2992
		[Tooltip("If checked, ignores the object that owns this FSM.")]
		public FsmBool ignoreOwner;

		// Token: 0x04000BB1 RID: 2993
		[Tooltip("Only consider objects visible to the camera.")]
		public FsmBool mustBeVisible;

		// Token: 0x04000BB2 RID: 2994
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the closest object.")]
		public FsmGameObject storeObject;

		// Token: 0x04000BB3 RID: 2995
		[Tooltip("Store the distance to the closest object.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeDistance;

		// Token: 0x04000BB4 RID: 2996
		[Tooltip("Repeat every frame")]
		public bool everyFrame;
	}
}
