﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000202 RID: 514
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("GUILayout Text Field. Optionally send an event if the text has been edited.")]
	public class GUILayoutTextField : GUILayoutAction
	{
		// Token: 0x060008D3 RID: 2259 RVA: 0x0003ADDC File Offset: 0x00038FDC
		public override void Reset()
		{
			base.Reset();
			this.text = null;
			this.maxLength = 25;
			this.style = "TextField";
			this.changedEvent = null;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x0003AE10 File Offset: 0x00039010
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.text.Value = GUILayout.TextField(this.text.Value, this.maxLength.Value, this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C92 RID: 3218
		[UIHint(UIHint.Variable)]
		public FsmString text;

		// Token: 0x04000C93 RID: 3219
		public FsmInt maxLength;

		// Token: 0x04000C94 RID: 3220
		public FsmString style;

		// Token: 0x04000C95 RID: 3221
		public FsmEvent changedEvent;
	}
}
