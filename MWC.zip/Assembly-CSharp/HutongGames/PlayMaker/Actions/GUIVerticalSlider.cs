﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000208 RID: 520
	[Tooltip("GUI Vertical Slider connected to a Float Variable.")]
	[ActionCategory(ActionCategory.GUI)]
	public class GUIVerticalSlider : GUIAction
	{
		// Token: 0x060008E8 RID: 2280 RVA: 0x0003B410 File Offset: 0x00039610
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.topValue = 100f;
			this.bottomValue = 0f;
			this.sliderStyle = "verticalslider";
			this.thumbStyle = "verticalsliderthumb";
			this.width = 0.1f;
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x0003B47C File Offset: 0x0003967C
		public override void OnGUI()
		{
			base.OnGUI();
			if (this.floatVariable != null)
			{
				this.floatVariable.Value = GUI.VerticalSlider(this.rect, this.floatVariable.Value, this.topValue.Value, this.bottomValue.Value, (!(this.sliderStyle.Value != string.Empty)) ? "verticalslider" : this.sliderStyle.Value, (!(this.thumbStyle.Value != string.Empty)) ? "verticalsliderthumb" : this.thumbStyle.Value);
			}
		}

		// Token: 0x04000CAB RID: 3243
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000CAC RID: 3244
		[RequiredField]
		public FsmFloat topValue;

		// Token: 0x04000CAD RID: 3245
		[RequiredField]
		public FsmFloat bottomValue;

		// Token: 0x04000CAE RID: 3246
		public FsmString sliderStyle;

		// Token: 0x04000CAF RID: 3247
		public FsmString thumbStyle;
	}
}
