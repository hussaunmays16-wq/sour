﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FC RID: 508
	[Tooltip("GUILayout Text Field to edit an Int Variable. Optionally send an event if the text has been edited.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutIntField : GUILayoutAction
	{
		// Token: 0x060008C1 RID: 2241 RVA: 0x0003A900 File Offset: 0x00038B00
		public override void Reset()
		{
			base.Reset();
			this.intVariable = null;
			this.style = string.Empty;
			this.changedEvent = null;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x0003A934 File Offset: 0x00038B34
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			if (!string.IsNullOrEmpty(this.style.Value))
			{
				this.intVariable.Value = int.Parse(GUILayout.TextField(this.intVariable.Value.ToString(), this.style.Value, base.LayoutOptions));
			}
			else
			{
				this.intVariable.Value = int.Parse(GUILayout.TextField(this.intVariable.Value.ToString(), base.LayoutOptions));
			}
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C7C RID: 3196
		[Tooltip("Int Variable to show in the edit field.")]
		[UIHint(UIHint.Variable)]
		public FsmInt intVariable;

		// Token: 0x04000C7D RID: 3197
		[Tooltip("Optional GUIStyle in the active GUISKin.")]
		public FsmString style;

		// Token: 0x04000C7E RID: 3198
		[Tooltip("Optional event to send when the value changes.")]
		public FsmEvent changedEvent;
	}
}
