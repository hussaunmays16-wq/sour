﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000185 RID: 389
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Draws a line from a Start point in a direction. Specify the start point as Game Objects or Vector3 world positions. If both are specified, position is used as a local offset from the Object's position.")]
	public class DrawDebugRay : FsmStateAction
	{
		// Token: 0x0600071A RID: 1818 RVA: 0x00031CD0 File Offset: 0x0002FED0
		public override void Reset()
		{
			this.fromObject = new FsmGameObject
			{
				UseVariable = true
			};
			this.fromPosition = new FsmVector3
			{
				UseVariable = true
			};
			this.direction = new FsmVector3
			{
				UseVariable = true
			};
			this.color = Color.white;
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x00031D2C File Offset: 0x0002FF2C
		public override void OnUpdate()
		{
			Vector3 position = ActionHelpers.GetPosition(this.fromObject, this.fromPosition);
			Debug.DrawRay(position, this.direction.Value, this.color.Value);
		}

		// Token: 0x04000A01 RID: 2561
		[Tooltip("Draw ray from a GameObject.")]
		public FsmGameObject fromObject;

		// Token: 0x04000A02 RID: 2562
		[Tooltip("Draw ray from a world position, or local offset from GameObject if provided.")]
		public FsmVector3 fromPosition;

		// Token: 0x04000A03 RID: 2563
		[Tooltip("Direction vector of ray.")]
		public FsmVector3 direction;

		// Token: 0x04000A04 RID: 2564
		[Tooltip("The color of the ray.")]
		public FsmColor color;
	}
}
