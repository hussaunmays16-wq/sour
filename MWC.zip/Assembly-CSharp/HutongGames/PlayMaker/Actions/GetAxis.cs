﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000212 RID: 530
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Gets the value of the specified Input Axis and stores it in a Float Variable. See Unity Input Manager docs.")]
	public class GetAxis : FsmStateAction
	{
		// Token: 0x06000915 RID: 2325 RVA: 0x0003BCD8 File Offset: 0x00039ED8
		public override void Reset()
		{
			this.axisName = string.Empty;
			this.multiplier = 1f;
			this.store = null;
			this.everyFrame = true;
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x0003BD14 File Offset: 0x00039F14
		public override void OnEnter()
		{
			this.DoGetAxis();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000917 RID: 2327 RVA: 0x0003BD30 File Offset: 0x00039F30
		public override void OnUpdate()
		{
			this.DoGetAxis();
		}

		// Token: 0x06000918 RID: 2328 RVA: 0x0003BD38 File Offset: 0x00039F38
		private void DoGetAxis()
		{
			float num = Input.GetAxis(this.axisName.Value);
			if (!this.multiplier.IsNone)
			{
				num *= this.multiplier.Value;
			}
			this.store.Value = num;
		}

		// Token: 0x04000CDE RID: 3294
		[RequiredField]
		[Tooltip("The name of the axis. Set in the Unity Input Manager.")]
		public FsmString axisName;

		// Token: 0x04000CDF RID: 3295
		[Tooltip("Axis values are in the range -1 to 1. Use the multiplier to set a larger range.")]
		public FsmFloat multiplier;

		// Token: 0x04000CE0 RID: 3296
		[Tooltip("Store the result in a float variable.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat store;

		// Token: 0x04000CE1 RID: 3297
		[Tooltip("Repeat every frame. Typically this would be set to True.")]
		public bool everyFrame;
	}
}
