﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DF RID: 991
	[Tooltip("Saves a PlayMaker Array List Proxy component to MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class ArrayListEasyUpload : ArrayListActions
	{
		// Token: 0x060010C5 RID: 4293 RVA: 0x0005BBB8 File Offset: 0x00059DB8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x0005BC30 File Offset: 0x00059E30
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.UploadArrayList();
			}
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x0005BC6C File Offset: 0x00059E6C
		private void UploadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text))
			{
				text = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference.Value
				});
			}
			List<string> list = new List<string>();
			foreach (object item in this.proxy.arrayList)
			{
				list.Add(PlayMakerUtils.ParseValueToString(item));
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				text,
				"&webfilename=",
				this.saveFile.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Upload<string>(list));
			this.Log(string.Concat(new string[]
			{
				"Uploading to ",
				this.urlToPHPFile.Value,
				"?tag=",
				text,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x0005BE28 File Offset: 0x0005A028
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isUploaded);
				base.Finish();
			}
		}

		// Token: 0x040015C8 RID: 5576
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015C9 RID: 5577
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015CA RID: 5578
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015CB RID: 5579
		[Tooltip("The name of the file that we'll create to store our data. Leave as default if unsure.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015CC RID: 5580
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x040015CD RID: 5581
		[RequiredField]
		[Tooltip("The username that you have specified in your ES2.php file.")]
		public FsmString username = "ES2";

		// Token: 0x040015CE RID: 5582
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x040015CF RID: 5583
		[Tooltip("The Event to send if Upload succeeded.")]
		[ActionSection("Result")]
		public FsmEvent isUploaded;

		// Token: 0x040015D0 RID: 5584
		[Tooltip("The event to send if Upload failed.")]
		public FsmEvent isError;

		// Token: 0x040015D1 RID: 5585
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x040015D2 RID: 5586
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015D3 RID: 5587
		private ES2Web web;
	}
}
