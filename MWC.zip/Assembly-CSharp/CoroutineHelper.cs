﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020000B5 RID: 181
public static class CoroutineHelper
{
	// Token: 0x06000338 RID: 824 RVA: 0x00015468 File Offset: 0x00013668
	public static IEnumerator WaitForActualSeconds(float time)
	{
		float start = Time.realtimeSinceStartup;
		while (Time.realtimeSinceStartup < start + time)
		{
			yield return MasterAudio.EndOfFrameDelay;
		}
		yield break;
	}
}
