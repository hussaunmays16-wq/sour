﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200049C RID: 1180
	[ActionCategory("cInput")]
	[Tooltip("Set if an axis is inverted.")]
	public class CInputAxisInverted : FsmStateAction
	{
		// Token: 0x06001432 RID: 5170 RVA: 0x00088714 File Offset: 0x00086914
		public override void Reset()
		{
			this.invertAxis = null;
		}

		// Token: 0x06001433 RID: 5171 RVA: 0x00088720 File Offset: 0x00086920
		public override void OnUpdate()
		{
			cInput.AxisInverted(this.axisName.Value, this.invertAxis.Value);
		}

		// Token: 0x04001C9C RID: 7324
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001C9D RID: 7325
		[Tooltip("Invert the axis.")]
		public FsmBool invertAxis;
	}
}
