﻿using System;
using UnityEngine;

// Token: 0x02000471 RID: 1137
public class BlobShadowController : MonoBehaviour
{
	// Token: 0x0600131C RID: 4892 RVA: 0x0006C90C File Offset: 0x0006AB0C
	private void Start()
	{
		this.mTranform = base.transform;
	}

	// Token: 0x0600131D RID: 4893 RVA: 0x0006C91C File Offset: 0x0006AB1C
	private void Update()
	{
		this.mTranform.position = this.mTranform.parent.position + Vector3.up * 8.246965f;
		this.mTranform.rotation = Quaternion.LookRotation(-Vector3.up, this.mTranform.parent.forward);
	}

	// Token: 0x04001904 RID: 6404
	private Transform mTranform;
}
