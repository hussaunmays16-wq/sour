﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001A0 RID: 416
	[Tooltip("Checks if data exists at the specified path.")]
	[ActionCategory("Easy Save 2")]
	public class Exists : FsmStateAction
	{
		// Token: 0x06000781 RID: 1921 RVA: 0x000357F0 File Offset: 0x000339F0
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00035820 File Offset: 0x00033A20
		public override void OnEnter()
		{
			string text;
			if (this.uniqueTag.Value != string.Empty)
			{
				text = this.saveFile.Value + "?tag=" + this.uniqueTag.Value;
			}
			else
			{
				text = this.saveFile.Value;
			}
			this.Log("Checked existence of " + text);
			if (ES2.Exists(text))
			{
				base.Fsm.Event(this.ifExists);
			}
			else
			{
				base.Fsm.Event(this.ifDoesNotExist);
			}
		}

		// Token: 0x04000B11 RID: 2833
		[RequiredField]
		[Tooltip("The Event to send if this it does exist.")]
		public FsmEvent ifExists;

		// Token: 0x04000B12 RID: 2834
		[Tooltip("The event to sent if it doesn't exist.")]
		[RequiredField]
		public FsmEvent ifDoesNotExist;

		// Token: 0x04000B13 RID: 2835
		[Tooltip("The tag that we want to check for (Optional).")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000B14 RID: 2836
		[Tooltip("The file we want to check the existence of.")]
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";
	}
}
