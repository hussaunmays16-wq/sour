﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000215 RID: 533
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Gets the pressed state of the specified Button and stores it in a Bool Variable. See Unity Input Manager docs.")]
	public class GetButton : FsmStateAction
	{
		// Token: 0x0600091D RID: 2333 RVA: 0x0003BFE8 File Offset: 0x0003A1E8
		public override void Reset()
		{
			this.buttonName = "Fire1";
			this.storeResult = null;
			this.everyFrame = true;
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x0003C008 File Offset: 0x0003A208
		public override void OnEnter()
		{
			this.DoGetButton();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600091F RID: 2335 RVA: 0x0003C024 File Offset: 0x0003A224
		public override void OnUpdate()
		{
			this.DoGetButton();
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x0003C02C File Offset: 0x0003A22C
		private void DoGetButton()
		{
			this.storeResult.Value = cInput.GetKey(this.buttonName.Value);
		}

		// Token: 0x04000CED RID: 3309
		[Tooltip("The name of the button. Set in the Unity Input Manager.")]
		[RequiredField]
		public FsmString buttonName;

		// Token: 0x04000CEE RID: 3310
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a bool variable.")]
		public FsmBool storeResult;

		// Token: 0x04000CEF RID: 3311
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
