﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000161 RID: 353
	[Tooltip("Moves a Game Object with a Character Controller. Velocity along the y-axis is ignored. Speed is in meters/s. Gravity is automatically applied.")]
	[ActionCategory(ActionCategory.Character)]
	public class ControllerSimpleMove : FsmStateAction
	{
		// Token: 0x06000695 RID: 1685 RVA: 0x00030868 File Offset: 0x0002EA68
		public override void Reset()
		{
			this.gameObject = null;
			this.moveVector = new FsmVector3
			{
				UseVariable = true
			};
			this.speed = 1f;
			this.space = Space.World;
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x000308A8 File Offset: 0x0002EAA8
		public override void OnUpdate()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.previousGo)
			{
				this.controller = ownerDefaultTarget.GetComponent<CharacterController>();
				this.previousGo = ownerDefaultTarget;
			}
			if (this.controller != null)
			{
				Vector3 a = (this.space != Space.World) ? ownerDefaultTarget.transform.TransformDirection(this.moveVector.Value) : this.moveVector.Value;
				this.controller.SimpleMove(a * this.speed.Value);
			}
		}

		// Token: 0x0400098E RID: 2446
		[RequiredField]
		[CheckForComponent(typeof(CharacterController))]
		[Tooltip("The GameObject to move.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400098F RID: 2447
		[Tooltip("The movement vector.")]
		[RequiredField]
		public FsmVector3 moveVector;

		// Token: 0x04000990 RID: 2448
		[Tooltip("Multiply the movement vector by a speed factor.")]
		public FsmFloat speed;

		// Token: 0x04000991 RID: 2449
		[Tooltip("Move in local or word space.")]
		public Space space;

		// Token: 0x04000992 RID: 2450
		private GameObject previousGo;

		// Token: 0x04000993 RID: 2451
		private CharacterController controller;
	}
}
