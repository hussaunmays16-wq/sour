﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D9 RID: 473
	[Tooltip("Subtracts a value from a Float Variable.")]
	[ActionCategory(ActionCategory.Math)]
	public class FloatSubtract : FsmStateAction
	{
		// Token: 0x0600084E RID: 2126 RVA: 0x00038E38 File Offset: 0x00037038
		public override void Reset()
		{
			this.floatVariable = null;
			this.subtract = null;
			this.everyFrame = false;
			this.perSecond = false;
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00038E58 File Offset: 0x00037058
		public override void OnEnter()
		{
			this.DoFloatSubtract();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00038E74 File Offset: 0x00037074
		public override void OnUpdate()
		{
			this.DoFloatSubtract();
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00038E7C File Offset: 0x0003707C
		private void DoFloatSubtract()
		{
			if (!this.perSecond)
			{
				this.floatVariable.Value -= this.subtract.Value;
			}
			else
			{
				this.floatVariable.Value -= this.subtract.Value * Time.deltaTime;
			}
		}

		// Token: 0x04000BF6 RID: 3062
		[UIHint(UIHint.Variable)]
		[Tooltip("The float variable to subtract from.")]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000BF7 RID: 3063
		[RequiredField]
		[Tooltip("Value to subtract from the float variable.")]
		public FsmFloat subtract;

		// Token: 0x04000BF8 RID: 3064
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x04000BF9 RID: 3065
		[Tooltip("Used with Every Frame. Adds the value over one second to make the operation frame rate independent.")]
		public bool perSecond;
	}
}
