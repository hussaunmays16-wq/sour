﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A6 RID: 1190
	[ActionCategory("cInput")]
	[Tooltip("Gets a axis sensitivity and stores the value in a fsm variable.")]
	public class CInputGetAxisSensitivity : FsmStateAction
	{
		// Token: 0x0600144D RID: 5197 RVA: 0x00088AB4 File Offset: 0x00086CB4
		public override void Reset()
		{
			this.axisName = null;
			this.storeAxisSensitivity = null;
		}

		// Token: 0x0600144E RID: 5198 RVA: 0x00088AC4 File Offset: 0x00086CC4
		public override void OnUpdate()
		{
			if (this.axisName == null)
			{
				return;
			}
			this.storeAxisSensitivity.Value = cInput.GetAxisSensitivity(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CB6 RID: 7350
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CB7 RID: 7351
		[Tooltip("The value of the axis.")]
		public FsmFloat storeAxisSensitivity;

		// Token: 0x04001CB8 RID: 7352
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
