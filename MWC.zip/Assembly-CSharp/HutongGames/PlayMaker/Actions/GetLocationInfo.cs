﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200023B RID: 571
	[Tooltip("Gets Location Info from a mobile device. NOTE: Use StartLocationService before trying to get location info.")]
	[ActionCategory(ActionCategory.Device)]
	public class GetLocationInfo : FsmStateAction
	{
		// Token: 0x060009C5 RID: 2501 RVA: 0x0003E2B8 File Offset: 0x0003C4B8
		public override void Reset()
		{
			this.longitude = null;
			this.latitude = null;
			this.altitude = null;
			this.horizontalAccuracy = null;
			this.verticalAccuracy = null;
			this.errorEvent = null;
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0003E2F0 File Offset: 0x0003C4F0
		public override void OnEnter()
		{
			this.DoGetLocationInfo();
			base.Finish();
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x0003E300 File Offset: 0x0003C500
		private void DoGetLocationInfo()
		{
		}

		// Token: 0x04000DC3 RID: 3523
		[UIHint(UIHint.Variable)]
		public FsmVector3 vectorPosition;

		// Token: 0x04000DC4 RID: 3524
		[UIHint(UIHint.Variable)]
		public FsmFloat longitude;

		// Token: 0x04000DC5 RID: 3525
		[UIHint(UIHint.Variable)]
		public FsmFloat latitude;

		// Token: 0x04000DC6 RID: 3526
		[UIHint(UIHint.Variable)]
		public FsmFloat altitude;

		// Token: 0x04000DC7 RID: 3527
		[UIHint(UIHint.Variable)]
		public FsmFloat horizontalAccuracy;

		// Token: 0x04000DC8 RID: 3528
		[UIHint(UIHint.Variable)]
		public FsmFloat verticalAccuracy;

		// Token: 0x04000DC9 RID: 3529
		[Tooltip("Event to send if the location cannot be queried.")]
		public FsmEvent errorEvent;
	}
}
