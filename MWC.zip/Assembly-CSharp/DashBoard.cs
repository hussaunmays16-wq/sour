﻿using System;
using UnityEngine;

// Token: 0x02000480 RID: 1152
[ExecuteInEditMode]
public class DashBoard : MonoBehaviour
{
	// Token: 0x06001356 RID: 4950 RVA: 0x00072788 File Offset: 0x00070988
	private void Start()
	{
		this.drivetrain = base.transform.parent.GetComponent<Drivetrain>();
		if (this.digitalSpeedoOnBoard != null)
		{
			this.textMeshSpeed = this.digitalSpeedoOnBoard.GetComponent<TextMesh>();
		}
		if (this.digitalGearOnBoard != null)
		{
			this.textMeshGear = this.digitalGearOnBoard.GetComponent<TextMesh>();
		}
		if (this.digitalSpeedoUnit == DashBoard.Unit.Kmh)
		{
			this.factor = 3.6f;
		}
		else
		{
			this.factor = 2.237f;
		}
	}

	// Token: 0x06001357 RID: 4951 RVA: 0x00072818 File Offset: 0x00070A18
	private void OnGUI()
	{
		if (this.speedoMeterType == DashBoard.SpeedoMeterType.RigidBody)
		{
			this.absVelo = Mathf.Abs(this.drivetrain.velo);
		}
		else
		{
			this.absVelo = Mathf.Abs(this.drivetrain.wheelTireVelo);
		}
		this.speedoMeterVelo = this.absVelo * 3.6f;
		this.digitalSpeedoVelo = this.absVelo * this.factor;
		GUI.depth = this.depth;
		if (this.RPMFactor < 0f)
		{
			this.RPMFactor = 0f;
		}
		if (this.drivetrain)
		{
			this.actualtachoMeterNeedleAngle = this.drivetrain.rpm * (this.RPMFactor / 10f) + this.tachoMeterNeedleAngle;
		}
		if (this.speedoMeterFactor < 0.5f)
		{
			this.speedoMeterFactor = 0.5f;
		}
		if (this.drivetrain)
		{
			this.actualspeedoMeterNeedleAngle = this.speedoMeterVelo * this.speedoMeterFactor + this.speedoMeterNeedleAngle;
		}
		if (!Application.isPlaying || this.showGUIDashboard)
		{
			if (this.tachoMeter)
			{
				float num = 0f;
				if (this.tachoMeterDocking == DashBoard.Docking.Right)
				{
					num = (float)(Screen.width - this.speedoMeter.width);
				}
				this.tachoMeterRect = new Rect(this.tachoMeterPosition.x + num, (float)(Screen.height - this.tachoMeter.height) - this.tachoMeterPosition.y + 4f, (float)this.tachoMeter.width * this.tachoMeterDimension, (float)this.tachoMeter.height * this.tachoMeterDimension);
				GUI.DrawTexture(this.tachoMeterRect, this.tachoMeter);
				if (this.tachoMeterNeedle)
				{
					if (this.tachoMeterNeedleSize == Vector2.zero)
					{
						this.tachoMeterNeedleSize.x = (float)this.tachoMeterNeedle.width;
						this.tachoMeterNeedleSize.y = (float)this.tachoMeterNeedle.height;
					}
					this.tachoMeterNeedleRect = new Rect(this.tachoMeterRect.x + this.tachoMeterRect.width / 2f - this.tachoMeterNeedleSize.x * this.tachoMeterDimension * 0.5f, this.tachoMeterRect.y + this.tachoMeterRect.height / 2f - this.tachoMeterNeedleSize.y * this.tachoMeterDimension * 0.5f, this.tachoMeterNeedleSize.x * this.tachoMeterDimension, this.tachoMeterNeedleSize.y * this.tachoMeterDimension);
					this.pivot = new Vector2(this.tachoMeterNeedleRect.xMin + this.tachoMeterNeedleRect.width * 0.5f, this.tachoMeterNeedleRect.yMin + this.tachoMeterNeedleRect.height * 0.5f);
					Matrix4x4 matrix = GUI.matrix;
					GUIUtility.RotateAroundPivot(this.actualtachoMeterNeedleAngle, this.pivot);
					GUI.DrawTexture(this.tachoMeterNeedleRect, this.tachoMeterNeedle);
					GUI.matrix = matrix;
				}
			}
			if (this.speedoMeter)
			{
				float num2 = 0f;
				if (this.speedoMeterDocking == DashBoard.Docking.Right)
				{
					num2 = (float)(Screen.width - this.speedoMeter.width);
				}
				Rect position = new Rect(this.speedoMeterPosition.x + num2, (float)(Screen.height - this.speedoMeter.height) - this.speedoMeterPosition.y + 4f, (float)this.speedoMeter.width * this.speedoMeterDimension, (float)this.speedoMeter.height * this.speedoMeterDimension);
				GUI.DrawTexture(position, this.speedoMeter);
				if (this.speedoMeterNeedle)
				{
					if (this.speedoMeterNeedleSize == Vector2.zero)
					{
						this.speedoMeterNeedleSize.x = (float)this.speedoMeterNeedle.width;
						this.speedoMeterNeedleSize.y = (float)this.speedoMeterNeedle.height;
					}
					this.speedoMeterNeedleRect = new Rect(position.x + position.width / 2f - this.speedoMeterNeedleSize.x * this.speedoMeterDimension * 0.5f, position.y + position.height / 2f - this.speedoMeterNeedleSize.y * this.speedoMeterDimension * 0.5f, this.speedoMeterNeedleSize.x * this.speedoMeterDimension, this.speedoMeterNeedleSize.y * this.speedoMeterDimension);
					this.pivot = new Vector2(this.speedoMeterNeedleRect.xMin + this.speedoMeterNeedleRect.width * 0.5f, this.speedoMeterNeedleRect.yMin + this.speedoMeterNeedleRect.height * 0.5f);
					Matrix4x4 matrix2 = GUI.matrix;
					GUIUtility.RotateAroundPivot(this.actualspeedoMeterNeedleAngle, this.pivot);
					GUI.DrawTexture(this.speedoMeterNeedleRect, this.speedoMeterNeedle);
					GUI.matrix = matrix2;
				}
			}
			this.sign = 1;
			this.shift = 0;
			if (this.dashboardLightsDocking == DashBoard.Docking.Right)
			{
				this.sign = -1;
				this.shift = Mathf.RoundToInt((float)Screen.width - (float)(this.TCS.width * 3) * this.dashboardLightsDimension);
			}
			bool flag = this.carController == null;
			if (this.TCS)
			{
				bool flag2 = false;
				if (!flag)
				{
					flag2 = this.carController.TCSTriggered;
				}
				else if (!Application.isPlaying)
				{
					flag2 = true;
				}
				if (flag2)
				{
					GUI.DrawTexture(new Rect((float)this.sign * this.dashboardLightsPosition.x + (float)this.shift, (float)Screen.height - (float)this.TCS.height * this.dashboardLightsDimension - this.dashboardLightsPosition.y, (float)this.TCS.width * this.dashboardLightsDimension, (float)this.TCS.height * this.dashboardLightsDimension), this.TCS);
				}
			}
			if (this.ABS)
			{
				bool flag3 = false;
				if (!flag)
				{
					flag3 = this.carController.ABSTriggered;
				}
				else if (!Application.isPlaying)
				{
					flag3 = true;
				}
				if (flag3)
				{
					GUI.DrawTexture(new Rect((float)this.TCS.width * this.dashboardLightsDimension + (float)this.sign * this.dashboardLightsPosition.x + (float)this.shift, (float)Screen.height - (float)this.ABS.height * this.dashboardLightsDimension - this.dashboardLightsPosition.y, (float)this.ABS.width * this.dashboardLightsDimension, (float)this.ABS.height * this.dashboardLightsDimension), this.ABS);
				}
			}
			if (this.ESP)
			{
				bool flag4 = false;
				if (!flag)
				{
					flag4 = this.carController.ESPTriggered;
				}
				else if (!Application.isPlaying)
				{
					flag4 = true;
				}
				if (flag4)
				{
					GUI.DrawTexture(new Rect((float)this.TCS.width * this.dashboardLightsDimension + (float)this.ABS.width * this.dashboardLightsDimension + (float)this.sign * this.dashboardLightsPosition.x + (float)this.shift, (float)Screen.height - (float)this.ESP.height * this.dashboardLightsDimension - this.dashboardLightsPosition.y, (float)this.ESP.width * this.dashboardLightsDimension, (float)this.ESP.height * this.dashboardLightsDimension), this.ESP);
				}
			}
			if (this.throttleMonitor)
			{
				float num3 = 0f;
				if (!flag)
				{
					num3 = this.carController.throttle;
				}
				else if (!Application.isPlaying)
				{
					num3 = 1f;
				}
				Rect position2 = new Rect(this.pedalsMonitorPosition.x + (float)Screen.width - 10f, (float)Screen.height - this.pedalsMonitorPosition.y, 10f, (float)(-(float)this.throttleMonitor.height) * num3);
				GUI.DrawTexture(position2, this.throttleMonitor);
			}
			if (this.brakeMonitor)
			{
				float num4 = 0f;
				if (!flag)
				{
					num4 = this.carController.brake;
				}
				else if (!Application.isPlaying)
				{
					num4 = 1f;
				}
				Rect position3 = new Rect(this.pedalsMonitorPosition.x - 12f + (float)Screen.width - 10f, (float)Screen.height - this.pedalsMonitorPosition.y, 10f, (float)(-(float)this.brakeMonitor.height) * num4);
				GUI.DrawTexture(position3, this.brakeMonitor);
			}
			if (this.clutchMonitor)
			{
				float num5 = 0f;
				if (this.drivetrain != null && this.drivetrain.clutch != null)
				{
					num5 = this.drivetrain.clutch.GetClutchPosition();
				}
				else if (!Application.isPlaying)
				{
					num5 = 0f;
				}
				Rect position4 = new Rect(this.pedalsMonitorPosition.x - 24f + (float)Screen.width - 10f, (float)Screen.height - this.pedalsMonitorPosition.y, 10f, (float)(-(float)this.clutchMonitor.height) * (1f - num5));
				GUI.DrawTexture(position4, this.clutchMonitor);
			}
			if (this.drivetrain)
			{
				this.sign = 1;
				this.shift = 0;
				if (this.gearMonitorDocking == DashBoard.Docking.Right)
				{
					this.sign = -1;
					this.shift = Screen.width - 25;
				}
				this.gearRect = new Rect((float)this.sign * this.gearMonitorPosition.x + (float)this.shift, -this.gearMonitorPosition.y + (float)Screen.height - 50f, 50f, 50f);
				if (this.drivetrain.gear < this.drivetrain.neutral)
				{
					GUI.Label(this.gearRect, "R", this.gearMonitorStyle);
				}
				else if (this.drivetrain.gear == this.drivetrain.neutral)
				{
					GUI.Label(this.gearRect, "H", this.gearMonitorStyle);
				}
				else
				{
					GUI.Label(this.gearRect, string.Empty + (this.drivetrain.gear - this.drivetrain.neutral), this.gearMonitorStyle);
				}
				this.sign = 1;
				this.shift = 0;
				if (this.digitalSpeedoDocking == DashBoard.Docking.Right)
				{
					this.sign = -1;
					this.shift = Screen.width - 25;
				}
				this.speedoRect = new Rect((float)this.sign * this.digitalSpeedoPosition.x + (float)this.shift, -this.digitalSpeedoPosition.y + (float)Screen.height - 50f, 50f, 50f);
				GUI.Label(this.speedoRect, string.Empty + Mathf.Round(this.digitalSpeedoVelo), this.digitalSpeedoStyle);
			}
		}
		if (this.textMeshSpeed != null)
		{
			this.textMeshSpeed.text = string.Empty + Mathf.Round(this.digitalSpeedoVelo);
		}
		if (this.tachoMeterNeedleOnBoard != null)
		{
			this.tachoMeterNeedleOnBoard.transform.localRotation = Quaternion.Euler(this.tachoMeterNeedleOnBoard.transform.localEulerAngles.x, this.tachoMeterNeedleOnBoard.transform.localEulerAngles.y, this.actualtachoMeterNeedleAngle);
		}
		if (this.speedoMeterNeedleOnBoard != null)
		{
			this.speedoMeterNeedleOnBoard.transform.localRotation = Quaternion.Euler(this.speedoMeterNeedleOnBoard.transform.localEulerAngles.x, this.speedoMeterNeedleOnBoard.transform.localEulerAngles.y, this.actualspeedoMeterNeedleAngle);
		}
		if (this.textMeshGear != null)
		{
			if (this.drivetrain.gear < this.drivetrain.neutral)
			{
				this.textMeshGear.text = "R";
			}
			else if (this.drivetrain.gear == this.drivetrain.neutral)
			{
				this.textMeshGear.text = "H";
			}
			else
			{
				this.textMeshGear.text = string.Empty + (this.drivetrain.gear - this.drivetrain.neutral);
			}
		}
	}

	// Token: 0x04001A0C RID: 6668
	public int depth = 2;

	// Token: 0x04001A0D RID: 6669
	public Texture2D tachoMeter;

	// Token: 0x04001A0E RID: 6670
	[HideInInspector]
	public bool tachoMeterDisabled;

	// Token: 0x04001A0F RID: 6671
	public Vector2 tachoMeterPosition;

	// Token: 0x04001A10 RID: 6672
	public DashBoard.Docking tachoMeterDocking;

	// Token: 0x04001A11 RID: 6673
	public float tachoMeterDimension = 1f;

	// Token: 0x04001A12 RID: 6674
	public Texture2D tachoMeterNeedle;

	// Token: 0x04001A13 RID: 6675
	public Vector2 tachoMeterNeedleSize;

	// Token: 0x04001A14 RID: 6676
	public float tachoMeterNeedleAngle;

	// Token: 0x04001A15 RID: 6677
	private float actualtachoMeterNeedleAngle;

	// Token: 0x04001A16 RID: 6678
	public float RPMFactor = 3.5714f;

	// Token: 0x04001A17 RID: 6679
	public Texture2D speedoMeter;

	// Token: 0x04001A18 RID: 6680
	[HideInInspector]
	public bool speedoMeterDisabled;

	// Token: 0x04001A19 RID: 6681
	public Vector2 speedoMeterPosition;

	// Token: 0x04001A1A RID: 6682
	public DashBoard.Docking speedoMeterDocking = DashBoard.Docking.Right;

	// Token: 0x04001A1B RID: 6683
	public float speedoMeterDimension = 1f;

	// Token: 0x04001A1C RID: 6684
	public Texture2D speedoMeterNeedle;

	// Token: 0x04001A1D RID: 6685
	public Vector2 speedoMeterNeedleSize;

	// Token: 0x04001A1E RID: 6686
	public float speedoMeterNeedleAngle;

	// Token: 0x04001A1F RID: 6687
	private float actualspeedoMeterNeedleAngle;

	// Token: 0x04001A20 RID: 6688
	public float speedoMeterFactor;

	// Token: 0x04001A21 RID: 6689
	public DashBoard.SpeedoMeterType speedoMeterType;

	// Token: 0x04001A22 RID: 6690
	public DashBoard.Unit digitalSpeedoUnit;

	// Token: 0x04001A23 RID: 6691
	public GUIStyle digitalSpeedoStyle;

	// Token: 0x04001A24 RID: 6692
	public Vector2 digitalSpeedoPosition;

	// Token: 0x04001A25 RID: 6693
	public DashBoard.Docking digitalSpeedoDocking;

	// Token: 0x04001A26 RID: 6694
	public GUIStyle gearMonitorStyle;

	// Token: 0x04001A27 RID: 6695
	public Vector2 gearMonitorPosition;

	// Token: 0x04001A28 RID: 6696
	public DashBoard.Docking gearMonitorDocking;

	// Token: 0x04001A29 RID: 6697
	public Texture2D clutchMonitor;

	// Token: 0x04001A2A RID: 6698
	public Texture2D throttleMonitor;

	// Token: 0x04001A2B RID: 6699
	public Texture2D brakeMonitor;

	// Token: 0x04001A2C RID: 6700
	public Vector2 pedalsMonitorPosition;

	// Token: 0x04001A2D RID: 6701
	public Texture2D ABS;

	// Token: 0x04001A2E RID: 6702
	public Texture2D TCS;

	// Token: 0x04001A2F RID: 6703
	public Texture2D ESP;

	// Token: 0x04001A30 RID: 6704
	public Vector2 dashboardLightsPosition;

	// Token: 0x04001A31 RID: 6705
	public DashBoard.Docking dashboardLightsDocking;

	// Token: 0x04001A32 RID: 6706
	public float dashboardLightsDimension = 1f;

	// Token: 0x04001A33 RID: 6707
	public GameObject digitalSpeedoOnBoard;

	// Token: 0x04001A34 RID: 6708
	public GameObject digitalGearOnBoard;

	// Token: 0x04001A35 RID: 6709
	public GameObject tachoMeterNeedleOnBoard;

	// Token: 0x04001A36 RID: 6710
	public GameObject speedoMeterNeedleOnBoard;

	// Token: 0x04001A37 RID: 6711
	private TextMesh textMeshSpeed;

	// Token: 0x04001A38 RID: 6712
	private TextMesh textMeshGear;

	// Token: 0x04001A39 RID: 6713
	[HideInInspector]
	public bool showGUIDashboard = true;

	// Token: 0x04001A3A RID: 6714
	[HideInInspector]
	public CarController carController;

	// Token: 0x04001A3B RID: 6715
	private Drivetrain drivetrain;

	// Token: 0x04001A3C RID: 6716
	private Rect tachoMeterRect;

	// Token: 0x04001A3D RID: 6717
	private Rect tachoMeterNeedleRect;

	// Token: 0x04001A3E RID: 6718
	private Rect speedoMeterRect;

	// Token: 0x04001A3F RID: 6719
	private Rect speedoMeterNeedleRect;

	// Token: 0x04001A40 RID: 6720
	private Rect instrumentalPanelRect;

	// Token: 0x04001A41 RID: 6721
	private Rect gearRect;

	// Token: 0x04001A42 RID: 6722
	private Rect speedoRect;

	// Token: 0x04001A43 RID: 6723
	private Vector2 pivot;

	// Token: 0x04001A44 RID: 6724
	private float speedoMeterVelo;

	// Token: 0x04001A45 RID: 6725
	private float digitalSpeedoVelo;

	// Token: 0x04001A46 RID: 6726
	private float factor;

	// Token: 0x04001A47 RID: 6727
	private float absVelo;

	// Token: 0x04001A48 RID: 6728
	private int sign = 1;

	// Token: 0x04001A49 RID: 6729
	private int shift;

	// Token: 0x02000481 RID: 1153
	public enum Docking
	{
		// Token: 0x04001A4B RID: 6731
		Left,
		// Token: 0x04001A4C RID: 6732
		Right
	}

	// Token: 0x02000482 RID: 1154
	public enum Unit
	{
		// Token: 0x04001A4E RID: 6734
		Kmh,
		// Token: 0x04001A4F RID: 6735
		Mph
	}

	// Token: 0x02000483 RID: 1155
	public enum SpeedoMeterType
	{
		// Token: 0x04001A51 RID: 6737
		RigidBody,
		// Token: 0x04001A52 RID: 6738
		Wheel
	}
}
