﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200025F RID: 607
	[Tooltip("Gets the number of Touches.")]
	[ActionCategory(ActionCategory.Device)]
	public class GetTouchCount : FsmStateAction
	{
		// Token: 0x06000A57 RID: 2647 RVA: 0x0003F9D8 File Offset: 0x0003DBD8
		public override void Reset()
		{
			this.storeCount = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x0003F9E8 File Offset: 0x0003DBE8
		public override void OnEnter()
		{
			this.DoGetTouchCount();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x0003FA04 File Offset: 0x0003DC04
		public override void OnUpdate()
		{
			this.DoGetTouchCount();
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x0003FA0C File Offset: 0x0003DC0C
		private void DoGetTouchCount()
		{
			this.storeCount.Value = Input.touchCount;
		}

		// Token: 0x04000E42 RID: 3650
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt storeCount;

		// Token: 0x04000E43 RID: 3651
		public bool everyFrame;
	}
}
