﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D8 RID: 472
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Sends Events based on the sign of a Float.")]
	public class FloatSignTest : FsmStateAction
	{
		// Token: 0x06000848 RID: 2120 RVA: 0x00038D74 File Offset: 0x00036F74
		public override void Reset()
		{
			this.floatValue = 0f;
			this.isPositive = null;
			this.isNegative = null;
			this.everyFrame = false;
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00038D9C File Offset: 0x00036F9C
		public override void OnEnter()
		{
			this.DoSignTest();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00038DB8 File Offset: 0x00036FB8
		public override void OnUpdate()
		{
			this.DoSignTest();
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00038DC0 File Offset: 0x00036FC0
		private void DoSignTest()
		{
			if (this.floatValue == null)
			{
				return;
			}
			base.Fsm.Event((this.floatValue.Value >= 0f) ? this.isPositive : this.isNegative);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00038E00 File Offset: 0x00037000
		public override string ErrorCheck()
		{
			if (FsmEvent.IsNullOrEmpty(this.isPositive) && FsmEvent.IsNullOrEmpty(this.isNegative))
			{
				return "Action sends no events!";
			}
			return string.Empty;
		}

		// Token: 0x04000BF2 RID: 3058
		[UIHint(UIHint.Variable)]
		[Tooltip("The float variable to test.")]
		[RequiredField]
		public FsmFloat floatValue;

		// Token: 0x04000BF3 RID: 3059
		[Tooltip("Event to send if the float variable is positive.")]
		public FsmEvent isPositive;

		// Token: 0x04000BF4 RID: 3060
		[Tooltip("Event to send if the float variable is negative.")]
		public FsmEvent isNegative;

		// Token: 0x04000BF5 RID: 3061
		[Tooltip("Repeat every frame. Useful if the variable is changing and you're waiting for a particular result.")]
		public bool everyFrame;
	}
}
