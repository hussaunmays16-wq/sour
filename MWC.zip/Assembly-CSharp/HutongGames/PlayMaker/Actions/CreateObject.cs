﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200016E RID: 366
	[Tooltip("Creates a Game Object, usually from a Prefab.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class CreateObject : FsmStateAction
	{
		// Token: 0x060006CD RID: 1741 RVA: 0x00031134 File Offset: 0x0002F334
		public override void Reset()
		{
			this.gameObject = null;
			this.spawnPoint = null;
			this.position = new FsmVector3
			{
				UseVariable = true
			};
			this.rotation = new FsmVector3
			{
				UseVariable = true
			};
			this.storeObject = null;
			this.networkInstantiate = false;
			this.networkGroup = 0;
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x00031198 File Offset: 0x0002F398
		public override void OnEnter()
		{
			GameObject value = this.gameObject.Value;
			if (value != null)
			{
				Vector3 a = Vector3.zero;
				Vector3 euler = Vector3.up;
				if (this.spawnPoint.Value != null)
				{
					a = this.spawnPoint.Value.transform.position;
					if (!this.position.IsNone)
					{
						a += this.position.Value;
					}
					euler = (this.rotation.IsNone ? this.spawnPoint.Value.transform.eulerAngles : this.rotation.Value);
				}
				else
				{
					if (!this.position.IsNone)
					{
						a = this.position.Value;
					}
					if (!this.rotation.IsNone)
					{
						euler = this.rotation.Value;
					}
				}
				GameObject value2;
				if (!this.networkInstantiate.Value)
				{
					value2 = (GameObject)UnityEngine.Object.Instantiate(value, a, Quaternion.Euler(euler));
				}
				else
				{
					value2 = (GameObject)Network.Instantiate(value, a, Quaternion.Euler(euler), this.networkGroup.Value);
				}
				this.storeObject.Value = value2;
			}
			base.Finish();
		}

		// Token: 0x040009C6 RID: 2502
		[Tooltip("GameObject to create. Usually a Prefab.")]
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x040009C7 RID: 2503
		[Tooltip("Optional Spawn Point.")]
		public FsmGameObject spawnPoint;

		// Token: 0x040009C8 RID: 2504
		[Tooltip("Position. If a Spawn Point is defined, this is used as a local offset from the Spawn Point position.")]
		public FsmVector3 position;

		// Token: 0x040009C9 RID: 2505
		[Tooltip("Rotation. NOTE: Overrides the rotation of the Spawn Point.")]
		public FsmVector3 rotation;

		// Token: 0x040009CA RID: 2506
		[UIHint(UIHint.Variable)]
		[Tooltip("Optionally store the created object.")]
		public FsmGameObject storeObject;

		// Token: 0x040009CB RID: 2507
		[Tooltip("Use Network.Instantiate to create a Game Object on all clients in a networked game.")]
		public FsmBool networkInstantiate;

		// Token: 0x040009CC RID: 2508
		[Tooltip("Usually 0. The group number allows you to group together network messages which allows you to filter them if so desired.")]
		public FsmInt networkGroup;
	}
}
