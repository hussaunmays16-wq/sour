﻿using System;
using System.Collections;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B1 RID: 945
	[Tooltip("Shuffle elements from an ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListShuffle : ArrayListActions
	{
		// Token: 0x06000FFD RID: 4093 RVA: 0x00057BD4 File Offset: 0x00055DD4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.startIndex = 0;
			this.shufflingRange = 0;
		}

		// Token: 0x06000FFE RID: 4094 RVA: 0x00057C08 File Offset: 0x00055E08
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListShuffle(this.proxy.arrayList);
			}
			base.Finish();
		}

		// Token: 0x06000FFF RID: 4095 RVA: 0x00057C54 File Offset: 0x00055E54
		public void DoArrayListShuffle(ArrayList source)
		{
			if (!base.isProxyValid())
			{
				return;
			}
			int num = 0;
			int num2 = this.proxy.arrayList.Count - 1;
			if (this.startIndex.Value > 0)
			{
				num = Mathf.Min(this.startIndex.Value, num2);
			}
			if (this.shufflingRange.Value > 0)
			{
				num2 = Mathf.Min(this.proxy.arrayList.Count - 1, num + this.shufflingRange.Value);
			}
			Debug.Log(num);
			Debug.Log(num2);
			for (int i = num2; i > num; i--)
			{
				int index = UnityEngine.Random.Range(num, i + 1);
				object value = this.proxy.arrayList[i];
				this.proxy.arrayList[i] = this.proxy.arrayList[index];
				this.proxy.arrayList[index] = value;
			}
		}

		// Token: 0x040014CA RID: 5322
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component to shuffle")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014CB RID: 5323
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to copy from ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014CC RID: 5324
		[Tooltip("Optional start Index for the shuffling. Leave it to 0 for no effect")]
		public FsmInt startIndex;

		// Token: 0x040014CD RID: 5325
		[Tooltip("Optional range for the shuffling, starting at the start index if greater than 0. Leave it to 0 for no effect, that is will shuffle the whole array")]
		public FsmInt shufflingRange;
	}
}
