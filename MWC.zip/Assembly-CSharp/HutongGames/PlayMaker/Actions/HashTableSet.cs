﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003CC RID: 972
	[Tooltip("Set an key/value pair to a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy)")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableSet : HashTableActions
	{
		// Token: 0x06001069 RID: 4201 RVA: 0x0005969C File Offset: 0x0005789C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
			this.variable = null;
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x000596BC File Offset: 0x000578BC
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SetHashTable();
			}
			base.Finish();
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x000596FC File Offset: 0x000578FC
		public void SetHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.hashTable[this.key.Value] = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable);
		}

		// Token: 0x0400154A RID: 5450
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400154B RID: 5451
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400154C RID: 5452
		[RequiredField]
		[Tooltip("The Key value for that hash set")]
		[UIHint(UIHint.FsmString)]
		public FsmString key;

		// Token: 0x0400154D RID: 5453
		[Tooltip("The variable to set.")]
		[ActionSection("Result")]
		public FsmVar variable;
	}
}
