﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021C RID: 540
	[ActionCategory(ActionCategory.Color)]
	[Tooltip("Get the RGBA channels of a Color Variable and store them in Float Variables.")]
	public class GetColorRGBA : FsmStateAction
	{
		// Token: 0x06000939 RID: 2361 RVA: 0x0003C588 File Offset: 0x0003A788
		public override void Reset()
		{
			this.color = null;
			this.storeRed = null;
			this.storeGreen = null;
			this.storeBlue = null;
			this.storeAlpha = null;
			this.everyFrame = false;
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x0003C5C0 File Offset: 0x0003A7C0
		public override void OnEnter()
		{
			this.DoGetColorRGBA();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x0003C5DC File Offset: 0x0003A7DC
		public override void OnUpdate()
		{
			this.DoGetColorRGBA();
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x0003C5E4 File Offset: 0x0003A7E4
		private void DoGetColorRGBA()
		{
			if (this.color.IsNone)
			{
				return;
			}
			this.storeRed.Value = this.color.Value.r;
			this.storeGreen.Value = this.color.Value.g;
			this.storeBlue.Value = this.color.Value.b;
			this.storeAlpha.Value = this.color.Value.a;
		}

		// Token: 0x04000D05 RID: 3333
		[Tooltip("The Color variable.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmColor color;

		// Token: 0x04000D06 RID: 3334
		[Tooltip("Store the red channel in a float variable.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeRed;

		// Token: 0x04000D07 RID: 3335
		[Tooltip("Store the green channel in a float variable.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeGreen;

		// Token: 0x04000D08 RID: 3336
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the blue channel in a float variable.")]
		public FsmFloat storeBlue;

		// Token: 0x04000D09 RID: 3337
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the alpha channel in a float variable.")]
		public FsmFloat storeAlpha;

		// Token: 0x04000D0A RID: 3338
		[Tooltip("Repeat every frame. Useful if the color variable is changing.")]
		public bool everyFrame;
	}
}
