﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D3 RID: 979
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Send event to all the GameObjects within an arrayList.")]
	public class ArrayListSendEventToGameObjects : ArrayListActions
	{
		// Token: 0x06001087 RID: 4231 RVA: 0x00059D74 File Offset: 0x00057F74
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.sendEvent = null;
			this.excludeSelf = false;
			this.sendToChildren = false;
		}

		// Token: 0x06001088 RID: 4232 RVA: 0x00059DA4 File Offset: 0x00057FA4
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoSendEvent();
		}

		// Token: 0x06001089 RID: 4233 RVA: 0x00059DE4 File Offset: 0x00057FE4
		private void DoSendEvent()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject go = (GameObject)obj;
				this.sendEventToGO(go);
			}
		}

		// Token: 0x0600108A RID: 4234 RVA: 0x00059E64 File Offset: 0x00058064
		private void sendEventToGO(GameObject _go)
		{
			FsmEventTarget fsmEventTarget = new FsmEventTarget();
			fsmEventTarget.excludeSelf = this.excludeSelf.Value;
			fsmEventTarget.gameObject = new FsmOwnerDefault
			{
				OwnerOption = OwnerDefaultOption.SpecifyGameObject,
				GameObject = new FsmGameObject(),
				GameObject = 
				{
					Value = base.Owner
				}
			};
			fsmEventTarget.target = FsmEventTarget.EventTarget.GameObject;
			fsmEventTarget.sendToChildren = this.sendToChildren.Value;
			base.Fsm.Event(fsmEventTarget, this.sendEvent);
		}

		// Token: 0x04001569 RID: 5481
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400156A RID: 5482
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400156B RID: 5483
		[RequiredField]
		[Tooltip("The event to send. NOTE: Events must be marked Global to send between FSMs.")]
		public FsmEvent sendEvent;

		// Token: 0x0400156C RID: 5484
		public FsmBool excludeSelf;

		// Token: 0x0400156D RID: 5485
		public FsmBool sendToChildren;
	}
}
