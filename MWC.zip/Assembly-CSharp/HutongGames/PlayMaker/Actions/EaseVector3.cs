﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200013F RID: 319
	[ActionCategory(ActionCategory.AnimateVariables)]
	[Tooltip("Easing Animation - Vector3")]
	public class EaseVector3 : EaseFsmAction
	{
		// Token: 0x060005FA RID: 1530 RVA: 0x0002DFF0 File Offset: 0x0002C1F0
		public override void Reset()
		{
			base.Reset();
			this.vector3Variable = null;
			this.fromValue = null;
			this.toValue = null;
			this.finishInNextStep = false;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0002E020 File Offset: 0x0002C220
		public override void OnEnter()
		{
			base.OnEnter();
			this.fromFloats = new float[3];
			this.fromFloats[0] = this.fromValue.Value.x;
			this.fromFloats[1] = this.fromValue.Value.y;
			this.fromFloats[2] = this.fromValue.Value.z;
			this.toFloats = new float[3];
			this.toFloats[0] = this.toValue.Value.x;
			this.toFloats[1] = this.toValue.Value.y;
			this.toFloats[2] = this.toValue.Value.z;
			this.resultFloats = new float[3];
			this.finishInNextStep = false;
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0002E104 File Offset: 0x0002C304
		public override void OnExit()
		{
			base.OnExit();
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0002E10C File Offset: 0x0002C30C
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.vector3Variable.IsNone && this.isRunning)
			{
				this.vector3Variable.Value = new Vector3(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2]);
			}
			if (this.finishInNextStep)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.vector3Variable.IsNone)
				{
					this.vector3Variable.Value = new Vector3((!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.x : this.fromValue.Value.x) : this.toValue.Value.x, (!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.y : this.fromValue.Value.y) : this.toValue.Value.y, (!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.z : this.fromValue.Value.z) : this.toValue.Value.z);
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x040008F2 RID: 2290
		[RequiredField]
		public FsmVector3 fromValue;

		// Token: 0x040008F3 RID: 2291
		[RequiredField]
		public FsmVector3 toValue;

		// Token: 0x040008F4 RID: 2292
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector3Variable;

		// Token: 0x040008F5 RID: 2293
		private bool finishInNextStep;
	}
}
