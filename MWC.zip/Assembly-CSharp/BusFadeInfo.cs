﻿using System;

// Token: 0x02000079 RID: 121
[Serializable]
public class BusFadeInfo
{
	// Token: 0x04000298 RID: 664
	public string NameOfBus;

	// Token: 0x04000299 RID: 665
	public GroupBus ActingBus;

	// Token: 0x0400029A RID: 666
	public float TargetVolume;

	// Token: 0x0400029B RID: 667
	public float VolumeStep;

	// Token: 0x0400029C RID: 668
	public bool IsActive = true;

	// Token: 0x0400029D RID: 669
	public Action completionAction;
}
