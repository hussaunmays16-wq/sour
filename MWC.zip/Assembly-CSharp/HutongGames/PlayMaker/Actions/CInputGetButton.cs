﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A7 RID: 1191
	[ActionCategory("cInput")]
	[Tooltip("Gets cInput button events down -> up -> pressed in order.")]
	public class CInputGetButton : FsmStateAction
	{
		// Token: 0x06001450 RID: 5200 RVA: 0x00088B18 File Offset: 0x00086D18
		public override void Reset()
		{
			this.buttonName = null;
			this.buttonDownEvent = null;
			this.buttonUpEvent = null;
			this.buttonPressedEvent = null;
			this.everyFrame = null;
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x00088B40 File Offset: 0x00086D40
		public override void OnUpdate()
		{
			if (cInput.GetKeyDown(this.buttonName.Value))
			{
				base.Fsm.Event(this.buttonDownEvent);
			}
			else if (cInput.GetKeyUp(this.buttonName.Value))
			{
				base.Fsm.Event(this.buttonUpEvent);
			}
			else if (cInput.GetKey(this.buttonName.Value))
			{
				base.Fsm.Event(this.buttonPressedEvent);
			}
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CB9 RID: 7353
		[Tooltip("The name of the button.")]
		[RequiredField]
		public FsmString buttonName;

		// Token: 0x04001CBA RID: 7354
		[Tooltip("The event that fires if the button gets down.")]
		public FsmEvent buttonDownEvent;

		// Token: 0x04001CBB RID: 7355
		[Tooltip("The event that fires if the button gets up.")]
		public FsmEvent buttonUpEvent;

		// Token: 0x04001CBC RID: 7356
		[Tooltip("The event that fires if the button is pressed (also on entering the action).")]
		public FsmEvent buttonPressedEvent;

		// Token: 0x04001CBD RID: 7357
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
