﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000232 RID: 562
	[Tooltip("Get the values of multiple variables in another FSM and store in variables of the same name in this FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmVariables : FsmStateAction
	{
		// Token: 0x0600099F RID: 2463 RVA: 0x0003DCBC File Offset: 0x0003BEBC
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.getVariables = null;
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x0003DCDC File Offset: 0x0003BEDC
		private void InitFsmVars()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.cachedGO)
			{
				this.sourceVariables = new INamedVariable[this.getVariables.Length];
				this.targetVariables = new NamedVariable[this.getVariables.Length];
				for (int i = 0; i < this.getVariables.Length; i++)
				{
					string variableName = this.getVariables[i].variableName;
					this.sourceFsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
					this.sourceVariables[i] = this.sourceFsm.FsmVariables.GetVariable(variableName);
					this.targetVariables[i] = base.Fsm.Variables.GetVariable(variableName);
					this.getVariables[i].Type = FsmUtility.GetVariableType(this.targetVariables[i]);
					if (!string.IsNullOrEmpty(variableName) && this.sourceVariables[i] == null)
					{
						this.LogWarning("Missing Variable: " + variableName);
					}
					this.cachedGO = ownerDefaultTarget;
				}
			}
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x0003DDFC File Offset: 0x0003BFFC
		public override void OnEnter()
		{
			this.InitFsmVars();
			this.DoGetFsmVariables();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x0003DE1C File Offset: 0x0003C01C
		public override void OnUpdate()
		{
			this.DoGetFsmVariables();
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x0003DE24 File Offset: 0x0003C024
		private void DoGetFsmVariables()
		{
			this.InitFsmVars();
			for (int i = 0; i < this.getVariables.Length; i++)
			{
				this.getVariables[i].GetValueFrom(this.sourceVariables[i]);
				this.getVariables[i].ApplyValueTo(this.targetVariables[i]);
			}
		}

		// Token: 0x04000D9A RID: 3482
		[RequiredField]
		[Tooltip("The GameObject that owns the FSM")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D9B RID: 3483
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D9C RID: 3484
		[HideTypeFilter]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmVar[] getVariables;

		// Token: 0x04000D9D RID: 3485
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D9E RID: 3486
		private GameObject cachedGO;

		// Token: 0x04000D9F RID: 3487
		private PlayMakerFSM sourceFsm;

		// Token: 0x04000DA0 RID: 3488
		private INamedVariable[] sourceVariables;

		// Token: 0x04000DA1 RID: 3489
		private NamedVariable[] targetVariables;
	}
}
