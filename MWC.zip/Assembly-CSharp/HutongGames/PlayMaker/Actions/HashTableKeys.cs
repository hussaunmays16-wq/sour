﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C9 RID: 969
	[Tooltip("Store all the keys of a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy) into a PlayMaker arrayList Proxy component (PlayMakerArrayListProxy).")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableKeys : HashTableActions
	{
		// Token: 0x0600105D RID: 4189 RVA: 0x000594B8 File Offset: 0x000576B8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.arrayListGameObject = null;
			this.arrayListReference = null;
		}

		// Token: 0x0600105E RID: 4190 RVA: 0x000594D8 File Offset: 0x000576D8
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doHashTableKeys();
			}
			base.Finish();
		}

		// Token: 0x0600105F RID: 4191 RVA: 0x00059518 File Offset: 0x00057718
		public void doHashTableKeys()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.arrayListGameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			PlayMakerArrayListProxy arrayListProxyPointer = base.GetArrayListProxyPointer(ownerDefaultTarget, this.arrayListReference.Value, false);
			if (arrayListProxyPointer != null)
			{
				arrayListProxyPointer.arrayList.AddRange(this.proxy.hashTable.Keys);
			}
		}

		// Token: 0x04001541 RID: 5441
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[ActionSection("Set up")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001542 RID: 5442
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001543 RID: 5443
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component that will store the keys")]
		[ActionSection("Result")]
		[RequiredField]
		public FsmOwnerDefault arrayListGameObject;

		// Token: 0x04001544 RID: 5444
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component that will store the keys ( necessary if several component coexists on the same GameObject")]
		public FsmString arrayListReference;
	}
}
