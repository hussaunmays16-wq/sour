﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020E RID: 526
	[ActionCategory(ActionCategory.Logic)]
	[Tooltip("Tests if a GameObject Variable has a null value. E.g., If the FindGameObject action failed to find an object.")]
	public class GameObjectIsNull : FsmStateAction
	{
		// Token: 0x06000902 RID: 2306 RVA: 0x0003B92C File Offset: 0x00039B2C
		public override void Reset()
		{
			this.gameObject = null;
			this.isNull = null;
			this.isNotNull = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0003B954 File Offset: 0x00039B54
		public override void OnEnter()
		{
			this.DoIsGameObjectNull();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0003B970 File Offset: 0x00039B70
		public override void OnUpdate()
		{
			this.DoIsGameObjectNull();
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x0003B978 File Offset: 0x00039B78
		private void DoIsGameObjectNull()
		{
			bool flag = this.gameObject.Value == null;
			if (this.storeResult != null)
			{
				this.storeResult.Value = flag;
			}
			base.Fsm.Event((!flag) ? this.isNotNull : this.isNull);
		}

		// Token: 0x04000CCA RID: 3274
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The GameObject variable to test.")]
		public FsmGameObject gameObject;

		// Token: 0x04000CCB RID: 3275
		[Tooltip("Event to send if the GamObject is null.")]
		public FsmEvent isNull;

		// Token: 0x04000CCC RID: 3276
		[Tooltip("Event to send if the GamObject is NOT null.")]
		public FsmEvent isNotNull;

		// Token: 0x04000CCD RID: 3277
		[Tooltip("Store the result in a bool variable.")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000CCE RID: 3278
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
