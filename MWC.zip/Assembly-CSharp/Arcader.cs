﻿using System;
using UnityEngine;

// Token: 0x0200046C RID: 1132
public class Arcader : Modifier
{
	// Token: 0x0600130F RID: 4879 RVA: 0x0006BEB4 File Offset: 0x0006A0B4
	protected override void COGHelper(out float COGYShift, float absLateralSlip, float strength)
	{
		COGYShift = Mathf.Clamp01(absLateralSlip) * 0.35f * strength * this.COGHelperStrength;
		base.SetCOGYPosition(COGYShift);
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x0006BED8 File Offset: 0x0006A0D8
	protected override void TorqueHelper(out float torque, float absLateralSlip, float lateralSlip, float strength)
	{
		torque = (absLateralSlip - 1f) * Mathf.Sign(lateralSlip) * 10000f * strength * this.torqueHelperStrength;
		if (absLateralSlip > 1f)
		{
			this.body.AddRelativeTorque(-Vector3.up * torque);
		}
	}

	// Token: 0x06001311 RID: 4881 RVA: 0x0006BF2C File Offset: 0x0006A12C
	protected override void GripHelper(out float gripSlip, out float gripVelo, float absLateralSlip, float strength)
	{
		gripSlip = (gripVelo = 0f);
		foreach (Wheel wheel in this.axles.allWheels)
		{
			gripSlip = Mathf.Clamp01(absLateralSlip) * strength;
			wheel.gripSlip = gripSlip;
			gripVelo = (this.veloKmh - this.minVelocity) * 0.0015f * strength * this.gripHelperStrength;
			wheel.gripVelo = gripVelo;
		}
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x0006BFA4 File Offset: 0x0006A1A4
	protected override void ResetParameters()
	{
		if (this.carDynamics != null)
		{
			this.COGHelper(out this.COGYShift, 0f, 0f);
		}
		if (this.axles.allWheels != null)
		{
			this.GripHelper(out this.gripSlip, out this.gripVelo, 0f, 0f);
		}
	}
}
