﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003AE RID: 942
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Reverses the sequence of elements in a PlayMaker ArrayList Proxy component")]
	public class ArrayListReverse : ArrayListActions
	{
		// Token: 0x06000FF0 RID: 4080 RVA: 0x00057A14 File Offset: 0x00055C14
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x00057A24 File Offset: 0x00055C24
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListReverse();
			}
			base.Finish();
		}

		// Token: 0x06000FF2 RID: 4082 RVA: 0x00057A64 File Offset: 0x00055C64
		public void DoArrayListReverse()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.arrayList.Reverse();
		}

		// Token: 0x040014C1 RID: 5313
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014C2 RID: 5314
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
