﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200016C RID: 364
	[Tooltip("Converts an String value to an Int value.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertStringToInt : FsmStateAction
	{
		// Token: 0x060006C5 RID: 1733 RVA: 0x00030F24 File Offset: 0x0002F124
		public override void Reset()
		{
			this.intVariable = null;
			this.stringVariable = null;
			this.everyFrame = false;
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00030F3C File Offset: 0x0002F13C
		public override void OnEnter()
		{
			this.DoConvertStringToInt();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00030F58 File Offset: 0x0002F158
		public override void OnUpdate()
		{
			this.DoConvertStringToInt();
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00030F60 File Offset: 0x0002F160
		private void DoConvertStringToInt()
		{
			this.intVariable.Value = int.Parse(this.stringVariable.Value);
		}

		// Token: 0x040009BE RID: 2494
		[Tooltip("The String variable to convert to an integer.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmString stringVariable;

		// Token: 0x040009BF RID: 2495
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in an Int variable.")]
		[RequiredField]
		public FsmInt intVariable;

		// Token: 0x040009C0 RID: 2496
		[Tooltip("Repeat every frame. Useful if the String variable is changing.")]
		public bool everyFrame;
	}
}
