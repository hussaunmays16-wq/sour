﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021B RID: 539
	[Tooltip("Gets info on the last collision event and store in variables. See Unity Physics docs.")]
	[ActionCategory(ActionCategory.Physics)]
	public class GetCollisionInfo : FsmStateAction
	{
		// Token: 0x06000935 RID: 2357 RVA: 0x0003C420 File Offset: 0x0003A620
		public override void Reset()
		{
			this.gameObjectHit = null;
			this.relativeVelocity = null;
			this.relativeSpeed = null;
			this.contactPoint = null;
			this.contactNormal = null;
			this.physicsMaterialName = null;
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x0003C458 File Offset: 0x0003A658
		private void StoreCollisionInfo()
		{
			if (base.Fsm.CollisionInfo == null)
			{
				return;
			}
			this.gameObjectHit.Value = base.Fsm.CollisionInfo.gameObject;
			this.relativeSpeed.Value = base.Fsm.CollisionInfo.relativeVelocity.magnitude;
			this.relativeVelocity.Value = base.Fsm.CollisionInfo.relativeVelocity;
			this.physicsMaterialName.Value = base.Fsm.CollisionInfo.collider.material.name;
			if (base.Fsm.CollisionInfo.contacts != null && base.Fsm.CollisionInfo.contacts.Length > 0)
			{
				this.contactPoint.Value = base.Fsm.CollisionInfo.contacts[0].point;
				this.contactNormal.Value = base.Fsm.CollisionInfo.contacts[0].normal;
			}
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x0003C570 File Offset: 0x0003A770
		public override void OnEnter()
		{
			this.StoreCollisionInfo();
			base.Finish();
		}

		// Token: 0x04000CFF RID: 3327
		[Tooltip("Get the GameObject hit.")]
		[UIHint(UIHint.Variable)]
		public FsmGameObject gameObjectHit;

		// Token: 0x04000D00 RID: 3328
		[Tooltip("Get the relative velocity of the collision.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 relativeVelocity;

		// Token: 0x04000D01 RID: 3329
		[UIHint(UIHint.Variable)]
		[Tooltip("Get the relative speed of the collision. Useful for controlling reactions. E.g., selecting an appropriate sound fx.")]
		public FsmFloat relativeSpeed;

		// Token: 0x04000D02 RID: 3330
		[Tooltip("Get the world position of the collision contact. Useful for spawning effects etc.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 contactPoint;

		// Token: 0x04000D03 RID: 3331
		[Tooltip("Get the collision normal vector. Useful for aligning spawned effects etc.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 contactNormal;

		// Token: 0x04000D04 RID: 3332
		[Tooltip("Get the name of the physics material of the colliding GameObject. Useful for triggering different effects. Audio, particles...")]
		[UIHint(UIHint.Variable)]
		public FsmString physicsMaterialName;
	}
}
