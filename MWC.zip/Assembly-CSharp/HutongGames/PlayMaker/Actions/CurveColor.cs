﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000134 RID: 308
	[ActionCategory(ActionCategory.AnimateVariables)]
	[Tooltip("Animates the value of a Color Variable FROM-TO with assistance of Deformation Curves.")]
	public class CurveColor : CurveFsmAction
	{
		// Token: 0x060005AD RID: 1453 RVA: 0x0002AC44 File Offset: 0x00028E44
		public override void Reset()
		{
			base.Reset();
			this.colorVariable = new FsmColor
			{
				UseVariable = true
			};
			this.toValue = new FsmColor
			{
				UseVariable = true
			};
			this.fromValue = new FsmColor
			{
				UseVariable = true
			};
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0002AC94 File Offset: 0x00028E94
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[4];
			this.fromFloats = new float[4];
			this.fromFloats[0] = ((!this.fromValue.IsNone) ? this.fromValue.Value.r : 0f);
			this.fromFloats[1] = ((!this.fromValue.IsNone) ? this.fromValue.Value.g : 0f);
			this.fromFloats[2] = ((!this.fromValue.IsNone) ? this.fromValue.Value.b : 0f);
			this.fromFloats[3] = ((!this.fromValue.IsNone) ? this.fromValue.Value.a : 0f);
			this.toFloats = new float[4];
			this.toFloats[0] = ((!this.toValue.IsNone) ? this.toValue.Value.r : 0f);
			this.toFloats[1] = ((!this.toValue.IsNone) ? this.toValue.Value.g : 0f);
			this.toFloats[2] = ((!this.toValue.IsNone) ? this.toValue.Value.b : 0f);
			this.toFloats[3] = ((!this.toValue.IsNone) ? this.toValue.Value.a : 0f);
			this.curves = new AnimationCurve[4];
			this.curves[0] = this.curveR.curve;
			this.curves[1] = this.curveG.curve;
			this.curves[2] = this.curveB.curve;
			this.curves[3] = this.curveA.curve;
			this.calculations = new CurveFsmAction.Calculation[4];
			this.calculations[0] = this.calculationR;
			this.calculations[1] = this.calculationG;
			this.calculations[2] = this.calculationB;
			this.calculations[2] = this.calculationA;
			base.Init();
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x0002AF20 File Offset: 0x00029120
		public override void OnExit()
		{
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x0002AF24 File Offset: 0x00029124
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.colorVariable.IsNone && this.isRunning)
			{
				this.clr = new Color(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
				this.colorVariable.Value = this.clr;
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.colorVariable.IsNone)
				{
					this.clr = new Color(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
					this.colorVariable.Value = this.clr;
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x04000868 RID: 2152
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmColor colorVariable;

		// Token: 0x04000869 RID: 2153
		[RequiredField]
		public FsmColor fromValue;

		// Token: 0x0400086A RID: 2154
		[RequiredField]
		public FsmColor toValue;

		// Token: 0x0400086B RID: 2155
		[RequiredField]
		public FsmAnimationCurve curveR;

		// Token: 0x0400086C RID: 2156
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.Red and toValue.Rec.")]
		public CurveFsmAction.Calculation calculationR;

		// Token: 0x0400086D RID: 2157
		[RequiredField]
		public FsmAnimationCurve curveG;

		// Token: 0x0400086E RID: 2158
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.Green and toValue.Green.")]
		public CurveFsmAction.Calculation calculationG;

		// Token: 0x0400086F RID: 2159
		[RequiredField]
		public FsmAnimationCurve curveB;

		// Token: 0x04000870 RID: 2160
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.Blue and toValue.Blue.")]
		public CurveFsmAction.Calculation calculationB;

		// Token: 0x04000871 RID: 2161
		[RequiredField]
		public FsmAnimationCurve curveA;

		// Token: 0x04000872 RID: 2162
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to otherwise linear move between fromValue.Alpha and toValue.Alpha.")]
		public CurveFsmAction.Calculation calculationA;

		// Token: 0x04000873 RID: 2163
		private Color clr;

		// Token: 0x04000874 RID: 2164
		private bool finishInNextStep;
	}
}
