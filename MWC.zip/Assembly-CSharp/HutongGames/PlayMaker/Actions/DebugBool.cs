﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000171 RID: 369
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Logs the value of a Bool Variable in the PlayMaker Log Window.")]
	public class DebugBool : FsmStateAction
	{
		// Token: 0x060006DC RID: 1756 RVA: 0x000313E8 File Offset: 0x0002F5E8
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.boolVariable = null;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x000313F8 File Offset: 0x0002F5F8
		public override void OnEnter()
		{
			string text = "None";
			if (!this.boolVariable.IsNone)
			{
				text = this.boolVariable.Name + ": " + this.boolVariable.Value;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009D1 RID: 2513
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009D2 RID: 2514
		[Tooltip("Prints the value of a Bool variable in the PlayMaker log window.")]
		[UIHint(UIHint.Variable)]
		public FsmBool boolVariable;
	}
}
