﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001D3 RID: 467
	[Tooltip("Divides one Float by another.")]
	[ActionCategory(ActionCategory.Math)]
	public class FloatDivide : FsmStateAction
	{
		// Token: 0x06000837 RID: 2103 RVA: 0x000389C8 File Offset: 0x00036BC8
		public override void Reset()
		{
			this.floatVariable = null;
			this.divideBy = null;
			this.everyFrame = false;
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000389E0 File Offset: 0x00036BE0
		public override void OnEnter()
		{
			this.floatVariable.Value /= this.divideBy.Value;
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00038A1C File Offset: 0x00036C1C
		public override void OnUpdate()
		{
			this.floatVariable.Value /= this.divideBy.Value;
		}

		// Token: 0x04000BD7 RID: 3031
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The float variable to divide.")]
		public FsmFloat floatVariable;

		// Token: 0x04000BD8 RID: 3032
		[Tooltip("Divide the float variable by this value.")]
		[RequiredField]
		public FsmFloat divideBy;

		// Token: 0x04000BD9 RID: 3033
		[Tooltip("Repeate every frame. Useful if the variables are changing.")]
		public bool everyFrame;
	}
}
