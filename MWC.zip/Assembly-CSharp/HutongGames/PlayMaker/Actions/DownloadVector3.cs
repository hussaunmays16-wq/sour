﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000194 RID: 404
	[Tooltip("Downloads a Vector3 from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class DownloadVector3 : FsmStateAction
	{
		// Token: 0x06000752 RID: 1874 RVA: 0x00033BF8 File Offset: 0x00031DF8
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.loadValue = null;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00033C64 File Offset: 0x00031E64
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new object[]
			{
				"Downloading from ",
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile
			}));
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00033D38 File Offset: 0x00031F38
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				this.loadValue.Value = this.web.Load<Vector3>(this.uniqueTag.Value);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
			}
		}

		// Token: 0x04000A90 RID: 2704
		[Tooltip("The variable we want to load our data into.")]
		[RequiredField]
		public FsmVector3 loadValue;

		// Token: 0x04000A91 RID: 2705
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000A92 RID: 2706
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04000A93 RID: 2707
		[RequiredField]
		[Tooltip("The password that you have specified in your ES2.php file.")]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000A94 RID: 2708
		[Tooltip("The unique tag for this save. For example, the object's name if no other objects use the same name.")]
		[RequiredField]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000A95 RID: 2709
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04000A96 RID: 2710
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04000A97 RID: 2711
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x04000A98 RID: 2712
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x04000A99 RID: 2713
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000A9A RID: 2714
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000A9B RID: 2715
		private ES2Web web;
	}
}
