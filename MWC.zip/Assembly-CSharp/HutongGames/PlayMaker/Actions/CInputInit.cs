﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AF RID: 1199
	[Tooltip("Initialize cInput to work with. You have to execute this first!")]
	[ActionCategory("cInput")]
	public class CInputInit : FsmStateAction
	{
		// Token: 0x06001469 RID: 5225 RVA: 0x0008907C File Offset: 0x0008727C
		public override void OnEnter()
		{
			cInput.Init();
			base.Finish();
		}
	}
}
