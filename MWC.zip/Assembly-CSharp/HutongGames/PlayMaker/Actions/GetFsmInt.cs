﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000229 RID: 553
	[Tooltip("Get the value of an Integer Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmInt : FsmStateAction
	{
		// Token: 0x06000971 RID: 2417 RVA: 0x0003D2C4 File Offset: 0x0003B4C4
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x0003D2E4 File Offset: 0x0003B4E4
		public override void OnEnter()
		{
			this.DoGetFsmInt();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x0003D300 File Offset: 0x0003B500
		public override void OnUpdate()
		{
			this.DoGetFsmInt();
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x0003D308 File Offset: 0x0003B508
		private void DoGetFsmInt()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmInt fsmInt = this.fsm.FsmVariables.GetFsmInt(this.variableName.Value);
			if (fsmInt == null)
			{
				return;
			}
			this.storeValue.Value = fsmInt.Value;
		}

		// Token: 0x04000D5B RID: 3419
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D5C RID: 3420
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D5D RID: 3421
		[UIHint(UIHint.FsmInt)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D5E RID: 3422
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmInt storeValue;

		// Token: 0x04000D5F RID: 3423
		public bool everyFrame;

		// Token: 0x04000D60 RID: 3424
		private GameObject goLastFrame;

		// Token: 0x04000D61 RID: 3425
		private PlayMakerFSM fsm;
	}
}
