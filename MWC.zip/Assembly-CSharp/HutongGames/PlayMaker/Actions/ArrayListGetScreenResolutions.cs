﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003EC RID: 1004
	[Tooltip("Store all resolutions")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetScreenResolutions : ArrayListActions
	{
		// Token: 0x06001100 RID: 4352 RVA: 0x0005DA40 File Offset: 0x0005BC40
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06001101 RID: 4353 RVA: 0x0005DA50 File Offset: 0x0005BC50
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.getResolutions();
			}
			base.Finish();
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x0005DA90 File Offset: 0x0005BC90
		public void getResolutions()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.arrayList.Clear();
			Resolution[] resolutions = Screen.resolutions;
			foreach (Resolution resolution in resolutions)
			{
				this.proxy.arrayList.Add(new Vector3((float)resolution.width, (float)resolution.height, (float)resolution.refreshRate));
			}
		}

		// Token: 0x0400162F RID: 5679
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001630 RID: 5680
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
