﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000223 RID: 547
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Measures the Distance betweens 2 Game Objects and stores the result in a Float Variable.")]
	public class GetDistance : FsmStateAction
	{
		// Token: 0x06000955 RID: 2389 RVA: 0x0003CBE4 File Offset: 0x0003ADE4
		public override void Reset()
		{
			this.gameObject = null;
			this.target = null;
			this.storeResult = null;
			this.everyFrame = true;
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x0003CC04 File Offset: 0x0003AE04
		public override void OnEnter()
		{
			this.DoGetDistance();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x0003CC20 File Offset: 0x0003AE20
		public override void OnUpdate()
		{
			this.DoGetDistance();
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x0003CC28 File Offset: 0x0003AE28
		private void DoGetDistance()
		{
			GameObject gameObject = (this.gameObject.OwnerOption != OwnerDefaultOption.UseOwner) ? this.gameObject.GameObject.Value : base.Owner;
			if (gameObject == null || this.target.Value == null || this.storeResult == null)
			{
				return;
			}
			this.storeResult.Value = Vector3.Distance(gameObject.transform.position, this.target.Value.transform.position);
		}

		// Token: 0x04000D2C RID: 3372
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D2D RID: 3373
		[RequiredField]
		public FsmGameObject target;

		// Token: 0x04000D2E RID: 3374
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeResult;

		// Token: 0x04000D2F RID: 3375
		public bool everyFrame;
	}
}
