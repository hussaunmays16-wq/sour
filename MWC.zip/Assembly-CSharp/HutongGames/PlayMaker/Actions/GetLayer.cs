﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200023A RID: 570
	[Tooltip("Gets a Game Object's Layer and stores it in an Int Variable.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetLayer : FsmStateAction
	{
		// Token: 0x060009C0 RID: 2496 RVA: 0x0003E234 File Offset: 0x0003C434
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x0003E24C File Offset: 0x0003C44C
		public override void OnEnter()
		{
			this.DoGetLayer();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x0003E268 File Offset: 0x0003C468
		public override void OnUpdate()
		{
			this.DoGetLayer();
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x0003E270 File Offset: 0x0003C470
		private void DoGetLayer()
		{
			if (this.gameObject.Value == null)
			{
				return;
			}
			this.storeResult.Value = this.gameObject.Value.layer;
		}

		// Token: 0x04000DC0 RID: 3520
		[RequiredField]
		public FsmGameObject gameObject;

		// Token: 0x04000DC1 RID: 3521
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmInt storeResult;

		// Token: 0x04000DC2 RID: 3522
		public bool everyFrame;
	}
}
