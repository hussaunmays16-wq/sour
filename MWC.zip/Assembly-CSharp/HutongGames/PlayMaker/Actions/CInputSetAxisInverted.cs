﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B7 RID: 1207
	[ActionCategory("cInput")]
	[Tooltip("Sets if a axis is inverted or not inverted.")]
	public class CInputSetAxisInverted : FsmStateAction
	{
		// Token: 0x0600147E RID: 5246 RVA: 0x00089234 File Offset: 0x00087434
		public override void Reset()
		{
			this.axisName = null;
			this.axisInverted = null;
			this.storeResult = null;
			this.everyFrame = null;
		}

		// Token: 0x0600147F RID: 5247 RVA: 0x00089254 File Offset: 0x00087454
		public override void OnUpdate()
		{
			this.storeResult.Value = cInput.AxisInverted(this.axisName.Value, this.axisInverted.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CEC RID: 7404
		[RequiredField]
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CED RID: 7405
		[Tooltip("True = axis is inverted.")]
		public FsmBool axisInverted;

		// Token: 0x04001CEE RID: 7406
		[Tooltip("Stores the result if needed")]
		public FsmBool storeResult;

		// Token: 0x04001CEF RID: 7407
		[Tooltip("Execute every frame.")]
		public FsmBool everyFrame;
	}
}
