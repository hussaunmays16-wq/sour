﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003ED RID: 1005
	[Tooltip("Get the current resolution")]
	[ActionCategory(ActionCategory.Application)]
	public class GetCurrentResolution : FsmStateAction
	{
		// Token: 0x06001104 RID: 4356 RVA: 0x0005DB20 File Offset: 0x0005BD20
		public override void Reset()
		{
			this.width = null;
			this.height = null;
			this.refreshRate = null;
			this.currentResolution = null;
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x0005DB40 File Offset: 0x0005BD40
		public override void OnEnter()
		{
			this.width.Value = (float)Screen.currentResolution.width;
			this.height.Value = (float)Screen.currentResolution.height;
			this.refreshRate.Value = (float)Screen.currentResolution.refreshRate;
			this.currentResolution.Value = new Vector3((float)Screen.currentResolution.width, (float)Screen.currentResolution.height, (float)Screen.currentResolution.refreshRate);
			base.Finish();
		}

		// Token: 0x04001631 RID: 5681
		[UIHint(UIHint.Variable)]
		[Tooltip("The current resolution width")]
		public FsmFloat width;

		// Token: 0x04001632 RID: 5682
		[UIHint(UIHint.Variable)]
		[Tooltip("The current resolution height")]
		public FsmFloat height;

		// Token: 0x04001633 RID: 5683
		[UIHint(UIHint.Variable)]
		[Tooltip("The current resolution refrehs rate")]
		public FsmFloat refreshRate;

		// Token: 0x04001634 RID: 5684
		[Tooltip("The current resolution ( width, height, refreshRate )")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 currentResolution;
	}
}
