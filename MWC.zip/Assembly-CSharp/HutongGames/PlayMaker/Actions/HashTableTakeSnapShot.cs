﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003CF RID: 975
	[Tooltip("Takes a PlayMaker HashTable Proxy component snapshot, use action HashTableRevertToSnapShot was used. A Snapshot is taken by default at the beginning for the prefill data")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableTakeSnapShot : HashTableActions
	{
		// Token: 0x06001074 RID: 4212 RVA: 0x00059828 File Offset: 0x00057A28
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06001075 RID: 4213 RVA: 0x00059838 File Offset: 0x00057A38
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoHashTableTakeSnapShot();
			}
			base.Finish();
		}

		// Token: 0x06001076 RID: 4214 RVA: 0x00059878 File Offset: 0x00057A78
		public void DoHashTableTakeSnapShot()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.TakeSnapShot();
		}

		// Token: 0x04001552 RID: 5458
		[RequiredField]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001553 RID: 5459
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
