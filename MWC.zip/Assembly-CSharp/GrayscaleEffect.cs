﻿using System;
using UnityEngine;

// Token: 0x0200045A RID: 1114
[AddComponentMenu("Image Effects/Grayscale")]
[ExecuteInEditMode]
public class GrayscaleEffect : ImageEffectBase
{
	// Token: 0x060012BF RID: 4799 RVA: 0x000698B0 File Offset: 0x00067AB0
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		base.material.SetTexture("_RampTex", this.textureRamp);
		base.material.SetFloat("_RampOffset", this.rampOffset);
		Graphics.Blit(source, destination, base.material);
	}

	// Token: 0x0400186E RID: 6254
	public Texture textureRamp;

	// Token: 0x0400186F RID: 6255
	public float rampOffset;
}
