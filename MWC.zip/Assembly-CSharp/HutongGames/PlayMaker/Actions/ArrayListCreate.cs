﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B5 RID: 949
	[Tooltip("Adds a PlayMakerArrayList Component to a Game Object. Use this to create arrayList on the fly instead of during authoring.\n Optionally remove the ArrayList component on exiting the state.\n Simply point to existing if the reference exists already.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListCreate : ArrayListActions
	{
		// Token: 0x0600100D RID: 4109 RVA: 0x00057F88 File Offset: 0x00056188
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.alreadyExistsEvent = null;
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x00057FA0 File Offset: 0x000561A0
		public override void OnEnter()
		{
			this.DoAddPlayMakerArrayList();
			base.Finish();
		}

		// Token: 0x0600100F RID: 4111 RVA: 0x00057FB0 File Offset: 0x000561B0
		public override void OnExit()
		{
			if (this.removeOnExit.Value && this.addedComponent != null)
			{
				UnityEngine.Object.Destroy(this.addedComponent);
			}
		}

		// Token: 0x06001010 RID: 4112 RVA: 0x00057FEC File Offset: 0x000561EC
		private void DoAddPlayMakerArrayList()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			PlayMakerArrayListProxy arrayListProxyPointer = base.GetArrayListProxyPointer(ownerDefaultTarget, this.reference.Value, true);
			if (arrayListProxyPointer != null)
			{
				base.Fsm.Event(this.alreadyExistsEvent);
			}
			else
			{
				this.addedComponent = ownerDefaultTarget.AddComponent<PlayMakerArrayListProxy>();
				if (this.addedComponent == null)
				{
					this.LogError("Can't add PlayMakerArrayListProxy");
				}
				else
				{
					this.addedComponent.referenceName = this.reference.Value;
				}
			}
		}

		// Token: 0x040014D7 RID: 5335
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject to add the PlayMaker ArrayList Proxy component to")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014D8 RID: 5336
		[Tooltip("Author defined Reference of the PlayMaker arrayList proxy component ( necessary if several component coexists on the same GameObject")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040014D9 RID: 5337
		[Tooltip("Remove the Component when this State is exited.")]
		public FsmBool removeOnExit;

		// Token: 0x040014DA RID: 5338
		[Tooltip("The event to trigger if the arrayList exists already")]
		[UIHint(UIHint.FsmEvent)]
		[ActionSection("Result")]
		public FsmEvent alreadyExistsEvent;

		// Token: 0x040014DB RID: 5339
		private PlayMakerArrayListProxy addedComponent;
	}
}
