﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003E0 RID: 992
	[ActionCategory("Easy Save 2")]
	[Tooltip("Saves a PlayMaker Array List Proxy component to MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	public class ArrayListEasyUploadEncrypted : ArrayListActions
	{
		// Token: 0x060010CA RID: 4298 RVA: 0x0005BF48 File Offset: 0x0005A148
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.encryption = false;
			this.filePassword = string.Empty;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x0005BFDC File Offset: 0x0005A1DC
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.UploadArrayList();
			}
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x0005C018 File Offset: 0x0005A218
		private void UploadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = "false";
			if (this.encryption.Value)
			{
				text = "true";
			}
			string text2 = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text2))
			{
				text2 = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference.Value
				});
			}
			List<string> list = new List<string>();
			foreach (object item in this.proxy.arrayList)
			{
				list.Add(PlayMakerUtils.ParseValueToString(item));
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				text2,
				"&webfilename=",
				this.saveFile.Value,
				"&encrypt=",
				text,
				"&password=",
				this.filePassword.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Upload<string>(list));
			this.Log(string.Concat(new string[]
			{
				"Uploading to ",
				this.urlToPHPFile.Value,
				"?tag=",
				text2,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010CD RID: 4301 RVA: 0x0005C218 File Offset: 0x0005A418
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isUploaded);
				base.Finish();
			}
		}

		// Token: 0x040015D4 RID: 5588
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015D5 RID: 5589
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015D6 RID: 5590
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015D7 RID: 5591
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data. Leave as default if unsure.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015D8 RID: 5592
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x040015D9 RID: 5593
		[Tooltip("the password of the saved item")]
		public FsmString filePassword = string.Empty;

		// Token: 0x040015DA RID: 5594
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		[RequiredField]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x040015DB RID: 5595
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x040015DC RID: 5596
		[RequiredField]
		[Tooltip("The password that you have specified in your ES2.php file.")]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x040015DD RID: 5597
		[Tooltip("The Event to send if Upload succeeded.")]
		[ActionSection("Result")]
		public FsmEvent isUploaded;

		// Token: 0x040015DE RID: 5598
		[Tooltip("The event to send if Upload failed.")]
		public FsmEvent isError;

		// Token: 0x040015DF RID: 5599
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x040015E0 RID: 5600
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015E1 RID: 5601
		private ES2Web web;
	}
}
