﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DA RID: 986
	[Tooltip("Loads a PlayMaker Array List Proxy component From MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class ArrayListEasyDownloadEncrypted : ArrayListActions
	{
		// Token: 0x060010B0 RID: 4272 RVA: 0x0005ADD4 File Offset: 0x00058FD4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.localFile = string.Empty;
			this.encryption = false;
			this.filePassword = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010B1 RID: 4273 RVA: 0x0005AE78 File Offset: 0x00059078
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DownloadArrayList();
			}
		}

		// Token: 0x060010B2 RID: 4274 RVA: 0x0005AEB4 File Offset: 0x000590B4
		private void DownloadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._tag = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(this._tag))
			{
				this._tag = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference.Value
				});
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this._tag,
				"&webfilename=",
				this.saveFile.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new string[]
			{
				"Downloading from ",
				this.urlToPHPFile.Value,
				"?tag=",
				this.uniqueTag.Value,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x0005B01C File Offset: 0x0005921C
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				string text = "false";
				if (this.encryption.Value)
				{
					text = "true";
				}
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(string.Concat(new object[]
					{
						this.localFile.Value,
						"?tag=",
						this.uniqueTag,
						"&encrypt=",
						text,
						"&password=",
						this.password.Value
					}));
				}
				this.Log(string.Concat(new object[]
				{
					"Loaded from ",
					this.saveFile.Value,
					"?tag=",
					this.uniqueTag
				}));
				string text2 = "&savelocation=file";
				List<string> list = ES2.LoadList<string>(string.Concat(new string[]
				{
					this.localFile.Value,
					"?tag=",
					this.uniqueTag.Value,
					"&encrypt=",
					text,
					"&password=",
					this.filePassword.Value,
					text2
				}));
				this.Log(string.Concat(new object[]
				{
					"Loaded from ",
					this.localFile.Value,
					"?tag=",
					this.uniqueTag
				}));
				Debug.LogWarning("Persistent Data Path:" + Application.persistentDataPath);
				this.proxy.arrayList.Clear();
				foreach (string source in list)
				{
					this.proxy.arrayList.Add(PlayMakerUtils.ParseValueFromString(source));
				}
				base.Finish();
			}
		}

		// Token: 0x040015A2 RID: 5538
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015A3 RID: 5539
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015A4 RID: 5540
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015A5 RID: 5541
		[RequiredField]
		[Tooltip("The name of the file in the online database.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015A6 RID: 5542
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x040015A7 RID: 5543
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x040015A8 RID: 5544
		[Tooltip("the password of the saved item")]
		public FsmString filePassword = string.Empty;

		// Token: 0x040015A9 RID: 5545
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x040015AA RID: 5546
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x040015AB RID: 5547
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x040015AC RID: 5548
		[ActionSection("Result")]
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x040015AD RID: 5549
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x040015AE RID: 5550
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x040015AF RID: 5551
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015B0 RID: 5552
		private ES2Web web;

		// Token: 0x040015B1 RID: 5553
		private string _tag;
	}
}
