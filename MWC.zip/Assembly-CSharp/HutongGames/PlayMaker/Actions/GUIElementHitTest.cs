﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E5 RID: 485
	[ActionCategory(ActionCategory.GUIElement)]
	[Tooltip("Performs a Hit Test on a Game Object with a GUITexture or GUIText component.")]
	public class GUIElementHitTest : FsmStateAction
	{
		// Token: 0x0600087B RID: 2171 RVA: 0x000397A8 File Offset: 0x000379A8
		public override void Reset()
		{
			this.gameObject = null;
			this.camera = null;
			this.screenPoint = new FsmVector3
			{
				UseVariable = true
			};
			this.screenX = new FsmFloat
			{
				UseVariable = true
			};
			this.screenY = new FsmFloat
			{
				UseVariable = true
			};
			this.normalized = true;
			this.hitEvent = null;
			this.everyFrame = true;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00039820 File Offset: 0x00037A20
		public override void OnEnter()
		{
			this.DoHitTest();
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00039840 File Offset: 0x00037A40
		public override void OnUpdate()
		{
			this.DoHitTest();
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00039848 File Offset: 0x00037A48
		private void DoHitTest()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.gameObjectCached)
			{
				this.guiElement = (ownerDefaultTarget.GetComponent<GUITexture>() ?? ownerDefaultTarget.GetComponent<GUIText>());
				this.gameObjectCached = ownerDefaultTarget;
			}
			if (this.guiElement == null)
			{
				base.Finish();
				return;
			}
			Vector3 screenPosition = (!this.screenPoint.IsNone) ? this.screenPoint.Value : new Vector3(0f, 0f);
			if (!this.screenX.IsNone)
			{
				screenPosition.x = this.screenX.Value;
			}
			if (!this.screenY.IsNone)
			{
				screenPosition.y = this.screenY.Value;
			}
			if (this.normalized.Value)
			{
				screenPosition.x *= (float)Screen.width;
				screenPosition.y *= (float)Screen.height;
			}
			if (this.guiElement.HitTest(screenPosition, this.camera))
			{
				this.storeResult.Value = true;
				base.Fsm.Event(this.hitEvent);
			}
			else
			{
				this.storeResult.Value = false;
			}
		}

		// Token: 0x04000C2C RID: 3116
		[Tooltip("The GameObject that has a GUITexture or GUIText component.")]
		[RequiredField]
		[CheckForComponent(typeof(GUIElement))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000C2D RID: 3117
		[Tooltip("Specify camera or use MainCamera as default.")]
		public Camera camera;

		// Token: 0x04000C2E RID: 3118
		[Tooltip("A vector position on screen. Usually stored by actions like GetTouchInfo, or World To Screen Point.")]
		public FsmVector3 screenPoint;

		// Token: 0x04000C2F RID: 3119
		[Tooltip("Specify screen X coordinate.")]
		public FsmFloat screenX;

		// Token: 0x04000C30 RID: 3120
		[Tooltip("Specify screen Y coordinate.")]
		public FsmFloat screenY;

		// Token: 0x04000C31 RID: 3121
		[Tooltip("Whether the specified screen coordinates are normalized (0-1).")]
		public FsmBool normalized;

		// Token: 0x04000C32 RID: 3122
		[Tooltip("Event to send if the Hit Test is true.")]
		public FsmEvent hitEvent;

		// Token: 0x04000C33 RID: 3123
		[Tooltip("Store the result of the Hit Test in a bool variable (true/false).")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000C34 RID: 3124
		[Tooltip("Repeat every frame. Useful if you want to wait for the hit test to return true.")]
		public FsmBool everyFrame;

		// Token: 0x04000C35 RID: 3125
		private GUIElement guiElement;

		// Token: 0x04000C36 RID: 3126
		private GameObject gameObjectCached;
	}
}
