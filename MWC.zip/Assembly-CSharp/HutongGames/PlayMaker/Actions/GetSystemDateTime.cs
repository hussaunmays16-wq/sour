﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200025A RID: 602
	[Tooltip("Gets system date and time info and stores it in a string variable. An optional format string gives you a lot of control over the formatting (see online docs for format syntax).")]
	[ActionCategory(ActionCategory.Time)]
	public class GetSystemDateTime : FsmStateAction
	{
		// Token: 0x06000A46 RID: 2630 RVA: 0x0003F6F8 File Offset: 0x0003D8F8
		public override void Reset()
		{
			this.storeString = null;
			this.format = "MM/dd/yyyy HH:mm";
		}

		// Token: 0x06000A47 RID: 2631 RVA: 0x0003F714 File Offset: 0x0003D914
		public override void OnEnter()
		{
			this.storeString.Value = DateTime.Now.ToString(this.format.Value);
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A48 RID: 2632 RVA: 0x0003F758 File Offset: 0x0003D958
		public override void OnUpdate()
		{
			this.storeString.Value = DateTime.Now.ToString(this.format.Value);
		}

		// Token: 0x04000E2E RID: 3630
		[UIHint(UIHint.Variable)]
		[Tooltip("Store System DateTime as a string.")]
		public FsmString storeString;

		// Token: 0x04000E2F RID: 3631
		[Tooltip("Optional format string. E.g., MM/dd/yyyy HH:mm")]
		public FsmString format;

		// Token: 0x04000E30 RID: 3632
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
