﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000397 RID: 919
	[Tooltip("Add an item to a PlayMaker Array List Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListAdd : ArrayListActions
	{
		// Token: 0x06000F93 RID: 3987 RVA: 0x00055C28 File Offset: 0x00053E28
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.variable = null;
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x00055C40 File Offset: 0x00053E40
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.AddToArrayList();
			}
			base.Finish();
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x00055C80 File Offset: 0x00053E80
		public void AddToArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.Add(PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variable), this.variable.Type.ToString(), false);
		}

		// Token: 0x04001444 RID: 5188
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001445 RID: 5189
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x04001446 RID: 5190
		[ActionSection("Data")]
		[Tooltip("The variable to add.")]
		[RequiredField]
		public FsmVar variable;
	}
}
