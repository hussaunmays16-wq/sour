﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200012E RID: 302
	[Tooltip("Animates the value of a Color Variable using an Animation Curve.")]
	[ActionCategory(ActionCategory.AnimateVariables)]
	public class AnimateColor : AnimateFsmAction
	{
		// Token: 0x06000597 RID: 1431 RVA: 0x0002972C File Offset: 0x0002792C
		public override void Reset()
		{
			base.Reset();
			this.colorVariable = new FsmColor
			{
				UseVariable = true
			};
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00029754 File Offset: 0x00027954
		public override void OnEnter()
		{
			base.OnEnter();
			this.finishInNextStep = false;
			this.resultFloats = new float[4];
			this.fromFloats = new float[4];
			this.fromFloats[0] = ((!this.colorVariable.IsNone) ? this.colorVariable.Value.r : 0f);
			this.fromFloats[1] = ((!this.colorVariable.IsNone) ? this.colorVariable.Value.g : 0f);
			this.fromFloats[2] = ((!this.colorVariable.IsNone) ? this.colorVariable.Value.b : 0f);
			this.fromFloats[3] = ((!this.colorVariable.IsNone) ? this.colorVariable.Value.a : 0f);
			this.curves = new AnimationCurve[4];
			this.curves[0] = this.curveR.curve;
			this.curves[1] = this.curveG.curve;
			this.curves[2] = this.curveB.curve;
			this.curves[3] = this.curveA.curve;
			this.calculations = new AnimateFsmAction.Calculation[4];
			this.calculations[0] = this.calculationR;
			this.calculations[1] = this.calculationG;
			this.calculations[2] = this.calculationB;
			this.calculations[3] = this.calculationA;
			base.Init();
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x000298FC File Offset: 0x00027AFC
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.colorVariable.IsNone && this.isRunning)
			{
				this.clr = new Color(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
				this.colorVariable.Value = this.clr;
			}
			if (this.finishInNextStep && !this.looping)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.colorVariable.IsNone)
				{
					this.clr = new Color(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
					this.colorVariable.Value = this.clr;
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x04000825 RID: 2085
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmColor colorVariable;

		// Token: 0x04000826 RID: 2086
		[RequiredField]
		public FsmAnimationCurve curveR;

		// Token: 0x04000827 RID: 2087
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to colorVariable.r.")]
		public AnimateFsmAction.Calculation calculationR;

		// Token: 0x04000828 RID: 2088
		[RequiredField]
		public FsmAnimationCurve curveG;

		// Token: 0x04000829 RID: 2089
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to colorVariable.g.")]
		public AnimateFsmAction.Calculation calculationG;

		// Token: 0x0400082A RID: 2090
		[RequiredField]
		public FsmAnimationCurve curveB;

		// Token: 0x0400082B RID: 2091
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to colorVariable.b.")]
		public AnimateFsmAction.Calculation calculationB;

		// Token: 0x0400082C RID: 2092
		[RequiredField]
		public FsmAnimationCurve curveA;

		// Token: 0x0400082D RID: 2093
		[Tooltip("Calculation lets you set a type of curve deformation that will be applied to colorVariable.a.")]
		public AnimateFsmAction.Calculation calculationA;

		// Token: 0x0400082E RID: 2094
		private bool finishInNextStep;

		// Token: 0x0400082F RID: 2095
		private Color clr;
	}
}
