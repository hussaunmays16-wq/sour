﻿using System;
using System.IO;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000401 RID: 1025
	[Tooltip("Get infos from a file by index within a directory.")]
	[ActionCategory("Files")]
	public class GetFileInfoByIndex : FsmStateAction
	{
		// Token: 0x06001149 RID: 4425 RVA: 0x0005F978 File Offset: 0x0005DB78
		public override void Reset()
		{
			this.folderPath = null;
			this.searchPattern = "*";
			this.searchOption = SearchOption.TopDirectoryOnly;
			this.fileIndex = 0;
			this.dateTimeFormat = "dddd, MMMM dd, yyyy h:mm:ss tt";
			this.IndexOutOfRangeEvent = null;
			this.directoryName = null;
			this.extension = null;
			this.fileName = null;
			this.fullName = null;
			this.isReadOnly = null;
			this.creationTime = null;
			this.lastAccessTime = null;
			this.lastWriteTime = null;
			this.fileSize = null;
		}

		// Token: 0x0600114A RID: 4426 RVA: 0x0005FA08 File Offset: 0x0005DC08
		public override void OnEnter()
		{
			this.DoGetFileInfoByIndex();
			base.Finish();
		}

		// Token: 0x0600114B RID: 4427 RVA: 0x0005FA18 File Offset: 0x0005DC18
		private void DoGetFileInfoByIndex()
		{
			string[] files = Directory.GetFiles(this.folderPath.Value, this.searchPattern.Value, this.searchOption);
			if (files.Length == 0)
			{
				base.Fsm.Event(this.IndexOutOfRangeEvent);
			}
			if (this.fileIndex.Value < 0 || this.fileIndex.Value >= files.Length)
			{
				base.Fsm.Event(this.IndexOutOfRangeEvent);
			}
			FileInfo fileInfo = new FileInfo(files[this.fileIndex.Value]);
			if (!this.fileName.IsNone)
			{
				this.fileName.Value = fileInfo.Name;
			}
			if (!this.extension.IsNone)
			{
				this.extension.Value = Path.GetExtension(fileInfo.FullName);
			}
			if (!this.directoryName.IsNone)
			{
				this.directoryName.Value = fileInfo.DirectoryName;
			}
			if (!this.fullName.IsNone)
			{
				this.fullName.Value = fileInfo.FullName;
			}
			if (!this.isReadOnly.IsNone)
			{
				this.isReadOnly.Value = fileInfo.IsReadOnly;
			}
			if (!this.creationTime.IsNone)
			{
				this.creationTime.Value = fileInfo.CreationTime.ToString(this.dateTimeFormat.Value);
			}
			if (!this.lastWriteTime.IsNone)
			{
				this.lastWriteTime.Value = fileInfo.LastWriteTime.ToString(this.dateTimeFormat.Value);
			}
			if (!this.lastAccessTime.IsNone)
			{
				this.lastAccessTime.Value = fileInfo.LastAccessTime.ToString(this.lastAccessTime.Value);
			}
			if (!this.fileSize.IsNone)
			{
				this.fileSize.Value = (int)fileInfo.Length;
			}
		}

		// Token: 0x040016B0 RID: 5808
		[Tooltip("The path of the folder.")]
		[RequiredField]
		public FsmString folderPath;

		// Token: 0x040016B1 RID: 5809
		[RequiredField]
		[Tooltip("The search pattern. Use * for all")]
		public FsmString searchPattern;

		// Token: 0x040016B2 RID: 5810
		[Tooltip("The search options. let you search only in the folder or in all sub folders too")]
		public SearchOption searchOption;

		// Token: 0x040016B3 RID: 5811
		[Tooltip("The number of files in the folder")]
		[RequiredField]
		public FsmInt fileIndex;

		// Token: 0x040016B4 RID: 5812
		[Tooltip("The datetime format to get datetime properties of the file in the folder")]
		public FsmString dateTimeFormat;

		// Token: 0x040016B5 RID: 5813
		[Tooltip("The name of the file")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmString fileName;

		// Token: 0x040016B6 RID: 5814
		[UIHint(UIHint.Variable)]
		[Tooltip("The extension  of the file")]
		public FsmString extension;

		// Token: 0x040016B7 RID: 5815
		[UIHint(UIHint.Variable)]
		[Tooltip("The full name of the file")]
		public FsmString fullName;

		// Token: 0x040016B8 RID: 5816
		[UIHint(UIHint.Variable)]
		[Tooltip("The directory name of the file")]
		public FsmString directoryName;

		// Token: 0x040016B9 RID: 5817
		[UIHint(UIHint.Variable)]
		[Tooltip("The readonly state of the file")]
		public FsmBool isReadOnly;

		// Token: 0x040016BA RID: 5818
		[Tooltip("The creation time of the file")]
		[UIHint(UIHint.Variable)]
		public FsmString creationTime;

		// Token: 0x040016BB RID: 5819
		[UIHint(UIHint.Variable)]
		[Tooltip("The last access time of the file")]
		public FsmString lastAccessTime;

		// Token: 0x040016BC RID: 5820
		[UIHint(UIHint.Variable)]
		[Tooltip("The last write time of the file")]
		public FsmString lastWriteTime;

		// Token: 0x040016BD RID: 5821
		[Tooltip("The file size in bytes")]
		[UIHint(UIHint.Variable)]
		public FsmInt fileSize;

		// Token: 0x040016BE RID: 5822
		[Tooltip("Event sent if no file found")]
		public FsmEvent IndexOutOfRangeEvent;
	}
}
