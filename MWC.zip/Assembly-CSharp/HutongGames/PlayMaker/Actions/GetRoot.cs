﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000250 RID: 592
	[Tooltip("Gets the top most parent of the Game Object.\nIf the game object has no parent, returns itself.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetRoot : FsmStateAction
	{
		// Token: 0x06000A19 RID: 2585 RVA: 0x0003F08C File Offset: 0x0003D28C
		public override void Reset()
		{
			this.gameObject = null;
			this.storeRoot = null;
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0003F09C File Offset: 0x0003D29C
		public override void OnEnter()
		{
			this.DoGetRoot();
			base.Finish();
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0003F0AC File Offset: 0x0003D2AC
		private void DoGetRoot()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			this.storeRoot.Value = ownerDefaultTarget.transform.root.gameObject;
		}

		// Token: 0x04000E08 RID: 3592
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E09 RID: 3593
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmGameObject storeRoot;
	}
}
