﻿using System;
using UnityEngine;

// Token: 0x02000459 RID: 1113
[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
[AddComponentMenu("Image Effects/GlowThreshold_26")]
public class GlowEffectThreshold_26 : MonoBehaviour
{
	// Token: 0x17000090 RID: 144
	// (get) Token: 0x060012B5 RID: 4789 RVA: 0x00069434 File Offset: 0x00067634
	protected static Material compositeMaterial
	{
		get
		{
			if (GlowEffectThreshold_26.m_CompositeMaterial == null)
			{
				GlowEffectThreshold_26.m_CompositeMaterial = new Material(GlowEffectThreshold_26.compositeMatString);
				GlowEffectThreshold_26.m_CompositeMaterial.hideFlags = HideFlags.HideAndDontSave;
				GlowEffectThreshold_26.m_CompositeMaterial.shader.hideFlags = HideFlags.HideAndDontSave;
			}
			return GlowEffectThreshold_26.m_CompositeMaterial;
		}
	}

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x060012B6 RID: 4790 RVA: 0x00069484 File Offset: 0x00067684
	protected static Material blurMaterial
	{
		get
		{
			if (GlowEffectThreshold_26.m_BlurMaterial == null)
			{
				GlowEffectThreshold_26.m_BlurMaterial = new Material(GlowEffectThreshold_26.blurMatString);
				GlowEffectThreshold_26.m_BlurMaterial.hideFlags = HideFlags.HideAndDontSave;
				GlowEffectThreshold_26.m_BlurMaterial.shader.hideFlags = HideFlags.HideAndDontSave;
			}
			return GlowEffectThreshold_26.m_BlurMaterial;
		}
	}

	// Token: 0x17000092 RID: 146
	// (get) Token: 0x060012B7 RID: 4791 RVA: 0x000694D4 File Offset: 0x000676D4
	protected Material downsampleMaterial
	{
		get
		{
			if (this.m_DownsampleMaterial == null)
			{
				this.m_DownsampleMaterial = new Material(this.downsampleShader);
				this.m_DownsampleMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.m_DownsampleMaterial;
		}
	}

	// Token: 0x060012B8 RID: 4792 RVA: 0x0006950C File Offset: 0x0006770C
	protected void OnDisable()
	{
		if (GlowEffectThreshold_26.m_CompositeMaterial)
		{
			UnityEngine.Object.DestroyImmediate(GlowEffectThreshold_26.m_CompositeMaterial.shader);
			UnityEngine.Object.DestroyImmediate(GlowEffectThreshold_26.m_CompositeMaterial);
		}
		if (GlowEffectThreshold_26.m_BlurMaterial)
		{
			UnityEngine.Object.DestroyImmediate(GlowEffectThreshold_26.m_BlurMaterial.shader);
			UnityEngine.Object.DestroyImmediate(GlowEffectThreshold_26.m_BlurMaterial);
		}
		if (this.m_DownsampleMaterial)
		{
			UnityEngine.Object.DestroyImmediate(this.m_DownsampleMaterial);
		}
	}

	// Token: 0x060012B9 RID: 4793 RVA: 0x00069584 File Offset: 0x00067784
	protected void Start()
	{
		if (!SystemInfo.supportsImageEffects)
		{
			base.enabled = false;
			return;
		}
		if (this.downsampleShader == null)
		{
			Debug.Log("No downsample shader assigned! Disabling glow.");
			base.enabled = false;
		}
		else
		{
			if (!GlowEffectThreshold_26.blurMaterial.shader.isSupported)
			{
				base.enabled = false;
			}
			if (!GlowEffectThreshold_26.compositeMaterial.shader.isSupported)
			{
				base.enabled = false;
			}
			if (!this.downsampleMaterial.shader.isSupported)
			{
				base.enabled = false;
			}
		}
	}

	// Token: 0x060012BA RID: 4794 RVA: 0x0006961C File Offset: 0x0006781C
	public void FourTapCone(RenderTexture source, RenderTexture dest, int iteration)
	{
		float num = 0.5f + (float)iteration * this.blurSpread;
		Graphics.BlitMultiTap(source, dest, GlowEffectThreshold_26.blurMaterial, new Vector2[]
		{
			new Vector2(-num, -num),
			new Vector2(-num, num),
			new Vector2(num, num),
			new Vector2(num, -num)
		});
	}

	// Token: 0x060012BB RID: 4795 RVA: 0x0006969C File Offset: 0x0006789C
	private void DownSample4x(RenderTexture source, RenderTexture dest)
	{
		this.downsampleMaterial.SetFloat("_GlowThreshold", this.glowThreshold);
		this.downsampleMaterial.color = new Color(this.glowTint.r, this.glowTint.g, this.glowTint.b, this.glowTint.a / 4f);
		Graphics.Blit(source, dest, this.downsampleMaterial);
	}

	// Token: 0x060012BC RID: 4796 RVA: 0x00069710 File Offset: 0x00067910
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		this.glowThreshold = Mathf.Clamp(this.glowThreshold, 0f, 1f);
		this.glowIntensity = Mathf.Clamp(this.glowIntensity, 0f, 10f);
		this.blurIterations = Mathf.Clamp(this.blurIterations, 0, 30);
		this.blurSpread = Mathf.Clamp(this.blurSpread, 0.5f, 1f);
		RenderTexture temporary = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0);
		RenderTexture temporary2 = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0);
		this.DownSample4x(source, temporary);
		float num = Mathf.Clamp01((this.glowIntensity - 1f) / 4f);
		GlowEffectThreshold_26.blurMaterial.color = new Color(1f, 1f, 1f, 0.25f + num);
		bool flag = true;
		for (int i = 0; i < this.blurIterations; i++)
		{
			if (flag)
			{
				this.FourTapCone(temporary, temporary2, i);
			}
			else
			{
				this.FourTapCone(temporary2, temporary, i);
			}
			flag = !flag;
		}
		ImageEffects.Blit(source, destination);
		if (flag)
		{
			this.BlitGlow(temporary, destination);
		}
		else
		{
			this.BlitGlow(temporary2, destination);
		}
		RenderTexture.ReleaseTemporary(temporary);
		RenderTexture.ReleaseTemporary(temporary2);
	}

	// Token: 0x060012BD RID: 4797 RVA: 0x00069864 File Offset: 0x00067A64
	public void BlitGlow(RenderTexture source, RenderTexture dest)
	{
		GlowEffectThreshold_26.compositeMaterial.color = new Color(1f, 1f, 1f, Mathf.Clamp01(this.glowIntensity));
		Graphics.Blit(source, dest, GlowEffectThreshold_26.compositeMaterial);
	}

	// Token: 0x04001863 RID: 6243
	public float glowThreshold = 0.25f;

	// Token: 0x04001864 RID: 6244
	public float glowIntensity = 1.5f;

	// Token: 0x04001865 RID: 6245
	public int blurIterations = 3;

	// Token: 0x04001866 RID: 6246
	public float blurSpread = 0.7f;

	// Token: 0x04001867 RID: 6247
	public Color glowTint = new Color(1f, 1f, 1f, 0f);

	// Token: 0x04001868 RID: 6248
	private static string compositeMatString = "Shader \"GlowCompose\" {\n\tProperties {\n\t\t_Color (\"Glow Amount\", Color) = (1,1,1,1)\n\t\t_MainTex (\"\", RECT) = \"white\" {}\n\t}\n\tSubShader {\n\t\tPass {\n\t\t\tZTest Always Cull Off ZWrite Off Fog { Mode Off }\n\t\t\tBlend One One\n\t\t\tSetTexture [_MainTex] {constantColor [_Color] combine constant * texture DOUBLE}\n\t\t}\n\t}\n\tFallback off\n}";

	// Token: 0x04001869 RID: 6249
	private static Material m_CompositeMaterial;

	// Token: 0x0400186A RID: 6250
	private static string blurMatString = "Shader \"GlowConeTap\" {\n\tProperties {\n\t\t_Color (\"Blur Boost\", Color) = (0,0,0,0.25)\n\t\t_MainTex (\"\", RECT) = \"white\" {}\n\t}\n\tSubShader {\n\t\tPass {\n\t\t\tZTest Always Cull Off ZWrite Off Fog { Mode Off }\n\t\t\tSetTexture [_MainTex] {constantColor [_Color] combine texture * constant alpha}\n\t\t\tSetTexture [_MainTex] {constantColor [_Color] combine texture * constant + previous}\n\t\t\tSetTexture [_MainTex] {constantColor [_Color] combine texture * constant + previous}\n\t\t\tSetTexture [_MainTex] {constantColor [_Color] combine texture * constant + previous}\n\t\t}\n\t}\n\tFallback off\n}";

	// Token: 0x0400186B RID: 6251
	private static Material m_BlurMaterial;

	// Token: 0x0400186C RID: 6252
	public Shader downsampleShader;

	// Token: 0x0400186D RID: 6253
	private Material m_DownsampleMaterial;
}
