﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BF RID: 959
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Check if a key exists in a PlayMaker HashTable Proxy component (PlayMakerHashTablePRoxy)")]
	public class HashTableContainsKey : HashTableActions
	{
		// Token: 0x06001036 RID: 4150 RVA: 0x000589C0 File Offset: 0x00056BC0
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.key = null;
			this.containsKey = null;
			this.keyFoundEvent = null;
			this.keyNotFoundEvent = null;
		}

		// Token: 0x06001037 RID: 4151 RVA: 0x000589F8 File Offset: 0x00056BF8
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.checkIfContainsKey();
			}
			base.Finish();
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x00058A38 File Offset: 0x00056C38
		public void checkIfContainsKey()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.containsKey.Value = this.proxy.hashTable.ContainsKey(this.key.Value);
			if (this.containsKey.Value)
			{
				base.Fsm.Event(this.keyFoundEvent);
			}
			else
			{
				base.Fsm.Event(this.keyNotFoundEvent);
			}
		}

		// Token: 0x04001506 RID: 5382
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001507 RID: 5383
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001508 RID: 5384
		[Tooltip("The Key value to check for")]
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		public FsmString key;

		// Token: 0x04001509 RID: 5385
		[Tooltip("Store the result of the test")]
		[UIHint(UIHint.FsmBool)]
		public FsmBool containsKey;

		// Token: 0x0400150A RID: 5386
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when key is found")]
		[ActionSection("Result")]
		public FsmEvent keyFoundEvent;

		// Token: 0x0400150B RID: 5387
		[Tooltip("The event to trigger when key is not found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent keyNotFoundEvent;
	}
}
