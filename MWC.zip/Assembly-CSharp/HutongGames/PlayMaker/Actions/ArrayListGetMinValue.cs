﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D8 RID: 984
	[Tooltip("Return the minimum value within an arrayList. It can use float, int, vector2 and vector3 ( uses magnitude), rect ( uses surface), gameobject ( using bounding box volume), and string ( use lenght)")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetMinValue : ArrayListActions
	{
		// Token: 0x060010A5 RID: 4261 RVA: 0x0005A70C File Offset: 0x0005890C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.minimumValue = null;
			this.minimumValueIndex = null;
			this.everyframe = true;
		}

		// Token: 0x060010A6 RID: 4262 RVA: 0x0005A734 File Offset: 0x00058934
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindMinimumValue();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x060010A7 RID: 4263 RVA: 0x0005A788 File Offset: 0x00058988
		public override void OnUpdate()
		{
			this.DoFindMinimumValue();
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x0005A790 File Offset: 0x00058990
		private void DoFindMinimumValue()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			VariableType type = this.minimumValue.Type;
			if (!ArrayListGetMinValue.supportedTypes.Contains(this.minimumValue.Type))
			{
				return;
			}
			float num = float.PositiveInfinity;
			int num2 = 0;
			int num3 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				try
				{
					float floatFromObject = PlayMakerUtils.GetFloatFromObject(obj, type, true);
					if (num > floatFromObject)
					{
						num = floatFromObject;
						num2 = num3;
					}
				}
				finally
				{
				}
				num3++;
			}
			this.minimumValueIndex.Value = num2;
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.minimumValue, this.proxy.arrayList[num2]);
		}

		// Token: 0x060010A9 RID: 4265 RVA: 0x0005A8A8 File Offset: 0x00058AA8
		public override string ErrorCheck()
		{
			if (!ArrayListGetMinValue.supportedTypes.Contains(this.minimumValue.Type))
			{
				return "A " + this.minimumValue.Type + " can not be processed as a minimum";
			}
			return string.Empty;
		}

		// Token: 0x0400158E RID: 5518
		private static VariableType[] supportedTypes = new VariableType[]
		{
			VariableType.Float,
			VariableType.Int,
			VariableType.Rect,
			VariableType.Vector2,
			VariableType.Vector3,
			VariableType.GameObject,
			VariableType.String
		};

		// Token: 0x0400158F RID: 5519
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001590 RID: 5520
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001591 RID: 5521
		[Tooltip("Performs every frame. WARNING, it could be affecting performances.")]
		public bool everyframe;

		// Token: 0x04001592 RID: 5522
		[Tooltip("The Minimum Value")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[ActionSection("Result")]
		public FsmVar minimumValue;

		// Token: 0x04001593 RID: 5523
		[UIHint(UIHint.Variable)]
		[Tooltip("The index of the Maximum Value within that arrayList")]
		public FsmInt minimumValueIndex;
	}
}
