﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004BB RID: 1211
	[ActionCategory("cInput")]
	[Tooltip("Toggles the cInput test GUI on or off.")]
	public class CInputToggleGUI : FsmStateAction
	{
		// Token: 0x06001489 RID: 5257 RVA: 0x00089394 File Offset: 0x00087594
		public override void OnEnter()
		{
			cGUI.ToggleGUI();
			base.Finish();
		}
	}
}
