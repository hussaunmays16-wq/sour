﻿using System;
using UnityEngine;

// Token: 0x02000486 RID: 1158
public class Clutch
{
	// Token: 0x06001376 RID: 4982 RVA: 0x00075130 File Offset: 0x00073330
	public float GetDragImpulse(float engine_speed, float drive_speed, float engineInertia, float totalRotationalInertia, float ratio, float wheelImpulse, float engineTorqueImpulse)
	{
		float num = totalRotationalInertia / (ratio * ratio);
		this.impulseLimit = this.clutch_position * this.maxTorque * Time.deltaTime;
		this.speedDiff = engine_speed - drive_speed;
		float num2 = engineInertia * num * this.speedDiff;
		float num3 = engineInertia * (wheelImpulse / ratio);
		float num4 = num * engineTorqueImpulse;
		float value = (num2 - num3 + num4) / (engineInertia + num);
		return Mathf.Clamp(value, -this.impulseLimit, this.impulseLimit);
	}

	// Token: 0x06001377 RID: 4983 RVA: 0x000751A4 File Offset: 0x000733A4
	public void SetClutchPosition(float value)
	{
		this.clutch_position = value;
	}

	// Token: 0x06001378 RID: 4984 RVA: 0x000751B0 File Offset: 0x000733B0
	public float GetClutchPosition()
	{
		return this.clutch_position;
	}

	// Token: 0x04001ACD RID: 6861
	public float maxTorque;

	// Token: 0x04001ACE RID: 6862
	public float speedDiff;

	// Token: 0x04001ACF RID: 6863
	private float clutch_position;

	// Token: 0x04001AD0 RID: 6864
	private float impulseLimit;
}
