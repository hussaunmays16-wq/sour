﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000487 RID: 1159
public class ForceFeedback : MonoBehaviour
{
	// Token: 0x0600137A RID: 4986
	[DllImport("user32")]
	private static extern int GetForegroundWindow();

	// Token: 0x0600137B RID: 4987
	[DllImport("UnityForceFeedback")]
	private static extern int InitDirectInput(int HWND);

	// Token: 0x0600137C RID: 4988
	[DllImport("UnityForceFeedback")]
	private static extern void Aquire();

	// Token: 0x0600137D RID: 4989
	[DllImport("UnityForceFeedback")]
	private static extern int SetDeviceForcesXY(int x, int y);

	// Token: 0x0600137E RID: 4990
	[DllImport("UnityForceFeedback")]
	private static extern bool StartEffect();

	// Token: 0x0600137F RID: 4991
	[DllImport("UnityForceFeedback")]
	private static extern bool StopEffect();

	// Token: 0x06001380 RID: 4992
	[DllImport("UnityForceFeedback")]
	private static extern bool SetAutoCenter(bool autoCentre);

	// Token: 0x06001381 RID: 4993
	[DllImport("UnityForceFeedback")]
	private static extern void FreeDirectInput();

	// Token: 0x06001382 RID: 4994 RVA: 0x000751FC File Offset: 0x000733FC
	public void Start()
	{
		this.cardynamics = base.GetComponent<CarDynamics>();
		this.InitialiseForceFeedback();
		ForceFeedback.SetAutoCenter(false);
	}

	// Token: 0x06001383 RID: 4995 RVA: 0x00075218 File Offset: 0x00073418
	public void Update()
	{
		this.sign = 1;
		if (this.invertForceFeedback)
		{
			this.sign = -1;
		}
		this.forceFeedback = this.cardynamics.forceFeedback;
		if (Mathf.Abs(this.forceFeedback) > (float)this.clampValue)
		{
			this.forceFeedback = (float)this.clampValue * Mathf.Sign(this.forceFeedback);
		}
		this.force = (int)(this.forceFeedback * this.multiplier) * this.factor * this.sign;
		ForceFeedback.SetDeviceForcesXY(this.force, 0);
	}

	// Token: 0x06001384 RID: 4996 RVA: 0x000752B0 File Offset: 0x000734B0
	public void OnApplicationQuit()
	{
		this.ShutDownForceFeedback();
	}

	// Token: 0x06001385 RID: 4997 RVA: 0x000752B8 File Offset: 0x000734B8
	private void InitialiseForceFeedback()
	{
		if (this.forceFeedbackEnabled)
		{
			Debug.LogWarning("UnityCar: Force feedback attempted to initialise but was aleady running!");
			return;
		}
		int foregroundWindow = ForceFeedback.GetForegroundWindow();
		ForceFeedback.InitDirectInput(foregroundWindow);
		ForceFeedback.Aquire();
		ForceFeedback.StartEffect();
		this.forceFeedbackEnabled = true;
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x000752FC File Offset: 0x000734FC
	private void ShutDownForceFeedback()
	{
		ForceFeedback.StopEffect();
		if (this.forceFeedbackEnabled)
		{
			ForceFeedback.FreeDirectInput();
		}
		else
		{
			Debug.LogWarning("UnityCar:  Force feedback attempted to shutdown but wasn't running!");
		}
	}

	// Token: 0x04001AD1 RID: 6865
	[HideInInspector]
	public int force;

	// Token: 0x04001AD2 RID: 6866
	private float forceFeedback;

	// Token: 0x04001AD3 RID: 6867
	private bool forceFeedbackEnabled;

	// Token: 0x04001AD4 RID: 6868
	private CarDynamics cardynamics;

	// Token: 0x04001AD5 RID: 6869
	public int factor = 1000;

	// Token: 0x04001AD6 RID: 6870
	public float multiplier = 0.5f;

	// Token: 0x04001AD7 RID: 6871
	public float smoothingFactor = 0.5f;

	// Token: 0x04001AD8 RID: 6872
	public int clampValue = 20;

	// Token: 0x04001AD9 RID: 6873
	public bool invertForceFeedback;

	// Token: 0x04001ADA RID: 6874
	private int sign = 1;

	// Token: 0x04001ADB RID: 6875
	private float m_force;
}
