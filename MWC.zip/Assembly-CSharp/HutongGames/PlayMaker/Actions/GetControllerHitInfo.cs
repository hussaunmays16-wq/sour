﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200021F RID: 543
	[ActionCategory(ActionCategory.Character)]
	[Tooltip("Gets info on the last Character Controller collision and store in variables.")]
	public class GetControllerHitInfo : FsmStateAction
	{
		// Token: 0x06000946 RID: 2374 RVA: 0x0003C848 File Offset: 0x0003AA48
		public override void Reset()
		{
			this.gameObjectHit = null;
			this.contactPoint = null;
			this.contactNormal = null;
			this.moveDirection = null;
			this.moveLength = null;
			this.physicsMaterialName = null;
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x0003C880 File Offset: 0x0003AA80
		private void StoreTriggerInfo()
		{
			if (base.Fsm.ControllerCollider == null)
			{
				return;
			}
			this.gameObjectHit.Value = base.Fsm.ControllerCollider.gameObject;
			this.contactPoint.Value = base.Fsm.ControllerCollider.point;
			this.contactNormal.Value = base.Fsm.ControllerCollider.normal;
			this.moveDirection.Value = base.Fsm.ControllerCollider.moveDirection;
			this.moveLength.Value = base.Fsm.ControllerCollider.moveLength;
			this.physicsMaterialName.Value = base.Fsm.ControllerCollider.collider.material.name;
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x0003C94C File Offset: 0x0003AB4C
		public override void OnEnter()
		{
			this.StoreTriggerInfo();
			base.Finish();
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x0003C95C File Offset: 0x0003AB5C
		public override string ErrorCheck()
		{
			return ActionHelpers.CheckOwnerPhysicsSetup(base.Owner);
		}

		// Token: 0x04000D16 RID: 3350
		[UIHint(UIHint.Variable)]
		public FsmGameObject gameObjectHit;

		// Token: 0x04000D17 RID: 3351
		[UIHint(UIHint.Variable)]
		public FsmVector3 contactPoint;

		// Token: 0x04000D18 RID: 3352
		[UIHint(UIHint.Variable)]
		public FsmVector3 contactNormal;

		// Token: 0x04000D19 RID: 3353
		[UIHint(UIHint.Variable)]
		public FsmVector3 moveDirection;

		// Token: 0x04000D1A RID: 3354
		[UIHint(UIHint.Variable)]
		public FsmFloat moveLength;

		// Token: 0x04000D1B RID: 3355
		[UIHint(UIHint.Variable)]
		[Tooltip("Useful for triggering different effects. Audio, particles...")]
		public FsmString physicsMaterialName;
	}
}
