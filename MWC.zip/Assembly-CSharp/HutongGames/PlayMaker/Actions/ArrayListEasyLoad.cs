﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DB RID: 987
	[ActionCategory("Easy Save 2")]
	[Tooltip("Loads a PlayMaker Array List Proxy component using EasySave")]
	public class ArrayListEasyLoad : ArrayListActions
	{
		// Token: 0x060010B5 RID: 4277 RVA: 0x0005B2C4 File Offset: 0x000594C4
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.saveFile = "defaultES2File.txt";
			this.loadFromResources = false;
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x0005B310 File Offset: 0x00059510
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.LoadArrayList();
			}
			base.Finish();
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x0005B350 File Offset: 0x00059550
		public void LoadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(text))
			{
				text = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference.Value
				});
			}
			ES2Settings es2Settings = new ES2Settings();
			if (this.loadFromResources.Value)
			{
				es2Settings.saveLocation = ES2Settings.SaveLocation.Resources;
			}
			List<string> list = ES2.LoadList<string>(this.saveFile.Value + "?tag=" + text);
			this.Log(string.Concat(new object[]
			{
				"Loaded from ",
				this.saveFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			this.proxy.arrayList.Clear();
			foreach (string source in list)
			{
				this.proxy.arrayList.Add(PlayMakerUtils.ParseValueFromString(source));
			}
			base.Finish();
		}

		// Token: 0x040015B2 RID: 5554
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015B3 RID: 5555
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x040015B4 RID: 5556
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		[ActionSection("Easy Save Set Up")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015B5 RID: 5557
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x040015B6 RID: 5558
		[Tooltip("Whether the data we are loading is stored in the Resources folder.")]
		public FsmBool loadFromResources;
	}
}
