﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C4 RID: 964
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Gets an item from a PlayMaker HashTable Proxy component")]
	public class HashTableGet : HashTableActions
	{
		// Token: 0x06001049 RID: 4169 RVA: 0x00058E40 File Offset: 0x00057040
		public override void Reset()
		{
			this.gameObject = null;
			this.key = null;
			this.KeyFoundEvent = null;
			this.KeyNotFoundEvent = null;
			this.result = null;
		}

		// Token: 0x0600104A RID: 4170 RVA: 0x00058E68 File Offset: 0x00057068
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.Get();
			}
			base.Finish();
		}

		// Token: 0x0600104B RID: 4171 RVA: 0x00058EA8 File Offset: 0x000570A8
		public void Get()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			if (!this.proxy.hashTable.ContainsKey(this.key.Value))
			{
				base.Fsm.Event(this.KeyNotFoundEvent);
				return;
			}
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.result, this.proxy.hashTable[this.key.Value]);
			base.Fsm.Event(this.KeyFoundEvent);
		}

		// Token: 0x04001520 RID: 5408
		[RequiredField]
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001521 RID: 5409
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001522 RID: 5410
		[Tooltip("The Key value for that hash set")]
		[RequiredField]
		[UIHint(UIHint.FsmString)]
		public FsmString key;

		// Token: 0x04001523 RID: 5411
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmVar result;

		// Token: 0x04001524 RID: 5412
		[Tooltip("The event to trigger when key is found")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent KeyFoundEvent;

		// Token: 0x04001525 RID: 5413
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("The event to trigger when key is not found")]
		public FsmEvent KeyNotFoundEvent;
	}
}
