﻿using System;
using UnityEngine;

// Token: 0x02000455 RID: 1109
[ExecuteInEditMode]
[AddComponentMenu("Image Effects/Color Correction PCMac")]
public class ColorCorrectionEffectPCMac_26 : ImageEffectBase
{
	// Token: 0x0600129B RID: 4763 RVA: 0x00068A74 File Offset: 0x00066C74
	private void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		bool flag = false;
		switch (Application.platform)
		{
		case RuntimePlatform.OSXEditor:
		case RuntimePlatform.OSXPlayer:
		case RuntimePlatform.OSXWebPlayer:
		case RuntimePlatform.OSXDashboardPlayer:
			flag = true;
			break;
		}
		if (flag)
		{
			base.material.SetTexture("_RampTex", this.textureRampMac);
		}
		else
		{
			base.material.SetTexture("_RampTex", this.textureRampPC);
		}
		base.material.SetVector("_RampOffset", new Vector4(this.rampOffsetR, this.rampOffsetG, this.rampOffsetB, 0f));
		Graphics.Blit(source, destination, base.material);
	}

	// Token: 0x04001846 RID: 6214
	public Texture textureRampPC;

	// Token: 0x04001847 RID: 6215
	public Texture textureRampMac;

	// Token: 0x04001848 RID: 6216
	public float rampOffsetR;

	// Token: 0x04001849 RID: 6217
	public float rampOffsetG;

	// Token: 0x0400184A RID: 6218
	public float rampOffsetB;
}
