﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000198 RID: 408
	[Tooltip("Downloads a Texture from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class DownloadTexture : FsmStateAction
	{
		// Token: 0x06000762 RID: 1890 RVA: 0x000345E0 File Offset: 0x000327E0
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.loadValue = null;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x0003464C File Offset: 0x0003284C
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new object[]
			{
				"Downloading from ",
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile
			}));
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x00034720 File Offset: 0x00032920
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				this.loadValue.Value = this.web.Load<Texture2D>(this.uniqueTag.Value);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
			}
		}

		// Token: 0x04000ABE RID: 2750
		[RequiredField]
		[Tooltip("The variable we want to load our data into.")]
		public FsmTexture loadValue;

		// Token: 0x04000ABF RID: 2751
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000AC0 RID: 2752
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04000AC1 RID: 2753
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000AC2 RID: 2754
		[RequiredField]
		[Tooltip("The unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000AC3 RID: 2755
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04000AC4 RID: 2756
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04000AC5 RID: 2757
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x04000AC6 RID: 2758
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x04000AC7 RID: 2759
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000AC8 RID: 2760
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000AC9 RID: 2761
		private ES2Web web;
	}
}
