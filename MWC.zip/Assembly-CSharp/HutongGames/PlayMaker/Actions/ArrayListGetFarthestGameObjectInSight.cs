﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D2 RID: 978
	[Tooltip("Return the farthest GameObject within an arrayList from a transform or position which does not have a collider between itself and another GameObject")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListGetFarthestGameObjectInSight : ArrayListActions
	{
		// Token: 0x06001081 RID: 4225 RVA: 0x00059B24 File Offset: 0x00057D24
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.distanceFrom = null;
			this.orDistanceFromVector3 = null;
			this.farthestGameObject = null;
			this.farthestIndex = null;
			this.everyframe = true;
			this.fromGameObject = null;
			this.layerMask = new FsmInt[0];
			this.invertMask = false;
		}

		// Token: 0x06001082 RID: 4226 RVA: 0x00059B84 File Offset: 0x00057D84
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindFarthestGo();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x06001083 RID: 4227 RVA: 0x00059BD8 File Offset: 0x00057DD8
		public override void OnUpdate()
		{
			this.DoFindFarthestGo();
		}

		// Token: 0x06001084 RID: 4228 RVA: 0x00059BE0 File Offset: 0x00057DE0
		private void DoFindFarthestGo()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			Vector3 vector = this.orDistanceFromVector3.Value;
			GameObject value = this.distanceFrom.Value;
			if (value != null)
			{
				vector += value.transform.position;
			}
			float num = float.PositiveInfinity;
			int num2 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject gameObject = (GameObject)obj;
				if (gameObject != null && this.DoLineCast(gameObject))
				{
					float sqrMagnitude = (gameObject.transform.position - vector).sqrMagnitude;
					if (sqrMagnitude >= num)
					{
						num = sqrMagnitude;
						this.farthestGameObject.Value = gameObject;
						this.farthestIndex.Value = num2;
					}
				}
				num2++;
			}
		}

		// Token: 0x06001085 RID: 4229 RVA: 0x00059D00 File Offset: 0x00057F00
		private bool DoLineCast(GameObject toGameObject)
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.fromGameObject);
			Vector3 position = ownerDefaultTarget.transform.position;
			Vector3 position2 = toGameObject.transform.position;
			RaycastHit raycastHitInfo;
			bool result = !Physics.Linecast(position, position2, out raycastHitInfo, ActionHelpers.LayerArrayToLayerMask(this.layerMask, this.invertMask.Value));
			base.Fsm.RaycastHitInfo = raycastHitInfo;
			return result;
		}

		// Token: 0x0400155F RID: 5471
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001560 RID: 5472
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001561 RID: 5473
		[Tooltip("Compare the distance of the items in the list to the position of this gameObject")]
		public FsmGameObject distanceFrom;

		// Token: 0x04001562 RID: 5474
		[Tooltip("If DistanceFrom declared, use OrDistanceFromVector3 as an offset")]
		public FsmVector3 orDistanceFromVector3;

		// Token: 0x04001563 RID: 5475
		public bool everyframe;

		// Token: 0x04001564 RID: 5476
		[Tooltip("The line start of the sweep.")]
		[ActionSection("Raycast Settings")]
		public FsmOwnerDefault fromGameObject;

		// Token: 0x04001565 RID: 5477
		[UIHint(UIHint.Layer)]
		[Tooltip("Pick only from these layers.")]
		public FsmInt[] layerMask;

		// Token: 0x04001566 RID: 5478
		[Tooltip("Invert the mask, so you pick from all layers except those defined above.")]
		public FsmBool invertMask;

		// Token: 0x04001567 RID: 5479
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		public FsmGameObject farthestGameObject;

		// Token: 0x04001568 RID: 5480
		[UIHint(UIHint.Variable)]
		public FsmInt farthestIndex;
	}
}
