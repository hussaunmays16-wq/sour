﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000224 RID: 548
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Gets info on the last event that caused a state change. See also Set Event Data action.")]
	public class GetEventInfo : FsmStateAction
	{
		// Token: 0x0600095A RID: 2394 RVA: 0x0003CCC8 File Offset: 0x0003AEC8
		public override void Reset()
		{
			this.sentByGameObject = null;
			this.fsmName = null;
			this.getBoolData = null;
			this.getIntData = null;
			this.getFloatData = null;
			this.getVector2Data = null;
			this.getVector3Data = null;
			this.getStringData = null;
			this.getGameObjectData = null;
			this.getRectData = null;
			this.getQuaternionData = null;
			this.getMaterialData = null;
			this.getTextureData = null;
			this.getColorData = null;
			this.getObjectData = null;
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x0003CD40 File Offset: 0x0003AF40
		public override void OnEnter()
		{
			if (Fsm.EventData.SentByFsm != null)
			{
				this.sentByGameObject.Value = Fsm.EventData.SentByFsm.GameObject;
				this.fsmName.Value = Fsm.EventData.SentByFsm.Name;
			}
			else
			{
				this.sentByGameObject.Value = null;
				this.fsmName.Value = string.Empty;
			}
			this.getBoolData.Value = Fsm.EventData.BoolData;
			this.getIntData.Value = Fsm.EventData.IntData;
			this.getFloatData.Value = Fsm.EventData.FloatData;
			this.getVector2Data.Value = Fsm.EventData.Vector2Data;
			this.getVector3Data.Value = Fsm.EventData.Vector3Data;
			this.getStringData.Value = Fsm.EventData.StringData;
			this.getGameObjectData.Value = Fsm.EventData.GameObjectData;
			this.getRectData.Value = Fsm.EventData.RectData;
			this.getQuaternionData.Value = Fsm.EventData.QuaternionData;
			this.getMaterialData.Value = Fsm.EventData.MaterialData;
			this.getTextureData.Value = Fsm.EventData.TextureData;
			this.getColorData.Value = Fsm.EventData.ColorData;
			this.getObjectData.Value = Fsm.EventData.ObjectData;
			base.Finish();
		}

		// Token: 0x04000D30 RID: 3376
		[UIHint(UIHint.Variable)]
		public FsmGameObject sentByGameObject;

		// Token: 0x04000D31 RID: 3377
		[UIHint(UIHint.Variable)]
		public FsmString fsmName;

		// Token: 0x04000D32 RID: 3378
		[UIHint(UIHint.Variable)]
		public FsmBool getBoolData;

		// Token: 0x04000D33 RID: 3379
		[UIHint(UIHint.Variable)]
		public FsmInt getIntData;

		// Token: 0x04000D34 RID: 3380
		[UIHint(UIHint.Variable)]
		public FsmFloat getFloatData;

		// Token: 0x04000D35 RID: 3381
		[UIHint(UIHint.Variable)]
		public FsmVector2 getVector2Data;

		// Token: 0x04000D36 RID: 3382
		[UIHint(UIHint.Variable)]
		public FsmVector3 getVector3Data;

		// Token: 0x04000D37 RID: 3383
		[UIHint(UIHint.Variable)]
		public FsmString getStringData;

		// Token: 0x04000D38 RID: 3384
		[UIHint(UIHint.Variable)]
		public FsmGameObject getGameObjectData;

		// Token: 0x04000D39 RID: 3385
		[UIHint(UIHint.Variable)]
		public FsmRect getRectData;

		// Token: 0x04000D3A RID: 3386
		[UIHint(UIHint.Variable)]
		public FsmQuaternion getQuaternionData;

		// Token: 0x04000D3B RID: 3387
		[UIHint(UIHint.Variable)]
		public FsmMaterial getMaterialData;

		// Token: 0x04000D3C RID: 3388
		[UIHint(UIHint.Variable)]
		public FsmTexture getTextureData;

		// Token: 0x04000D3D RID: 3389
		[UIHint(UIHint.Variable)]
		public FsmColor getColorData;

		// Token: 0x04000D3E RID: 3390
		[UIHint(UIHint.Variable)]
		public FsmObject getObjectData;
	}
}
