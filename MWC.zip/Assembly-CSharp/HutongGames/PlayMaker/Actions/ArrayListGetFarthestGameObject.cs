﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D1 RID: 977
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Return the farthest GameObject within an arrayList from a transform or position.")]
	public class ArrayListGetFarthestGameObject : ArrayListActions
	{
		// Token: 0x0600107C RID: 4220 RVA: 0x00059978 File Offset: 0x00057B78
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.distanceFrom = null;
			this.orDistanceFromVector3 = null;
			this.farthestGameObject = null;
			this.farthestIndex = null;
			this.everyframe = true;
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x000599AC File Offset: 0x00057BAC
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindFarthestGo();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x00059A00 File Offset: 0x00057C00
		public override void OnUpdate()
		{
			this.DoFindFarthestGo();
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x00059A08 File Offset: 0x00057C08
		private void DoFindFarthestGo()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			Vector3 vector = this.orDistanceFromVector3.Value;
			GameObject value = this.distanceFrom.Value;
			if (value != null)
			{
				vector += value.transform.position;
			}
			float num = 0f;
			int num2 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject gameObject = (GameObject)obj;
				if (gameObject != null)
				{
					float sqrMagnitude = (gameObject.transform.position - vector).sqrMagnitude;
					if (sqrMagnitude >= num)
					{
						num = sqrMagnitude;
						this.farthestGameObject.Value = gameObject;
						this.farthestIndex.Value = num2;
					}
				}
				num2++;
			}
		}

		// Token: 0x04001558 RID: 5464
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[ActionSection("Set up")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001559 RID: 5465
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400155A RID: 5466
		[Tooltip("Compare the distance of the items in the list to the position of this gameObject")]
		public FsmGameObject distanceFrom;

		// Token: 0x0400155B RID: 5467
		[Tooltip("If DistanceFrom declared, use OrDistanceFromVector3 as an offset")]
		public FsmVector3 orDistanceFromVector3;

		// Token: 0x0400155C RID: 5468
		public bool everyframe;

		// Token: 0x0400155D RID: 5469
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmGameObject farthestGameObject;

		// Token: 0x0400155E RID: 5470
		[UIHint(UIHint.Variable)]
		public FsmInt farthestIndex;
	}
}
