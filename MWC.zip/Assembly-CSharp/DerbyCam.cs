﻿using System;
using UnityEngine;

// Token: 0x020000C2 RID: 194
public class DerbyCam : MonoBehaviour
{
	// Token: 0x060003B3 RID: 947 RVA: 0x00018664 File Offset: 0x00016864
	private void Update()
	{
		base.transform.LookAt(this.Car.transform);
	}

	// Token: 0x04000575 RID: 1397
	public GameObject Car;
}
