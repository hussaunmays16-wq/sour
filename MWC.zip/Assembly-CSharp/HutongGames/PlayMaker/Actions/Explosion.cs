﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C7 RID: 455
	[Tooltip("Applies an explosion Force to all Game Objects with a Rigid Body inside a Radius.")]
	[ActionCategory(ActionCategory.Physics)]
	public class Explosion : FsmStateAction
	{
		// Token: 0x060007FF RID: 2047 RVA: 0x00037F2C File Offset: 0x0003612C
		public override void Reset()
		{
			this.center = null;
			this.upwardsModifier = 0f;
			this.forceMode = ForceMode.Force;
			this.everyFrame = false;
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x00037F54 File Offset: 0x00036154
		public override void Awake()
		{
			base.Fsm.HandleFixedUpdate = true;
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x00037F64 File Offset: 0x00036164
		public override void OnEnter()
		{
			this.DoExplosion();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x00037F80 File Offset: 0x00036180
		public override void OnFixedUpdate()
		{
			this.DoExplosion();
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x00037F88 File Offset: 0x00036188
		private void DoExplosion()
		{
			Collider[] array = Physics.OverlapSphere(this.center.Value, this.radius.Value);
			foreach (Collider collider in array)
			{
				Rigidbody component = collider.gameObject.GetComponent<Rigidbody>();
				if (component != null && this.ShouldApplyForce(collider.gameObject))
				{
					component.AddExplosionForce(this.force.Value, this.center.Value, this.radius.Value, this.upwardsModifier.Value, this.forceMode);
				}
			}
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x00038030 File Offset: 0x00036230
		private bool ShouldApplyForce(GameObject go)
		{
			int num = ActionHelpers.LayerArrayToLayerMask(this.layerMask, this.invertMask.Value);
			return (1 << go.layer & num) > 0;
		}

		// Token: 0x04000BA2 RID: 2978
		[RequiredField]
		[Tooltip("The world position of the center of the explosion.")]
		public FsmVector3 center;

		// Token: 0x04000BA3 RID: 2979
		[RequiredField]
		[Tooltip("The strength of the explosion.")]
		public FsmFloat force;

		// Token: 0x04000BA4 RID: 2980
		[RequiredField]
		[Tooltip("The radius of the explosion. Force falls of linearly with distance.")]
		public FsmFloat radius;

		// Token: 0x04000BA5 RID: 2981
		[Tooltip("Applies the force as if it was applied from beneath the object. This is useful since explosions that throw things up instead of pushing things to the side look cooler. A value of 2 will apply a force as if it is applied from 2 meters below while not changing the actual explosion position.")]
		public FsmFloat upwardsModifier;

		// Token: 0x04000BA6 RID: 2982
		[Tooltip("The type of force to apply.")]
		public ForceMode forceMode;

		// Token: 0x04000BA7 RID: 2983
		[UIHint(UIHint.Layer)]
		public FsmInt layer;

		// Token: 0x04000BA8 RID: 2984
		[Tooltip("Layers to effect.")]
		[UIHint(UIHint.Layer)]
		public FsmInt[] layerMask;

		// Token: 0x04000BA9 RID: 2985
		[Tooltip("Invert the mask, so you effect all layers except those defined above.")]
		public FsmBool invertMask;

		// Token: 0x04000BAA RID: 2986
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
