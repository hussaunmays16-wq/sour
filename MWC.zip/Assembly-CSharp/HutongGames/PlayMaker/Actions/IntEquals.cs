﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000407 RID: 1031
	[Tooltip("Sends Events based on the comparison of multiple Integers.")]
	[ActionCategory(ActionCategory.Logic)]
	public class IntEquals : FsmStateAction
	{
		// Token: 0x06001166 RID: 4454 RVA: 0x0006011C File Offset: 0x0005E31C
		public override void Reset()
		{
			this.integers = new FsmInt[2];
			this.equal = null;
			this.notEqual = null;
			this.everyFrame = false;
		}

		// Token: 0x06001167 RID: 4455 RVA: 0x00060140 File Offset: 0x0005E340
		public override void OnEnter()
		{
			this.DoIntCompare();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x0006015C File Offset: 0x0005E35C
		public override void OnUpdate()
		{
			this.DoIntCompare();
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x00060164 File Offset: 0x0005E364
		private void DoIntCompare()
		{
			if (this.integers.Length > 1)
			{
				int value = this.integers[0].Value;
				foreach (FsmInt fsmInt in this.integers)
				{
					if (value != fsmInt.Value)
					{
						base.Fsm.Event(this.notEqual);
						return;
					}
				}
			}
			base.Fsm.Event(this.equal);
		}

		// Token: 0x0600116A RID: 4458 RVA: 0x000601DC File Offset: 0x0005E3DC
		public override string ErrorCheck()
		{
			if (FsmEvent.IsNullOrEmpty(this.equal) && FsmEvent.IsNullOrEmpty(this.notEqual))
			{
				return "Action sends no events!";
			}
			if (this.integers.Length < 2)
			{
				return "Action needs more than 1 int to compare";
			}
			return string.Empty;
		}

		// Token: 0x040016D6 RID: 5846
		[RequiredField]
		public FsmInt[] integers;

		// Token: 0x040016D7 RID: 5847
		[Tooltip("Event sent if all ints equal")]
		public FsmEvent equal;

		// Token: 0x040016D8 RID: 5848
		[Tooltip("Event sent if ints not equal")]
		public FsmEvent notEqual;

		// Token: 0x040016D9 RID: 5849
		public bool everyFrame;
	}
}
