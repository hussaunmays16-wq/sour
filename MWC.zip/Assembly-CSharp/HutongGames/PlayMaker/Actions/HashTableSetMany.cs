﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003CD RID: 973
	[Tooltip("Set key/value pairs to a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy)")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableSetMany : HashTableActions
	{
		// Token: 0x0600106D RID: 4205 RVA: 0x0005974C File Offset: 0x0005794C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.keys = null;
			this.variables = null;
		}

		// Token: 0x0600106E RID: 4206 RVA: 0x0005976C File Offset: 0x0005796C
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.SetHashTable();
			}
			base.Finish();
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x000597AC File Offset: 0x000579AC
		public void SetHashTable()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			for (int i = 0; i < this.keys.Length; i++)
			{
				this.proxy.hashTable[this.keys[i].Value] = PlayMakerUtils.GetValueFromFsmVar(base.Fsm, this.variables[i]);
			}
		}

		// Token: 0x0400154E RID: 5454
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400154F RID: 5455
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001550 RID: 5456
		[CompoundArray("Count", "Key", "Value")]
		[ActionSection("Data")]
		[RequiredField]
		[UIHint(UIHint.FsmString)]
		[Tooltip("The Key values for that hash set")]
		public FsmString[] keys;

		// Token: 0x04001551 RID: 5457
		[Tooltip("The variable to set.")]
		public FsmVar[] variables;
	}
}
