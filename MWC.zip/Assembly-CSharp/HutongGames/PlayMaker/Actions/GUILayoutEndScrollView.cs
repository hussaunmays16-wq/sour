﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F6 RID: 502
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("Close a group started with GUILayout Begin ScrollView.")]
	public class GUILayoutEndScrollView : FsmStateAction
	{
		// Token: 0x060008B0 RID: 2224 RVA: 0x0003A61C File Offset: 0x0003881C
		public override void OnGUI()
		{
			GUILayout.EndScrollView();
		}
	}
}
