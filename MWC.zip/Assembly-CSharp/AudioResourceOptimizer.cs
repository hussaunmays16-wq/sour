﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000094 RID: 148
public static class AudioResourceOptimizer
{
	// Token: 0x06000239 RID: 569 RVA: 0x0000E4FC File Offset: 0x0000C6FC
	public static void ClearAudioClips()
	{
		AudioResourceOptimizer.AudioClipsByName.Clear();
		AudioResourceOptimizer.AudioResourceTargetsByName.Clear();
	}

	// Token: 0x0600023A RID: 570 RVA: 0x0000E514 File Offset: 0x0000C714
	public static string GetLocalizedDynamicSoundGroupFileName(SystemLanguage localLanguage, bool useLocalization, string resourceFileName)
	{
		if (!useLocalization)
		{
			return resourceFileName;
		}
		if (MasterAudio.Instance != null)
		{
			return AudioResourceOptimizer.GetLocalizedFileName(useLocalization, resourceFileName);
		}
		return localLanguage.ToString() + "/" + resourceFileName;
	}

	// Token: 0x0600023B RID: 571 RVA: 0x0000E558 File Offset: 0x0000C758
	public static string GetLocalizedFileName(bool useLocalization, string resourceFileName)
	{
		return (!useLocalization) ? resourceFileName : (AudioResourceOptimizer.SupportedLanguageFolder() + "/" + resourceFileName);
	}

	// Token: 0x0600023C RID: 572 RVA: 0x0000E578 File Offset: 0x0000C778
	public static void AddTargetForClip(string clipName, AudioSource source)
	{
		if (!AudioResourceOptimizer.AudioResourceTargetsByName.ContainsKey(clipName))
		{
			AudioResourceOptimizer.AudioResourceTargetsByName.Add(clipName, new List<AudioSource>
			{
				source
			});
		}
		else
		{
			List<AudioSource> list = AudioResourceOptimizer.AudioResourceTargetsByName[clipName];
			list.Add(source);
		}
	}

	// Token: 0x0600023D RID: 573 RVA: 0x0000E5C8 File Offset: 0x0000C7C8
	private static string SupportedLanguageFolder()
	{
		if (!string.IsNullOrEmpty(AudioResourceOptimizer._supportedLanguageFolder))
		{
			return AudioResourceOptimizer._supportedLanguageFolder;
		}
		SystemLanguage systemLanguage = Application.systemLanguage;
		if (MasterAudio.Instance != null)
		{
			MasterAudio.LanguageMode langMode = MasterAudio.Instance.langMode;
			if (langMode != MasterAudio.LanguageMode.SpecificLanguage)
			{
				if (langMode == MasterAudio.LanguageMode.DynamicallySet)
				{
					systemLanguage = MasterAudio.DynamicLanguage;
				}
			}
			else
			{
				systemLanguage = MasterAudio.Instance.testLanguage;
			}
		}
		if (MasterAudio.Instance.supportedLanguages.Contains(systemLanguage))
		{
			AudioResourceOptimizer._supportedLanguageFolder = systemLanguage.ToString();
		}
		else
		{
			AudioResourceOptimizer._supportedLanguageFolder = MasterAudio.Instance.defaultLanguage.ToString();
		}
		return AudioResourceOptimizer._supportedLanguageFolder;
	}

	// Token: 0x0600023E RID: 574 RVA: 0x0000E684 File Offset: 0x0000C884
	public static void ClearSupportLanguageFolder()
	{
		AudioResourceOptimizer._supportedLanguageFolder = string.Empty;
	}

	// Token: 0x0600023F RID: 575 RVA: 0x0000E690 File Offset: 0x0000C890
	public static AudioClip PopulateResourceSongToPlaylistController(string controllerName, string songResourceName, string playlistName)
	{
		AudioClip audioClip = Resources.Load(songResourceName) as AudioClip;
		if (audioClip == null)
		{
			MasterAudio.LogWarning(string.Concat(new string[]
			{
				"Resource file '",
				songResourceName,
				"' could not be located from Playlist '",
				playlistName,
				"'."
			}));
			return null;
		}
		AudioResourceOptimizer.FinishRecordingPlaylistClip(controllerName, audioClip);
		return audioClip;
	}

	// Token: 0x06000240 RID: 576 RVA: 0x0000E6F0 File Offset: 0x0000C8F0
	private static void FinishRecordingPlaylistClip(string controllerName, AudioClip resAudioClip)
	{
		List<AudioClip> list;
		if (!AudioResourceOptimizer.PlaylistClipsByPlaylistName.ContainsKey(controllerName))
		{
			list = new List<AudioClip>(5);
			AudioResourceOptimizer.PlaylistClipsByPlaylistName.Add(controllerName, list);
		}
		else
		{
			list = AudioResourceOptimizer.PlaylistClipsByPlaylistName[controllerName];
		}
		list.Add(resAudioClip);
	}

	// Token: 0x06000241 RID: 577 RVA: 0x0000E738 File Offset: 0x0000C938
	public static IEnumerator PopulateResourceSongToPlaylistControllerAsync(string songResourceName, string playlistName, PlaylistController controller, PlaylistController.AudioPlayType playType)
	{
		ResourceRequest asyncRes = Resources.LoadAsync(songResourceName, typeof(AudioClip));
		while (!asyncRes.isDone)
		{
			yield return MasterAudio.EndOfFrameDelay;
		}
		AudioClip resAudioClip = asyncRes.asset as AudioClip;
		if (resAudioClip == null)
		{
			MasterAudio.LogWarning(string.Concat(new string[]
			{
				"Resource file '",
				songResourceName,
				"' could not be located from Playlist '",
				playlistName,
				"'."
			}));
			yield break;
		}
		AudioResourceOptimizer.FinishRecordingPlaylistClip(controller.ControllerName, resAudioClip);
		controller.FinishLoadingNewSong(resAudioClip, playType);
		yield break;
	}

	// Token: 0x06000242 RID: 578 RVA: 0x0000E784 File Offset: 0x0000C984
	public static IEnumerator PopulateSourcesWithResourceClipAsync(string clipName, SoundGroupVariation variation, Action successAction, Action failureAction)
	{
		if (AudioResourceOptimizer.AudioClipsByName.ContainsKey(clipName))
		{
			if (successAction != null)
			{
				successAction();
			}
			yield break;
		}
		ResourceRequest asyncRes = Resources.LoadAsync(clipName, typeof(AudioClip));
		while (!asyncRes.isDone)
		{
			yield return MasterAudio.EndOfFrameDelay;
		}
		AudioClip resAudioClip = asyncRes.asset as AudioClip;
		if (resAudioClip == null)
		{
			MasterAudio.LogError("Resource file '" + clipName + "' could not be located.");
			if (failureAction != null)
			{
				failureAction();
			}
			yield break;
		}
		if (!AudioResourceOptimizer.AudioResourceTargetsByName.ContainsKey(clipName))
		{
			Debug.LogError("No Audio Sources found to add Resource file '" + clipName + "'.");
			if (failureAction != null)
			{
				failureAction();
			}
			yield break;
		}
		List<AudioSource> sources = AudioResourceOptimizer.AudioResourceTargetsByName[clipName];
		for (int i = 0; i < sources.Count; i++)
		{
			sources[i].clip = resAudioClip;
		}
		if (!AudioResourceOptimizer.AudioClipsByName.ContainsKey(clipName))
		{
			AudioResourceOptimizer.AudioClipsByName.Add(clipName, resAudioClip);
		}
		if (successAction != null)
		{
			successAction();
		}
		yield break;
	}

	// Token: 0x06000243 RID: 579 RVA: 0x0000E7C4 File Offset: 0x0000C9C4
	public static void UnloadPlaylistSongIfUnused(string controllerName, AudioClip clipToRemove)
	{
		if (clipToRemove == null)
		{
			return;
		}
		if (!AudioResourceOptimizer.PlaylistClipsByPlaylistName.ContainsKey(controllerName))
		{
			return;
		}
		List<AudioClip> list = AudioResourceOptimizer.PlaylistClipsByPlaylistName[controllerName];
		if (!list.Contains(clipToRemove))
		{
			return;
		}
		list.Remove(clipToRemove);
		if (!list.Contains(clipToRemove))
		{
			Resources.UnloadAsset(clipToRemove);
		}
	}

	// Token: 0x06000244 RID: 580 RVA: 0x0000E824 File Offset: 0x0000CA24
	public static bool PopulateSourcesWithResourceClip(string clipName, SoundGroupVariation variation)
	{
		if (AudioResourceOptimizer.AudioClipsByName.ContainsKey(clipName))
		{
			return true;
		}
		AudioClip audioClip = Resources.Load(clipName) as AudioClip;
		if (audioClip == null)
		{
			MasterAudio.LogError("Resource file '" + clipName + "' could not be located.");
			return false;
		}
		if (!AudioResourceOptimizer.AudioResourceTargetsByName.ContainsKey(clipName))
		{
			Debug.LogError("No Audio Sources found to add Resource file '" + clipName + "'.");
			return false;
		}
		List<AudioSource> list = AudioResourceOptimizer.AudioResourceTargetsByName[clipName];
		for (int i = 0; i < list.Count; i++)
		{
			list[i].clip = audioClip;
		}
		AudioResourceOptimizer.AudioClipsByName.Add(clipName, audioClip);
		return true;
	}

	// Token: 0x06000245 RID: 581 RVA: 0x0000E8D8 File Offset: 0x0000CAD8
	public static void DeleteAudioSourceFromList(string clipName, AudioSource source)
	{
		if (!AudioResourceOptimizer.AudioResourceTargetsByName.ContainsKey(clipName))
		{
			Debug.Log("No Audio Sources found for Resource file '" + clipName + "'.");
			return;
		}
		List<AudioSource> list = AudioResourceOptimizer.AudioResourceTargetsByName[clipName];
		list.Remove(source);
		if (list.Count == 0)
		{
			AudioResourceOptimizer.AudioResourceTargetsByName.Remove(clipName);
		}
	}

	// Token: 0x06000246 RID: 582 RVA: 0x0000E938 File Offset: 0x0000CB38
	public static void UnloadClipIfUnused(string clipName)
	{
		if (!AudioResourceOptimizer.AudioClipsByName.ContainsKey(clipName))
		{
			return;
		}
		List<AudioSource> list = new List<AudioSource>();
		if (AudioResourceOptimizer.AudioResourceTargetsByName.ContainsKey(clipName))
		{
			list = AudioResourceOptimizer.AudioResourceTargetsByName[clipName];
			for (int i = 0; i < list.Count; i++)
			{
				AudioSource audioSource = list[i];
				SoundGroupVariation component = audioSource.GetComponent<SoundGroupVariation>();
				if (component.IsPlaying)
				{
					return;
				}
			}
		}
		AudioClip assetToUnload = AudioResourceOptimizer.AudioClipsByName[clipName];
		for (int j = 0; j < list.Count; j++)
		{
			list[j].clip = null;
		}
		AudioResourceOptimizer.AudioClipsByName.Remove(clipName);
		Resources.UnloadAsset(assetToUnload);
	}

	// Token: 0x040003C3 RID: 963
	private static readonly Dictionary<string, List<AudioSource>> AudioResourceTargetsByName = new Dictionary<string, List<AudioSource>>();

	// Token: 0x040003C4 RID: 964
	private static readonly Dictionary<string, AudioClip> AudioClipsByName = new Dictionary<string, AudioClip>();

	// Token: 0x040003C5 RID: 965
	private static readonly Dictionary<string, List<AudioClip>> PlaylistClipsByPlaylistName = new Dictionary<string, List<AudioClip>>(5);

	// Token: 0x040003C6 RID: 966
	private static string _supportedLanguageFolder = string.Empty;
}
