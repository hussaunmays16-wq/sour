﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C3 RID: 963
	[Tooltip("Check if an HashTable Proxy component exists.")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableExists : ArrayListActions
	{
		// Token: 0x06001046 RID: 4166 RVA: 0x00058D98 File Offset: 0x00056F98
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.doesExists = null;
			this.doesExistsEvent = null;
			this.doesNotExistsEvent = null;
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x00058DC0 File Offset: 0x00056FC0
		public override void OnEnter()
		{
			PlayMakerHashTableProxy hashTableProxyPointer = base.GetHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value, true);
			bool flag = hashTableProxyPointer != null;
			this.doesExists.Value = flag;
			if (flag)
			{
				base.Fsm.Event(this.doesExistsEvent);
			}
			else
			{
				base.Fsm.Event(this.doesNotExistsEvent);
			}
			base.Finish();
		}

		// Token: 0x0400151B RID: 5403
		[ActionSection("Set up")]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400151C RID: 5404
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400151D RID: 5405
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store in a bool wether it exists or not")]
		public FsmBool doesExists;

		// Token: 0x0400151E RID: 5406
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this HashTable exists ")]
		public FsmEvent doesExistsEvent;

		// Token: 0x0400151F RID: 5407
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this HashTable does not exists")]
		public FsmEvent doesNotExistsEvent;
	}
}
