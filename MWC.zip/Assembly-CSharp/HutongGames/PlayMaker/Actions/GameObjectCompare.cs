﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200020A RID: 522
	[Tooltip("Compares 2 Game Objects and sends Events based on the result.")]
	[ActionCategory(ActionCategory.Logic)]
	public class GameObjectCompare : FsmStateAction
	{
		// Token: 0x060008EF RID: 2287 RVA: 0x0003B5F0 File Offset: 0x000397F0
		public override void Reset()
		{
			this.gameObjectVariable = null;
			this.compareTo = null;
			this.equalEvent = null;
			this.notEqualEvent = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x0003B628 File Offset: 0x00039828
		public override void OnEnter()
		{
			this.DoGameObjectCompare();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x0003B644 File Offset: 0x00039844
		public override void OnUpdate()
		{
			this.DoGameObjectCompare();
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x0003B64C File Offset: 0x0003984C
		private void DoGameObjectCompare()
		{
			bool flag = base.Fsm.GetOwnerDefaultTarget(this.gameObjectVariable) == this.compareTo.Value;
			this.storeResult.Value = flag;
			if (flag && this.equalEvent != null)
			{
				base.Fsm.Event(this.equalEvent);
			}
			else if (!flag && this.notEqualEvent != null)
			{
				base.Fsm.Event(this.notEqualEvent);
			}
		}

		// Token: 0x04000CB4 RID: 3252
		[UIHint(UIHint.Variable)]
		[Title("Game Object")]
		[Tooltip("A Game Object variable to compare.")]
		[RequiredField]
		public FsmOwnerDefault gameObjectVariable;

		// Token: 0x04000CB5 RID: 3253
		[Tooltip("Compare the variable with this Game Object")]
		[RequiredField]
		public FsmGameObject compareTo;

		// Token: 0x04000CB6 RID: 3254
		[Tooltip("Send this event if Game Objects are equal")]
		public FsmEvent equalEvent;

		// Token: 0x04000CB7 RID: 3255
		[Tooltip("Send this event if Game Objects are not equal")]
		public FsmEvent notEqualEvent;

		// Token: 0x04000CB8 RID: 3256
		[Tooltip("Store the result of the check in a Bool Variable. (True if equal, false if not equal).")]
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;

		// Token: 0x04000CB9 RID: 3257
		[Tooltip("Repeat every frame. Useful if you're waiting for a true or false result.")]
		public bool everyFrame;
	}
}
