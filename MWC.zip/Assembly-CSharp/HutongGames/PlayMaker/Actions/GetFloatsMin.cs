﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000406 RID: 1030
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Returns the minimum float from a list")]
	public class GetFloatsMin : FsmStateAction
	{
		// Token: 0x06001161 RID: 4449 RVA: 0x00060054 File Offset: 0x0005E254
		public override void Reset()
		{
			this.floats = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06001162 RID: 4450 RVA: 0x0006006C File Offset: 0x0005E26C
		public override void OnEnter()
		{
			this.DoMinFromFloats();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06001163 RID: 4451 RVA: 0x00060088 File Offset: 0x0005E288
		public override void OnUpdate()
		{
			this.DoMinFromFloats();
		}

		// Token: 0x06001164 RID: 4452 RVA: 0x00060090 File Offset: 0x0005E290
		private void DoMinFromFloats()
		{
			float num = float.PositiveInfinity;
			foreach (FsmFloat fsmFloat in this.floats)
			{
				float value = fsmFloat.Value;
				if (fsmFloat.UseVariable && !fsmFloat.IsNone)
				{
					value = base.Fsm.Variables.GetFsmFloat(fsmFloat.Name).Value;
				}
				num = Mathf.Min(num, value);
			}
			this.storeResult.Value = num;
		}

		// Token: 0x040016D3 RID: 5843
		[Tooltip("The float variables.")]
		[RequiredField]
		public FsmFloat[] floats;

		// Token: 0x040016D4 RID: 5844
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeResult;

		// Token: 0x040016D5 RID: 5845
		public bool everyFrame;
	}
}
