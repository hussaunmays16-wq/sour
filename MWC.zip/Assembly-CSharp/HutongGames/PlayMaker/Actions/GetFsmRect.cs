﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022D RID: 557
	[Tooltip("Get the value of a Rect Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmRect : FsmStateAction
	{
		// Token: 0x06000985 RID: 2437 RVA: 0x0003D6F0 File Offset: 0x0003B8F0
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.variableName = string.Empty;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x0003D728 File Offset: 0x0003B928
		public override void OnEnter()
		{
			this.DoGetFsmVariable();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x0003D744 File Offset: 0x0003B944
		public override void OnUpdate()
		{
			this.DoGetFsmVariable();
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x0003D74C File Offset: 0x0003B94C
		private void DoGetFsmVariable()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null || this.storeValue == null)
			{
				return;
			}
			FsmRect fsmRect = this.fsm.FsmVariables.GetFsmRect(this.variableName.Value);
			if (fsmRect != null)
			{
				this.storeValue.Value = fsmRect.Value;
			}
		}

		// Token: 0x04000D77 RID: 3447
		[Tooltip("The GameObject that owns the FSM.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D78 RID: 3448
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D79 RID: 3449
		[UIHint(UIHint.FsmRect)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D7A RID: 3450
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmRect storeValue;

		// Token: 0x04000D7B RID: 3451
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x04000D7C RID: 3452
		private GameObject goLastFrame;

		// Token: 0x04000D7D RID: 3453
		protected PlayMakerFSM fsm;
	}
}
