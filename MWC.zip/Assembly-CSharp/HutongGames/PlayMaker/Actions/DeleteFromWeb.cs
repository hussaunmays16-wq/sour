﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001A1 RID: 417
	[ActionCategory("Easy Save 2")]
	[Tooltip("Deletes data from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	public class DeleteFromWeb : FsmStateAction
	{
		// Token: 0x06000784 RID: 1924 RVA: 0x00035940 File Offset: 0x00033B40
		public override void Reset()
		{
			this.tag = string.Empty;
			this.file = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x000359A4 File Offset: 0x00033BA4
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.tag,
				"&webfilename=",
				this.file,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Delete());
			this.Log(string.Concat(new object[]
			{
				"Web Deleting from ",
				this.urlToPHPFile,
				"?tag=",
				this.tag,
				"&webfilename=",
				this.file
			}));
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x00035A78 File Offset: 0x00033C78
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDeleted);
			}
		}

		// Token: 0x04000B15 RID: 2837
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[RequiredField]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000B16 RID: 2838
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04000B17 RID: 2839
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000B18 RID: 2840
		[Tooltip("The tag which we want to delete. Leave blank if deleting entire file.")]
		[RequiredField]
		public FsmString tag = string.Empty;

		// Token: 0x04000B19 RID: 2841
		[Tooltip("The name of the file that we want to either delete, or delete a tag from.")]
		[RequiredField]
		public FsmString file = "defaultES2File.txt";

		// Token: 0x04000B1A RID: 2842
		[Tooltip("The Event to send if Delete succeeded.")]
		public FsmEvent isDeleted;

		// Token: 0x04000B1B RID: 2843
		[Tooltip("The event to send if Delete failed.")]
		public FsmEvent isError;

		// Token: 0x04000B1C RID: 2844
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000B1D RID: 2845
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000B1E RID: 2846
		private ES2Web web;
	}
}
