﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039D RID: 925
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Count items from a PlayMaker ArrayList Proxy component")]
	public class ArrayListCount : ArrayListActions
	{
		// Token: 0x06000FAB RID: 4011 RVA: 0x00056418 File Offset: 0x00054618
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.count = null;
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x00056430 File Offset: 0x00054630
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.getArrayListCount();
			}
			base.Finish();
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x00056470 File Offset: 0x00054670
		public void getArrayListCount()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			int value = this.proxy.arrayList.Count;
			this.count.Value = value;
		}

		// Token: 0x0400145C RID: 5212
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400145D RID: 5213
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400145E RID: 5214
		[Tooltip("Store the count value")]
		[UIHint(UIHint.FsmInt)]
		[ActionSection("Result")]
		public FsmInt count;
	}
}
