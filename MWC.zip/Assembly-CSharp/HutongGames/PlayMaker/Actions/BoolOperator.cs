﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000150 RID: 336
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Performs boolean operations on 2 Bool Variables.")]
	public class BoolOperator : FsmStateAction
	{
		// Token: 0x0600063C RID: 1596 RVA: 0x0002F000 File Offset: 0x0002D200
		public override void Reset()
		{
			this.bool1 = false;
			this.bool2 = false;
			this.operation = BoolOperator.Operation.AND;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0002F030 File Offset: 0x0002D230
		public override void OnEnter()
		{
			this.DoBoolOperator();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0002F04C File Offset: 0x0002D24C
		public override void OnUpdate()
		{
			this.DoBoolOperator();
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x0002F054 File Offset: 0x0002D254
		private void DoBoolOperator()
		{
			bool value = this.bool1.Value;
			bool value2 = this.bool2.Value;
			switch (this.operation)
			{
			case BoolOperator.Operation.AND:
				this.storeResult.Value = (value && value2);
				break;
			case BoolOperator.Operation.NAND:
				this.storeResult.Value = (!value || !value2);
				break;
			case BoolOperator.Operation.OR:
				this.storeResult.Value = (value || value2);
				break;
			case BoolOperator.Operation.XOR:
				this.storeResult.Value = (value ^ value2);
				break;
			}
		}

		// Token: 0x0400092F RID: 2351
		[RequiredField]
		[Tooltip("The first Bool variable.")]
		public FsmBool bool1;

		// Token: 0x04000930 RID: 2352
		[Tooltip("The second Bool variable.")]
		[RequiredField]
		public FsmBool bool2;

		// Token: 0x04000931 RID: 2353
		[Tooltip("Boolean Operation.")]
		public BoolOperator.Operation operation;

		// Token: 0x04000932 RID: 2354
		[Tooltip("Store the result in a Bool Variable.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmBool storeResult;

		// Token: 0x04000933 RID: 2355
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x02000151 RID: 337
		public enum Operation
		{
			// Token: 0x04000935 RID: 2357
			AND,
			// Token: 0x04000936 RID: 2358
			NAND,
			// Token: 0x04000937 RID: 2359
			OR,
			// Token: 0x04000938 RID: 2360
			XOR
		}
	}
}
