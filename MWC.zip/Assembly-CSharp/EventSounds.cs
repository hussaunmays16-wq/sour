﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x0200006C RID: 108
[AddComponentMenu("Dark Tonic/Master Audio/Event Sounds")]
public class EventSounds : MonoBehaviour, ICustomEventReceiver, IPointerDownHandler, IEventSystemHandler, IDragHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IDropHandler, IScrollHandler, IUpdateSelectedHandler, ISelectHandler, IDeselectHandler, IMoveHandler, IInitializePotentialDragHandler, IBeginDragHandler, IEndDragHandler, ISubmitHandler, ICancelHandler
{
	// Token: 0x06000170 RID: 368 RVA: 0x00009498 File Offset: 0x00007698
	private void Awake()
	{
		this._trans = base.transform;
		this._anim = base.GetComponent<Animator>();
		this._slider = base.GetComponent<Slider>();
		this._button = base.GetComponent<Button>();
		this.SpawnedOrAwake();
	}

	// Token: 0x06000171 RID: 369 RVA: 0x000094DC File Offset: 0x000076DC
	protected virtual void SpawnedOrAwake()
	{
		this._isVisible = false;
		this._validMechanimStateChangedSounds.Clear();
		this._needsCoroutine = false;
		if (this.disableSounds || this._anim == null)
		{
			return;
		}
		for (int i = 0; i < this.mechanimStateChangedSounds.Count; i++)
		{
			AudioEventGroup audioEventGroup = this.mechanimStateChangedSounds[i];
			if (audioEventGroup.mechanimEventActive && !string.IsNullOrEmpty(audioEventGroup.mechanimStateName))
			{
				this._needsCoroutine = true;
				this._validMechanimStateChangedSounds.Add(audioEventGroup);
			}
		}
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000957C File Offset: 0x0000777C
	private IEnumerator CoUpdate()
	{
		for (;;)
		{
			yield return MasterAudio.EndOfFrameDelay;
			for (int i = 0; i < this._validMechanimStateChangedSounds.Count; i++)
			{
				AudioEventGroup chg = this._validMechanimStateChangedSounds[i];
				if (!this._anim.GetCurrentAnimatorStateInfo(0).IsName(chg.mechanimStateName))
				{
					chg.mechEventPlayedForState = false;
				}
				else if (!chg.mechEventPlayedForState)
				{
					chg.mechEventPlayedForState = true;
					this.PlaySounds(chg, EventSounds.EventType.MechanimStateChanged);
				}
			}
		}
		yield break;
	}

	// Token: 0x06000173 RID: 371 RVA: 0x00009598 File Offset: 0x00007798
	private void Start()
	{
		this.CheckForIllegalCustomEvents();
		if (this.useStartSound)
		{
			this.PlaySounds(this.startSound, EventSounds.EventType.OnStart);
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x000095B8 File Offset: 0x000077B8
	private void OnBecameVisible()
	{
		if (!this.useVisibleSound || this._isVisible)
		{
			return;
		}
		this._isVisible = true;
		this.PlaySounds(this.visibleSound, EventSounds.EventType.OnVisible);
	}

	// Token: 0x06000175 RID: 373 RVA: 0x000095E8 File Offset: 0x000077E8
	private void OnBecameInvisible()
	{
		if (!this.useInvisibleSound)
		{
			return;
		}
		this._isVisible = false;
		this.PlaySounds(this.invisibleSound, EventSounds.EventType.OnInvisible);
	}

	// Token: 0x06000176 RID: 374 RVA: 0x00009618 File Offset: 0x00007818
	private void OnEnable()
	{
		if (this._slider != null)
		{
			this._slider.onValueChanged.AddListener(new UnityAction<float>(this.SliderChanged));
		}
		if (this._button != null)
		{
			this._button.onClick.AddListener(new UnityAction(this.ButtonClicked));
		}
		this._mouseDragResult = null;
		this.RegisterReceiver();
		if (this._needsCoroutine)
		{
			base.StopAllCoroutines();
			base.StartCoroutine(this.CoUpdate());
		}
		if (this.useEnableSound)
		{
			this.PlaySounds(this.enableSound, EventSounds.EventType.OnEnable);
		}
	}

	// Token: 0x06000177 RID: 375 RVA: 0x000096C4 File Offset: 0x000078C4
	private void OnDisable()
	{
		if (this._slider != null)
		{
			this._slider.onValueChanged.RemoveListener(new UnityAction<float>(this.SliderChanged));
		}
		if (this._button != null)
		{
			this._button.onClick.RemoveListener(new UnityAction(this.ButtonClicked));
		}
		this.UnregisterReceiver();
		if (!this.useDisableSound || MasterAudio.AppIsShuttingDown)
		{
			return;
		}
		this.PlaySounds(this.disableSound, EventSounds.EventType.OnDisable);
	}

	// Token: 0x06000178 RID: 376 RVA: 0x00009758 File Offset: 0x00007958
	private void OnTriggerEnter2D(Collider2D other)
	{
		if (!this.useTriggerEnter2dSound)
		{
			return;
		}
		if (this.triggerEnter2dSound.useLayerFilter && !this.triggerEnter2dSound.matchingLayers.Contains(other.gameObject.layer))
		{
			return;
		}
		if (this.triggerEnter2dSound.useTagFilter && !this.triggerEnter2dSound.matchingTags.Contains(other.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.triggerEnter2dSound, EventSounds.EventType.OnTriggerEnter2D);
	}

	// Token: 0x06000179 RID: 377 RVA: 0x000097E4 File Offset: 0x000079E4
	private void OnTriggerExit2D(Collider2D other)
	{
		if (!this.useTriggerExit2dSound)
		{
			return;
		}
		if (this.triggerExit2dSound.useLayerFilter && !this.triggerExit2dSound.matchingLayers.Contains(other.gameObject.layer))
		{
			return;
		}
		if (this.triggerExit2dSound.useTagFilter && !this.triggerExit2dSound.matchingTags.Contains(other.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.triggerExit2dSound, EventSounds.EventType.OnTriggerExit2D);
	}

	// Token: 0x0600017A RID: 378 RVA: 0x00009870 File Offset: 0x00007A70
	private void OnCollisionEnter2D(Collision2D collision)
	{
		if (!this.useCollision2dSound)
		{
			return;
		}
		if (this.collision2dSound.useLayerFilter && !this.collision2dSound.matchingLayers.Contains(collision.gameObject.layer))
		{
			return;
		}
		if (this.collision2dSound.useTagFilter && !this.collision2dSound.matchingTags.Contains(collision.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.collision2dSound, EventSounds.EventType.OnCollision2D);
	}

	// Token: 0x0600017B RID: 379 RVA: 0x000098FC File Offset: 0x00007AFC
	private void OnCollisionExit2D(Collision2D collision)
	{
		if (!this.useCollisionExit2dSound)
		{
			return;
		}
		if (this.collisionExit2dSound.useLayerFilter && !this.collisionExit2dSound.matchingLayers.Contains(collision.gameObject.layer))
		{
			return;
		}
		if (this.collisionExit2dSound.useTagFilter && !this.collisionExit2dSound.matchingTags.Contains(collision.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.collisionExit2dSound, EventSounds.EventType.OnCollisionExit2D);
	}

	// Token: 0x0600017C RID: 380 RVA: 0x00009988 File Offset: 0x00007B88
	private void OnCollisionEnter(Collision collision)
	{
		if (!this.useCollisionSound)
		{
			return;
		}
		if (this.collisionSound.useLayerFilter && !this.collisionSound.matchingLayers.Contains(collision.gameObject.layer))
		{
			return;
		}
		if (this.collisionSound.useTagFilter && !this.collisionSound.matchingTags.Contains(collision.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.collisionSound, EventSounds.EventType.OnCollision);
	}

	// Token: 0x0600017D RID: 381 RVA: 0x00009A10 File Offset: 0x00007C10
	private void OnCollisionExit(Collision collision)
	{
		if (!this.useCollisionExitSound)
		{
			return;
		}
		if (this.collisionExitSound.useLayerFilter && !this.collisionExitSound.matchingLayers.Contains(collision.gameObject.layer))
		{
			return;
		}
		if (this.collisionExitSound.useTagFilter && !this.collisionExitSound.matchingTags.Contains(collision.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.collisionExitSound, EventSounds.EventType.OnCollisionExit);
	}

	// Token: 0x0600017E RID: 382 RVA: 0x00009A9C File Offset: 0x00007C9C
	private void OnTriggerEnter(Collider other)
	{
		if (!this.useTriggerEnterSound)
		{
			return;
		}
		if (this.triggerSound.useLayerFilter && !this.triggerSound.matchingLayers.Contains(other.gameObject.layer))
		{
			return;
		}
		if (this.triggerSound.useTagFilter && !this.triggerSound.matchingTags.Contains(other.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.triggerSound, EventSounds.EventType.OnTriggerEnter);
	}

	// Token: 0x0600017F RID: 383 RVA: 0x00009B24 File Offset: 0x00007D24
	private void OnTriggerExit(Collider other)
	{
		if (!this.useTriggerExitSound)
		{
			return;
		}
		if (this.triggerExitSound.useLayerFilter && !this.triggerExitSound.matchingLayers.Contains(other.gameObject.layer))
		{
			return;
		}
		if (this.triggerExitSound.useTagFilter && !this.triggerExitSound.matchingTags.Contains(other.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.triggerExitSound, EventSounds.EventType.OnTriggerExit);
	}

	// Token: 0x06000180 RID: 384 RVA: 0x00009BAC File Offset: 0x00007DAC
	private void OnParticleCollision(GameObject other)
	{
		if (!this.useParticleCollisionSound)
		{
			return;
		}
		if (this.particleCollisionSound.useLayerFilter && !this.particleCollisionSound.matchingLayers.Contains(other.gameObject.layer))
		{
			return;
		}
		if (this.particleCollisionSound.useTagFilter && !this.particleCollisionSound.matchingTags.Contains(other.gameObject.tag))
		{
			return;
		}
		this.PlaySounds(this.particleCollisionSound, EventSounds.EventType.OnParticleCollision);
	}

	// Token: 0x06000181 RID: 385 RVA: 0x00009C38 File Offset: 0x00007E38
	public void OnPointerEnter(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityPointerEnterSound)
		{
			this.PlaySounds(this.unityPointerEnterSound, EventSounds.EventType.UnityPointerEnter);
		}
	}

	// Token: 0x06000182 RID: 386 RVA: 0x00009C6C File Offset: 0x00007E6C
	public void OnPointerExit(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityPointerExitSound)
		{
			this.PlaySounds(this.unityPointerExitSound, EventSounds.EventType.UnityPointerExit);
		}
	}

	// Token: 0x06000183 RID: 387 RVA: 0x00009CA0 File Offset: 0x00007EA0
	public void OnPointerDown(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityPointerDownSound)
		{
			this.PlaySounds(this.unityPointerDownSound, EventSounds.EventType.UnityPointerDown);
		}
	}

	// Token: 0x06000184 RID: 388 RVA: 0x00009CD4 File Offset: 0x00007ED4
	public void OnPointerUp(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityPointerUpSound)
		{
			this.PlaySounds(this.unityPointerUpSound, EventSounds.EventType.UnityPointerUp);
		}
	}

	// Token: 0x06000185 RID: 389 RVA: 0x00009D08 File Offset: 0x00007F08
	public void OnDrag(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityDragSound)
		{
			this.PlaySounds(this.unityDragSound, EventSounds.EventType.UnityDrag);
		}
	}

	// Token: 0x06000186 RID: 390 RVA: 0x00009D3C File Offset: 0x00007F3C
	public void OnDrop(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityDropSound)
		{
			this.PlaySounds(this.unityDropSound, EventSounds.EventType.UnityDrop);
		}
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00009D70 File Offset: 0x00007F70
	public void OnScroll(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityScrollSound)
		{
			this.PlaySounds(this.unityScrollSound, EventSounds.EventType.UnityScroll);
		}
	}

	// Token: 0x06000188 RID: 392 RVA: 0x00009DA4 File Offset: 0x00007FA4
	public void OnUpdateSelected(BaseEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityUpdateSelectedSound)
		{
			this.PlaySounds(this.unityUpdateSelectedSound, EventSounds.EventType.UnityUpdateSelected);
		}
	}

	// Token: 0x06000189 RID: 393 RVA: 0x00009DD8 File Offset: 0x00007FD8
	public void OnSelect(BaseEventData data)
	{
		if (this.IsSetToUGUI && this.useUnitySelectSound)
		{
			this.PlaySounds(this.unitySelectSound, EventSounds.EventType.UnitySelect);
		}
	}

	// Token: 0x0600018A RID: 394 RVA: 0x00009E0C File Offset: 0x0000800C
	public void OnDeselect(BaseEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityDeselectSound)
		{
			this.PlaySounds(this.unityDeselectSound, EventSounds.EventType.UnityDeselect);
		}
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00009E40 File Offset: 0x00008040
	public void OnMove(AxisEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityMoveSound)
		{
			this.PlaySounds(this.unityMoveSound, EventSounds.EventType.UnityMove);
		}
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00009E74 File Offset: 0x00008074
	public void OnInitializePotentialDrag(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityInitializePotentialDragSound)
		{
			this.PlaySounds(this.unityInitializePotentialDragSound, EventSounds.EventType.UnityInitializePotentialDrag);
		}
	}

	// Token: 0x0600018D RID: 397 RVA: 0x00009EA8 File Offset: 0x000080A8
	public void OnBeginDrag(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityBeginDragSound)
		{
			this.PlaySounds(this.unityBeginDragSound, EventSounds.EventType.UnityBeginDrag);
		}
	}

	// Token: 0x0600018E RID: 398 RVA: 0x00009EDC File Offset: 0x000080DC
	public void OnEndDrag(PointerEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityEndDragSound)
		{
			this.PlaySounds(this.unityEndDragSound, EventSounds.EventType.UnityEndDrag);
		}
	}

	// Token: 0x0600018F RID: 399 RVA: 0x00009F10 File Offset: 0x00008110
	public void OnSubmit(BaseEventData data)
	{
		if (this.IsSetToUGUI && this.useUnitySubmitSound)
		{
			this.PlaySounds(this.unitySubmitSound, EventSounds.EventType.UnitySubmit);
		}
	}

	// Token: 0x06000190 RID: 400 RVA: 0x00009F44 File Offset: 0x00008144
	public void OnCancel(BaseEventData data)
	{
		if (this.IsSetToUGUI && this.useUnityCancelSound)
		{
			this.PlaySounds(this.unityCancelSound, EventSounds.EventType.UnityCancel);
		}
	}

	// Token: 0x06000191 RID: 401 RVA: 0x00009F78 File Offset: 0x00008178
	private void SliderChanged(float newValue)
	{
		if (!this.useUnitySliderChangedSound)
		{
			return;
		}
		this.unitySliderChangedSound.sliderValue = newValue;
		this.PlaySounds(this.unitySliderChangedSound, EventSounds.EventType.UnitySliderChanged);
	}

	// Token: 0x06000192 RID: 402 RVA: 0x00009FAC File Offset: 0x000081AC
	private void ButtonClicked()
	{
		if (this.useUnityButtonClickedSound)
		{
			this.PlaySounds(this.unityButtonClickedSound, EventSounds.EventType.UnityButtonClicked);
		}
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000193 RID: 403 RVA: 0x00009FC8 File Offset: 0x000081C8
	private bool IsSetToUGUI
	{
		get
		{
			return this.unityUIMode != EventSounds.UnityUIVersion.Legacy;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000194 RID: 404 RVA: 0x00009FD8 File Offset: 0x000081D8
	private bool IsSetToLegacyUI
	{
		get
		{
			return this.unityUIMode == EventSounds.UnityUIVersion.Legacy;
		}
	}

	// Token: 0x06000195 RID: 405 RVA: 0x00009FE4 File Offset: 0x000081E4
	private void OnMouseEnter()
	{
		if (this.IsSetToLegacyUI && this.useMouseEnterSound)
		{
			this.PlaySounds(this.mouseEnterSound, EventSounds.EventType.OnMouseEnter);
		}
	}

	// Token: 0x06000196 RID: 406 RVA: 0x0000A00C File Offset: 0x0000820C
	private void OnMouseExit()
	{
		if (this.IsSetToLegacyUI && this.useMouseExitSound)
		{
			this.PlaySounds(this.mouseExitSound, EventSounds.EventType.OnMouseExit);
		}
	}

	// Token: 0x06000197 RID: 407 RVA: 0x0000A040 File Offset: 0x00008240
	private void OnMouseDown()
	{
		if (this.IsSetToLegacyUI && this.useMouseClickSound)
		{
			this.PlaySounds(this.mouseClickSound, EventSounds.EventType.OnMouseClick);
		}
	}

	// Token: 0x06000198 RID: 408 RVA: 0x0000A068 File Offset: 0x00008268
	private void OnMouseUp()
	{
		if (this.IsSetToLegacyUI && this.useMouseUpSound)
		{
			this.PlaySounds(this.mouseUpSound, EventSounds.EventType.OnMouseUp);
		}
		if (this.useMouseDragSound)
		{
			EventSounds.PreviousSoundStopMode mouseDragStopMode = this.mouseUpSound.mouseDragStopMode;
			if (mouseDragStopMode != EventSounds.PreviousSoundStopMode.Stop)
			{
				if (mouseDragStopMode == EventSounds.PreviousSoundStopMode.FadeOut)
				{
					if (this._mouseDragResult != null && (this._mouseDragResult.SoundPlayed || this._mouseDragResult.SoundScheduled))
					{
						this._mouseDragResult.ActingVariation.FadeToVolume(0f, this.mouseUpSound.mouseDragFadeOutTime);
					}
				}
			}
			else if (this._mouseDragResult != null && (this._mouseDragResult.SoundPlayed || this._mouseDragResult.SoundScheduled))
			{
				this._mouseDragResult.ActingVariation.Stop(true);
			}
			this._mouseDragResult = null;
		}
		this._mouseDragSoundPlayed = false;
	}

	// Token: 0x06000199 RID: 409 RVA: 0x0000A164 File Offset: 0x00008364
	private void OnMouseDrag()
	{
		if (!this.IsSetToLegacyUI || !this.useMouseDragSound)
		{
			return;
		}
		if (this._mouseDragSoundPlayed)
		{
			return;
		}
		this.PlaySounds(this.mouseDragSound, EventSounds.EventType.OnMouseDrag);
		this._mouseDragSoundPlayed = true;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x0000A1AC File Offset: 0x000083AC
	private void OnPress(bool isDown)
	{
		if (!this.showNGUI)
		{
			return;
		}
		if (isDown)
		{
			if (this.useNguiMouseDownSound)
			{
				this.PlaySounds(this.nguiMouseDownSound, EventSounds.EventType.NGUIMouseDown);
			}
		}
		else if (this.useNguiMouseUpSound)
		{
			this.PlaySounds(this.nguiMouseUpSound, EventSounds.EventType.NGUIMouseUp);
		}
	}

	// Token: 0x0600019B RID: 411 RVA: 0x0000A204 File Offset: 0x00008404
	private void OnClick()
	{
		if (this.showNGUI && this.useNguiOnClickSound)
		{
			this.PlaySounds(this.nguiOnClickSound, EventSounds.EventType.NGUIOnClick);
		}
	}

	// Token: 0x0600019C RID: 412 RVA: 0x0000A238 File Offset: 0x00008438
	private void OnHover(bool isOver)
	{
		if (!this.showNGUI)
		{
			return;
		}
		if (isOver)
		{
			if (this.useNguiMouseEnterSound)
			{
				this.PlaySounds(this.nguiMouseEnterSound, EventSounds.EventType.NGUIMouseEnter);
			}
		}
		else if (this.useNguiMouseExitSound)
		{
			this.PlaySounds(this.nguiMouseExitSound, EventSounds.EventType.NGUIMouseExit);
		}
	}

	// Token: 0x0600019D RID: 413 RVA: 0x0000A290 File Offset: 0x00008490
	private void OnSpawned()
	{
		this.SpawnedOrAwake();
		if (this.showPoolManager && this.useSpawnedSound)
		{
			this.PlaySounds(this.spawnedSound, EventSounds.EventType.OnSpawned);
		}
	}

	// Token: 0x0600019E RID: 414 RVA: 0x0000A2BC File Offset: 0x000084BC
	private void OnDespawned()
	{
		if (this.showPoolManager && this.useDespawnedSound)
		{
			this.PlaySounds(this.despawnedSound, EventSounds.EventType.OnDespawned);
		}
	}

	// Token: 0x0600019F RID: 415 RVA: 0x0000A2F0 File Offset: 0x000084F0
	private void OnDrawGizmos()
	{
		if (this.showGizmo)
		{
			Gizmos.DrawIcon(base.transform.position, "MasterAudio Icon.png", true);
		}
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000A314 File Offset: 0x00008514
	private IEnumerator TryPlayStartSound(AudioEventGroup grp, AudioEvent aEvent)
	{
		for (int i = 0; i < 3; i++)
		{
			if (MasterAudio.IgnoreTimeScale)
			{
				yield return base.StartCoroutine(CoroutineHelper.WaitForActualSeconds(0.1f));
			}
			else
			{
				yield return MasterAudio.InnerLoopDelay;
			}
			PlaySoundResult result = this.PerformSingleAction(grp, aEvent, EventSounds.EventType.OnStart, false);
			if (result != null && result.SoundPlayed)
			{
				break;
			}
		}
		yield break;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000A34C File Offset: 0x0000854C
	private static bool CheckForRetriggerLimit(AudioEventGroup grp)
	{
		EventSounds.RetriggerLimMode retriggerLimitMode = grp.retriggerLimitMode;
		if (retriggerLimitMode != EventSounds.RetriggerLimMode.FrameBased)
		{
			if (retriggerLimitMode == EventSounds.RetriggerLimMode.TimeBased)
			{
				if (grp.triggeredLastTime > 0f && Time.time - grp.triggeredLastTime < grp.limitPerXSec)
				{
					return false;
				}
			}
		}
		else if (grp.triggeredLastFrame > 0 && Time.frameCount - grp.triggeredLastFrame < grp.limitPerXFrm)
		{
			return false;
		}
		return true;
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000A3CC File Offset: 0x000085CC
	public void PlaySounds(AudioEventGroup eventGrp, EventSounds.EventType eType)
	{
		if (!EventSounds.CheckForRetriggerLimit(eventGrp))
		{
			return;
		}
		if (MasterAudio.SafeInstance == null)
		{
			return;
		}
		EventSounds.RetriggerLimMode retriggerLimitMode = eventGrp.retriggerLimitMode;
		if (retriggerLimitMode != EventSounds.RetriggerLimMode.FrameBased)
		{
			if (retriggerLimitMode == EventSounds.RetriggerLimMode.TimeBased)
			{
				eventGrp.triggeredLastTime = Time.time;
			}
		}
		else
		{
			eventGrp.triggeredLastFrame = Time.frameCount;
		}
		if (!MasterAudio.AppIsShuttingDown && MasterAudio.IsWarming)
		{
			AudioEvent aEvent = new AudioEvent();
			this.PerformSingleAction(eventGrp, aEvent, eType, true);
			return;
		}
		for (int i = 0; i < eventGrp.SoundEvents.Count; i++)
		{
			this.PerformSingleAction(eventGrp, eventGrp.SoundEvents[i], eType, true);
		}
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x0000A488 File Offset: 0x00008688
	private PlaySoundResult PerformSingleAction(AudioEventGroup grp, AudioEvent aEvent, EventSounds.EventType eType, bool isFirstTry = true)
	{
		if (this.disableSounds || MasterAudio.AppIsShuttingDown || MasterAudio.SafeInstance == null)
		{
			return null;
		}
		bool flag = eType == EventSounds.EventType.UnitySliderChanged && aEvent.targetVolMode == AudioEvent.TargetVolumeMode.UseSliderValue;
		float volumePercentage = aEvent.volume;
		string soundType = aEvent.soundType;
		float? pitch = new float?(aEvent.pitch);
		if (!aEvent.useFixedPitch)
		{
			pitch = null;
		}
		PlaySoundResult playSoundResult = null;
		MasterAudio.SoundSpawnLocationMode soundSpawnLocationMode = this.soundSpawnMode;
		if (eType == EventSounds.EventType.OnDisable || eType == EventSounds.EventType.OnDespawned)
		{
			soundSpawnLocationMode = MasterAudio.SoundSpawnLocationMode.CallerLocation;
		}
		bool flag2 = (eType == EventSounds.EventType.OnStart && !isFirstTry) || eType == EventSounds.EventType.OnMouseDrag;
		switch (aEvent.currentSoundFunctionType)
		{
		case MasterAudio.EventSoundFunctionType.PlaySound:
		{
			string variationName = null;
			if (aEvent.variationType == EventSounds.VariationType.PlaySpecific)
			{
				variationName = aEvent.variationName;
			}
			if (eType != EventSounds.EventType.OnStart || !isFirstTry || MasterAudio.SoundGroupExists(soundType))
			{
				if (flag)
				{
					volumePercentage = grp.sliderValue;
				}
				switch (soundSpawnLocationMode)
				{
				case MasterAudio.SoundSpawnLocationMode.MasterAudioLocation:
					if (flag2)
					{
						playSoundResult = MasterAudio.PlaySound(soundType, volumePercentage, pitch, aEvent.delaySound, variationName, false, false);
					}
					else
					{
						MasterAudio.PlaySoundAndForget(soundType, volumePercentage, pitch, aEvent.delaySound, variationName);
					}
					break;
				case MasterAudio.SoundSpawnLocationMode.CallerLocation:
					if (flag2)
					{
						playSoundResult = MasterAudio.PlaySound3DAtTransform(soundType, this._trans, volumePercentage, pitch, aEvent.delaySound, variationName, false, false);
					}
					else
					{
						MasterAudio.PlaySound3DAtTransformAndForget(soundType, this._trans, volumePercentage, pitch, aEvent.delaySound, variationName);
					}
					break;
				case MasterAudio.SoundSpawnLocationMode.AttachToCaller:
					if (flag2)
					{
						playSoundResult = MasterAudio.PlaySound3DFollowTransform(soundType, this._trans, volumePercentage, pitch, aEvent.delaySound, variationName, false, false);
					}
					else
					{
						MasterAudio.PlaySound3DFollowTransformAndForget(soundType, this._trans, volumePercentage, pitch, aEvent.delaySound, variationName);
					}
					break;
				}
			}
			if (eType == EventSounds.EventType.OnMouseDrag)
			{
				this._mouseDragResult = playSoundResult;
			}
			if (playSoundResult == null || !playSoundResult.SoundPlayed)
			{
				if (eType == EventSounds.EventType.OnStart && isFirstTry)
				{
					base.StartCoroutine(this.TryPlayStartSound(grp, aEvent));
				}
				return playSoundResult;
			}
			break;
		}
		case MasterAudio.EventSoundFunctionType.GroupControl:
		{
			playSoundResult = new PlaySoundResult
			{
				ActingVariation = null,
				SoundPlayed = true,
				SoundScheduled = false
			};
			List<string> list = new List<string>();
			if (!aEvent.allSoundTypesForGroupCmd || MasterAudio.GroupCommandsWithNoAllGroupSelector.Contains(aEvent.currentSoundGroupCommand))
			{
				list.Add(aEvent.soundType);
			}
			else
			{
				list.AddRange(MasterAudio.RuntimeSoundGroupNames);
			}
			for (int i = 0; i < list.Count; i++)
			{
				string sType = list[i];
				switch (aEvent.currentSoundGroupCommand)
				{
				case MasterAudio.SoundGroupCommand.None:
					playSoundResult.SoundPlayed = false;
					break;
				case MasterAudio.SoundGroupCommand.FadeToVolume:
				{
					float newVolume = (!flag) ? aEvent.fadeVolume : grp.sliderValue;
					MasterAudio.FadeSoundGroupToVolume(sType, newVolume, aEvent.fadeTime, null);
					break;
				}
				case MasterAudio.SoundGroupCommand.FadeOutAllOfSound:
					MasterAudio.FadeOutAllOfSound(sType, aEvent.fadeTime);
					break;
				case MasterAudio.SoundGroupCommand.Mute:
					MasterAudio.MuteGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.Pause:
					MasterAudio.PauseSoundGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.Solo:
					MasterAudio.SoloGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.StopAllOfSound:
					MasterAudio.StopAllOfSound(sType);
					break;
				case MasterAudio.SoundGroupCommand.Unmute:
					MasterAudio.UnmuteGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.Unpause:
					MasterAudio.UnpauseSoundGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.Unsolo:
					MasterAudio.UnsoloGroup(sType);
					break;
				case MasterAudio.SoundGroupCommand.StopAllSoundsOfTransform:
					MasterAudio.StopAllSoundsOfTransform(this._trans);
					break;
				case MasterAudio.SoundGroupCommand.PauseAllSoundsOfTransform:
					MasterAudio.PauseAllSoundsOfTransform(this._trans);
					break;
				case MasterAudio.SoundGroupCommand.UnpauseAllSoundsOfTransform:
					MasterAudio.UnpauseAllSoundsOfTransform(this._trans);
					break;
				case MasterAudio.SoundGroupCommand.StopSoundGroupOfTransform:
					MasterAudio.StopSoundGroupOfTransform(this._trans, sType);
					break;
				case MasterAudio.SoundGroupCommand.PauseSoundGroupOfTransform:
					MasterAudio.PauseSoundGroupOfTransform(this._trans, sType);
					break;
				case MasterAudio.SoundGroupCommand.UnpauseSoundGroupOfTransform:
					MasterAudio.UnpauseSoundGroupOfTransform(this._trans, sType);
					break;
				case MasterAudio.SoundGroupCommand.FadeOutSoundGroupOfTransform:
					MasterAudio.FadeOutSoundGroupOfTransform(this._trans, sType, aEvent.fadeTime);
					break;
				case MasterAudio.SoundGroupCommand.RefillSoundGroupPool:
					MasterAudio.RefillSoundGroupPool(sType);
					break;
				}
			}
			break;
		}
		case MasterAudio.EventSoundFunctionType.BusControl:
		{
			playSoundResult = new PlaySoundResult
			{
				ActingVariation = null,
				SoundPlayed = true,
				SoundScheduled = false
			};
			List<string> list2 = new List<string>();
			if (!aEvent.allSoundTypesForBusCmd)
			{
				list2.Add(aEvent.busName);
			}
			else
			{
				list2.AddRange(MasterAudio.RuntimeBusNames);
			}
			for (int j = 0; j < list2.Count; j++)
			{
				string busName = list2[j];
				switch (aEvent.currentBusCommand)
				{
				case MasterAudio.BusCommand.None:
					playSoundResult.SoundPlayed = false;
					break;
				case MasterAudio.BusCommand.FadeToVolume:
				{
					float newVolume2 = (!flag) ? aEvent.fadeVolume : grp.sliderValue;
					MasterAudio.FadeBusToVolume(busName, newVolume2, aEvent.fadeTime, null);
					break;
				}
				case MasterAudio.BusCommand.Mute:
					MasterAudio.MuteBus(busName);
					break;
				case MasterAudio.BusCommand.Pause:
					MasterAudio.PauseBus(busName);
					break;
				case MasterAudio.BusCommand.Solo:
					MasterAudio.SoloBus(busName);
					break;
				case MasterAudio.BusCommand.Unmute:
					MasterAudio.UnmuteBus(busName);
					break;
				case MasterAudio.BusCommand.Unpause:
					MasterAudio.UnpauseBus(busName);
					break;
				case MasterAudio.BusCommand.Unsolo:
					MasterAudio.UnsoloBus(busName);
					break;
				case MasterAudio.BusCommand.Stop:
					MasterAudio.StopBus(busName);
					break;
				case MasterAudio.BusCommand.ChangeBusPitch:
					MasterAudio.ChangeBusPitch(busName, aEvent.pitch);
					break;
				}
			}
			break;
		}
		case MasterAudio.EventSoundFunctionType.PlaylistControl:
			playSoundResult = new PlaySoundResult
			{
				ActingVariation = null,
				SoundPlayed = true,
				SoundScheduled = false
			};
			if (string.IsNullOrEmpty(aEvent.playlistControllerName))
			{
				aEvent.playlistControllerName = "~only~";
			}
			if (MasterAudio.PlaylistCommandsThatFailOnStart.Contains(aEvent.currentPlaylistCommand) && eType == EventSounds.EventType.OnStart && isFirstTry)
			{
				base.StartCoroutine(this.TryPlayStartSound(grp, aEvent));
			}
			else
			{
				switch (aEvent.currentPlaylistCommand)
				{
				case MasterAudio.PlaylistCommand.None:
					playSoundResult.SoundPlayed = false;
					break;
				case MasterAudio.PlaylistCommand.ChangePlaylist:
					if (string.IsNullOrEmpty(aEvent.playlistName))
					{
						Debug.Log("You have not specified a Playlist name for Event Sounds on '" + this._trans.name + "'.");
						playSoundResult.SoundPlayed = false;
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.ChangePlaylistByName(aEvent.playlistControllerName, aEvent.playlistName, aEvent.startPlaylist);
					}
					break;
				case MasterAudio.PlaylistCommand.FadeToVolume:
				{
					float targetVolume = (!flag) ? aEvent.fadeVolume : grp.sliderValue;
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.FadeAllPlaylistsToVolume(targetVolume, aEvent.fadeTime);
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.FadePlaylistToVolume(aEvent.playlistControllerName, targetVolume, aEvent.fadeTime);
					}
					break;
				}
				case MasterAudio.PlaylistCommand.PlayClip:
					if (string.IsNullOrEmpty(aEvent.clipName))
					{
						Debug.Log("You have not specified a clip name for Event Sounds on '" + this._trans.name + "'.");
						playSoundResult.SoundPlayed = false;
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						if (!MasterAudio.TriggerPlaylistClip(aEvent.playlistControllerName, aEvent.clipName))
						{
							playSoundResult.SoundPlayed = false;
						}
					}
					break;
				case MasterAudio.PlaylistCommand.PlayRandomSong:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.TriggerRandomClipAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.TriggerRandomPlaylistClip(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.PlayNextSong:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.TriggerNextClipAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.TriggerNextPlaylistClip(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Pause:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.PauseAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.PausePlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Resume:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.ResumeAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.ResumePlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Stop:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.StopAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.StopPlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Mute:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.MuteAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.MutePlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Unmute:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.UnmuteAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.UnmutePlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.ToggleMute:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.ToggleMuteAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.ToggleMutePlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Restart:
					if (aEvent.allPlaylistControllersForGroupCmd)
					{
						MasterAudio.RestartAllPlaylists();
					}
					else if (!(aEvent.playlistControllerName == "[None]"))
					{
						MasterAudio.RestartPlaylist(aEvent.playlistControllerName);
					}
					break;
				case MasterAudio.PlaylistCommand.Start:
					if (!(aEvent.playlistControllerName == "[None]") && !(aEvent.playlistName == "[None]"))
					{
						MasterAudio.StartPlaylist(aEvent.playlistControllerName, aEvent.playlistName);
					}
					break;
				}
			}
			break;
		case MasterAudio.EventSoundFunctionType.CustomEventControl:
			playSoundResult = new PlaySoundResult
			{
				ActingVariation = null,
				SoundPlayed = false,
				SoundScheduled = false
			};
			if (eType == EventSounds.EventType.UserDefinedEvent)
			{
				Debug.LogError("Custom Event Receivers cannot fire events. Occured in Transform '" + base.name + "'.");
			}
			else
			{
				MasterAudio.CustomEventCommand currentCustomEventCommand = aEvent.currentCustomEventCommand;
				if (currentCustomEventCommand == MasterAudio.CustomEventCommand.FireEvent)
				{
					MasterAudio.FireCustomEvent(aEvent.theCustomEventName, this._trans.position);
				}
			}
			break;
		case MasterAudio.EventSoundFunctionType.GlobalControl:
			switch (aEvent.currentGlobalCommand)
			{
			case MasterAudio.GlobalCommand.PauseMixer:
				MasterAudio.PauseMixer();
				break;
			case MasterAudio.GlobalCommand.UnpauseMixer:
				MasterAudio.UnpauseMixer();
				break;
			case MasterAudio.GlobalCommand.StopMixer:
				MasterAudio.StopMixer();
				break;
			case MasterAudio.GlobalCommand.StopEverything:
				MasterAudio.StopEverything();
				break;
			case MasterAudio.GlobalCommand.PauseEverything:
				MasterAudio.PauseEverything();
				break;
			case MasterAudio.GlobalCommand.UnpauseEverything:
				MasterAudio.UnpauseEverything();
				break;
			case MasterAudio.GlobalCommand.MuteEverything:
				MasterAudio.MuteEverything();
				break;
			case MasterAudio.GlobalCommand.UnmuteEverything:
				MasterAudio.UnmuteEverything();
				break;
			case MasterAudio.GlobalCommand.SetMasterMixerVolume:
			{
				float masterVolumeLevel = (!flag) ? aEvent.volume : grp.sliderValue;
				MasterAudio.MasterVolumeLevel = masterVolumeLevel;
				break;
			}
			case MasterAudio.GlobalCommand.SetMasterPlaylistVolume:
			{
				float playlistMasterVolume = (!flag) ? aEvent.volume : grp.sliderValue;
				MasterAudio.PlaylistMasterVolume = playlistMasterVolume;
				break;
			}
			}
			break;
		case MasterAudio.EventSoundFunctionType.UnityMixerControl:
		{
			MasterAudio.UnityMixerCommand currentMixerCommand = aEvent.currentMixerCommand;
			if (currentMixerCommand != MasterAudio.UnityMixerCommand.TransitionToSnapshot)
			{
				if (currentMixerCommand == MasterAudio.UnityMixerCommand.TransitionToSnapshotBlend)
				{
					List<AudioMixerSnapshot> list3 = new List<AudioMixerSnapshot>();
					List<float> list4 = new List<float>();
					AudioMixer audioMixer = null;
					for (int k = 0; k < aEvent.snapshotsToBlend.Count; k++)
					{
						AudioEvent.MA_SnapshotInfo ma_SnapshotInfo = aEvent.snapshotsToBlend[k];
						if (!(ma_SnapshotInfo.snapshot == null))
						{
							if (audioMixer == null)
							{
								audioMixer = ma_SnapshotInfo.snapshot.audioMixer;
							}
							else if (audioMixer != ma_SnapshotInfo.snapshot.audioMixer)
							{
								Debug.LogError(string.Concat(new string[]
								{
									"Snapshot '",
									ma_SnapshotInfo.snapshot.name,
									"' isn't in the same Audio Mixer as the previous snapshot in EventSounds on GameObject '",
									base.name,
									"'. Please make sure all the Snapshots to blend are on the same mixer."
								}));
								break;
							}
							list3.Add(ma_SnapshotInfo.snapshot);
							list4.Add(ma_SnapshotInfo.weight);
						}
					}
					if (list3.Count > 0)
					{
						Debug.Log("trans");
						audioMixer.TransitionToSnapshots(list3.ToArray(), list4.ToArray(), aEvent.snapshotTransitionTime);
					}
				}
			}
			else
			{
				AudioMixerSnapshot snapshotToTransitionTo = aEvent.snapshotToTransitionTo;
				if (snapshotToTransitionTo != null)
				{
					snapshotToTransitionTo.audioMixer.TransitionToSnapshots(new AudioMixerSnapshot[]
					{
						snapshotToTransitionTo
					}, new float[]
					{
						1f
					}, aEvent.snapshotTransitionTime);
				}
			}
			break;
		}
		case MasterAudio.EventSoundFunctionType.PersistentSettingsControl:
			switch (aEvent.currentPersistentSettingsCommand)
			{
			case MasterAudio.PersistentSettingsCommand.SetBusVolume:
			{
				List<string> list5 = new List<string>();
				if (!aEvent.allSoundTypesForBusCmd)
				{
					list5.Add(aEvent.busName);
				}
				else
				{
					list5.AddRange(MasterAudio.RuntimeBusNames);
				}
				for (int l = 0; l < list5.Count; l++)
				{
					string busName2 = list5[l];
					float vol = (!flag) ? aEvent.volume : grp.sliderValue;
					PersistentAudioSettings.SetBusVolume(busName2, vol);
				}
				break;
			}
			case MasterAudio.PersistentSettingsCommand.SetGroupVolume:
			{
				List<string> list6 = new List<string>();
				if (!aEvent.allSoundTypesForGroupCmd)
				{
					list6.Add(aEvent.soundType);
				}
				else
				{
					list6.AddRange(MasterAudio.RuntimeSoundGroupNames);
				}
				for (int m = 0; m < list6.Count; m++)
				{
					string grpName = list6[m];
					float vol2 = (!flag) ? aEvent.volume : grp.sliderValue;
					PersistentAudioSettings.SetGroupVolume(grpName, vol2);
				}
				break;
			}
			case MasterAudio.PersistentSettingsCommand.SetMixerVolume:
			{
				float value = (!flag) ? aEvent.volume : grp.sliderValue;
				PersistentAudioSettings.MixerVolume = new float?(value);
				break;
			}
			case MasterAudio.PersistentSettingsCommand.SetMusicVolume:
			{
				float value2 = (!flag) ? aEvent.volume : grp.sliderValue;
				PersistentAudioSettings.MusicVolume = new float?(value2);
				break;
			}
			}
			break;
		}
		if (aEvent.emitParticles && playSoundResult != null && (playSoundResult.SoundPlayed || playSoundResult.SoundScheduled))
		{
			MasterAudio.TriggerParticleEmission(this._trans, aEvent.particleCountToEmit);
		}
		return playSoundResult;
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x0000B380 File Offset: 0x00009580
	private void LogIfCustomEventMissing(AudioEventGroup eventGroup)
	{
		if (!this.logMissingEvents)
		{
			return;
		}
		if (eventGroup.isCustomEvent && (!eventGroup.customSoundActive || string.IsNullOrEmpty(eventGroup.customEventName)))
		{
			return;
		}
		for (int i = 0; i < eventGroup.SoundEvents.Count; i++)
		{
			AudioEvent audioEvent = eventGroup.SoundEvents[i];
			if (audioEvent.currentSoundFunctionType == MasterAudio.EventSoundFunctionType.CustomEventControl)
			{
				string theCustomEventName = audioEvent.theCustomEventName;
				if (!MasterAudio.CustomEventExists(theCustomEventName))
				{
					MasterAudio.LogWarning(string.Concat(new string[]
					{
						"Transform '",
						base.name,
						"' is set up to receive or fire Custom Event '",
						theCustomEventName,
						"', which does not exist in Master Audio."
					}));
				}
			}
		}
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x0000B444 File Offset: 0x00009644
	public void CheckForIllegalCustomEvents()
	{
		if (this.useStartSound)
		{
			this.LogIfCustomEventMissing(this.startSound);
		}
		if (this.useVisibleSound)
		{
			this.LogIfCustomEventMissing(this.visibleSound);
		}
		if (this.useInvisibleSound)
		{
			this.LogIfCustomEventMissing(this.invisibleSound);
		}
		if (this.useCollisionSound)
		{
			this.LogIfCustomEventMissing(this.collisionSound);
		}
		if (this.useCollisionExitSound)
		{
			this.LogIfCustomEventMissing(this.collisionExitSound);
		}
		if (this.useTriggerEnterSound)
		{
			this.LogIfCustomEventMissing(this.triggerSound);
		}
		if (this.useTriggerExitSound)
		{
			this.LogIfCustomEventMissing(this.triggerExitSound);
		}
		if (this.useMouseEnterSound)
		{
			this.LogIfCustomEventMissing(this.mouseEnterSound);
		}
		if (this.useMouseExitSound)
		{
			this.LogIfCustomEventMissing(this.mouseExitSound);
		}
		if (this.useMouseClickSound)
		{
			this.LogIfCustomEventMissing(this.mouseClickSound);
		}
		if (this.useMouseDragSound)
		{
			this.LogIfCustomEventMissing(this.mouseDragSound);
		}
		if (this.useMouseUpSound)
		{
			this.LogIfCustomEventMissing(this.mouseUpSound);
		}
		if (this.useNguiMouseDownSound)
		{
			this.LogIfCustomEventMissing(this.nguiMouseDownSound);
		}
		if (this.useNguiMouseUpSound)
		{
			this.LogIfCustomEventMissing(this.nguiMouseUpSound);
		}
		if (this.useNguiOnClickSound)
		{
			this.LogIfCustomEventMissing(this.nguiOnClickSound);
		}
		if (this.useNguiMouseEnterSound)
		{
			this.LogIfCustomEventMissing(this.nguiMouseEnterSound);
		}
		if (this.useNguiMouseExitSound)
		{
			this.LogIfCustomEventMissing(this.nguiMouseExitSound);
		}
		if (this.useSpawnedSound)
		{
			this.LogIfCustomEventMissing(this.spawnedSound);
		}
		if (this.useDespawnedSound)
		{
			this.LogIfCustomEventMissing(this.despawnedSound);
		}
		if (this.useEnableSound)
		{
			this.LogIfCustomEventMissing(this.enableSound);
		}
		if (this.useDisableSound)
		{
			this.LogIfCustomEventMissing(this.disableSound);
		}
		if (this.useCollision2dSound)
		{
			this.LogIfCustomEventMissing(this.collision2dSound);
		}
		if (this.useCollisionExit2dSound)
		{
			this.LogIfCustomEventMissing(this.collisionExit2dSound);
		}
		if (this.useTriggerEnter2dSound)
		{
			this.LogIfCustomEventMissing(this.triggerEnter2dSound);
		}
		if (this.useTriggerExit2dSound)
		{
			this.LogIfCustomEventMissing(this.triggerExit2dSound);
		}
		if (this.useParticleCollisionSound)
		{
			this.LogIfCustomEventMissing(this.particleCollisionSound);
		}
		if (this.useUnitySliderChangedSound)
		{
			this.LogIfCustomEventMissing(this.unitySliderChangedSound);
		}
		if (this.useUnityButtonClickedSound)
		{
			this.LogIfCustomEventMissing(this.unityButtonClickedSound);
		}
		if (this.useUnityPointerDownSound)
		{
			this.LogIfCustomEventMissing(this.unityPointerDownSound);
		}
		if (this.useUnityDragSound)
		{
			this.LogIfCustomEventMissing(this.unityDragSound);
		}
		if (this.useUnityDropSound)
		{
			this.LogIfCustomEventMissing(this.unityDropSound);
		}
		if (this.useUnityPointerUpSound)
		{
			this.LogIfCustomEventMissing(this.unityPointerUpSound);
		}
		if (this.useUnityPointerEnterSound)
		{
			this.LogIfCustomEventMissing(this.unityPointerEnterSound);
		}
		if (this.useUnityPointerExitSound)
		{
			this.LogIfCustomEventMissing(this.unityPointerExitSound);
		}
		if (this.useUnityScrollSound)
		{
			this.LogIfCustomEventMissing(this.unityScrollSound);
		}
		if (this.useUnityUpdateSelectedSound)
		{
			this.LogIfCustomEventMissing(this.unityUpdateSelectedSound);
		}
		if (this.useUnitySelectSound)
		{
			this.LogIfCustomEventMissing(this.unitySelectSound);
		}
		if (this.useUnityDeselectSound)
		{
			this.LogIfCustomEventMissing(this.unityDeselectSound);
		}
		if (this.useUnityMoveSound)
		{
			this.LogIfCustomEventMissing(this.unityMoveSound);
		}
		if (this.useUnityInitializePotentialDragSound)
		{
			this.LogIfCustomEventMissing(this.unityInitializePotentialDragSound);
		}
		if (this.useUnityBeginDragSound)
		{
			this.LogIfCustomEventMissing(this.unityBeginDragSound);
		}
		if (this.useUnityEndDragSound)
		{
			this.LogIfCustomEventMissing(this.unityEndDragSound);
		}
		if (this.useUnitySubmitSound)
		{
			this.LogIfCustomEventMissing(this.unitySubmitSound);
		}
		if (this.useUnityCancelSound)
		{
			this.LogIfCustomEventMissing(this.unityCancelSound);
		}
		for (int i = 0; i < this.userDefinedSounds.Count; i++)
		{
			AudioEventGroup eventGroup = this.userDefinedSounds[i];
			this.LogIfCustomEventMissing(eventGroup);
		}
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000B878 File Offset: 0x00009A78
	public void ReceiveEvent(string customEventName, Vector3 originPoint)
	{
		for (int i = 0; i < this.userDefinedSounds.Count; i++)
		{
			AudioEventGroup audioEventGroup = this.userDefinedSounds[i];
			if (audioEventGroup.customSoundActive && !string.IsNullOrEmpty(audioEventGroup.customEventName))
			{
				if (audioEventGroup.customEventName.Equals(customEventName))
				{
					this.PlaySounds(audioEventGroup, EventSounds.EventType.UserDefinedEvent);
				}
			}
		}
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x0000B8F0 File Offset: 0x00009AF0
	public bool SubscribesToEvent(string customEventName)
	{
		for (int i = 0; i < this.userDefinedSounds.Count; i++)
		{
			AudioEventGroup audioEventGroup = this.userDefinedSounds[i];
			if (audioEventGroup.customSoundActive && !string.IsNullOrEmpty(audioEventGroup.customEventName) && audioEventGroup.customEventName.Equals(customEventName))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x0000B958 File Offset: 0x00009B58
	public void RegisterReceiver()
	{
		if (this.userDefinedSounds.Count > 0)
		{
			MasterAudio.AddCustomEventReceiver(this, this._trans);
		}
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x0000B978 File Offset: 0x00009B78
	public void UnregisterReceiver()
	{
		if (this.userDefinedSounds.Count > 0)
		{
			MasterAudio.RemoveCustomEventReceiver(this);
		}
	}

	// Token: 0x040001A1 RID: 417
	public bool showGizmo = true;

	// Token: 0x040001A2 RID: 418
	public MasterAudio.SoundSpawnLocationMode soundSpawnMode = MasterAudio.SoundSpawnLocationMode.AttachToCaller;

	// Token: 0x040001A3 RID: 419
	public bool disableSounds;

	// Token: 0x040001A4 RID: 420
	public bool showPoolManager;

	// Token: 0x040001A5 RID: 421
	public bool showNGUI;

	// Token: 0x040001A6 RID: 422
	public EventSounds.UnityUIVersion unityUIMode = EventSounds.UnityUIVersion.uGUI;

	// Token: 0x040001A7 RID: 423
	public bool logMissingEvents = true;

	// Token: 0x040001A8 RID: 424
	public static List<string> LayerTagFilterEvents = new List<string>
	{
		EventSounds.EventType.OnCollision.ToString(),
		EventSounds.EventType.OnTriggerEnter.ToString(),
		EventSounds.EventType.OnTriggerExit.ToString(),
		EventSounds.EventType.OnCollision2D.ToString(),
		EventSounds.EventType.OnTriggerEnter2D.ToString(),
		EventSounds.EventType.OnTriggerExit2D.ToString(),
		EventSounds.EventType.OnParticleCollision.ToString(),
		EventSounds.EventType.OnCollisionExit.ToString(),
		EventSounds.EventType.OnCollisionExit2D.ToString()
	};

	// Token: 0x040001A9 RID: 425
	public static List<MasterAudio.PlaylistCommand> PlaylistCommandsWithAll = new List<MasterAudio.PlaylistCommand>
	{
		MasterAudio.PlaylistCommand.FadeToVolume,
		MasterAudio.PlaylistCommand.Pause,
		MasterAudio.PlaylistCommand.PlayNextSong,
		MasterAudio.PlaylistCommand.PlayRandomSong,
		MasterAudio.PlaylistCommand.Resume,
		MasterAudio.PlaylistCommand.Stop,
		MasterAudio.PlaylistCommand.Mute,
		MasterAudio.PlaylistCommand.Unmute,
		MasterAudio.PlaylistCommand.ToggleMute,
		MasterAudio.PlaylistCommand.Restart
	};

	// Token: 0x040001AA RID: 426
	public AudioEventGroup startSound;

	// Token: 0x040001AB RID: 427
	public AudioEventGroup visibleSound;

	// Token: 0x040001AC RID: 428
	public AudioEventGroup invisibleSound;

	// Token: 0x040001AD RID: 429
	public AudioEventGroup collisionSound;

	// Token: 0x040001AE RID: 430
	public AudioEventGroup collisionExitSound;

	// Token: 0x040001AF RID: 431
	public AudioEventGroup triggerSound;

	// Token: 0x040001B0 RID: 432
	public AudioEventGroup triggerExitSound;

	// Token: 0x040001B1 RID: 433
	public AudioEventGroup mouseEnterSound;

	// Token: 0x040001B2 RID: 434
	public AudioEventGroup mouseExitSound;

	// Token: 0x040001B3 RID: 435
	public AudioEventGroup mouseClickSound;

	// Token: 0x040001B4 RID: 436
	public AudioEventGroup mouseUpSound;

	// Token: 0x040001B5 RID: 437
	public AudioEventGroup mouseDragSound;

	// Token: 0x040001B6 RID: 438
	public AudioEventGroup spawnedSound;

	// Token: 0x040001B7 RID: 439
	public AudioEventGroup despawnedSound;

	// Token: 0x040001B8 RID: 440
	public AudioEventGroup enableSound;

	// Token: 0x040001B9 RID: 441
	public AudioEventGroup disableSound;

	// Token: 0x040001BA RID: 442
	public AudioEventGroup collision2dSound;

	// Token: 0x040001BB RID: 443
	public AudioEventGroup collisionExit2dSound;

	// Token: 0x040001BC RID: 444
	public AudioEventGroup triggerEnter2dSound;

	// Token: 0x040001BD RID: 445
	public AudioEventGroup triggerExit2dSound;

	// Token: 0x040001BE RID: 446
	public AudioEventGroup particleCollisionSound;

	// Token: 0x040001BF RID: 447
	public AudioEventGroup nguiOnClickSound;

	// Token: 0x040001C0 RID: 448
	public AudioEventGroup nguiMouseDownSound;

	// Token: 0x040001C1 RID: 449
	public AudioEventGroup nguiMouseUpSound;

	// Token: 0x040001C2 RID: 450
	public AudioEventGroup nguiMouseEnterSound;

	// Token: 0x040001C3 RID: 451
	public AudioEventGroup nguiMouseExitSound;

	// Token: 0x040001C4 RID: 452
	public AudioEventGroup unitySliderChangedSound;

	// Token: 0x040001C5 RID: 453
	public AudioEventGroup unityButtonClickedSound;

	// Token: 0x040001C6 RID: 454
	public AudioEventGroup unityPointerDownSound;

	// Token: 0x040001C7 RID: 455
	public AudioEventGroup unityDragSound;

	// Token: 0x040001C8 RID: 456
	public AudioEventGroup unityPointerUpSound;

	// Token: 0x040001C9 RID: 457
	public AudioEventGroup unityPointerEnterSound;

	// Token: 0x040001CA RID: 458
	public AudioEventGroup unityPointerExitSound;

	// Token: 0x040001CB RID: 459
	public AudioEventGroup unityDropSound;

	// Token: 0x040001CC RID: 460
	public AudioEventGroup unityScrollSound;

	// Token: 0x040001CD RID: 461
	public AudioEventGroup unityUpdateSelectedSound;

	// Token: 0x040001CE RID: 462
	public AudioEventGroup unitySelectSound;

	// Token: 0x040001CF RID: 463
	public AudioEventGroup unityDeselectSound;

	// Token: 0x040001D0 RID: 464
	public AudioEventGroup unityMoveSound;

	// Token: 0x040001D1 RID: 465
	public AudioEventGroup unityInitializePotentialDragSound;

	// Token: 0x040001D2 RID: 466
	public AudioEventGroup unityBeginDragSound;

	// Token: 0x040001D3 RID: 467
	public AudioEventGroup unityEndDragSound;

	// Token: 0x040001D4 RID: 468
	public AudioEventGroup unitySubmitSound;

	// Token: 0x040001D5 RID: 469
	public AudioEventGroup unityCancelSound;

	// Token: 0x040001D6 RID: 470
	public List<AudioEventGroup> userDefinedSounds = new List<AudioEventGroup>();

	// Token: 0x040001D7 RID: 471
	public List<AudioEventGroup> mechanimStateChangedSounds = new List<AudioEventGroup>();

	// Token: 0x040001D8 RID: 472
	public bool useStartSound;

	// Token: 0x040001D9 RID: 473
	public bool useVisibleSound;

	// Token: 0x040001DA RID: 474
	public bool useInvisibleSound;

	// Token: 0x040001DB RID: 475
	public bool useCollisionSound;

	// Token: 0x040001DC RID: 476
	public bool useCollisionExitSound;

	// Token: 0x040001DD RID: 477
	public bool useTriggerEnterSound;

	// Token: 0x040001DE RID: 478
	public bool useTriggerExitSound;

	// Token: 0x040001DF RID: 479
	public bool useMouseEnterSound;

	// Token: 0x040001E0 RID: 480
	public bool useMouseExitSound;

	// Token: 0x040001E1 RID: 481
	public bool useMouseClickSound;

	// Token: 0x040001E2 RID: 482
	public bool useMouseUpSound;

	// Token: 0x040001E3 RID: 483
	public bool useMouseDragSound;

	// Token: 0x040001E4 RID: 484
	public bool useSpawnedSound;

	// Token: 0x040001E5 RID: 485
	public bool useDespawnedSound;

	// Token: 0x040001E6 RID: 486
	public bool useEnableSound;

	// Token: 0x040001E7 RID: 487
	public bool useDisableSound;

	// Token: 0x040001E8 RID: 488
	public bool useCollision2dSound;

	// Token: 0x040001E9 RID: 489
	public bool useCollisionExit2dSound;

	// Token: 0x040001EA RID: 490
	public bool useTriggerEnter2dSound;

	// Token: 0x040001EB RID: 491
	public bool useTriggerExit2dSound;

	// Token: 0x040001EC RID: 492
	public bool useParticleCollisionSound;

	// Token: 0x040001ED RID: 493
	public bool useNguiOnClickSound;

	// Token: 0x040001EE RID: 494
	public bool useNguiMouseDownSound;

	// Token: 0x040001EF RID: 495
	public bool useNguiMouseUpSound;

	// Token: 0x040001F0 RID: 496
	public bool useNguiMouseEnterSound;

	// Token: 0x040001F1 RID: 497
	public bool useNguiMouseExitSound;

	// Token: 0x040001F2 RID: 498
	public bool useUnitySliderChangedSound;

	// Token: 0x040001F3 RID: 499
	public bool useUnityButtonClickedSound;

	// Token: 0x040001F4 RID: 500
	public bool useUnityPointerDownSound;

	// Token: 0x040001F5 RID: 501
	public bool useUnityDragSound;

	// Token: 0x040001F6 RID: 502
	public bool useUnityPointerUpSound;

	// Token: 0x040001F7 RID: 503
	public bool useUnityPointerEnterSound;

	// Token: 0x040001F8 RID: 504
	public bool useUnityPointerExitSound;

	// Token: 0x040001F9 RID: 505
	public bool useUnityDropSound;

	// Token: 0x040001FA RID: 506
	public bool useUnityScrollSound;

	// Token: 0x040001FB RID: 507
	public bool useUnityUpdateSelectedSound;

	// Token: 0x040001FC RID: 508
	public bool useUnitySelectSound;

	// Token: 0x040001FD RID: 509
	public bool useUnityDeselectSound;

	// Token: 0x040001FE RID: 510
	public bool useUnityMoveSound;

	// Token: 0x040001FF RID: 511
	public bool useUnityInitializePotentialDragSound;

	// Token: 0x04000200 RID: 512
	public bool useUnityBeginDragSound;

	// Token: 0x04000201 RID: 513
	public bool useUnityEndDragSound;

	// Token: 0x04000202 RID: 514
	public bool useUnitySubmitSound;

	// Token: 0x04000203 RID: 515
	public bool useUnityCancelSound;

	// Token: 0x04000204 RID: 516
	private Slider _slider;

	// Token: 0x04000205 RID: 517
	private Button _button;

	// Token: 0x04000206 RID: 518
	private bool _isVisible;

	// Token: 0x04000207 RID: 519
	private bool _needsCoroutine;

	// Token: 0x04000208 RID: 520
	private bool _mouseDragSoundPlayed;

	// Token: 0x04000209 RID: 521
	private PlaySoundResult _mouseDragResult;

	// Token: 0x0400020A RID: 522
	private Transform _trans;

	// Token: 0x0400020B RID: 523
	private readonly List<AudioEventGroup> _validMechanimStateChangedSounds = new List<AudioEventGroup>();

	// Token: 0x0400020C RID: 524
	private Animator _anim;

	// Token: 0x0200006D RID: 109
	public enum UnityUIVersion
	{
		// Token: 0x0400020E RID: 526
		Legacy,
		// Token: 0x0400020F RID: 527
		uGUI
	}

	// Token: 0x0200006E RID: 110
	public enum EventType
	{
		// Token: 0x04000211 RID: 529
		OnStart,
		// Token: 0x04000212 RID: 530
		OnVisible,
		// Token: 0x04000213 RID: 531
		OnInvisible,
		// Token: 0x04000214 RID: 532
		OnCollision,
		// Token: 0x04000215 RID: 533
		OnTriggerEnter,
		// Token: 0x04000216 RID: 534
		OnTriggerExit,
		// Token: 0x04000217 RID: 535
		OnMouseEnter,
		// Token: 0x04000218 RID: 536
		OnMouseClick,
		// Token: 0x04000219 RID: 537
		OnSpawned,
		// Token: 0x0400021A RID: 538
		OnDespawned,
		// Token: 0x0400021B RID: 539
		OnEnable,
		// Token: 0x0400021C RID: 540
		OnDisable,
		// Token: 0x0400021D RID: 541
		OnCollision2D,
		// Token: 0x0400021E RID: 542
		OnTriggerEnter2D,
		// Token: 0x0400021F RID: 543
		OnTriggerExit2D,
		// Token: 0x04000220 RID: 544
		OnParticleCollision,
		// Token: 0x04000221 RID: 545
		UserDefinedEvent,
		// Token: 0x04000222 RID: 546
		OnCollisionExit,
		// Token: 0x04000223 RID: 547
		OnCollisionExit2D,
		// Token: 0x04000224 RID: 548
		OnMouseUp,
		// Token: 0x04000225 RID: 549
		OnMouseExit,
		// Token: 0x04000226 RID: 550
		OnMouseDrag,
		// Token: 0x04000227 RID: 551
		NGUIOnClick,
		// Token: 0x04000228 RID: 552
		NGUIMouseDown,
		// Token: 0x04000229 RID: 553
		NGUIMouseUp,
		// Token: 0x0400022A RID: 554
		NGUIMouseEnter,
		// Token: 0x0400022B RID: 555
		NGUIMouseExit,
		// Token: 0x0400022C RID: 556
		MechanimStateChanged,
		// Token: 0x0400022D RID: 557
		UnitySliderChanged,
		// Token: 0x0400022E RID: 558
		UnityButtonClicked,
		// Token: 0x0400022F RID: 559
		UnityPointerDown,
		// Token: 0x04000230 RID: 560
		UnityPointerUp,
		// Token: 0x04000231 RID: 561
		UnityPointerEnter,
		// Token: 0x04000232 RID: 562
		UnityPointerExit,
		// Token: 0x04000233 RID: 563
		UnityDrag,
		// Token: 0x04000234 RID: 564
		UnityDrop,
		// Token: 0x04000235 RID: 565
		UnityScroll,
		// Token: 0x04000236 RID: 566
		UnityUpdateSelected,
		// Token: 0x04000237 RID: 567
		UnitySelect,
		// Token: 0x04000238 RID: 568
		UnityDeselect,
		// Token: 0x04000239 RID: 569
		UnityMove,
		// Token: 0x0400023A RID: 570
		UnityInitializePotentialDrag,
		// Token: 0x0400023B RID: 571
		UnityBeginDrag,
		// Token: 0x0400023C RID: 572
		UnityEndDrag,
		// Token: 0x0400023D RID: 573
		UnitySubmit,
		// Token: 0x0400023E RID: 574
		UnityCancel
	}

	// Token: 0x0200006F RID: 111
	public enum VariationType
	{
		// Token: 0x04000240 RID: 576
		PlaySpecific,
		// Token: 0x04000241 RID: 577
		PlayRandom
	}

	// Token: 0x02000070 RID: 112
	public enum PreviousSoundStopMode
	{
		// Token: 0x04000243 RID: 579
		None,
		// Token: 0x04000244 RID: 580
		Stop,
		// Token: 0x04000245 RID: 581
		FadeOut
	}

	// Token: 0x02000071 RID: 113
	public enum RetriggerLimMode
	{
		// Token: 0x04000247 RID: 583
		None,
		// Token: 0x04000248 RID: 584
		FrameBased,
		// Token: 0x04000249 RID: 585
		TimeBased
	}
}
