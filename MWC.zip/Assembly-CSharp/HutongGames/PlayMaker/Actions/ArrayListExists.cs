﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200039E RID: 926
	[Tooltip("Check if an ArrayList Proxy component exists.")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListExists : ArrayListActions
	{
		// Token: 0x06000FAF RID: 4015 RVA: 0x000564B0 File Offset: 0x000546B0
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.doesExists = null;
			this.doesExistsEvent = null;
			this.doesNotExistsEvent = null;
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x000564D8 File Offset: 0x000546D8
		public override void OnEnter()
		{
			PlayMakerArrayListProxy arrayListProxyPointer = base.GetArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value, true);
			bool flag = arrayListProxyPointer != null;
			this.doesExists.Value = flag;
			if (flag)
			{
				base.Fsm.Event(this.doesExistsEvent);
			}
			else
			{
				base.Fsm.Event(this.doesNotExistsEvent);
			}
			base.Finish();
		}

		// Token: 0x0400145F RID: 5215
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001460 RID: 5216
		[UIHint(UIHint.FsmString)]
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		public FsmString reference;

		// Token: 0x04001461 RID: 5217
		[ActionSection("Result")]
		[Tooltip("Store in a bool wether it exists or not")]
		[UIHint(UIHint.Variable)]
		public FsmBool doesExists;

		// Token: 0x04001462 RID: 5218
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this arrayList exists ")]
		public FsmEvent doesExistsEvent;

		// Token: 0x04001463 RID: 5219
		[Tooltip("Event sent if this arrayList does not exists")]
		[UIHint(UIHint.FsmEvent)]
		public FsmEvent doesNotExistsEvent;
	}
}
