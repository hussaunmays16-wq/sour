﻿using System;
using UnityEngine;

// Token: 0x02000026 RID: 38
[Serializable]
public class AxleInfo
{
	// Token: 0x040000BF RID: 191
	public WheelCollider leftWheel;

	// Token: 0x040000C0 RID: 192
	public WheelCollider rightWheel;

	// Token: 0x040000C1 RID: 193
	public bool motor;

	// Token: 0x040000C2 RID: 194
	public bool steering;
}
