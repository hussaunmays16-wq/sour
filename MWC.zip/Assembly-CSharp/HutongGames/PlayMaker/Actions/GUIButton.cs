﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E3 RID: 483
	[ActionCategory(ActionCategory.GUI)]
	[Tooltip("GUI button. Sends an Event when pressed. Optionally store the button state in a Bool Variable.")]
	public class GUIButton : GUIContentAction
	{
		// Token: 0x06000875 RID: 2165 RVA: 0x0003967C File Offset: 0x0003787C
		public override void Reset()
		{
			base.Reset();
			this.sendEvent = null;
			this.storeButtonState = null;
			this.style = "Button";
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x000396B0 File Offset: 0x000378B0
		public override void OnGUI()
		{
			base.OnGUI();
			bool value = false;
			if (GUI.Button(this.rect, this.content, this.style.Value))
			{
				base.Fsm.Event(this.sendEvent);
				value = true;
			}
			if (this.storeButtonState != null)
			{
				this.storeButtonState.Value = value;
			}
		}

		// Token: 0x04000C25 RID: 3109
		public FsmEvent sendEvent;

		// Token: 0x04000C26 RID: 3110
		[UIHint(UIHint.Variable)]
		public FsmBool storeButtonState;
	}
}
