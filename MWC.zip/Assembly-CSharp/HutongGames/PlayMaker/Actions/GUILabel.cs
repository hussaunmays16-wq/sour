﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E7 RID: 487
	[ActionCategory(ActionCategory.GUI)]
	[Tooltip("GUI Label.")]
	public class GUILabel : GUIContentAction
	{
		// Token: 0x06000883 RID: 2179 RVA: 0x00039ADC File Offset: 0x00037CDC
		public override void OnGUI()
		{
			base.OnGUI();
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUI.Label(this.rect, this.content);
			}
			else
			{
				GUI.Label(this.rect, this.content, this.style.Value);
			}
		}
	}
}
