﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004A5 RID: 1189
	[Tooltip("Gets the raw axis input and stores it in a fsm variable.")]
	[ActionCategory("cInput")]
	public class CInputGetAxisRaw : FsmStateAction
	{
		// Token: 0x0600144A RID: 5194 RVA: 0x00088A50 File Offset: 0x00086C50
		public override void Reset()
		{
			this.axisName = null;
			this.storeAxisValue = null;
		}

		// Token: 0x0600144B RID: 5195 RVA: 0x00088A60 File Offset: 0x00086C60
		public override void OnUpdate()
		{
			if (this.axisName == null)
			{
				return;
			}
			this.storeAxisValue.Value = cInput.GetAxisRaw(this.axisName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CB3 RID: 7347
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CB4 RID: 7348
		[Tooltip("The value of the axis.")]
		public FsmFloat storeAxisValue;

		// Token: 0x04001CB5 RID: 7349
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
