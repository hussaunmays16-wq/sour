﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000221 RID: 545
	[ActionCategory(ActionCategory.Device)]
	[Tooltip("Gets the rotation of the device around its z axis (into the screen). For example when you steer with the iPhone in a driving game.")]
	public class GetDeviceRoll : FsmStateAction
	{
		// Token: 0x06000950 RID: 2384 RVA: 0x0003CA78 File Offset: 0x0003AC78
		public override void Reset()
		{
			this.baseOrientation = GetDeviceRoll.BaseOrientation.LandscapeLeft;
			this.storeAngle = null;
			this.limitAngle = new FsmFloat
			{
				UseVariable = true
			};
			this.smoothing = 5f;
			this.everyFrame = true;
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x0003CAC0 File Offset: 0x0003ACC0
		public override void OnEnter()
		{
			this.DoGetDeviceRoll();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x0003CADC File Offset: 0x0003ACDC
		public override void OnUpdate()
		{
			this.DoGetDeviceRoll();
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x0003CAE4 File Offset: 0x0003ACE4
		private void DoGetDeviceRoll()
		{
			float x = Input.acceleration.x;
			float y = Input.acceleration.y;
			float num = 0f;
			switch (this.baseOrientation)
			{
			case GetDeviceRoll.BaseOrientation.Portrait:
				num = -Mathf.Atan2(x, -y);
				break;
			case GetDeviceRoll.BaseOrientation.LandscapeLeft:
				num = Mathf.Atan2(y, -x);
				break;
			case GetDeviceRoll.BaseOrientation.LandscapeRight:
				num = -Mathf.Atan2(y, x);
				break;
			}
			if (!this.limitAngle.IsNone)
			{
				num = Mathf.Clamp(57.29578f * num, -this.limitAngle.Value, this.limitAngle.Value);
			}
			if (this.smoothing.Value > 0f)
			{
				num = Mathf.LerpAngle(this.lastZAngle, num, this.smoothing.Value * Time.deltaTime);
			}
			this.lastZAngle = num;
			this.storeAngle.Value = num;
		}

		// Token: 0x04000D22 RID: 3362
		[Tooltip("How the user is expected to hold the device (where angle will be zero).")]
		public GetDeviceRoll.BaseOrientation baseOrientation;

		// Token: 0x04000D23 RID: 3363
		[UIHint(UIHint.Variable)]
		public FsmFloat storeAngle;

		// Token: 0x04000D24 RID: 3364
		public FsmFloat limitAngle;

		// Token: 0x04000D25 RID: 3365
		public FsmFloat smoothing;

		// Token: 0x04000D26 RID: 3366
		public bool everyFrame;

		// Token: 0x04000D27 RID: 3367
		private float lastZAngle;

		// Token: 0x02000222 RID: 546
		public enum BaseOrientation
		{
			// Token: 0x04000D29 RID: 3369
			Portrait,
			// Token: 0x04000D2A RID: 3370
			LandscapeLeft,
			// Token: 0x04000D2B RID: 3371
			LandscapeRight
		}
	}
}
