﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FD RID: 509
	[Tooltip("GUILayout Label for an Int Variable.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutIntLabel : GUILayoutAction
	{
		// Token: 0x060008C4 RID: 2244 RVA: 0x0003AA08 File Offset: 0x00038C08
		public override void Reset()
		{
			base.Reset();
			this.prefix = string.Empty;
			this.style = string.Empty;
			this.intVariable = null;
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x0003AA38 File Offset: 0x00038C38
		public override void OnGUI()
		{
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUILayout.Label(new GUIContent(this.prefix.Value + this.intVariable.Value), base.LayoutOptions);
			}
			else
			{
				GUILayout.Label(new GUIContent(this.prefix.Value + this.intVariable.Value), this.style.Value, base.LayoutOptions);
			}
		}

		// Token: 0x04000C7F RID: 3199
		[Tooltip("Text to put before the int variable.")]
		public FsmString prefix;

		// Token: 0x04000C80 RID: 3200
		[UIHint(UIHint.Variable)]
		[Tooltip("Int variable to display.")]
		[RequiredField]
		public FsmInt intVariable;

		// Token: 0x04000C81 RID: 3201
		[Tooltip("Optional GUIStyle in the active GUISKin.")]
		public FsmString style;
	}
}
