﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000226 RID: 550
	[Tooltip("Get the value of a Color Variable from another FSM.")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetFsmColor : FsmStateAction
	{
		// Token: 0x06000962 RID: 2402 RVA: 0x0003CFCC File Offset: 0x0003B1CC
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x0003CFEC File Offset: 0x0003B1EC
		public override void OnEnter()
		{
			this.DoGetFsmColor();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x0003D008 File Offset: 0x0003B208
		public override void OnUpdate()
		{
			this.DoGetFsmColor();
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x0003D010 File Offset: 0x0003B210
		private void DoGetFsmColor()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmColor fsmColor = this.fsm.FsmVariables.GetFsmColor(this.variableName.Value);
			if (fsmColor == null)
			{
				return;
			}
			this.storeValue.Value = fsmColor.Value;
		}

		// Token: 0x04000D46 RID: 3398
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D47 RID: 3399
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x04000D48 RID: 3400
		[UIHint(UIHint.FsmColor)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D49 RID: 3401
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmColor storeValue;

		// Token: 0x04000D4A RID: 3402
		public bool everyFrame;

		// Token: 0x04000D4B RID: 3403
		private GameObject goLastFrame;

		// Token: 0x04000D4C RID: 3404
		private PlayMakerFSM fsm;
	}
}
