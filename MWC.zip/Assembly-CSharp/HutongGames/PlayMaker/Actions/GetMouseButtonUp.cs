﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000242 RID: 578
	[Tooltip("Sends an Event when the specified Mouse Button is released. Optionally store the button state in a bool variable.")]
	[ActionCategory(ActionCategory.Input)]
	public class GetMouseButtonUp : FsmStateAction
	{
		// Token: 0x060009DE RID: 2526 RVA: 0x0003E7CC File Offset: 0x0003C9CC
		public override void Reset()
		{
			this.button = MouseButton.Left;
			this.sendEvent = null;
			this.storeResult = null;
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x0003E7E4 File Offset: 0x0003C9E4
		public override void OnUpdate()
		{
			bool mouseButtonUp = Input.GetMouseButtonUp((int)this.button);
			if (mouseButtonUp)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = mouseButtonUp;
		}

		// Token: 0x04000DDB RID: 3547
		[RequiredField]
		public MouseButton button;

		// Token: 0x04000DDC RID: 3548
		public FsmEvent sendEvent;

		// Token: 0x04000DDD RID: 3549
		[UIHint(UIHint.Variable)]
		public FsmBool storeResult;
	}
}
