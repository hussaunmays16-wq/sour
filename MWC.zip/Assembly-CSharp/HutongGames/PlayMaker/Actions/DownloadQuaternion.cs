﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200019A RID: 410
	[ActionCategory("Easy Save 2")]
	[Tooltip("Downloads a Quaternion from MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	public class DownloadQuaternion : FsmStateAction
	{
		// Token: 0x0600076A RID: 1898 RVA: 0x00034AD4 File Offset: 0x00032CD4
		public override void Reset()
		{
			this.uniqueTag = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.loadValue = null;
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00034B40 File Offset: 0x00032D40
		public override void OnEnter()
		{
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile,
				"&webpassword=",
				this.password,
				"&webusername=",
				this.username
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new object[]
			{
				"Downloading from ",
				this.urlToPHPFile,
				"?tag=",
				this.uniqueTag,
				"&webfilename=",
				this.saveFile
			}));
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x00034C14 File Offset: 0x00032E14
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage.Value = this.web.error;
				this.errorCode.Value = this.web.errorCode;
				base.Fsm.Event(this.isError);
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				this.loadValue.Value = this.web.Load<Quaternion>(this.uniqueTag.Value);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
			}
		}

		// Token: 0x04000AD5 RID: 2773
		[RequiredField]
		[Tooltip("The variable we want to load our data into.")]
		public FsmQuaternion loadValue;

		// Token: 0x04000AD6 RID: 2774
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[RequiredField]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x04000AD7 RID: 2775
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x04000AD8 RID: 2776
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x04000AD9 RID: 2777
		[RequiredField]
		[Tooltip("The unique tag for this save. For example, the object's name if no other objects use the same name.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04000ADA RID: 2778
		[RequiredField]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04000ADB RID: 2779
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04000ADC RID: 2780
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x04000ADD RID: 2781
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x04000ADE RID: 2782
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x04000ADF RID: 2783
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x04000AE0 RID: 2784
		private ES2Web web;
	}
}
