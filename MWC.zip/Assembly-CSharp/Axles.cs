﻿using System;
using UnityEngine;

// Token: 0x0200046F RID: 1135
[ExecuteInEditMode]
[RequireComponent(typeof(Rigidbody))]
public class Axles : MonoBehaviour
{
	// Token: 0x06001316 RID: 4886 RVA: 0x0006C2B0 File Offset: 0x0006A4B0
	private void CheckWheels()
	{
		if (this.frontAxle.leftWheel == null)
		{
			Debug.LogWarning("UnityCar: front left wheel not assigned  (" + base.transform.name + ")");
		}
		if (this.frontAxle.rightWheel == null)
		{
			Debug.LogWarning("UnityCar: front right wheel not assigned  (" + base.transform.name + ")");
		}
		if (this.rearAxle.leftWheel == null)
		{
			Debug.LogWarning("UnityCar: rear left wheel not assigned  (" + base.transform.name + ")");
		}
		if (this.rearAxle.rightWheel == null)
		{
			Debug.LogWarning("UnityCar: rear right wheel not assigned  (" + base.transform.name + ")");
		}
	}

	// Token: 0x06001317 RID: 4887 RVA: 0x0006C394 File Offset: 0x0006A594
	private void Start()
	{
		this.CheckWheels();
	}

	// Token: 0x06001318 RID: 4888 RVA: 0x0006C39C File Offset: 0x0006A59C
	private void Awake()
	{
		this.SetWheels();
	}

	// Token: 0x06001319 RID: 4889 RVA: 0x0006C3A4 File Offset: 0x0006A5A4
	public void SetWheels()
	{
		if (this.frontAxle.leftWheel)
		{
			this.frontAxle.leftWheel.wheelPos = WheelPos.FRONT_LEFT;
		}
		if (this.frontAxle.rightWheel)
		{
			this.frontAxle.rightWheel.wheelPos = WheelPos.FRONT_RIGHT;
		}
		if (this.rearAxle.leftWheel)
		{
			this.rearAxle.leftWheel.wheelPos = WheelPos.REAR_LEFT;
		}
		if (this.rearAxle.rightWheel)
		{
			this.rearAxle.rightWheel.wheelPos = WheelPos.REAR_RIGHT;
		}
		this.frontAxle.wheels = new Wheel[0];
		if (this.frontAxle.leftWheel != null && this.frontAxle.rightWheel != null)
		{
			this.frontAxle.wheels = new Wheel[2];
			this.frontAxle.wheels[0] = this.frontAxle.leftWheel;
			this.frontAxle.wheels[1] = this.frontAxle.rightWheel;
		}
		else if (this.frontAxle.leftWheel != null || this.frontAxle.rightWheel != null)
		{
			this.frontAxle.wheels = new Wheel[1];
			if (this.frontAxle.leftWheel != null)
			{
				this.frontAxle.wheels[0] = this.frontAxle.leftWheel;
			}
			else
			{
				this.frontAxle.wheels[0] = this.frontAxle.rightWheel;
			}
		}
		this.frontAxle.camber = Mathf.Clamp(this.frontAxle.camber, -10f, 10f);
		this.rearAxle.wheels = new Wheel[0];
		if (this.rearAxle.leftWheel != null && this.rearAxle.rightWheel != null)
		{
			this.rearAxle.wheels = new Wheel[2];
			this.rearAxle.wheels[0] = this.rearAxle.leftWheel;
			this.rearAxle.wheels[1] = this.rearAxle.rightWheel;
		}
		else if (this.rearAxle.leftWheel != null || this.rearAxle.rightWheel != null)
		{
			this.rearAxle.wheels = new Wheel[1];
			if (this.rearAxle.leftWheel != null)
			{
				this.rearAxle.wheels[0] = this.rearAxle.leftWheel;
			}
			else
			{
				this.rearAxle.wheels[0] = this.rearAxle.rightWheel;
			}
		}
		this.rearAxle.camber = Mathf.Clamp(this.rearAxle.camber, -10f, 10f);
		Wheel[] array = new Wheel[this.otherAxles.Length * 2];
		int num = 0;
		foreach (Axle axle in this.otherAxles)
		{
			if (axle.leftWheel != null && axle.rightWheel != null)
			{
				axle.wheels = new Wheel[2];
				axle.wheels[0] = (array[num] = axle.leftWheel);
				axle.wheels[1] = (array[num + 1] = axle.rightWheel);
				num += 2;
			}
			else
			{
				axle.wheels = new Wheel[1];
				if (axle.leftWheel != null)
				{
					axle.wheels[0] = (array[0] = axle.leftWheel);
				}
				else
				{
					axle.wheels[0] = (array[0] = axle.rightWheel);
				}
				num++;
			}
			axle.camber = Mathf.Clamp(axle.camber, -10f, 10f);
		}
		this.otherWheels = new Wheel[num];
		array.CopyTo(this.otherWheels, 0);
		this.allWheels = new Wheel[this.frontAxle.wheels.Length + this.rearAxle.wheels.Length + this.otherWheels.Length];
		this.frontAxle.wheels.CopyTo(this.allWheels, 0);
		this.rearAxle.wheels.CopyTo(this.allWheels, this.frontAxle.wheels.Length);
		if (this.otherWheels.Length != 0)
		{
			this.otherWheels.CopyTo(this.allWheels, this.frontAxle.wheels.Length + this.rearAxle.wheels.Length);
		}
	}

	// Token: 0x040018E8 RID: 6376
	[HideInInspector]
	public Wheel[] otherWheels = new Wheel[0];

	// Token: 0x040018E9 RID: 6377
	[HideInInspector]
	public Wheel[] allWheels;

	// Token: 0x040018EA RID: 6378
	public Axle frontAxle = new Axle();

	// Token: 0x040018EB RID: 6379
	public Axle rearAxle = new Axle();

	// Token: 0x040018EC RID: 6380
	public Axle[] otherAxles = new Axle[0];
}
