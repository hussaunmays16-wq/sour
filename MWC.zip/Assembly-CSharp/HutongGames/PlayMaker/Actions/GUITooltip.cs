﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000207 RID: 519
	[Tooltip("Gets the Tooltip of the control the mouse is currently over and store it in a String Variable.")]
	[ActionCategory(ActionCategory.GUI)]
	public class GUITooltip : FsmStateAction
	{
		// Token: 0x060008E5 RID: 2277 RVA: 0x0003B3E8 File Offset: 0x000395E8
		public override void Reset()
		{
			this.storeTooltip = null;
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x0003B3F4 File Offset: 0x000395F4
		public override void OnGUI()
		{
			this.storeTooltip.Value = GUI.tooltip;
		}

		// Token: 0x04000CAA RID: 3242
		[UIHint(UIHint.Variable)]
		public FsmString storeTooltip;
	}
}
