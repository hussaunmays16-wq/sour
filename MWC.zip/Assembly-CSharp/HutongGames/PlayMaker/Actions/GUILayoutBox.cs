﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001EF RID: 495
	[Tooltip("GUILayout Box.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutBox : GUILayoutAction
	{
		// Token: 0x0600089B RID: 2203 RVA: 0x0003A214 File Offset: 0x00038414
		public override void Reset()
		{
			base.Reset();
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x0600089C RID: 2204 RVA: 0x0003A254 File Offset: 0x00038454
		public override void OnGUI()
		{
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUILayout.Box(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), base.LayoutOptions);
			}
			else
			{
				GUILayout.Box(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
			}
		}

		// Token: 0x04000C5C RID: 3164
		[Tooltip("Image to display in the Box.")]
		public FsmTexture image;

		// Token: 0x04000C5D RID: 3165
		[Tooltip("Text to display in the Box.")]
		public FsmString text;

		// Token: 0x04000C5E RID: 3166
		[Tooltip("Optional Tooltip string.")]
		public FsmString tooltip;

		// Token: 0x04000C5F RID: 3167
		[Tooltip("Optional GUIStyle in the active GUISkin.")]
		public FsmString style;
	}
}
