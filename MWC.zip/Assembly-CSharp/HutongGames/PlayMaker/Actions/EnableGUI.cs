﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001C6 RID: 454
	[Tooltip("Enables/Disables the PlayMakerGUI component in the scene. Note, you need a PlayMakerGUI component in the scene to see OnGUI actions. However, OnGUI can be very expensive on mobile devices. This action lets you turn OnGUI on/off (e.g., turn it on for a menu, and off during gameplay).")]
	[ActionCategory(ActionCategory.GUI)]
	public class EnableGUI : FsmStateAction
	{
		// Token: 0x060007FC RID: 2044 RVA: 0x00037EF4 File Offset: 0x000360F4
		public override void Reset()
		{
			this.enableGUI = true;
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00037F04 File Offset: 0x00036104
		public override void OnEnter()
		{
			PlayMakerGUI.Instance.enabled = this.enableGUI.Value;
			base.Finish();
		}

		// Token: 0x04000BA1 RID: 2977
		[Tooltip("Set to True to enable, False to disable.")]
		public FsmBool enableGUI;
	}
}
