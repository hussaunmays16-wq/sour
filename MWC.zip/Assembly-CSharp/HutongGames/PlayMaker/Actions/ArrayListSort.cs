﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B2 RID: 946
	[Tooltip("Sorts the sequence of elements in a PlayMaker ArrayList Proxy component")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListSort : ArrayListActions
	{
		// Token: 0x06001001 RID: 4097 RVA: 0x00057D60 File Offset: 0x00055F60
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x06001002 RID: 4098 RVA: 0x00057D70 File Offset: 0x00055F70
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListSort();
			}
			base.Finish();
		}

		// Token: 0x06001003 RID: 4099 RVA: 0x00057DB0 File Offset: 0x00055FB0
		public void DoArrayListSort()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.arrayList.Sort();
		}

		// Token: 0x040014CE RID: 5326
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014CF RID: 5327
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
