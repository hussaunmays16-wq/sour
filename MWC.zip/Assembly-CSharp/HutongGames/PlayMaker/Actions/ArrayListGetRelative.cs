﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003A9 RID: 937
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Gets an item from a PlayMaker ArrayList Proxy component using a base index and a relative increment. This allows you to move to next or previous items granuraly")]
	public class ArrayListGetRelative : ArrayListActions
	{
		// Token: 0x06000FDC RID: 4060 RVA: 0x00057548 File Offset: 0x00055748
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.baseIndex = null;
			this.increment = null;
			this.result = null;
			this.resultIndex = null;
		}

		// Token: 0x06000FDD RID: 4061 RVA: 0x00057580 File Offset: 0x00055780
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.GetItemAtIncrement();
			}
			base.Finish();
		}

		// Token: 0x06000FDE RID: 4062 RVA: 0x000575C0 File Offset: 0x000557C0
		public void GetItemAtIncrement()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			int num = this.baseIndex.Value + this.increment.Value;
			if (num >= 0)
			{
				this.resultIndex.Value = (this.baseIndex.Value + this.increment.Value) % this.proxy.arrayList.Count;
			}
			else
			{
				this.resultIndex.Value = this.proxy.arrayList.Count - Mathf.Abs(this.baseIndex.Value + this.increment.Value) % this.proxy.arrayList.Count;
			}
			object value = this.proxy.arrayList[this.resultIndex.Value];
			PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.result, value);
		}

		// Token: 0x040014AB RID: 5291
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014AC RID: 5292
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014AD RID: 5293
		[Tooltip("The index base to compute the item to get")]
		public FsmInt baseIndex;

		// Token: 0x040014AE RID: 5294
		[Tooltip("The incremental value from the base index to get the value from. Overshooting the range will loop back on the list.")]
		public FsmInt increment;

		// Token: 0x040014AF RID: 5295
		[ActionSection("Result")]
		[UIHint(UIHint.Variable)]
		public FsmVar result;

		// Token: 0x040014B0 RID: 5296
		[UIHint(UIHint.Variable)]
		[Tooltip("The index of the result")]
		public FsmInt resultIndex;
	}
}
