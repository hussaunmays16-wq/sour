﻿using System;
using UnityEngine;

// Token: 0x0200046B RID: 1131
public class AerodynamicResistance : MonoBehaviour
{
	// Token: 0x0600130C RID: 4876 RVA: 0x0006BDF0 File Offset: 0x00069FF0
	private void Start()
	{
		this.body = base.GetComponent<Rigidbody>();
		this.cardynamics = base.GetComponent<CarDynamics>();
	}

	// Token: 0x0600130D RID: 4877 RVA: 0x0006BE0C File Offset: 0x0006A00C
	private void FixedUpdate()
	{
		if (this.body.velocity.sqrMagnitude <= 0.001f)
		{
			this.dragForce = 0f;
		}
		else
		{
			this.dragForce = 0.5f * this.Cx * this.Area * this.cardynamics.airDensity * this.body.velocity.sqrMagnitude;
		}
		this.body.AddForce(-this.dragForce * this.body.velocity.normalized);
	}

	// Token: 0x040018D0 RID: 6352
	public float Cx = 0.3f;

	// Token: 0x040018D1 RID: 6353
	public float Area = 1.858f;

	// Token: 0x040018D2 RID: 6354
	public float dragForce;

	// Token: 0x040018D3 RID: 6355
	private Rigidbody body;

	// Token: 0x040018D4 RID: 6356
	private CarDynamics cardynamics;
}
