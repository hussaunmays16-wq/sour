﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000162 RID: 354
	[Tooltip("Converts a Bool value to a Color.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertBoolToColor : FsmStateAction
	{
		// Token: 0x06000698 RID: 1688 RVA: 0x00030960 File Offset: 0x0002EB60
		public override void Reset()
		{
			this.boolVariable = null;
			this.colorVariable = null;
			this.falseColor = Color.black;
			this.trueColor = Color.white;
			this.everyFrame = false;
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00030998 File Offset: 0x0002EB98
		public override void OnEnter()
		{
			this.DoConvertBoolToColor();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x000309B4 File Offset: 0x0002EBB4
		public override void OnUpdate()
		{
			this.DoConvertBoolToColor();
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x000309BC File Offset: 0x0002EBBC
		private void DoConvertBoolToColor()
		{
			this.colorVariable.Value = ((!this.boolVariable.Value) ? this.falseColor.Value : this.trueColor.Value);
		}

		// Token: 0x04000994 RID: 2452
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variable to test.")]
		public FsmBool boolVariable;

		// Token: 0x04000995 RID: 2453
		[UIHint(UIHint.Variable)]
		[Tooltip("The Color variable to set based on the bool variable value.")]
		[RequiredField]
		public FsmColor colorVariable;

		// Token: 0x04000996 RID: 2454
		[Tooltip("Color if Bool variable is false.")]
		public FsmColor falseColor;

		// Token: 0x04000997 RID: 2455
		[Tooltip("Color if Bool variable is true.")]
		public FsmColor trueColor;

		// Token: 0x04000998 RID: 2456
		[Tooltip("Repeat every frame. Useful if the Bool variable is changing.")]
		public bool everyFrame;
	}
}
