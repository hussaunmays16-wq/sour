﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003DC RID: 988
	[Tooltip("Loads a PlayMaker Array List Proxy component using EasySave")]
	[ActionCategory("Easy Save 2")]
	public class ArrayListEasyLoadEncrypted : ArrayListActions
	{
		// Token: 0x060010B9 RID: 4281 RVA: 0x0005B4F8 File Offset: 0x000596F8
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.encryption = false;
			this.password = string.Empty;
			this.loadFile = "defaultES2File.txt";
			this.loadFromResources = false;
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x0005B560 File Offset: 0x00059760
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.LoadArrayList();
			}
			base.Finish();
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x0005B5A0 File Offset: 0x000597A0
		public void LoadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			string text = "false";
			if (this.encryption.Value)
			{
				text = "true";
			}
			string text2 = "&savelocation=file";
			if (this.loadFromResources.Value)
			{
				text2 = "&savelocation=resources";
			}
			List<string> list = ES2.LoadList<string>(string.Concat(new string[]
			{
				this.loadFile.Value,
				"?tag=",
				this.uniqueTag.Value,
				"&encrypt=",
				text,
				"&password=",
				this.password.Value,
				text2
			}));
			this.Log(string.Concat(new object[]
			{
				"Loaded from ",
				this.loadFile.Value,
				"?tag=",
				this.uniqueTag
			}));
			Debug.LogWarning("Persistent Data Path:" + Application.persistentDataPath);
			this.proxy.arrayList.Clear();
			foreach (string source in list)
			{
				this.proxy.arrayList.Add(PlayMakerUtils.ParseValueFromString(source));
			}
			base.Finish();
		}

		// Token: 0x040015B7 RID: 5559
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040015B8 RID: 5560
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x040015B9 RID: 5561
		[Tooltip("A unique tag for this Load. For example, the object's name if no other objects use the same name.  --- Disabled: Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		[ActionSection("Easy Save Set Up")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x040015BA RID: 5562
		[Tooltip("Activate Decryption")]
		public FsmBool encryption;

		// Token: 0x040015BB RID: 5563
		[Tooltip("the password of the saved item")]
		public FsmString password = string.Empty;

		// Token: 0x040015BC RID: 5564
		[Tooltip("The name of the file that contains our data.")]
		[RequiredField]
		public FsmString loadFile = "defaultES2File.txt";

		// Token: 0x040015BD RID: 5565
		[Tooltip("Whether the data we are loading is stored in the Resources folder. (data needs .bytes extension!!!)")]
		public FsmBool loadFromResources;
	}
}
