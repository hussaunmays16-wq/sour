﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003F2 RID: 1010
	public abstract class ArrayListActions : CollectionsActions
	{
		// Token: 0x0600110E RID: 4366 RVA: 0x0005E014 File Offset: 0x0005C214
		protected bool SetUpArrayListProxyPointer(GameObject aProxyGO, string nameReference)
		{
			if (aProxyGO == null)
			{
				return false;
			}
			this.proxy = base.GetArrayListProxyPointer(aProxyGO, nameReference, false);
			return this.proxy != null;
		}

		// Token: 0x0600110F RID: 4367 RVA: 0x0005E040 File Offset: 0x0005C240
		protected bool SetUpArrayListProxyPointer(PlayMakerArrayListProxy aProxy, string nameReference)
		{
			if (aProxy == null)
			{
				return false;
			}
			this.proxy = base.GetArrayListProxyPointer(aProxy.gameObject, nameReference, false);
			return this.proxy != null;
		}

		// Token: 0x06001110 RID: 4368 RVA: 0x0005E07C File Offset: 0x0005C27C
		public bool isProxyValid()
		{
			if (this.proxy == null)
			{
				this.LogError("ArrayList proxy is null");
				return false;
			}
			if (this.proxy.arrayList == null)
			{
				this.LogError("ArrayList undefined");
				return false;
			}
			return true;
		}

		// Token: 0x0400164B RID: 5707
		internal PlayMakerArrayListProxy proxy;
	}
}
