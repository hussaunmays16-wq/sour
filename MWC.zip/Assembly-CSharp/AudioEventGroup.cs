﻿using System;
using System.Collections.Generic;

// Token: 0x02000078 RID: 120
[Serializable]
public class AudioEventGroup
{
	// Token: 0x04000283 RID: 643
	public bool isExpanded = true;

	// Token: 0x04000284 RID: 644
	public bool useLayerFilter;

	// Token: 0x04000285 RID: 645
	public bool useTagFilter;

	// Token: 0x04000286 RID: 646
	public List<int> matchingLayers = new List<int>
	{
		0
	};

	// Token: 0x04000287 RID: 647
	public List<string> matchingTags = new List<string>
	{
		"Default"
	};

	// Token: 0x04000288 RID: 648
	public bool customSoundActive;

	// Token: 0x04000289 RID: 649
	public bool isCustomEvent;

	// Token: 0x0400028A RID: 650
	public string customEventName = string.Empty;

	// Token: 0x0400028B RID: 651
	public bool mechanimEventActive;

	// Token: 0x0400028C RID: 652
	public bool isMechanimStateCheckEvent;

	// Token: 0x0400028D RID: 653
	public string mechanimStateName = string.Empty;

	// Token: 0x0400028E RID: 654
	public bool mechEventPlayedForState;

	// Token: 0x0400028F RID: 655
	public List<AudioEvent> SoundEvents = new List<AudioEvent>();

	// Token: 0x04000290 RID: 656
	public EventSounds.PreviousSoundStopMode mouseDragStopMode;

	// Token: 0x04000291 RID: 657
	public float mouseDragFadeOutTime = 1f;

	// Token: 0x04000292 RID: 658
	public EventSounds.RetriggerLimMode retriggerLimitMode;

	// Token: 0x04000293 RID: 659
	public int limitPerXFrm;

	// Token: 0x04000294 RID: 660
	public float limitPerXSec;

	// Token: 0x04000295 RID: 661
	public int triggeredLastFrame = -100;

	// Token: 0x04000296 RID: 662
	public float triggeredLastTime = -100f;

	// Token: 0x04000297 RID: 663
	public float sliderValue;
}
