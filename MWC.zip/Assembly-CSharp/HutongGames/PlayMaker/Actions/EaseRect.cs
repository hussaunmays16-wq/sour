﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200013E RID: 318
	[Tooltip("Easing Animation - Rect.")]
	[ActionCategory("AnimateVariables")]
	public class EaseRect : EaseFsmAction
	{
		// Token: 0x060005F5 RID: 1525 RVA: 0x0002DC38 File Offset: 0x0002BE38
		public override void Reset()
		{
			base.Reset();
			this.rectVariable = null;
			this.fromValue = null;
			this.toValue = null;
			this.finishInNextStep = false;
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x0002DC68 File Offset: 0x0002BE68
		public override void OnEnter()
		{
			base.OnEnter();
			this.fromFloats = new float[4];
			this.fromFloats[0] = this.fromValue.Value.x;
			this.fromFloats[1] = this.fromValue.Value.y;
			this.fromFloats[2] = this.fromValue.Value.width;
			this.fromFloats[3] = this.fromValue.Value.height;
			this.toFloats = new float[4];
			this.toFloats[0] = this.toValue.Value.x;
			this.toFloats[1] = this.toValue.Value.y;
			this.toFloats[2] = this.toValue.Value.width;
			this.toFloats[3] = this.toValue.Value.height;
			this.resultFloats = new float[4];
			this.finishInNextStep = false;
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0002DD84 File Offset: 0x0002BF84
		public override void OnExit()
		{
			base.OnExit();
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x0002DD8C File Offset: 0x0002BF8C
		public override void OnUpdate()
		{
			base.OnUpdate();
			if (!this.rectVariable.IsNone && this.isRunning)
			{
				this.rectVariable.Value = new Rect(this.resultFloats[0], this.resultFloats[1], this.resultFloats[2], this.resultFloats[3]);
			}
			if (this.finishInNextStep)
			{
				base.Finish();
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
			if (this.finishAction && !this.finishInNextStep)
			{
				if (!this.rectVariable.IsNone)
				{
					this.rectVariable.Value = new Rect((!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.x : this.fromValue.Value.x) : this.toValue.Value.x, (!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.y : this.fromValue.Value.y) : this.toValue.Value.y, (!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.width : this.fromValue.Value.width) : this.toValue.Value.width, (!this.reverse.IsNone) ? ((!this.reverse.Value) ? this.toValue.Value.height : this.fromValue.Value.height) : this.toValue.Value.height);
				}
				this.finishInNextStep = true;
			}
		}

		// Token: 0x040008EE RID: 2286
		[RequiredField]
		public FsmRect fromValue;

		// Token: 0x040008EF RID: 2287
		[RequiredField]
		public FsmRect toValue;

		// Token: 0x040008F0 RID: 2288
		[UIHint(UIHint.Variable)]
		public FsmRect rectVariable;

		// Token: 0x040008F1 RID: 2289
		private bool finishInNextStep;
	}
}
