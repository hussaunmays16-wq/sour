﻿using System;

// Token: 0x0200007A RID: 122
[Serializable]
public class CustomEvent
{
	// Token: 0x060001BE RID: 446 RVA: 0x0000BED4 File Offset: 0x0000A0D4
	public CustomEvent(string eventName)
	{
		this.EventName = eventName;
		this.ProspectiveName = eventName;
	}

	// Token: 0x0400029E RID: 670
	public string EventName;

	// Token: 0x0400029F RID: 671
	public string ProspectiveName;

	// Token: 0x040002A0 RID: 672
	public bool eventExpanded = true;

	// Token: 0x040002A1 RID: 673
	public MasterAudio.CustomEventReceiveMode eventReceiveMode;

	// Token: 0x040002A2 RID: 674
	public float distanceThreshold = 1f;

	// Token: 0x040002A3 RID: 675
	public int frameLastFired = -1;
}
