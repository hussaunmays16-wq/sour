﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024C RID: 588
	[ActionCategory(ActionCategory.GameObject)]
	[Tooltip("Gets a Random Child of a Game Object.")]
	public class GetRandomChild : FsmStateAction
	{
		// Token: 0x06000A06 RID: 2566 RVA: 0x0003ED38 File Offset: 0x0003CF38
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x0003ED48 File Offset: 0x0003CF48
		public override void OnEnter()
		{
			this.DoGetRandomChild();
			base.Finish();
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x0003ED58 File Offset: 0x0003CF58
		private void DoGetRandomChild()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			int childCount = ownerDefaultTarget.transform.childCount;
			if (childCount == 0)
			{
				return;
			}
			this.storeResult.Value = ownerDefaultTarget.transform.GetChild(UnityEngine.Random.Range(0, childCount)).gameObject;
		}

		// Token: 0x04000DF8 RID: 3576
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DF9 RID: 3577
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmGameObject storeResult;
	}
}
