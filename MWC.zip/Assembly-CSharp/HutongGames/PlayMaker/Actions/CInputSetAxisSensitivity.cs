﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B8 RID: 1208
	[ActionCategory("cInput")]
	[Tooltip("Sets the sensitivity of an axis.")]
	public class CInputSetAxisSensitivity : FsmStateAction
	{
		// Token: 0x06001481 RID: 5249 RVA: 0x000892A8 File Offset: 0x000874A8
		public override void Reset()
		{
			this.axisName = null;
			this.axisSensitivity = null;
		}

		// Token: 0x06001482 RID: 5250 RVA: 0x000892B8 File Offset: 0x000874B8
		public override void OnEnter()
		{
			cInput.SetAxisSensitivity(this.axisName.Value, this.axisSensitivity.Value);
			base.Finish();
		}

		// Token: 0x04001CF0 RID: 7408
		[Tooltip("The name of the axis.")]
		public FsmString axisName;

		// Token: 0x04001CF1 RID: 7409
		[Tooltip("The name of the axis deadzone.")]
		public FsmFloat axisSensitivity;
	}
}
