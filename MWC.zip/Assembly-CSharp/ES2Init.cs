﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000C7 RID: 199
[ExecuteInEditMode]
public class ES2Init : MonoBehaviour
{
	// Token: 0x060003C3 RID: 963 RVA: 0x000189A0 File Offset: 0x00016BA0
	public void Awake()
	{
		ES2Init.Init();
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x000189A8 File Offset: 0x00016BA8
	public static void Init()
	{
		ES2TypeManager.types = new Dictionary<Type, ES2Type>();
		ES2TypeManager.types[typeof(Vector2)] = new ES2_Vector2();
		ES2TypeManager.types[typeof(Vector3)] = new ES2_Vector3();
		ES2TypeManager.types[typeof(Vector4)] = new ES2_Vector4();
		ES2TypeManager.types[typeof(Texture2D)] = new ES2_Texture2D();
		ES2TypeManager.types[typeof(Quaternion)] = new ES2_Quaternion();
		ES2TypeManager.types[typeof(Mesh)] = new ES2_Mesh();
		ES2TypeManager.types[typeof(Color)] = new ES2_Color();
		ES2TypeManager.types[typeof(Color32)] = new ES2_Color32();
		ES2TypeManager.types[typeof(Material)] = new ES2_Material();
		ES2TypeManager.types[typeof(Rect)] = new ES2_Rect();
		ES2TypeManager.types[typeof(Bounds)] = new ES2_Bounds();
		ES2TypeManager.types[typeof(Transform)] = new ES2_Transform();
		ES2TypeManager.types[typeof(BoxCollider)] = new ES2_BoxCollider();
		ES2TypeManager.types[typeof(CapsuleCollider)] = new ES2_CapsuleCollider();
		ES2TypeManager.types[typeof(SphereCollider)] = new ES2_SphereCollider();
		ES2TypeManager.types[typeof(MeshCollider)] = new ES2_MeshCollider();
		ES2TypeManager.types[typeof(bool)] = new ES2_bool();
		ES2TypeManager.types[typeof(byte)] = new ES2_byte();
		ES2TypeManager.types[typeof(char)] = new ES2_char();
		ES2TypeManager.types[typeof(decimal)] = new ES2_decimal();
		ES2TypeManager.types[typeof(double)] = new ES2_double();
		ES2TypeManager.types[typeof(float)] = new ES2_float();
		ES2TypeManager.types[typeof(int)] = new ES2_int();
		ES2TypeManager.types[typeof(long)] = new ES2_long();
		ES2TypeManager.types[typeof(short)] = new ES2_short();
		ES2TypeManager.types[typeof(string)] = new ES2_string();
		ES2TypeManager.types[typeof(uint)] = new ES2_uint();
		ES2TypeManager.types[typeof(ulong)] = new ES2_ulong();
		ES2TypeManager.types[typeof(ushort)] = new ES2_ushort();
		ES2TypeManager.types[typeof(Enum)] = new ES2_Enum();
		ES2TypeManager.types[typeof(Matrix4x4)] = new ES2_Matrix4x4();
		ES2TypeManager.types[typeof(BoneWeight)] = new ES2_BoneWeight();
		ES2TypeManager.types[typeof(SkinnedMeshRenderer)] = new ES2_SkinnedMeshRenderer();
		ES2TypeManager.types[typeof(sbyte)] = new ES2_sbyte();
		ES2TypeManager.types[typeof(Sprite)] = new ES2_Sprite();
	}
}
