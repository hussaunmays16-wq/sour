﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200023D RID: 573
	[Tooltip("Gets the Mass of a Game Object's Rigid Body.")]
	[ActionCategory(ActionCategory.Physics)]
	public class GetMass : ComponentAction<Rigidbody>
	{
		// Token: 0x060009CC RID: 2508 RVA: 0x0003E360 File Offset: 0x0003C560
		public override void Reset()
		{
			this.gameObject = null;
			this.storeResult = null;
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x0003E370 File Offset: 0x0003C570
		public override void OnEnter()
		{
			this.DoGetMass();
			base.Finish();
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x0003E380 File Offset: 0x0003C580
		private void DoGetMass()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (base.UpdateCache(ownerDefaultTarget))
			{
				this.storeResult.Value = base.rigidbody.mass;
			}
		}

		// Token: 0x04000DCB RID: 3531
		[CheckForComponent(typeof(Rigidbody))]
		[Tooltip("The GameObject that owns the Rigidbody")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000DCC RID: 3532
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("Store the mass in a float variable.")]
		public FsmFloat storeResult;
	}
}
