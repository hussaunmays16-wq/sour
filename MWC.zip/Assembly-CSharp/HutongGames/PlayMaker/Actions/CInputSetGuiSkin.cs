﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004B9 RID: 1209
	[ActionCategory("cInput")]
	[Tooltip("Sets the cGUI skin")]
	public class CInputSetGuiSkin : FsmStateAction
	{
		// Token: 0x06001484 RID: 5252 RVA: 0x000892E4 File Offset: 0x000874E4
		public override void OnEnter()
		{
			cGUI.cSkin = this.guiSkin;
			base.Finish();
		}

		// Token: 0x04001CF2 RID: 7410
		[RequiredField]
		[Tooltip("The gui to set for cGUI.")]
		public GUISkin guiSkin;
	}
}
