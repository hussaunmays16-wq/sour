﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003B4 RID: 948
	[Tooltip("Takes a PlayMaker ArrayList Proxy component snapshot, use action ArrayListRevertToSnapShot was used. A Snapshot is taken by default at the beginning for the prefill data")]
	[ActionCategory("ArrayMaker/ArrayList")]
	public class ArrayListTakeSnapShot : ArrayListActions
	{
		// Token: 0x06001009 RID: 4105 RVA: 0x00057F14 File Offset: 0x00056114
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x00057F24 File Offset: 0x00056124
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoArrayListTakeSnapShot();
			}
			base.Finish();
		}

		// Token: 0x0600100B RID: 4107 RVA: 0x00057F64 File Offset: 0x00056164
		public void DoArrayListTakeSnapShot()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this.proxy.TakeSnapShot();
		}

		// Token: 0x040014D5 RID: 5333
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014D6 RID: 5334
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;
	}
}
