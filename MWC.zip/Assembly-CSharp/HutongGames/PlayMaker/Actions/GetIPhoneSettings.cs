﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000235 RID: 565
	[Tooltip("Get various iPhone settings.")]
	[ActionCategory(ActionCategory.Device)]
	public class GetIPhoneSettings : FsmStateAction
	{
		// Token: 0x060009AF RID: 2479 RVA: 0x0003E07C File Offset: 0x0003C27C
		public override void Reset()
		{
			this.getScreenCanDarken = null;
			this.getUniqueIdentifier = null;
			this.getName = null;
			this.getModel = null;
			this.getSystemName = null;
			this.getGeneration = null;
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x0003E0B4 File Offset: 0x0003C2B4
		public override void OnEnter()
		{
			base.Finish();
		}

		// Token: 0x04000DB0 RID: 3504
		[Tooltip("Allows device to fall into 'sleep' state with screen being dim if no touches occurred. Default value is true.")]
		[UIHint(UIHint.Variable)]
		public FsmBool getScreenCanDarken;

		// Token: 0x04000DB1 RID: 3505
		[Tooltip("A unique device identifier string. It is guaranteed to be unique for every device (Read Only).")]
		[UIHint(UIHint.Variable)]
		public FsmString getUniqueIdentifier;

		// Token: 0x04000DB2 RID: 3506
		[Tooltip("The user defined name of the device (Read Only).")]
		[UIHint(UIHint.Variable)]
		public FsmString getName;

		// Token: 0x04000DB3 RID: 3507
		[UIHint(UIHint.Variable)]
		[Tooltip("The model of the device (Read Only).")]
		public FsmString getModel;

		// Token: 0x04000DB4 RID: 3508
		[UIHint(UIHint.Variable)]
		[Tooltip("The name of the operating system running on the device (Read Only).")]
		public FsmString getSystemName;

		// Token: 0x04000DB5 RID: 3509
		[Tooltip("The generation of the device (Read Only).")]
		[UIHint(UIHint.Variable)]
		public FsmString getGeneration;
	}
}
