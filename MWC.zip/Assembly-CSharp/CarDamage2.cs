﻿using System;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class CarDamage2 : MonoBehaviour
{
	// Token: 0x0600000D RID: 13 RVA: 0x0000228C File Offset: 0x0000048C
	public void Start()
	{
		if (this.optionalMeshList.Length > 0)
		{
			this.meshfilters = this.optionalMeshList;
		}
		else
		{
			this.meshfilters = base.GetComponentsInChildren<MeshFilter>();
		}
		this.sqrDemRange = this.demolutionRange * this.demolutionRange;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x000022D8 File Offset: 0x000004D8
	public void OnCollisionEnter(Collision collision)
	{
		Vector3 relativeVelocity = collision.relativeVelocity;
		relativeVelocity.y *= this.YforceDamp;
		Vector3 vector = base.transform.position - collision.contacts[0].point;
		float num = relativeVelocity.magnitude * Vector3.Dot(collision.contacts[0].normal, vector.normalized);
		this.OnMeshForce(collision.contacts[0].point, Mathf.Clamp01(num / this.maxCollisionStrength));
	}

	// Token: 0x0600000F RID: 15 RVA: 0x0000236C File Offset: 0x0000056C
	public void OnMeshForce(Vector4 originPosAndForce)
	{
		this.OnMeshForce(originPosAndForce, originPosAndForce.w);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002384 File Offset: 0x00000584
	public void OnMeshForce(Vector3 originPos, float force)
	{
		force = Mathf.Clamp01(force);
		for (int i = 0; i < this.meshfilters.Length; i++)
		{
			Vector3[] vertices = this.meshfilters[i].mesh.vertices;
			for (int j = 0; j < vertices.Length; j++)
			{
				Vector3 point = Vector3.Scale(vertices[j], base.transform.localScale);
				Vector3 vector = this.meshfilters[i].transform.position + this.meshfilters[i].transform.rotation * point;
				Vector3 from = vector - originPos;
				Vector3 to = base.transform.position - vector;
				to.y = 0f;
				if (from.sqrMagnitude < this.sqrDemRange)
				{
					float num = Mathf.Clamp01(from.sqrMagnitude / this.sqrDemRange);
					float d = force * (1f - num) * this.maxMoveDelta;
					Vector3 point2 = Vector3.Slerp(from, to, this.impactDirManipulator).normalized * d;
					vertices[j] += Quaternion.Inverse(base.transform.rotation) * point2;
				}
			}
			this.meshfilters[i].mesh.vertices = vertices;
			this.meshfilters[i].mesh.RecalculateBounds();
		}
	}

	// Token: 0x04000005 RID: 5
	public float maxMoveDelta = 1f;

	// Token: 0x04000006 RID: 6
	public float maxCollisionStrength = 50f;

	// Token: 0x04000007 RID: 7
	public float YforceDamp = 0.1f;

	// Token: 0x04000008 RID: 8
	public float demolutionRange = 0.5f;

	// Token: 0x04000009 RID: 9
	public float impactDirManipulator;

	// Token: 0x0400000A RID: 10
	public MeshFilter[] optionalMeshList;

	// Token: 0x0400000B RID: 11
	private MeshFilter[] meshfilters;

	// Token: 0x0400000C RID: 12
	private float sqrDemRange;
}
