﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200026E RID: 622
	[Tooltip("Sends Events based on the comparison of 2 Integers.")]
	[ActionCategory(ActionCategory.Logic)]
	public class IntCompare : FsmStateAction
	{
		// Token: 0x06000A9B RID: 2715 RVA: 0x0004057C File Offset: 0x0003E77C
		public override void Reset()
		{
			this.integer1 = 0;
			this.integer2 = 0;
			this.equal = null;
			this.lessThan = null;
			this.greaterThan = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A9C RID: 2716 RVA: 0x000405C0 File Offset: 0x0003E7C0
		public override void OnEnter()
		{
			this.DoIntCompare();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A9D RID: 2717 RVA: 0x000405DC File Offset: 0x0003E7DC
		public override void OnUpdate()
		{
			this.DoIntCompare();
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x000405E4 File Offset: 0x0003E7E4
		private void DoIntCompare()
		{
			if (this.integer1.Value == this.integer2.Value)
			{
				base.Fsm.Event(this.equal);
				return;
			}
			if (this.integer1.Value < this.integer2.Value)
			{
				base.Fsm.Event(this.lessThan);
				return;
			}
			if (this.integer1.Value > this.integer2.Value)
			{
				base.Fsm.Event(this.greaterThan);
			}
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x00040678 File Offset: 0x0003E878
		public override string ErrorCheck()
		{
			if (FsmEvent.IsNullOrEmpty(this.equal) && FsmEvent.IsNullOrEmpty(this.lessThan) && FsmEvent.IsNullOrEmpty(this.greaterThan))
			{
				return "Action sends no events!";
			}
			return string.Empty;
		}

		// Token: 0x04000E7F RID: 3711
		[RequiredField]
		public FsmInt integer1;

		// Token: 0x04000E80 RID: 3712
		[RequiredField]
		public FsmInt integer2;

		// Token: 0x04000E81 RID: 3713
		[Tooltip("Event sent if Int 1 equals Int 2")]
		public FsmEvent equal;

		// Token: 0x04000E82 RID: 3714
		[Tooltip("Event sent if Int 1 is less than Int 2")]
		public FsmEvent lessThan;

		// Token: 0x04000E83 RID: 3715
		[Tooltip("Event sent if Int 1 is greater than Int 2")]
		public FsmEvent greaterThan;

		// Token: 0x04000E84 RID: 3716
		public bool everyFrame;
	}
}
