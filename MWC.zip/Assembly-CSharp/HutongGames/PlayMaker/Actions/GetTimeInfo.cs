﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200025D RID: 605
	[Tooltip("Gets various useful Time measurements.")]
	[ActionCategory(ActionCategory.Time)]
	public class GetTimeInfo : FsmStateAction
	{
		// Token: 0x06000A52 RID: 2642 RVA: 0x0003F884 File Offset: 0x0003DA84
		public override void Reset()
		{
			this.getInfo = GetTimeInfo.TimeInfo.TimeSinceLevelLoad;
			this.storeValue = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x0003F89C File Offset: 0x0003DA9C
		public override void OnEnter()
		{
			this.DoGetTimeInfo();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x0003F8B8 File Offset: 0x0003DAB8
		public override void OnUpdate()
		{
			this.DoGetTimeInfo();
		}

		// Token: 0x06000A55 RID: 2645 RVA: 0x0003F8C0 File Offset: 0x0003DAC0
		private void DoGetTimeInfo()
		{
			switch (this.getInfo)
			{
			case GetTimeInfo.TimeInfo.DeltaTime:
				this.storeValue.Value = Time.deltaTime;
				break;
			case GetTimeInfo.TimeInfo.TimeScale:
				this.storeValue.Value = Time.timeScale;
				break;
			case GetTimeInfo.TimeInfo.SmoothDeltaTime:
				this.storeValue.Value = Time.smoothDeltaTime;
				break;
			case GetTimeInfo.TimeInfo.TimeInCurrentState:
				this.storeValue.Value = base.State.StateTime;
				break;
			case GetTimeInfo.TimeInfo.TimeSinceStartup:
				this.storeValue.Value = Time.time;
				break;
			case GetTimeInfo.TimeInfo.TimeSinceLevelLoad:
				this.storeValue.Value = Time.timeSinceLevelLoad;
				break;
			case GetTimeInfo.TimeInfo.RealTimeSinceStartup:
				this.storeValue.Value = FsmTime.RealtimeSinceStartup;
				break;
			case GetTimeInfo.TimeInfo.RealTimeInCurrentState:
				this.storeValue.Value = FsmTime.RealtimeSinceStartup - base.State.RealStartTime;
				break;
			default:
				this.storeValue.Value = 0f;
				break;
			}
		}

		// Token: 0x04000E36 RID: 3638
		public GetTimeInfo.TimeInfo getInfo;

		// Token: 0x04000E37 RID: 3639
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeValue;

		// Token: 0x04000E38 RID: 3640
		public bool everyFrame;

		// Token: 0x0200025E RID: 606
		public enum TimeInfo
		{
			// Token: 0x04000E3A RID: 3642
			DeltaTime,
			// Token: 0x04000E3B RID: 3643
			TimeScale,
			// Token: 0x04000E3C RID: 3644
			SmoothDeltaTime,
			// Token: 0x04000E3D RID: 3645
			TimeInCurrentState,
			// Token: 0x04000E3E RID: 3646
			TimeSinceStartup,
			// Token: 0x04000E3F RID: 3647
			TimeSinceLevelLoad,
			// Token: 0x04000E40 RID: 3648
			RealTimeSinceStartup,
			// Token: 0x04000E41 RID: 3649
			RealTimeInCurrentState
		}
	}
}
