﻿using System;
using UnityEngine;

// Token: 0x0200006B RID: 107
[AddComponentMenu("Dark Tonic/Master Audio/Event Calc Sounds")]
public class EventCalcSounds : MonoBehaviour
{
	// Token: 0x06000168 RID: 360 RVA: 0x0000910C File Offset: 0x0000730C
	private void Awake()
	{
		this._trans = base.transform;
		this._audio = base.GetComponent<AudioSource>();
		this.SpawnedOrAwake();
	}

	// Token: 0x06000169 RID: 361 RVA: 0x0000912C File Offset: 0x0000732C
	protected virtual void SpawnedOrAwake()
	{
	}

	// Token: 0x0600016A RID: 362 RVA: 0x00009130 File Offset: 0x00007330
	protected virtual void _AudioSourceEnded()
	{
		this.PlaySound(this.audioSourceEndedSound);
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00009140 File Offset: 0x00007340
	private void PlaySound(AudioEvent aEvent)
	{
		if (this.disableSounds)
		{
			return;
		}
		float volume = aEvent.volume;
		string soundType = aEvent.soundType;
		float? pitch = new float?(aEvent.pitch);
		if (!aEvent.useFixedPitch)
		{
			pitch = null;
		}
		PlaySoundResult playSoundResult = null;
		switch (this.soundSpawnMode)
		{
		case MasterAudio.SoundSpawnLocationMode.MasterAudioLocation:
			if (aEvent.emitParticles)
			{
				playSoundResult = MasterAudio.PlaySound(soundType, volume, null, 0f, null, false, false);
			}
			else
			{
				MasterAudio.PlaySoundAndForget(soundType, volume, null, 0f, null);
			}
			break;
		case MasterAudio.SoundSpawnLocationMode.CallerLocation:
			if (aEvent.emitParticles)
			{
				playSoundResult = MasterAudio.PlaySound3DAtTransform(soundType, this._trans, volume, pitch, 0f, null, false, false);
			}
			else
			{
				MasterAudio.PlaySound3DAtTransformAndForget(soundType, this._trans, volume, pitch, 0f, null);
			}
			break;
		case MasterAudio.SoundSpawnLocationMode.AttachToCaller:
			if (aEvent.emitParticles)
			{
				playSoundResult = MasterAudio.PlaySound3DFollowTransform(soundType, this._trans, volume, pitch, 0f, null, false, false);
			}
			else
			{
				MasterAudio.PlaySound3DFollowTransformAndForget(soundType, this._trans, volume, pitch, 0f, null);
			}
			break;
		}
		if (playSoundResult == null || !playSoundResult.SoundPlayed)
		{
			return;
		}
		MasterAudio.TriggerParticleEmission(this._trans, aEvent.particleCountToEmit);
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00009294 File Offset: 0x00007494
	private void Update()
	{
		this.CheckForEvents();
	}

	// Token: 0x0600016D RID: 365 RVA: 0x0000929C File Offset: 0x0000749C
	private void CheckForEvents()
	{
		if (!this.useAudioSourceEndedSound || this._audio == null || this._audio.clip == null)
		{
			return;
		}
		if (this._audio.clip.length - this._audio.time >= Time.deltaTime * 2f)
		{
			return;
		}
		this._audio.Stop();
		if (this._audio.loop)
		{
			this._audio.Play();
		}
		this._AudioSourceEnded();
	}

	// Token: 0x0400019A RID: 410
	public const int FramesEarlyToTrigger = 2;

	// Token: 0x0400019B RID: 411
	public MasterAudio.SoundSpawnLocationMode soundSpawnMode = MasterAudio.SoundSpawnLocationMode.CallerLocation;

	// Token: 0x0400019C RID: 412
	public bool disableSounds;

	// Token: 0x0400019D RID: 413
	public AudioEvent audioSourceEndedSound;

	// Token: 0x0400019E RID: 414
	public bool useAudioSourceEndedSound;

	// Token: 0x0400019F RID: 415
	private AudioSource _audio;

	// Token: 0x040001A0 RID: 416
	private Transform _trans;
}
