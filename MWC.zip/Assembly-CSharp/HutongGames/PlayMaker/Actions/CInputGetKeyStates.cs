﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AD RID: 1197
	[Tooltip("stores key states in fsm variables")]
	[ActionCategory("cInput")]
	public class CInputGetKeyStates : FsmStateAction
	{
		// Token: 0x06001463 RID: 5219 RVA: 0x00088F54 File Offset: 0x00087154
		public override void Reset()
		{
			this.keyName = null;
			this.storeKeyDown = null;
			this.storeKeyUp = null;
			this.storeKeyPressed = null;
			this.everyFrame = null;
		}

		// Token: 0x06001464 RID: 5220 RVA: 0x00088F7C File Offset: 0x0008717C
		public override void OnLateUpdate()
		{
			this.storeKeyDown.Value = cInput.GetKeyDown(this.keyName.Value);
			this.storeKeyUp.Value = cInput.GetKeyUp(this.keyName.Value);
			this.storeKeyPressed.Value = cInput.GetKey(this.keyName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CD5 RID: 7381
		[RequiredField]
		[Tooltip("The name of the key.")]
		public FsmString keyName;

		// Token: 0x04001CD6 RID: 7382
		[Tooltip("key gets down.")]
		public FsmBool storeKeyDown;

		// Token: 0x04001CD7 RID: 7383
		[Tooltip("Key gets up.")]
		public FsmBool storeKeyUp;

		// Token: 0x04001CD8 RID: 7384
		[Tooltip("Key is still pressed.")]
		public FsmBool storeKeyPressed;

		// Token: 0x04001CD9 RID: 7385
		[Tooltip("update every frame or finish.")]
		public FsmBool everyFrame;
	}
}
