﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000180 RID: 384
	[ActionCategory(ActionCategory.Device)]
	[Tooltip("Plays a full-screen movie on a handheld device. Please consult the Unity docs for Handheld.PlayFullScreenMovie for proper usage.")]
	public class DevicePlayFullScreenMovie : FsmStateAction
	{
		// Token: 0x0600070B RID: 1803 RVA: 0x00031B24 File Offset: 0x0002FD24
		public override void Reset()
		{
			this.RemindMeAtRuntime = true;
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x00031B30 File Offset: 0x0002FD30
		public override void OnEnter()
		{
			if (this.RemindMeAtRuntime)
			{
				Debug.LogWarning("Current platform is not iOS or Android, DevicePlayFullScreenMovie action only works for iOS and Android");
			}
		}

		// Token: 0x040009F6 RID: 2550
		[RequiredField]
		[Tooltip("Note that player will stream movie directly from the iPhone disc, therefore you have to provide movie as a separate files and not as an usual asset.\nYou will have to create a folder named StreamingAssets inside your Unity project (inside your Assets folder). Store your movies inside that folder. Unity will automatically copy contents of that folder into the iPhone application bundle.")]
		public FsmString moviePath;

		// Token: 0x040009F7 RID: 2551
		[RequiredField]
		[Tooltip("This action will initiate a transition that fades the screen from your current content to the designated background color of the player. When playback finishes, the player uses another fade effect to transition back to your content.")]
		public FsmColor fadeColor;

		// Token: 0x040009F8 RID: 2552
		[ActionSection("Current platform is not iOS or Android")]
		public bool RemindMeAtRuntime;
	}
}
