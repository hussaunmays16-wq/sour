﻿using System;
using UnityEngine;

// Token: 0x02000476 RID: 1142
[RequireComponent(typeof(Axles))]
public abstract class CarController : MonoBehaviour
{
	// Token: 0x0600132D RID: 4909
	protected abstract void GetInput(out float throttleInput, out float brakeInput, out float steerInput, out float handbrakeInput, out float clutchInput, out bool startEngineInput, out int targetGear);

	// Token: 0x0600132E RID: 4910 RVA: 0x0006DD2C File Offset: 0x0006BF2C
	private void Start()
	{
		this.body = base.GetComponent<Rigidbody>();
		this.cardynamics = base.GetComponent<CarDynamics>();
		this.drivetrain = base.GetComponent<Drivetrain>();
		this.axles = base.GetComponent<Axles>();
		this.allWheels = this.axles.allWheels;
		this.myTransform = base.transform;
	}

	// Token: 0x0600132F RID: 4911 RVA: 0x0006DD88 File Offset: 0x0006BF88
	private void Update()
	{
		int num;
		this.GetInput(out this.throttleInput, out this.brakeInput, out this.steerInput, out this.handbrakeInput, out this.clutchInput, out this.startEngineInput, out num);
		if (!this.drivetrain.changingGear && num != this.drivetrain.gear)
		{
			this.drivetrain.Shift(num);
		}
		if (this.drivetrain.automatic && this.drivetrain.autoReverse)
		{
			if (this.brakeInput > 0f && this.velo <= 0.5f)
			{
				this.reverse = true;
				if (this.drivetrain.gear != this.drivetrain.firstReverse)
				{
					this.drivetrain.Shift(this.drivetrain.firstReverse);
				}
			}
			if (this.throttleInput > 0f && this.velo <= 0.5f)
			{
				this.reverse = false;
				if (this.drivetrain.gear != this.drivetrain.first)
				{
					this.drivetrain.Shift(this.drivetrain.first);
				}
			}
			if (this.reverse)
			{
				float num2 = this.throttleInput;
				this.throttleInput = this.brakeInput;
				this.brakeInput = num2;
			}
		}
		else
		{
			this.reverse = false;
		}
		this.brakeKey = (this.brakeInput > 0f);
		this.accelKey = (this.throttleInput > 0f);
	}

	// Token: 0x06001330 RID: 4912 RVA: 0x0006DF18 File Offset: 0x0006C118
	private void FixedUpdate()
	{
		this.maxThrottle = 1f;
		this.oldSteering = this.steering;
		this.velo = this.cardynamics.velo;
		this.veloKmh = this.cardynamics.velo * 3.6f;
		bool flag = this.drivetrain.OnGround();
		float num = this.cardynamics.LateralSlipVeloRearWheels();
		num = ((Mathf.Abs(num) >= 0.1f) ? num : 0f);
		this.counterSteering = (Mathf.Sign(num) == Mathf.Sign(this.steering) && num != 0f && this.steering != 0f);
		if (this.smoothInput)
		{
			this.SmoothSteer();
			this.smoothThrottle();
			this.smoothBrakes();
		}
		else
		{
			this.steering = this.steerInput;
			this.brake = this.brakeInput;
			this.throttle = this.throttleInput;
			if (this.drivetrain.changingGear && this.drivetrain.automatic)
			{
				this.throttle = 0f;
			}
		}
		if (this.steerAssistance && this.drivetrain.ratio > 0f && this.veloKmh > this.SteerAssistanceMinVelocity && (!this.counterSteering || this.steerInput == 0f))
		{
			this.SteerAssistance();
		}
		else
		{
			this.steerTimer = 0f;
			this.maxSteer = 1f;
		}
		this.TCSTriggered = false;
		if (this.TCS && this.drivetrain.ratio > 0f && this.drivetrain.clutch.GetClutchPosition() >= 0.9f && flag && this.throttle > this.drivetrain.idlethrottle && this.veloKmh > this.TCSMinVelocity)
		{
			this.DoTCS();
		}
		this.ESPTriggered = false;
		if (this.ESP && this.drivetrain.ratio > 0f && flag && this.veloKmh > this.ESPMinVelocity)
		{
			this.DoESP();
		}
		this.ABSTriggered = false;
		if (this.ABS && this.brake > 0f && this.veloKmh > this.ABSMinVelocity && flag)
		{
			this.DoABS();
		}
		float max;
		if (this.drivetrain.gearRatios[this.drivetrain.gear] > 0f)
		{
			max = this.maxThrottle;
		}
		else
		{
			max = this.maxThrottleInReverse;
		}
		if (this.drivetrain.revLimiterTriggered)
		{
			this.throttle = 0f;
		}
		else if (this.drivetrain.revLimiterReleased)
		{
			this.throttle = this.throttleInput;
		}
		else
		{
			this.throttle = Mathf.Clamp(this.throttle, this.drivetrain.idlethrottle, max);
		}
		this.brake = Mathf.Clamp01(this.brake);
		this.steering = Mathf.Clamp(this.steering, -1f, 1f);
		this.deltaSteering = this.steering - this.oldSteering;
		foreach (Wheel wheel in this.allWheels)
		{
			if (!this.ABS || this.veloKmh <= this.ABSMinVelocity || this.brakeInput <= 0f)
			{
				wheel.brake = this.brake;
			}
			wheel.handbrake = this.handbrakeInput;
			wheel.steering = this.steering;
			wheel.deltaSteering = this.deltaSteering;
		}
		this.drivetrain.throttle = this.throttle;
		if (this.drivetrain.clutch != null && (this.clutchInput != 0f || !this.drivetrain.autoClutch))
		{
			this.drivetrain.clutch.SetClutchPosition(1f - this.clutchInput);
		}
		this.drivetrain.startEngine = this.startEngineInput;
	}

	// Token: 0x06001331 RID: 4913 RVA: 0x0006E36C File Offset: 0x0006C56C
	private void SteerAssistance()
	{
		float num = 0f;
		foreach (Wheel wheel in this.allWheels)
		{
			num += wheel.lateralSlip;
		}
		num /= (float)this.allWheels.Length;
		this.maxSteer = Mathf.Clamp(1f - Mathf.Abs(num), -1f, 1f);
		if (this.steerTimer <= 1f)
		{
			this.steerTimer += Time.deltaTime;
			this.maxSteer = 1f - this.steerTimer + this.steerTimer * this.maxSteer;
		}
		this.oldSteering = this.steering;
		float num2 = Mathf.Sign(num);
		if (this.maxSteer > 0f)
		{
			this.steering = Mathf.Clamp(this.steering, -this.maxSteer, this.maxSteer);
		}
		else
		{
			this.steering = Mathf.Clamp(this.steering, num2 * this.maxSteer / 2f, num2 * this.maxSteer / 2f);
		}
		this.steeringVelo = this.steering - this.oldSteering;
		float num3 = 40f * this.cardynamics.fixedTimeStepScalar;
		float num4 = this.steeringVelo * num3;
		float num5 = num4;
		this.steering -= num5 * Time.deltaTime;
	}

	// Token: 0x06001332 RID: 4914 RVA: 0x0006E4D8 File Offset: 0x0006C6D8
	private void SmoothSteer()
	{
		if (this.steerInput < this.steering)
		{
			float num = (this.steering <= 0f || this.steerInput != 0f) ? (1f / (this.steerTime + this.veloSteerTime * this.velo)) : (1f / (this.steerReleaseTime + this.veloSteerReleaseTime * this.velo));
			if (this.counterSteering)
			{
				num *= 1f + Mathf.Abs(Mathf.Abs(this.steering) - Mathf.Abs(this.steerInput)) * this.steerCorrectionFactor;
			}
			this.steering -= num * Time.deltaTime;
			if (this.steerInput > this.steering)
			{
				this.steering = this.steerInput;
			}
		}
		else if (this.steerInput > this.steering)
		{
			float num = (this.steering >= 0f || this.steerInput != 0f) ? (1f / (this.steerTime + this.veloSteerTime * this.velo)) : (1f / (this.steerReleaseTime + this.veloSteerReleaseTime * this.velo));
			if (this.counterSteering)
			{
				num *= 1f + Mathf.Abs(Mathf.Abs(this.steering) - Mathf.Abs(this.steerInput)) * this.steerCorrectionFactor;
			}
			this.steering += num * Time.deltaTime;
			if (this.steerInput < this.steering)
			{
				this.steering = this.steerInput;
			}
		}
	}

	// Token: 0x06001333 RID: 4915 RVA: 0x0006E690 File Offset: 0x0006C890
	private void smoothThrottle()
	{
		if (this.throttleInput > 0f && (!this.drivetrain.changingGear || !this.drivetrain.automatic))
		{
			if (this.throttleInput < this.throttle)
			{
				this.throttle -= Time.deltaTime / this.throttleReleaseTime;
				if (this.throttleInput > this.throttle)
				{
					this.throttle = this.throttleInput;
				}
			}
			else if (this.throttleInput > this.throttle)
			{
				this.throttle += Time.deltaTime / this.throttleTime;
				if (this.throttleInput < this.throttle)
				{
					this.throttle = this.throttleInput;
				}
			}
		}
		else
		{
			this.throttle -= Time.deltaTime / this.throttleReleaseTime;
		}
	}

	// Token: 0x06001334 RID: 4916 RVA: 0x0006E780 File Offset: 0x0006C980
	private void smoothBrakes()
	{
		if (this.brakeInput > 0f)
		{
			if (this.brakeInput < this.brake)
			{
				this.brake -= Time.deltaTime / this.brakesReleaseTime;
				if (this.brakeInput > this.brake)
				{
					this.brake = this.brakeInput;
				}
			}
			else if (this.brakeInput > this.brake)
			{
				this.brake += Time.deltaTime / this.brakesTime;
				if (this.brakeInput < this.brake)
				{
					this.brake = this.brakeInput;
				}
			}
		}
		else
		{
			this.brake -= Time.deltaTime / this.brakesReleaseTime;
		}
	}

	// Token: 0x06001335 RID: 4917 RVA: 0x0006E850 File Offset: 0x0006CA50
	private void DoABS()
	{
		foreach (Wheel wheel in this.allWheels)
		{
			float num = -wheel.longitudinalSlip * (1f - this.ABSAllowedSlip);
			if (num >= 1f)
			{
				wheel.brake = 0f;
				this.ABSTriggered = true;
			}
			else
			{
				wheel.brake = this.brake;
				this.ABSTriggered = false;
			}
		}
	}

	// Token: 0x06001336 RID: 4918 RVA: 0x0006E8C8 File Offset: 0x0006CAC8
	private void DoTCS()
	{
		float num = 0f;
		foreach (Wheel wheel in this.drivetrain.poweredWheels)
		{
			float num2 = Mathf.Max(wheel.longitudinalSlip, Mathf.Abs(wheel.lateralSlip) * 1.5f);
			if (num2 > num)
			{
				num = num2;
			}
		}
		this.TCSTriggered = false;
		float num3 = num * (1f - this.TCSAllowedSlip) + this.externalTCSThreshold;
		if (num3 >= 1f)
		{
			this.maxThrottle = Mathf.Clamp(2f - num3, 0f, 1f);
			if (this.maxThrottle > 0.9f)
			{
				this.maxThrottle = 1f;
			}
			else
			{
				this.TCSTriggered = true;
			}
		}
	}

	// Token: 0x06001337 RID: 4919 RVA: 0x0006E9A0 File Offset: 0x0006CBA0
	private void DoESP()
	{
		Vector3 forward = this.myTransform.forward;
		Vector3 vector = this.body.velocity;
		vector -= this.myTransform.up * Vector3.Dot(vector, this.myTransform.up);
		vector.Normalize();
		float num = 0f;
		if (this.velo > 1f)
		{
			num = -Mathf.Asin(Vector3.Dot(Vector3.Cross(forward, vector), this.myTransform.up));
		}
		this.ESPTriggered = false;
		if (num > 0.1f)
		{
			if (this.axles.frontAxle.leftWheel)
			{
				this.axles.frontAxle.leftWheel.brake = Mathf.Clamp01(this.axles.frontAxle.leftWheel.brake + Mathf.Abs(num) * this.ESPStrength);
			}
			this.maxThrottle = Mathf.Max(this.maxThrottle - num * this.ESPStrength, this.drivetrain.idlethrottle);
			this.ESPTriggered = true;
		}
		else if (num < -0.1f)
		{
			if (this.axles.frontAxle.rightWheel)
			{
				this.axles.frontAxle.rightWheel.brake = Mathf.Clamp01(this.axles.frontAxle.rightWheel.brake + Mathf.Abs(num) * this.ESPStrength);
			}
			this.maxThrottle = Mathf.Max(this.maxThrottle + num * this.ESPStrength, this.drivetrain.idlethrottle);
			this.ESPTriggered = true;
		}
	}

	// Token: 0x04001939 RID: 6457
	private bool counterSteering;

	// Token: 0x0400193A RID: 6458
	private float steerTimer;

	// Token: 0x0400193B RID: 6459
	private Wheel[] allWheels;

	// Token: 0x0400193C RID: 6460
	private Transform myTransform;

	// Token: 0x0400193D RID: 6461
	public float brake;

	// Token: 0x0400193E RID: 6462
	public float throttle;

	// Token: 0x0400193F RID: 6463
	public float steering;

	// Token: 0x04001940 RID: 6464
	private float oldSteering;

	// Token: 0x04001941 RID: 6465
	private float deltaSteering;

	// Token: 0x04001942 RID: 6466
	private float steeringVelo;

	// Token: 0x04001943 RID: 6467
	private float maxSteer = 1f;

	// Token: 0x04001944 RID: 6468
	private float maxThrottle = 1f;

	// Token: 0x04001945 RID: 6469
	[HideInInspector]
	public bool brakeKey;

	// Token: 0x04001946 RID: 6470
	[HideInInspector]
	public bool accelKey;

	// Token: 0x04001947 RID: 6471
	[HideInInspector]
	public float steerInput;

	// Token: 0x04001948 RID: 6472
	[HideInInspector]
	public float brakeInput;

	// Token: 0x04001949 RID: 6473
	[HideInInspector]
	public float throttleInput;

	// Token: 0x0400194A RID: 6474
	[HideInInspector]
	public float handbrakeInput;

	// Token: 0x0400194B RID: 6475
	[HideInInspector]
	public float clutchInput;

	// Token: 0x0400194C RID: 6476
	[HideInInspector]
	public bool startEngineInput;

	// Token: 0x0400194D RID: 6477
	private Rigidbody body;

	// Token: 0x0400194E RID: 6478
	protected Drivetrain drivetrain;

	// Token: 0x0400194F RID: 6479
	private CarDynamics cardynamics;

	// Token: 0x04001950 RID: 6480
	private Axles axles;

	// Token: 0x04001951 RID: 6481
	private float velo;

	// Token: 0x04001952 RID: 6482
	private float veloKmh;

	// Token: 0x04001953 RID: 6483
	public bool smoothInput = true;

	// Token: 0x04001954 RID: 6484
	public float throttleTime = 0.1f;

	// Token: 0x04001955 RID: 6485
	public float throttleReleaseTime = 0.1f;

	// Token: 0x04001956 RID: 6486
	public float maxThrottleInReverse = 1f;

	// Token: 0x04001957 RID: 6487
	public float brakesTime = 0.1f;

	// Token: 0x04001958 RID: 6488
	public float brakesReleaseTime = 0.1f;

	// Token: 0x04001959 RID: 6489
	public float steerTime = 0.1f;

	// Token: 0x0400195A RID: 6490
	public float steerReleaseTime = 0.1f;

	// Token: 0x0400195B RID: 6491
	public float veloSteerTime = 0.05f;

	// Token: 0x0400195C RID: 6492
	public float veloSteerReleaseTime = 0.05f;

	// Token: 0x0400195D RID: 6493
	public float steerCorrectionFactor;

	// Token: 0x0400195E RID: 6494
	public bool steerAssistance = true;

	// Token: 0x0400195F RID: 6495
	public float SteerAssistanceMinVelocity = 20f;

	// Token: 0x04001960 RID: 6496
	public bool TCS = true;

	// Token: 0x04001961 RID: 6497
	[HideInInspector]
	public bool TCSTriggered;

	// Token: 0x04001962 RID: 6498
	public float TCSAllowedSlip;

	// Token: 0x04001963 RID: 6499
	public float TCSMinVelocity = 20f;

	// Token: 0x04001964 RID: 6500
	[HideInInspector]
	public float externalTCSThreshold;

	// Token: 0x04001965 RID: 6501
	public bool ABS = true;

	// Token: 0x04001966 RID: 6502
	[HideInInspector]
	public bool ABSTriggered;

	// Token: 0x04001967 RID: 6503
	public float ABSAllowedSlip;

	// Token: 0x04001968 RID: 6504
	public float ABSMinVelocity = 20f;

	// Token: 0x04001969 RID: 6505
	public bool ESP = true;

	// Token: 0x0400196A RID: 6506
	[HideInInspector]
	public bool ESPTriggered;

	// Token: 0x0400196B RID: 6507
	public float ESPStrength = 2f;

	// Token: 0x0400196C RID: 6508
	public float ESPMinVelocity = 35f;

	// Token: 0x0400196D RID: 6509
	[HideInInspector]
	public bool reverse;
}
