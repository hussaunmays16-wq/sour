﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000251 RID: 593
	[ActionCategory(ActionCategory.Transform)]
	[Tooltip("Gets the Rotation of a Game Object and stores it in a Vector3 Variable or each Axis in a Float Variable")]
	public class GetRotation : FsmStateAction
	{
		// Token: 0x06000A1D RID: 2589 RVA: 0x0003F0FC File Offset: 0x0003D2FC
		public override void Reset()
		{
			this.gameObject = null;
			this.quaternion = null;
			this.vector = null;
			this.xAngle = null;
			this.yAngle = null;
			this.zAngle = null;
			this.space = Space.World;
			this.everyFrame = false;
		}

		// Token: 0x06000A1E RID: 2590 RVA: 0x0003F144 File Offset: 0x0003D344
		public override void OnEnter()
		{
			this.DoGetRotation();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0003F160 File Offset: 0x0003D360
		public override void OnUpdate()
		{
			this.DoGetRotation();
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0003F168 File Offset: 0x0003D368
		private void DoGetRotation()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (this.space == Space.World)
			{
				this.quaternion.Value = ownerDefaultTarget.transform.rotation;
				Vector3 eulerAngles = ownerDefaultTarget.transform.eulerAngles;
				this.vector.Value = eulerAngles;
				this.xAngle.Value = eulerAngles.x;
				this.yAngle.Value = eulerAngles.y;
				this.zAngle.Value = eulerAngles.z;
			}
			else
			{
				Vector3 localEulerAngles = ownerDefaultTarget.transform.localEulerAngles;
				this.quaternion.Value = Quaternion.Euler(localEulerAngles);
				this.vector.Value = localEulerAngles;
				this.xAngle.Value = localEulerAngles.x;
				this.yAngle.Value = localEulerAngles.y;
				this.zAngle.Value = localEulerAngles.z;
			}
		}

		// Token: 0x04000E0A RID: 3594
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000E0B RID: 3595
		[UIHint(UIHint.Variable)]
		public FsmQuaternion quaternion;

		// Token: 0x04000E0C RID: 3596
		[UIHint(UIHint.Variable)]
		[Title("Euler Angles")]
		public FsmVector3 vector;

		// Token: 0x04000E0D RID: 3597
		[UIHint(UIHint.Variable)]
		public FsmFloat xAngle;

		// Token: 0x04000E0E RID: 3598
		[UIHint(UIHint.Variable)]
		public FsmFloat yAngle;

		// Token: 0x04000E0F RID: 3599
		[UIHint(UIHint.Variable)]
		public FsmFloat zAngle;

		// Token: 0x04000E10 RID: 3600
		public Space space;

		// Token: 0x04000E11 RID: 3601
		public bool everyFrame;
	}
}
