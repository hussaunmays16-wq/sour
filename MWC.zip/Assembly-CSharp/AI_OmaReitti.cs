﻿using System;
using UnityEngine;

// Token: 0x020000D4 RID: 212
public class AI_OmaReitti : MonoBehaviour
{
	// Token: 0x06000402 RID: 1026 RVA: 0x0001A68C File Offset: 0x0001888C
	private void Start()
	{
		this.moottori = base.GetComponent<ArcadeCarNoPhysics>();
		if (this.moottori != null)
		{
			this.moottori.onAI = true;
		}
		this.viimeSijainti = base.transform.position;
		if (this.raceManager == null)
		{
			this.raceManager = UnityEngine.Object.FindObjectOfType<RaceManager>();
		}
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x0001A6F0 File Offset: 0x000188F0
	private void Update()
	{
		if (this.aiMaalissa)
		{
			if (this.moottori != null)
			{
				this.moottori.NollaaVauhti();
			}
			return;
		}
		if (this.raceManager != null && !this.raceManager.peliKaynnissa)
		{
			if (this.moottori != null)
			{
				this.moottori.NollaaVauhti();
			}
			return;
		}
		if (this.reittipisteet == null || this.reittipisteet.Length == 0)
		{
			return;
		}
		this.Aja();
		this.TarkistaJumiutuminen();
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x0001A788 File Offset: 0x00018988
	private void Aja()
	{
		Transform transform = this.reittipisteet[this.nykyinenIndex];
		if (transform == null)
		{
			return;
		}
		Vector3 position = transform.position;
		position.y = base.transform.position.y;
		Vector3 normalized = (position - base.transform.position).normalized;
		float num = Vector3.Distance(base.transform.position, position);
		this.matkaKohteeseen = num;
		float num2 = this.LaskeSuuntaKulma(base.transform.up, normalized, Vector3.up);
		float num3 = Mathf.Clamp(num2 / 45f, -1f, 1f);
		if (this.kaannaOhjaus)
		{
			num3 = -num3;
		}
		float num4 = 1f - Mathf.Abs(num3) * 0.5f;
		if (num4 < 0.2f)
		{
			num4 = 0.2f;
		}
		this.nykyinenOhjaus = num3;
		this.nykyinenKaasu = num4;
		if (this.moottori != null)
		{
			this.moottori.ulkoinenKaanto = num3 * this.kaantymisHerkkyys;
			this.moottori.ulkoinenKaasu = num4;
		}
		float num5 = transform.localScale.x / 2f;
		if (num5 < 0.5f)
		{
			num5 = 2f;
		}
		this.nykyinenOsumaSade = num5;
		if (num < num5)
		{
			this.nykyinenIndex++;
			if (this.nykyinenIndex >= this.reittipisteet.Length)
			{
				this.nykyinenIndex = 0;
				this.aiKierros++;
				if (this.raceManager != null && this.aiKierros > this.raceManager.kierroksiaYhteensa)
				{
					this.aiMaalissa = true;
				}
			}
		}
		this.menossaKohti = transform.name;
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x0001A95C File Offset: 0x00018B5C
	private void TarkistaJumiutuminen()
	{
		this.tarkistusAjastin += Time.deltaTime;
		if (this.tarkistusAjastin > 1f)
		{
			float num = Vector3.Distance(base.transform.position, this.viimeSijainti);
			if (num < this.minimiLiike)
			{
				this.jumiAjastin += 1f;
			}
			else
			{
				this.jumiAjastin = 0f;
			}
			this.viimeSijainti = base.transform.position;
			this.tarkistusAjastin = 0f;
		}
		if (this.jumiAjastin > this.respawnAika)
		{
			this.RespawnAuto();
		}
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x0001AA04 File Offset: 0x00018C04
	private void RespawnAuto()
	{
		int num = this.nykyinenIndex - 1;
		if (num < 0)
		{
			num = this.reittipisteet.Length - 1;
		}
		if (this.reittipisteet[num] != null)
		{
			Vector3 position = this.reittipisteet[num].position;
			position.y = base.transform.position.y;
			base.transform.position = position;
			base.transform.LookAt(this.reittipisteet[this.nykyinenIndex]);
			base.transform.Rotate(90f, 0f, 0f);
			if (this.moottori != null)
			{
				this.moottori.NollaaVauhti();
			}
		}
		this.jumiAjastin = 0f;
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x0001AACC File Offset: 0x00018CCC
	private void OnGUI()
	{
		GUIStyle guistyle = new GUIStyle(GUI.skin.box);
		guistyle.alignment = TextAnchor.UpperLeft;
		guistyle.fontSize = 12;
		guistyle.fontStyle = FontStyle.Bold;
		float num = 220f;
		float height = 160f;
		float num2 = 10f;
		Rect position = new Rect((float)Screen.width - num - num2, num2, num, height);
		GUI.Box(position, "AI DEBUGGER", guistyle);
		GUIStyle guistyle2 = new GUIStyle(GUI.skin.label);
		guistyle2.normal.textColor = Color.white;
		guistyle2.fontSize = 12;
		float num3 = 20f;
		float num4 = position.y + 25f;
		float left = position.x + 10f;
		GUI.Label(new Rect(left, num4, 200f, 20f), "Kohde: " + this.menossaKohti, guistyle2);
		num4 += num3;
		GUI.Label(new Rect(left, num4, 200f, 20f), string.Concat(new string[]
		{
			"Etäisyys: ",
			this.matkaKohteeseen.ToString("F1"),
			"m (Raja: ",
			this.nykyinenOsumaSade.ToString("F1"),
			"m)"
		}), guistyle2);
		num4 += num3;
		GUI.Label(new Rect(left, num4, 200f, 20f), "Kaasu: " + (this.nykyinenKaasu * 100f).ToString("F0") + "%", guistyle2);
		num4 += num3;
		GUI.Label(new Rect(left, num4, 200f, 20f), "Ohjaus: " + this.nykyinenOhjaus.ToString("F2"), guistyle2);
		num4 += num3 + 5f;
		if (this.jumiAjastin > 1f)
		{
			guistyle2.normal.textColor = Color.yellow;
		}
		if (this.jumiAjastin > 3f)
		{
			guistyle2.normal.textColor = Color.red;
		}
		GUI.Label(new Rect(left, num4, 200f, 20f), string.Concat(new string[]
		{
			"Jumi-ajastin: ",
			this.jumiAjastin.ToString("F1"),
			" / ",
			this.respawnAika.ToString("F1"),
			"s"
		}), guistyle2);
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x0001AD50 File Offset: 0x00018F50
	private void OnDrawGizmos()
	{
		if (this.reittipisteet == null || this.reittipisteet.Length < 2)
		{
			return;
		}
		Gizmos.color = Color.yellow;
		for (int i = 0; i < this.reittipisteet.Length; i++)
		{
			if (this.reittipisteet[i] != null)
			{
				Transform transform = this.reittipisteet[i];
				float num = transform.localScale.x / 2f;
				if (num < 0.1f)
				{
					num = 0.5f;
				}
				Gizmos.DrawWireSphere(transform.position, num);
				int num2 = (i + 1) % this.reittipisteet.Length;
				if (this.reittipisteet[num2] != null)
				{
					Gizmos.DrawLine(transform.position, this.reittipisteet[num2].position);
				}
			}
		}
		if (Application.isPlaying && this.reittipisteet.Length > 0 && this.reittipisteet[this.nykyinenIndex] != null)
		{
			Gizmos.color = Color.red;
			Vector3 position = this.reittipisteet[this.nykyinenIndex].position;
			position.y = base.transform.position.y;
			Gizmos.DrawLine(base.transform.position, position);
		}
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x0001AE9C File Offset: 0x0001909C
	private float LaskeSuuntaKulma(Vector3 eteenpain, Vector3 kohdeSuunta, Vector3 kiertoAkseli)
	{
		float num = Vector3.Angle(eteenpain, kohdeSuunta);
		Vector3 rhs = Vector3.Cross(eteenpain, kohdeSuunta);
		if (Vector3.Dot(kiertoAkseli, rhs) < 0f)
		{
			num = -num;
		}
		return num;
	}

	// Token: 0x040005BB RID: 1467
	[Header("Reittipisteet (Raahaa tähän)")]
	public Transform[] reittipisteet;

	// Token: 0x040005BC RID: 1468
	[Header("Ajoasetukset")]
	public float kaantymisHerkkyys = 1f;

	// Token: 0x040005BD RID: 1469
	public bool kaannaOhjaus;

	// Token: 0x040005BE RID: 1470
	[Header("Turvajärjestelmä")]
	public float respawnAika = 4f;

	// Token: 0x040005BF RID: 1471
	public float minimiLiike = 0.5f;

	// Token: 0x040005C0 RID: 1472
	[Header("Debug (Vain luku)")]
	public int nykyinenIndex;

	// Token: 0x040005C1 RID: 1473
	public string menossaKohti = string.Empty;

	// Token: 0x040005C2 RID: 1474
	[Header("Kytkökset")]
	public RaceManager raceManager;

	// Token: 0x040005C3 RID: 1475
	public int aiKierros = 1;

	// Token: 0x040005C4 RID: 1476
	public bool aiMaalissa;

	// Token: 0x040005C5 RID: 1477
	private ArcadeCarNoPhysics moottori;

	// Token: 0x040005C6 RID: 1478
	private float jumiAjastin;

	// Token: 0x040005C7 RID: 1479
	private Vector3 viimeSijainti;

	// Token: 0x040005C8 RID: 1480
	private float tarkistusAjastin;

	// Token: 0x040005C9 RID: 1481
	private float nykyinenOhjaus;

	// Token: 0x040005CA RID: 1482
	private float nykyinenKaasu;

	// Token: 0x040005CB RID: 1483
	private float matkaKohteeseen;

	// Token: 0x040005CC RID: 1484
	private float nykyinenOsumaSade;
}
