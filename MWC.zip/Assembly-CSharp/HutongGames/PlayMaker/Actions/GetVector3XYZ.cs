﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000263 RID: 611
	[ActionCategory(ActionCategory.Vector3)]
	[Tooltip("Get the XYZ channels of a Vector3 Variable and storew them in Float Variables.")]
	public class GetVector3XYZ : FsmStateAction
	{
		// Token: 0x06000A6A RID: 2666 RVA: 0x0003FDEC File Offset: 0x0003DFEC
		public override void Reset()
		{
			this.vector3Variable = null;
			this.storeX = null;
			this.storeY = null;
			this.storeZ = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A6B RID: 2667 RVA: 0x0003FE14 File Offset: 0x0003E014
		public override void OnEnter()
		{
			this.DoGetVector3XYZ();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A6C RID: 2668 RVA: 0x0003FE30 File Offset: 0x0003E030
		public override void OnUpdate()
		{
			this.DoGetVector3XYZ();
		}

		// Token: 0x06000A6D RID: 2669 RVA: 0x0003FE38 File Offset: 0x0003E038
		private void DoGetVector3XYZ()
		{
			if (this.vector3Variable == null)
			{
				return;
			}
			if (this.storeX != null)
			{
				this.storeX.Value = this.vector3Variable.Value.x;
			}
			if (this.storeY != null)
			{
				this.storeY.Value = this.vector3Variable.Value.y;
			}
			if (this.storeZ != null)
			{
				this.storeZ.Value = this.vector3Variable.Value.z;
			}
		}

		// Token: 0x04000E56 RID: 3670
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector3Variable;

		// Token: 0x04000E57 RID: 3671
		[UIHint(UIHint.Variable)]
		public FsmFloat storeX;

		// Token: 0x04000E58 RID: 3672
		[UIHint(UIHint.Variable)]
		public FsmFloat storeY;

		// Token: 0x04000E59 RID: 3673
		[UIHint(UIHint.Variable)]
		public FsmFloat storeZ;

		// Token: 0x04000E5A RID: 3674
		public bool everyFrame;
	}
}
