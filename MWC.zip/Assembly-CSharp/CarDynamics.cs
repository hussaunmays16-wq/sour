﻿using System;
using UnityEngine;

// Token: 0x0200047A RID: 1146
[RequireComponent(typeof(Axles))]
[RequireComponent(typeof(Rigidbody))]
public class CarDynamics : MonoBehaviour
{
	// Token: 0x06001343 RID: 4931 RVA: 0x000701AC File Offset: 0x0006E3AC
	private float RoundTo(float value, int precision)
	{
		int num = 1;
		for (int i = 1; i <= precision; i++)
		{
			num *= 10;
		}
		return Mathf.Round(value * (float)num) / (float)num;
	}

	// Token: 0x06001344 RID: 4932 RVA: 0x000701E0 File Offset: 0x0006E3E0
	public float GetCentrifugalAccel()
	{
		float num = 0f;
		if (this.axles != null)
		{
			foreach (Wheel wheel in this.axles.allWheels)
			{
				num += wheel.Fy;
			}
		}
		return num * this.invAllWheelsLength / base.GetComponent<Rigidbody>().mass;
	}

	// Token: 0x06001345 RID: 4933 RVA: 0x00070248 File Offset: 0x0006E448
	public void FixPhysX()
	{
		this.body.collisionDetectionMode = CollisionDetectionMode.Continuous;
		this.body.collisionDetectionMode = CollisionDetectionMode.Discrete;
		this.body.centerOfMass -= this.deltaCenterOfMass;
	}

	// Token: 0x06001346 RID: 4934 RVA: 0x0007028C File Offset: 0x0006E48C
	private void Awake()
	{
		this.body = base.GetComponent<Rigidbody>();
		this.originalCenterOfMass = this.body.centerOfMass;
		this.myTransform = base.transform;
		this.drivetrain = base.GetComponent<Drivetrain>();
		this.axisCarController = base.GetComponent<AxisCarController>();
		this.mouseCarcontroller = base.GetComponent<MouseCarController>();
		this.mobileCarController = base.GetComponent<MobileCarController>();
		this.brakeLights = base.GetComponent<BrakeLights>();
		this.dashBoard = this.myTransform.GetComponentInChildren<DashBoard>();
		this.steeringWheel = base.transform.GetComponentInChildren<SteeringWheel>();
		this.soundController = base.GetComponent<SoundController>();
		this.SetController(this.controller.ToString());
		this.axles = base.GetComponent<Axles>();
		this.invAllWheelsLength = 1f / (float)this.axles.allWheels.Length;
		this.fixedTimeStepScalar = 0.02f / Time.fixedDeltaTime;
		this.invFixedTimeStepScalar = 1f / this.fixedTimeStepScalar;
	}

	// Token: 0x06001347 RID: 4935 RVA: 0x0007038C File Offset: 0x0006E58C
	private void Start()
	{
		this.body.inertiaTensor *= this.inertiaFactor;
		this.axles.frontAxle.oldCamber = this.axles.frontAxle.camber;
		this.axles.rearAxle.oldCamber = this.axles.rearAxle.camber;
		foreach (Axle axle in this.axles.otherAxles)
		{
			axle.oldCamber = axle.camber;
		}
		this.SetCenterOfMass(null);
		this.SetWheelsParams();
		this.SetBrakes();
		this.SetTiresType();
		this.xlocalPosition_orig = this.xlocalPosition;
		this.ylocalPosition_orig = this.ylocalPosition;
		this.zlocalPosition_orig = this.zlocalPosition;
	}

	// Token: 0x06001348 RID: 4936 RVA: 0x0007046C File Offset: 0x0006E66C
	public Vector3 BoundingSize(Collider[] colliders)
	{
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		if (colliders.Length != 0)
		{
			foreach (Collider collider in colliders)
			{
				if (collider.gameObject.layer != LayerMask.NameToLayer("Wheel") && collider.transform.GetComponent<FuelTank>() == null)
				{
					num += collider.bounds.size.x;
					num2 += collider.bounds.size.y;
					num3 += collider.bounds.size.z;
				}
			}
		}
		return new Vector3(num, num2, num3);
	}

	// Token: 0x06001349 RID: 4937 RVA: 0x00070540 File Offset: 0x0006E740
	public void SetCenterOfMass(Vector3? COGPosition = null)
	{
		if (this.centerOfMass == null)
		{
			this.centerOfMassObject = new GameObject("COG");
			this.centerOfMassObject.transform.parent = base.transform;
			this.centerOfMass = this.centerOfMassObject.transform;
			if (COGPosition != null)
			{
				Rigidbody component = base.GetComponent<Rigidbody>();
				Vector3 value = COGPosition.Value;
				this.centerOfMass.localPosition = value;
				component.centerOfMass = value;
			}
			else
			{
				this.centerOfMass.localPosition = base.GetComponent<Rigidbody>().centerOfMass;
			}
		}
		else
		{
			if (COGPosition != null)
			{
				Rigidbody component2 = base.GetComponent<Rigidbody>();
				Vector3 value = COGPosition.Value;
				this.centerOfMass.localPosition = value;
				component2.centerOfMass = value;
			}
			else
			{
				base.GetComponent<Rigidbody>().centerOfMass = this.centerOfMass.localPosition;
			}
			this.deltaCenterOfMass = this.originalCenterOfMass - this.centerOfMass.localPosition;
		}
		this.xlocalPosition = this.centerOfMass.localPosition.x;
		this.ylocalPosition = this.centerOfMass.localPosition.y;
		this.zlocalPosition = this.centerOfMass.localPosition.z;
	}

	// Token: 0x0600134A RID: 4938 RVA: 0x00070690 File Offset: 0x0006E890
	public void SetBrakes()
	{
		this.frontRearBrakeBalance = Mathf.Clamp01(this.frontRearBrakeBalance);
		this.frontRearHandBrakeBalance = Mathf.Clamp01(this.frontRearHandBrakeBalance);
		foreach (Wheel wheel in this.axles.frontAxle.wheels)
		{
			wheel.brakeFrictionTorque = this.axles.frontAxle.brakeFrictionTorque * Mathf.Min(this.frontRearBrakeBalance, 0.5f) * 2f;
			wheel.handbrakeFrictionTorque = this.axles.frontAxle.handbrakeFrictionTorque * Mathf.Min(this.frontRearHandBrakeBalance, 0.5f) * 2f;
		}
		foreach (Wheel wheel2 in this.axles.rearAxle.wheels)
		{
			wheel2.brakeFrictionTorque = this.axles.rearAxle.brakeFrictionTorque * Mathf.Min(1f - this.frontRearBrakeBalance, 0.5f) * 2f;
			wheel2.handbrakeFrictionTorque = this.axles.rearAxle.handbrakeFrictionTorque * Mathf.Min(1f - this.frontRearHandBrakeBalance, 0.5f) * 2f;
		}
		foreach (Axle axle in this.axles.otherAxles)
		{
			foreach (Wheel wheel3 in axle.wheels)
			{
				wheel3.brakeFrictionTorque = axle.brakeFrictionTorque;
				wheel3.handbrakeFrictionTorque = axle.handbrakeFrictionTorque;
			}
		}
	}

	// Token: 0x0600134B RID: 4939 RVA: 0x0007084C File Offset: 0x0006EA4C
	public void SetWheelsParams()
	{
		foreach (Wheel wheel in this.axles.frontAxle.wheels)
		{
			if (wheel != null)
			{
				wheel.forwardGripFactor = this.axles.frontAxle.forwardGripFactor;
				wheel.sidewaysGripFactor = this.axles.frontAxle.sidewaysGripFactor;
				wheel.suspensionTravel = this.axles.frontAxle.suspensionTravel;
				wheel.suspensionRate = this.axles.frontAxle.suspensionRate;
				wheel.bumpRate = this.axles.frontAxle.bumpRate;
				wheel.reboundRate = this.axles.frontAxle.reboundRate;
				wheel.fastBumpFactor = this.axles.frontAxle.fastBumpFactor;
				wheel.fastReboundFactor = this.axles.frontAxle.fastReboundFactor;
				wheel.pressure = this.axles.frontAxle.tiresPressure;
				wheel.optimalPressure = this.axles.frontAxle.optimalTiresPressure;
				wheel.SetTireStiffness();
				wheel.maxSteeringAngle = this.axles.frontAxle.maxSteeringAngle;
				wheel.axleWheelsLength = this.axles.frontAxle.wheels.Length;
				wheel.axlesNumber = this.axles.otherAxles.Length + 2;
				wheel.caster = this.axles.frontAxle.caster;
				if (wheel.wheelPos == WheelPos.FRONT_RIGHT)
				{
					wheel.deltaCamber = -this.axles.frontAxle.deltaCamber;
					wheel.camber = -this.axles.frontAxle.camber;
				}
				else
				{
					wheel.deltaCamber = this.axles.frontAxle.deltaCamber;
					wheel.camber = this.axles.frontAxle.camber;
				}
			}
		}
		foreach (Wheel wheel2 in this.axles.rearAxle.wheels)
		{
			if (wheel2 != null)
			{
				wheel2.forwardGripFactor = this.axles.rearAxle.forwardGripFactor;
				wheel2.sidewaysGripFactor = this.axles.rearAxle.sidewaysGripFactor;
				wheel2.suspensionTravel = this.axles.rearAxle.suspensionTravel;
				wheel2.suspensionRate = this.axles.rearAxle.suspensionRate;
				wheel2.bumpRate = this.axles.rearAxle.bumpRate;
				wheel2.reboundRate = this.axles.rearAxle.reboundRate;
				wheel2.fastBumpFactor = this.axles.rearAxle.fastBumpFactor;
				wheel2.fastReboundFactor = this.axles.rearAxle.fastReboundFactor;
				wheel2.pressure = this.axles.rearAxle.tiresPressure;
				wheel2.optimalPressure = this.axles.rearAxle.optimalTiresPressure;
				wheel2.SetTireStiffness();
				wheel2.maxSteeringAngle = -this.axles.rearAxle.maxSteeringAngle;
				wheel2.axleWheelsLength = this.axles.rearAxle.wheels.Length;
				wheel2.axlesNumber = this.axles.otherAxles.Length + 2;
				wheel2.caster = this.axles.rearAxle.caster;
				if (wheel2.wheelPos == WheelPos.REAR_RIGHT)
				{
					wheel2.deltaCamber = -this.axles.rearAxle.deltaCamber;
					wheel2.camber = -this.axles.rearAxle.camber;
				}
				else
				{
					wheel2.deltaCamber = this.axles.rearAxle.deltaCamber;
					wheel2.camber = this.axles.rearAxle.camber;
				}
			}
		}
		foreach (Axle axle in this.axles.otherAxles)
		{
			foreach (Wheel wheel3 in axle.wheels)
			{
				if (wheel3 != null)
				{
					wheel3.forwardGripFactor = axle.forwardGripFactor;
					wheel3.sidewaysGripFactor = axle.sidewaysGripFactor;
					wheel3.suspensionTravel = axle.suspensionTravel;
					wheel3.suspensionRate = axle.suspensionRate;
					wheel3.bumpRate = axle.bumpRate;
					wheel3.reboundRate = axle.reboundRate;
					wheel3.fastBumpFactor = axle.fastBumpFactor;
					wheel3.fastReboundFactor = axle.fastReboundFactor;
					wheel3.pressure = axle.tiresPressure;
					wheel3.optimalPressure = axle.optimalTiresPressure;
					wheel3.SetTireStiffness();
					wheel3.maxSteeringAngle = axle.maxSteeringAngle;
					wheel3.axleWheelsLength = axle.wheels.Length;
					wheel3.axlesNumber = this.axles.otherAxles.Length + 2;
					wheel3.caster = axle.caster;
					if (wheel3 == axle.rightWheel)
					{
						wheel3.deltaCamber = -axle.deltaCamber;
						wheel3.camber = -axle.camber;
					}
					else
					{
						wheel3.deltaCamber = axle.deltaCamber;
						wheel3.camber = axle.camber;
					}
				}
			}
		}
	}

	// Token: 0x0600134C RID: 4940 RVA: 0x00070DA4 File Offset: 0x0006EFA4
	public void SetTiresType()
	{
		foreach (Wheel w in this.axles.frontAxle.wheels)
		{
			this.LoadTiresData(w, this.axles.frontAxle.tires.ToString());
		}
		if (!this.tiresFound)
		{
			Debug.LogWarning(string.Concat(new string[]
			{
				"UnityCar: Tires \"",
				this.axles.frontAxle.tires.ToString(),
				"\" not found. Using standard tires data on front axle (",
				this.myTransform.name,
				")"
			}));
		}
		else
		{
			Debug.Log(string.Concat(new string[]
			{
				"UnityCar: Tires \"",
				this.axles.frontAxle.tires.ToString(),
				"\" loaded on front axle (",
				this.myTransform.name,
				")"
			}));
		}
		foreach (Wheel w2 in this.axles.rearAxle.wheels)
		{
			this.LoadTiresData(w2, this.axles.rearAxle.tires.ToString());
		}
		if (!this.tiresFound)
		{
			Debug.LogWarning(string.Concat(new string[]
			{
				"UnityCar: Tires \"",
				this.axles.rearAxle.tires.ToString(),
				"\" not found. Using standard tires data on rear axle (",
				this.myTransform.name,
				")"
			}));
		}
		else
		{
			Debug.Log(string.Concat(new string[]
			{
				"UnityCar: Tires \"",
				this.axles.rearAxle.tires.ToString(),
				"\" loaded on rear axle (",
				this.myTransform.name,
				")"
			}));
		}
		int num = 1;
		foreach (Axle axle in this.axles.otherAxles)
		{
			foreach (Wheel w3 in axle.wheels)
			{
				this.LoadTiresData(w3, axle.tires.ToString());
			}
			if (!this.tiresFound)
			{
				Debug.LogWarning(string.Concat(new object[]
				{
					"UnityCar: Tires  \"",
					axle.tires.ToString(),
					"\" not found. Using standard tires data on other axle",
					num,
					" (",
					this.myTransform.name,
					")"
				}));
			}
			else
			{
				Debug.Log(string.Concat(new object[]
				{
					"UnityCar: Tires \"",
					axle.tires.ToString(),
					"\" loaded on other axle",
					num,
					" (",
					this.myTransform.name,
					")"
				}));
			}
			num++;
		}
	}

	// Token: 0x0600134D RID: 4941 RVA: 0x000710FC File Offset: 0x0006F2FC
	public void LoadTiresData(Wheel w, string tires)
	{
		this.tiresFound = true;
		if (tires == "competition_front")
		{
			Array.Copy(TireParameters.aCompetitionFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bCompetitionFront, w.b, w.b.Length);
			if (TireParameters.cCompetitionFront.Length != 0)
			{
				Array.Copy(TireParameters.cCompetitionFront, w.c, w.c.Length);
			}
		}
		else if (tires == "competition_rear")
		{
			Array.Copy(TireParameters.aCompetitionRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bCompetitionRear, w.b, w.b.Length);
			if (TireParameters.cCompetitionRear.Length != 0)
			{
				Array.Copy(TireParameters.cCompetitionRear, w.c, w.c.Length);
			}
		}
		else if (tires == "supersport_front")
		{
			Array.Copy(TireParameters.aSuperSportFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bSuperSportFront, w.b, w.b.Length);
			if (TireParameters.cSuperSportFront.Length != 0)
			{
				Array.Copy(TireParameters.cSuperSportFront, w.c, w.c.Length);
			}
		}
		else if (tires == "supersport_rear")
		{
			Array.Copy(TireParameters.aSuperSportRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bSuperSportRear, w.b, w.b.Length);
			if (TireParameters.cSuperSportRear.Length != 0)
			{
				Array.Copy(TireParameters.cSuperSportRear, w.c, w.c.Length);
			}
		}
		else if (tires == "sport_front")
		{
			Array.Copy(TireParameters.aSportFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bSportFront, w.b, w.b.Length);
			if (TireParameters.cSportFront.Length != 0)
			{
				Array.Copy(TireParameters.cSportFront, w.c, w.c.Length);
			}
		}
		else if (tires == "sport_rear")
		{
			Array.Copy(TireParameters.aSportRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bSportRear, w.b, w.b.Length);
			if (TireParameters.cSportRear.Length != 0)
			{
				Array.Copy(TireParameters.cSportRear, w.c, w.c.Length);
			}
		}
		else if (tires == "touring_front")
		{
			Array.Copy(TireParameters.aTouringFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bTouringFront, w.b, w.b.Length);
			if (TireParameters.cTouringFront.Length != 0)
			{
				Array.Copy(TireParameters.cTouringFront, w.c, w.c.Length);
			}
		}
		else if (tires == "touring_rear")
		{
			Array.Copy(TireParameters.aTouringRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bTouringRear, w.b, w.b.Length);
			if (TireParameters.cTouringRear.Length != 0)
			{
				Array.Copy(TireParameters.cTouringRear, w.c, w.c.Length);
			}
		}
		else if (tires == "offroad_front")
		{
			Array.Copy(TireParameters.aOffRoadFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bOffRoadFront, w.b, w.b.Length);
			if (TireParameters.cOffRoadFront.Length != 0)
			{
				Array.Copy(TireParameters.cOffRoadFront, w.c, w.c.Length);
			}
		}
		else if (tires == "offroad_rear")
		{
			Array.Copy(TireParameters.aOffRoadRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bOffRoadRear, w.b, w.b.Length);
			if (TireParameters.cOffRoadRear.Length != 0)
			{
				Array.Copy(TireParameters.cOffRoadRear, w.c, w.c.Length);
			}
		}
		else if (tires == "truck_front")
		{
			Array.Copy(TireParameters.aTruckFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bTruckFront, w.b, w.b.Length);
			if (TireParameters.cTruckFront.Length != 0)
			{
				Array.Copy(TireParameters.cTruckFront, w.c, w.c.Length);
			}
		}
		else if (tires == "truck_rear")
		{
			Array.Copy(TireParameters.aTruckRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bTruckRear, w.b, w.b.Length);
			if (TireParameters.cTruckRear.Length != 0)
			{
				Array.Copy(TireParameters.cTruckRear, w.c, w.c.Length);
			}
		}
		else if (tires == "winter_front")
		{
			Array.Copy(TireParameters.aTruckFront, w.a, w.a.Length);
			Array.Copy(TireParameters.bTruckFront, w.b, w.b.Length);
			if (TireParameters.cTruckFront.Length != 0)
			{
				Array.Copy(TireParameters.cTruckFront, w.c, w.c.Length);
			}
		}
		else if (tires == "winter_rear")
		{
			Array.Copy(TireParameters.aWinterRear, w.a, w.a.Length);
			Array.Copy(TireParameters.bWinterRear, w.b, w.b.Length);
			if (TireParameters.cWinterRear.Length != 0)
			{
				Array.Copy(TireParameters.cWinterRear, w.c, w.c.Length);
			}
		}
		else
		{
			this.tiresFound = false;
		}
		w.CalculateIdealSlipRatioIdealSlipAngle(20);
	}

	// Token: 0x0600134E RID: 4942 RVA: 0x000716E0 File Offset: 0x0006F8E0
	public void SetController(string strcontroller)
	{
		this.axisCarController = base.GetComponent<AxisCarController>();
		this.mouseCarcontroller = base.GetComponent<MouseCarController>();
		this.mobileCarController = base.GetComponent<MobileCarController>();
		if (strcontroller == CarDynamics.Controller.axis.ToString())
		{
			if (this.axisCarController == null)
			{
				this.axisCarController = base.transform.gameObject.AddComponent<AxisCarController>();
			}
			this.axisCarController.enabled = true;
			this.carController = this.axisCarController;
			if (this.drivetrain != null)
			{
				this.drivetrain.carController = this.axisCarController;
			}
			if (this.brakeLights != null)
			{
				this.brakeLights.carController = this.axisCarController;
			}
			if (this.dashBoard != null)
			{
				this.dashBoard.carController = this.axisCarController;
			}
			if (this.steeringWheel != null)
			{
				this.steeringWheel.carController = this.axisCarController;
			}
			if (this.soundController != null)
			{
				this.soundController.carController = this.axisCarController;
			}
			if (this.mouseCarcontroller != null)
			{
				this.mouseCarcontroller.enabled = false;
			}
			if (this.mobileCarController != null)
			{
				this.mobileCarController.enabled = false;
			}
			this.controller = CarDynamics.Controller.axis;
		}
		else if (strcontroller == CarDynamics.Controller.mouse.ToString())
		{
			if (this.mouseCarcontroller == null)
			{
				this.mouseCarcontroller = base.transform.gameObject.AddComponent<MouseCarController>();
			}
			this.mouseCarcontroller.enabled = true;
			this.mouseCarcontroller.smoothInput = false;
			this.carController = this.mouseCarcontroller;
			if (this.drivetrain != null)
			{
				this.drivetrain.carController = this.mouseCarcontroller;
			}
			if (this.brakeLights != null)
			{
				this.brakeLights.carController = this.mouseCarcontroller;
			}
			if (this.dashBoard != null)
			{
				this.dashBoard.carController = this.mouseCarcontroller;
			}
			if (this.steeringWheel != null)
			{
				this.steeringWheel.carController = this.mouseCarcontroller;
			}
			if (this.soundController != null)
			{
				this.soundController.carController = this.mouseCarcontroller;
			}
			if (this.axisCarController != null)
			{
				this.axisCarController.enabled = false;
			}
			if (this.mobileCarController != null)
			{
				this.mobileCarController.enabled = false;
			}
			this.controller = CarDynamics.Controller.mouse;
		}
		else if (strcontroller == CarDynamics.Controller.mobile.ToString())
		{
			if (this.mobileCarController == null)
			{
				this.mobileCarController = base.transform.gameObject.AddComponent<MobileCarController>();
			}
			this.mobileCarController.enabled = true;
			this.carController = this.mobileCarController;
			if (this.drivetrain != null)
			{
				this.drivetrain.carController = this.mobileCarController;
			}
			if (this.brakeLights != null)
			{
				this.brakeLights.carController = this.mobileCarController;
			}
			if (this.dashBoard != null)
			{
				this.dashBoard.carController = this.mobileCarController;
			}
			if (this.steeringWheel != null)
			{
				this.steeringWheel.carController = this.mobileCarController;
			}
			if (this.soundController != null)
			{
				this.soundController.carController = this.mobileCarController;
			}
			if (this.axisCarController != null)
			{
				this.axisCarController.enabled = false;
			}
			if (this.mouseCarcontroller != null)
			{
				this.mouseCarcontroller.enabled = false;
			}
			this.controller = CarDynamics.Controller.mobile;
		}
		else if (strcontroller == CarDynamics.Controller.external.ToString())
		{
			if (this.mouseCarcontroller != null)
			{
				this.mouseCarcontroller.throttle = (this.drivetrain.throttle = 0f);
				this.mouseCarcontroller.enabled = false;
			}
			if (this.axisCarController != null)
			{
				this.axisCarController.throttle = (this.drivetrain.throttle = 0f);
				this.axisCarController.enabled = false;
			}
			if (this.mobileCarController != null)
			{
				this.mobileCarController.throttle = (this.drivetrain.throttle = 0f);
				this.mobileCarController.enabled = false;
			}
			this.controller = CarDynamics.Controller.external;
		}
	}

	// Token: 0x0600134F RID: 4943 RVA: 0x00071BBC File Offset: 0x0006FDBC
	private void FixedUpdate()
	{
		this.body.centerOfMass = this.centerOfMass.localPosition;
		this.fixedTimeStepScalar = 0.02f / Time.fixedDeltaTime;
		this.invFixedTimeStepScalar = 1f / this.fixedTimeStepScalar;
		this.velo = Mathf.Abs(this.myTransform.InverseTransformDirection(this.body.velocity).z);
		if (Application.isEditor)
		{
			this.SetBrakes();
			this.SetController(this.controller.ToString());
			this.axles.frontAxle.deltaCamber = this.axles.frontAxle.camber - this.axles.frontAxle.oldCamber;
			if (this.axles.frontAxle.deltaCamber != 0f)
			{
				this.axles.frontAxle.oldCamber = this.axles.frontAxle.camber;
				this.SetWheelsParams();
			}
			this.axles.rearAxle.deltaCamber = this.axles.rearAxle.camber - this.axles.rearAxle.oldCamber;
			if (this.axles.frontAxle.deltaCamber != 0f)
			{
				this.axles.rearAxle.oldCamber = this.axles.rearAxle.camber;
				this.SetWheelsParams();
			}
			foreach (Axle axle in this.axles.otherAxles)
			{
				axle.deltaCamber = axle.camber - axle.oldCamber;
				if (axle.deltaCamber != 0f)
				{
					axle.oldCamber = axle.camber;
					this.SetWheelsParams();
				}
			}
		}
		if (this.axles.frontAxle.leftWheel != null && this.axles.frontAxle.rightWheel != null)
		{
			this.antiRollBarForce = (this.axles.frontAxle.leftWheel.compression - this.axles.frontAxle.rightWheel.compression) * this.axles.frontAxle.antiRollBarRate;
			this.axles.frontAxle.leftWheel.antiRollBarForce = this.antiRollBarForce;
			this.axles.frontAxle.rightWheel.antiRollBarForce = -this.antiRollBarForce;
		}
		if (this.axles.rearAxle.leftWheel != null && this.axles.rearAxle.rightWheel != null)
		{
			this.antiRollBarForce = (this.axles.rearAxle.leftWheel.compression - this.axles.rearAxle.rightWheel.compression) * this.axles.rearAxle.antiRollBarRate;
			this.axles.rearAxle.leftWheel.antiRollBarForce = this.antiRollBarForce;
			this.axles.rearAxle.rightWheel.antiRollBarForce = -this.antiRollBarForce;
		}
		foreach (Axle axle2 in this.axles.otherAxles)
		{
			if (axle2.leftWheel != null && axle2.rightWheel != null)
			{
				this.antiRollBarForce = (axle2.leftWheel.compression - axle2.rightWheel.compression) * axle2.antiRollBarRate;
				axle2.leftWheel.antiRollBarForce = this.antiRollBarForce;
				axle2.rightWheel.antiRollBarForce = -this.antiRollBarForce;
			}
		}
		this.normalForceF = (this.normalForceR = 0f);
		foreach (Wheel wheel in this.axles.frontAxle.wheels)
		{
			this.normalForceF += wheel.normalForce;
		}
		if (this.axles.frontAxle.wheels.Length != 0)
		{
			this.normalForceF /= (float)this.axles.frontAxle.wheels.Length;
		}
		foreach (Wheel wheel2 in this.axles.rearAxle.wheels)
		{
			this.normalForceR += wheel2.normalForce;
		}
		if (this.axles.rearAxle.wheels.Length != 0)
		{
			this.normalForceR /= (float)this.axles.rearAxle.wheels.Length;
		}
		if (this.normalForceF + this.normalForceR != 0f)
		{
			this.frontRearWeightRepartition = this.RoundTo(this.normalForceF / (this.normalForceF + this.normalForceR), 2);
		}
		float num = this.body.mass * -Physics.gravity.y * 0.25f;
		if (this.zlocalPosition > 0f)
		{
			this.frontnforce = num * (1f + this.zlocalPosition);
			this.backnforce = num * (1f - this.zlocalPosition);
		}
		else
		{
			this.frontnforce = num * (1f + this.zlocalPosition);
			this.backnforce = num * (1f - this.zlocalPosition);
		}
		if (this.normalForceR != 0f)
		{
			this.factor1 = this.normalForceF / this.normalForceR;
		}
		if (this.backnforce != 0f)
		{
			this.factor2 = this.frontnforce / this.backnforce;
		}
		this.factor3 = this.factor2 + 0.25f * (1f - this.factor2);
		if (this.factor1 < this.factor3)
		{
			this.deltaFactor = this.factor3 - this.factor1;
		}
		else
		{
			this.deltaFactor = this.factor1 - this.factor3;
		}
		this.factor = this.factor3 - this.deltaFactor;
		this.factor = Mathf.Clamp(this.factor, 0.25f, 1f);
		this.forceFeedback = 0f;
		if (this.enableForceFeedback)
		{
			float num2 = 0f;
			foreach (Wheel wheel3 in this.axles.allWheels)
			{
				if (wheel3.maxSteeringAngle != 0f)
				{
					this.forceFeedback += wheel3.Mz;
					num2 += 1f;
				}
			}
			this.forceFeedback /= num2;
		}
	}

	// Token: 0x06001350 RID: 4944 RVA: 0x000722AC File Offset: 0x000704AC
	public float LateralSlipVeloRearWheels()
	{
		float num = 0f;
		foreach (Wheel wheel in this.axles.rearAxle.wheels)
		{
			num += wheel.lateralSlipVelo;
		}
		return num / (float)this.axles.rearAxle.wheels.Length;
	}

	// Token: 0x06001351 RID: 4945 RVA: 0x00072308 File Offset: 0x00070508
	public float SlipVelo()
	{
		float num = 0f;
		foreach (Wheel wheel in this.axles.allWheels)
		{
			num += wheel.slipVelo;
		}
		return num * this.invAllWheelsLength;
	}

	// Token: 0x06001352 RID: 4946 RVA: 0x00072350 File Offset: 0x00070550
	public bool AllWheelsOnGround()
	{
		bool flag = false;
		foreach (Wheel wheel in this.axles.allWheels)
		{
			flag = wheel.onGroundDown;
			if (flag)
			{
				break;
			}
		}
		return flag;
	}

	// Token: 0x0400198D RID: 6541
	private float frontnforce;

	// Token: 0x0400198E RID: 6542
	private float backnforce;

	// Token: 0x0400198F RID: 6543
	private float factor1;

	// Token: 0x04001990 RID: 6544
	private float factor2;

	// Token: 0x04001991 RID: 6545
	private float factor3;

	// Token: 0x04001992 RID: 6546
	private float deltaFactor;

	// Token: 0x04001993 RID: 6547
	[HideInInspector]
	public float factor;

	// Token: 0x04001994 RID: 6548
	[HideInInspector]
	public float velo;

	// Token: 0x04001995 RID: 6549
	public CarDynamics.Controller controller;

	// Token: 0x04001996 RID: 6550
	[HideInInspector]
	public CarController carController;

	// Token: 0x04001997 RID: 6551
	private AxisCarController axisCarController;

	// Token: 0x04001998 RID: 6552
	private MouseCarController mouseCarcontroller;

	// Token: 0x04001999 RID: 6553
	private MobileCarController mobileCarController;

	// Token: 0x0400199A RID: 6554
	private Drivetrain drivetrain;

	// Token: 0x0400199B RID: 6555
	private BrakeLights brakeLights;

	// Token: 0x0400199C RID: 6556
	private DashBoard dashBoard;

	// Token: 0x0400199D RID: 6557
	private SteeringWheel steeringWheel;

	// Token: 0x0400199E RID: 6558
	private SoundController soundController;

	// Token: 0x0400199F RID: 6559
	private Axles axles;

	// Token: 0x040019A0 RID: 6560
	[HideInInspector]
	public float transitionDamperVelo = 0.3f;

	// Token: 0x040019A1 RID: 6561
	public Transform centerOfMass;

	// Token: 0x040019A2 RID: 6562
	private GameObject centerOfMassObject;

	// Token: 0x040019A3 RID: 6563
	private Vector3 deltaCenterOfMass;

	// Token: 0x040019A4 RID: 6564
	private Vector3 originalCenterOfMass;

	// Token: 0x040019A5 RID: 6565
	private Transform myTransform;

	// Token: 0x040019A6 RID: 6566
	public float dampAbsRoadVelo = 8f;

	// Token: 0x040019A7 RID: 6567
	public float inertiaFactor = 1f;

	// Token: 0x040019A8 RID: 6568
	public float frontRearWeightRepartition = 0.5f;

	// Token: 0x040019A9 RID: 6569
	public float frontRearBrakeBalance = 0.65f;

	// Token: 0x040019AA RID: 6570
	public float frontRearHandBrakeBalance;

	// Token: 0x040019AB RID: 6571
	public bool enableForceFeedback;

	// Token: 0x040019AC RID: 6572
	[HideInInspector]
	public float forceFeedback;

	// Token: 0x040019AD RID: 6573
	[HideInInspector]
	public bool tridimensionalTire;

	// Token: 0x040019AE RID: 6574
	[HideInInspector]
	public bool tirePressureEnabled = true;

	// Token: 0x040019AF RID: 6575
	[HideInInspector]
	public float airDensity = 1.2041f;

	// Token: 0x040019B0 RID: 6576
	public Skidmarks skidmarks;

	// Token: 0x040019B1 RID: 6577
	public MyPhysicMaterial[] physicMaterials = new MyPhysicMaterial[4];

	// Token: 0x040019B2 RID: 6578
	[HideInInspector]
	public float xlocalPosition;

	// Token: 0x040019B3 RID: 6579
	[HideInInspector]
	public float xlocalPosition_orig;

	// Token: 0x040019B4 RID: 6580
	[HideInInspector]
	public float zlocalPosition;

	// Token: 0x040019B5 RID: 6581
	[HideInInspector]
	public float zlocalPosition_orig;

	// Token: 0x040019B6 RID: 6582
	[HideInInspector]
	public float ylocalPosition;

	// Token: 0x040019B7 RID: 6583
	[HideInInspector]
	public float ylocalPosition_orig;

	// Token: 0x040019B8 RID: 6584
	private float normalForceR;

	// Token: 0x040019B9 RID: 6585
	private float normalForceF;

	// Token: 0x040019BA RID: 6586
	private float antiRollBarForce;

	// Token: 0x040019BB RID: 6587
	[HideInInspector]
	public float fixedTimeStepScalar;

	// Token: 0x040019BC RID: 6588
	[HideInInspector]
	public float invFixedTimeStepScalar;

	// Token: 0x040019BD RID: 6589
	private float invAllWheelsLength;

	// Token: 0x040019BE RID: 6590
	private Rigidbody body;

	// Token: 0x040019BF RID: 6591
	private bool tiresFound;

	// Token: 0x0200047B RID: 1147
	public enum Controller
	{
		// Token: 0x040019C1 RID: 6593
		axis,
		// Token: 0x040019C2 RID: 6594
		mouse,
		// Token: 0x040019C3 RID: 6595
		mobile,
		// Token: 0x040019C4 RID: 6596
		external
	}

	// Token: 0x0200047C RID: 1148
	public enum SurfaceType
	{
		// Token: 0x040019C6 RID: 6598
		track,
		// Token: 0x040019C7 RID: 6599
		grass,
		// Token: 0x040019C8 RID: 6600
		sand,
		// Token: 0x040019C9 RID: 6601
		offroad,
		// Token: 0x040019CA RID: 6602
		oil
	}

	// Token: 0x0200047D RID: 1149
	public enum Tires
	{
		// Token: 0x040019CC RID: 6604
		competition_front,
		// Token: 0x040019CD RID: 6605
		competition_rear,
		// Token: 0x040019CE RID: 6606
		supersport_front,
		// Token: 0x040019CF RID: 6607
		supersport_rear,
		// Token: 0x040019D0 RID: 6608
		sport_front,
		// Token: 0x040019D1 RID: 6609
		sport_rear,
		// Token: 0x040019D2 RID: 6610
		touring_front,
		// Token: 0x040019D3 RID: 6611
		touring_rear,
		// Token: 0x040019D4 RID: 6612
		offroad_front,
		// Token: 0x040019D5 RID: 6613
		offroad_rear,
		// Token: 0x040019D6 RID: 6614
		truck_front,
		// Token: 0x040019D7 RID: 6615
		truck_rear,
		// Token: 0x040019D8 RID: 6616
		winter_front,
		// Token: 0x040019D9 RID: 6617
		winter_rear
	}
}
