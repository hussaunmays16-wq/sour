﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000405 RID: 1029
	[Tooltip("Returns the maximum float from a list")]
	[ActionCategory(ActionCategory.Math)]
	public class GetFloatsMax : FsmStateAction
	{
		// Token: 0x0600115C RID: 4444 RVA: 0x0005FF8C File Offset: 0x0005E18C
		public override void Reset()
		{
			this.floats = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x0600115D RID: 4445 RVA: 0x0005FFA4 File Offset: 0x0005E1A4
		public override void OnEnter()
		{
			this.DoMaxFromFloats();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600115E RID: 4446 RVA: 0x0005FFC0 File Offset: 0x0005E1C0
		public override void OnUpdate()
		{
			this.DoMaxFromFloats();
		}

		// Token: 0x0600115F RID: 4447 RVA: 0x0005FFC8 File Offset: 0x0005E1C8
		private void DoMaxFromFloats()
		{
			float num = float.NegativeInfinity;
			foreach (FsmFloat fsmFloat in this.floats)
			{
				float value = fsmFloat.Value;
				if (fsmFloat.UseVariable && !fsmFloat.IsNone)
				{
					value = base.Fsm.Variables.GetFsmFloat(fsmFloat.Name).Value;
				}
				num = Mathf.Max(num, value);
			}
			this.storeResult.Value = num;
		}

		// Token: 0x040016D0 RID: 5840
		[Tooltip("The float variables.")]
		[RequiredField]
		public FsmFloat[] floats;

		// Token: 0x040016D1 RID: 5841
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat storeResult;

		// Token: 0x040016D2 RID: 5842
		public bool everyFrame;
	}
}
