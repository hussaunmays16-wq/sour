﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000213 RID: 531
	[Tooltip("Gets a world direction Vector from 2 Input Axis. Typically used for a third person controller with Relative To set to the camera.")]
	[ActionCategory(ActionCategory.Input)]
	public class GetAxisVector : FsmStateAction
	{
		// Token: 0x0600091A RID: 2330 RVA: 0x0003BD88 File Offset: 0x00039F88
		public override void Reset()
		{
			this.horizontalAxis = "Horizontal";
			this.verticalAxis = "Vertical";
			this.multiplier = 1f;
			this.mapToPlane = GetAxisVector.AxisPlane.XZ;
			this.storeVector = null;
			this.storeMagnitude = null;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x0003BDDC File Offset: 0x00039FDC
		public override void OnUpdate()
		{
			Vector3 a = default(Vector3);
			Vector3 a2 = default(Vector3);
			if (this.relativeTo.Value == null)
			{
				switch (this.mapToPlane)
				{
				case GetAxisVector.AxisPlane.XZ:
					a = Vector3.forward;
					a2 = Vector3.right;
					break;
				case GetAxisVector.AxisPlane.XY:
					a = Vector3.up;
					a2 = Vector3.right;
					break;
				case GetAxisVector.AxisPlane.YZ:
					a = Vector3.up;
					a2 = Vector3.forward;
					break;
				}
			}
			else
			{
				Transform transform = this.relativeTo.Value.transform;
				switch (this.mapToPlane)
				{
				case GetAxisVector.AxisPlane.XZ:
					a = transform.TransformDirection(Vector3.forward);
					a.y = 0f;
					a = a.normalized;
					a2 = new Vector3(a.z, 0f, -a.x);
					break;
				case GetAxisVector.AxisPlane.XY:
				case GetAxisVector.AxisPlane.YZ:
					a = Vector3.up;
					a.z = 0f;
					a = a.normalized;
					a2 = transform.TransformDirection(Vector3.right);
					break;
				}
			}
			float d = (!this.horizontalAxis.IsNone && !string.IsNullOrEmpty(this.horizontalAxis.Value)) ? Input.GetAxis(this.horizontalAxis.Value) : 0f;
			float d2 = (!this.verticalAxis.IsNone && !string.IsNullOrEmpty(this.verticalAxis.Value)) ? Input.GetAxis(this.verticalAxis.Value) : 0f;
			Vector3 vector = d * a2 + d2 * a;
			vector *= this.multiplier.Value;
			this.storeVector.Value = vector;
			if (!this.storeMagnitude.IsNone)
			{
				this.storeMagnitude.Value = vector.magnitude;
			}
		}

		// Token: 0x04000CE2 RID: 3298
		[Tooltip("The name of the horizontal input axis. See Unity Input Manager.")]
		public FsmString horizontalAxis;

		// Token: 0x04000CE3 RID: 3299
		[Tooltip("The name of the vertical input axis. See Unity Input Manager.")]
		public FsmString verticalAxis;

		// Token: 0x04000CE4 RID: 3300
		[Tooltip("Input axis are reported in the range -1 to 1, this multiplier lets you set a new range.")]
		public FsmFloat multiplier;

		// Token: 0x04000CE5 RID: 3301
		[RequiredField]
		[Tooltip("The world plane to map the 2d input onto.")]
		public GetAxisVector.AxisPlane mapToPlane;

		// Token: 0x04000CE6 RID: 3302
		[Tooltip("Make the result relative to a GameObject, typically the main camera.")]
		public FsmGameObject relativeTo;

		// Token: 0x04000CE7 RID: 3303
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the direction vector.")]
		public FsmVector3 storeVector;

		// Token: 0x04000CE8 RID: 3304
		[Tooltip("Store the length of the direction vector.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeMagnitude;

		// Token: 0x02000214 RID: 532
		public enum AxisPlane
		{
			// Token: 0x04000CEA RID: 3306
			XZ,
			// Token: 0x04000CEB RID: 3307
			XY,
			// Token: 0x04000CEC RID: 3308
			YZ
		}
	}
}
