﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000008 RID: 8
	[Tooltip("Adds a value to an fsm Integer Variable.")]
	[ActionCategory(ActionCategory.Math)]
	public class AddToFsmInt : FsmStateAction
	{
		// Token: 0x06000012 RID: 18 RVA: 0x00002508 File Offset: 0x00000708
		public override void Reset()
		{
			this.gameObject = null;
			this.add = null;
			this.fsmName = string.Empty;
			this.storeResult = null;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002530 File Offset: 0x00000730
		public override void OnEnter()
		{
			this.DoAddToFsmInt();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x0000254C File Offset: 0x0000074C
		public override void OnUpdate()
		{
			this.DoAddToFsmInt();
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002554 File Offset: 0x00000754
		private void DoAddToFsmInt()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmInt fsmInt = this.fsm.FsmVariables.GetFsmInt(this.variableName.Value);
			if (fsmInt == null)
			{
				return;
			}
			fsmInt.Value += this.add.Value;
			if (this.storeResult != null)
			{
				this.storeResult.Value = fsmInt.Value;
			}
		}

		// Token: 0x0400000D RID: 13
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400000E RID: 14
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x0400000F RID: 15
		[RequiredField]
		[UIHint(UIHint.FsmInt)]
		public FsmString variableName;

		// Token: 0x04000010 RID: 16
		[RequiredField]
		public FsmInt add;

		// Token: 0x04000011 RID: 17
		[UIHint(UIHint.Variable)]
		[Tooltip("Optional storage of the result")]
		public FsmInt storeResult;

		// Token: 0x04000012 RID: 18
		public bool everyFrame;

		// Token: 0x04000013 RID: 19
		private GameObject goLastFrame;

		// Token: 0x04000014 RID: 20
		private PlayMakerFSM fsm;
	}
}
