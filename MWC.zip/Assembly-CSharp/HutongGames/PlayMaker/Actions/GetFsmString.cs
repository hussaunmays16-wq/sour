﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200022F RID: 559
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Get the value of a String Variable from another FSM.")]
	public class GetFsmString : FsmStateAction
	{
		// Token: 0x0600098F RID: 2447 RVA: 0x0003D918 File Offset: 0x0003BB18
		public override void Reset()
		{
			this.gameObject = null;
			this.fsmName = string.Empty;
			this.storeValue = null;
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x0003D938 File Offset: 0x0003BB38
		public override void OnEnter()
		{
			this.DoGetFsmString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000991 RID: 2449 RVA: 0x0003D954 File Offset: 0x0003BB54
		public override void OnUpdate()
		{
			this.DoGetFsmString();
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x0003D95C File Offset: 0x0003BB5C
		private void DoGetFsmString()
		{
			if (this.storeValue == null)
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			if (ownerDefaultTarget != this.goLastFrame)
			{
				this.goLastFrame = ownerDefaultTarget;
				this.fsm = ActionHelpers.GetGameObjectFsm(ownerDefaultTarget, this.fsmName.Value);
			}
			if (this.fsm == null)
			{
				return;
			}
			FsmString fsmString = this.fsm.FsmVariables.GetFsmString(this.variableName.Value);
			if (fsmString == null)
			{
				return;
			}
			this.storeValue.Value = fsmString.Value;
		}

		// Token: 0x04000D84 RID: 3460
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000D85 RID: 3461
		[UIHint(UIHint.FsmName)]
		[Tooltip("Optional name of FSM on Game Object")]
		public FsmString fsmName;

		// Token: 0x04000D86 RID: 3462
		[UIHint(UIHint.FsmString)]
		[RequiredField]
		public FsmString variableName;

		// Token: 0x04000D87 RID: 3463
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeValue;

		// Token: 0x04000D88 RID: 3464
		public bool everyFrame;

		// Token: 0x04000D89 RID: 3465
		private GameObject goLastFrame;

		// Token: 0x04000D8A RID: 3466
		private PlayMakerFSM fsm;
	}
}
