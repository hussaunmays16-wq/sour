﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000217 RID: 535
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Sends an Event when a Button is released.")]
	public class GetButtonUp : FsmStateAction
	{
		// Token: 0x06000925 RID: 2341 RVA: 0x0003C0C0 File Offset: 0x0003A2C0
		public override void Reset()
		{
			this.buttonName = "Fire1";
			this.sendEvent = null;
			this.storeResult = null;
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x0003C0E0 File Offset: 0x0003A2E0
		public override void OnUpdate()
		{
			bool keyUp = cInput.GetKeyUp(this.buttonName.Value);
			if (keyUp)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeResult.Value = keyUp;
		}

		// Token: 0x04000CF3 RID: 3315
		[Tooltip("The name of the button. Set in the Unity Input Manager.")]
		[RequiredField]
		public FsmString buttonName;

		// Token: 0x04000CF4 RID: 3316
		[Tooltip("Event to send if the button is released.")]
		public FsmEvent sendEvent;

		// Token: 0x04000CF5 RID: 3317
		[UIHint(UIHint.Variable)]
		[Tooltip("Set to True if the button is released.")]
		public FsmBool storeResult;
	}
}
