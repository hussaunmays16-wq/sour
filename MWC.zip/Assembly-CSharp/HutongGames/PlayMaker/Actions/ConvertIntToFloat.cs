﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000169 RID: 361
	[Tooltip("Converts an Integer value to a Float value.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertIntToFloat : FsmStateAction
	{
		// Token: 0x060006B6 RID: 1718 RVA: 0x00030D9C File Offset: 0x0002EF9C
		public override void Reset()
		{
			this.intVariable = null;
			this.floatVariable = null;
			this.everyFrame = false;
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x00030DB4 File Offset: 0x0002EFB4
		public override void OnEnter()
		{
			this.DoConvertIntToFloat();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x00030DD0 File Offset: 0x0002EFD0
		public override void OnUpdate()
		{
			this.DoConvertIntToFloat();
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00030DD8 File Offset: 0x0002EFD8
		private void DoConvertIntToFloat()
		{
			this.floatVariable.Value = (float)this.intVariable.Value;
		}

		// Token: 0x040009B4 RID: 2484
		[UIHint(UIHint.Variable)]
		[Tooltip("The Integer variable to convert to a float.")]
		[RequiredField]
		public FsmInt intVariable;

		// Token: 0x040009B5 RID: 2485
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a Float variable.")]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x040009B6 RID: 2486
		[Tooltip("Repeat every frame. Useful if the Integer variable is changing.")]
		public bool everyFrame;
	}
}
