﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001DB RID: 475
	[ActionCategory(ActionCategory.String)]
	[Tooltip("Replaces each format item in a specified string with the text equivalent of variable's value. Stores the result in a string variable.")]
	public class FormatString : FsmStateAction
	{
		// Token: 0x06000858 RID: 2136 RVA: 0x00038FAC File Offset: 0x000371AC
		public override void Reset()
		{
			this.format = null;
			this.variables = null;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x00038FCC File Offset: 0x000371CC
		public override void OnEnter()
		{
			this.objectArray = new object[this.variables.Length];
			this.DoFormatString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x00039004 File Offset: 0x00037204
		public override void OnUpdate()
		{
			this.DoFormatString();
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x0003900C File Offset: 0x0003720C
		private void DoFormatString()
		{
			for (int i = 0; i < this.variables.Length; i++)
			{
				this.variables[i].UpdateValue();
				this.objectArray[i] = this.variables[i].GetValue();
			}
			try
			{
				this.storeResult.Value = string.Format(this.format.Value, this.objectArray);
			}
			catch (FormatException ex)
			{
				this.LogError(ex.Message);
				base.Finish();
			}
		}

		// Token: 0x04000BFE RID: 3070
		[Tooltip("E.g. Hello {0} and {1}\nWith 2 variables that replace {0} and {1}\nSee C# string.Format docs.")]
		[RequiredField]
		public FsmString format;

		// Token: 0x04000BFF RID: 3071
		[Tooltip("Variables to use for each formatting item.")]
		public FsmVar[] variables;

		// Token: 0x04000C00 RID: 3072
		[Tooltip("Store the formatted result in a string variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;

		// Token: 0x04000C01 RID: 3073
		[Tooltip("Repeat every frame. This is useful if the variables are changing.")]
		public bool everyFrame;

		// Token: 0x04000C02 RID: 3074
		private object[] objectArray;
	}
}
