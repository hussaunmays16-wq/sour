﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D5 RID: 981
	[ActionCategory("ArrayMaker/ArrayList")]
	[Tooltip("Returns the Gameobject within an arrayList which have the max float value in its FSM")]
	public class ArrayListGetGameobjectMaxFsmFloatIndex : ArrayListActions
	{
		// Token: 0x06001092 RID: 4242 RVA: 0x0005A144 File Offset: 0x00058344
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.maxGameObject = null;
			this.maxIndex = null;
			this.everyframe = true;
			this.fsmName = string.Empty;
			this.storeMaxValue = null;
		}

		// Token: 0x06001093 RID: 4243 RVA: 0x0005A18C File Offset: 0x0005838C
		public override void OnEnter()
		{
			if (!base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				base.Finish();
			}
			this.DoFindMaxGo();
			if (!this.everyframe)
			{
				base.Finish();
			}
		}

		// Token: 0x06001094 RID: 4244 RVA: 0x0005A1E0 File Offset: 0x000583E0
		public override void OnUpdate()
		{
			this.DoFindMaxGo();
		}

		// Token: 0x06001095 RID: 4245 RVA: 0x0005A1E8 File Offset: 0x000583E8
		private void DoFindMaxGo()
		{
			float num = 0f;
			if (this.storeMaxValue.IsNone)
			{
				return;
			}
			if (!base.isProxyValid())
			{
				return;
			}
			int num2 = 0;
			foreach (object obj in this.proxy.arrayList)
			{
				GameObject gameObject = (GameObject)obj;
				if (gameObject != null)
				{
					this.fsm = ActionHelpers.GetGameObjectFsm(gameObject, this.fsmName.Value);
					if (this.fsm == null)
					{
						break;
					}
					FsmFloat fsmFloat = this.fsm.FsmVariables.GetFsmFloat(this.variableName.Value);
					if (fsmFloat == null)
					{
						break;
					}
					if (fsmFloat.Value > num)
					{
						this.storeMaxValue.Value = fsmFloat.Value;
						num = fsmFloat.Value;
						this.maxGameObject.Value = gameObject;
						this.maxIndex.Value = num2;
					}
				}
				num2++;
			}
		}

		// Token: 0x04001578 RID: 5496
		[ActionSection("Set up")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001579 RID: 5497
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400157A RID: 5498
		[Tooltip("Optional name of FSM on Game Object")]
		[UIHint(UIHint.FsmName)]
		public FsmString fsmName;

		// Token: 0x0400157B RID: 5499
		[RequiredField]
		[UIHint(UIHint.FsmFloat)]
		public FsmString variableName;

		// Token: 0x0400157C RID: 5500
		public bool everyframe;

		// Token: 0x0400157D RID: 5501
		[UIHint(UIHint.Variable)]
		[ActionSection("Result")]
		public FsmFloat storeMaxValue;

		// Token: 0x0400157E RID: 5502
		[UIHint(UIHint.Variable)]
		public FsmGameObject maxGameObject;

		// Token: 0x0400157F RID: 5503
		[UIHint(UIHint.Variable)]
		public FsmInt maxIndex;

		// Token: 0x04001580 RID: 5504
		private GameObject goLastFrame;

		// Token: 0x04001581 RID: 5505
		private PlayMakerFSM fsm;
	}
}
