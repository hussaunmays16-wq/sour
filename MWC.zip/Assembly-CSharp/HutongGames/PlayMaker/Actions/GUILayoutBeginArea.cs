﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001E9 RID: 489
	[Tooltip("Begin a GUILayout block of GUI controls in a fixed screen area. NOTE: Block must end with a corresponding GUILayoutEndArea.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutBeginArea : FsmStateAction
	{
		// Token: 0x06000888 RID: 2184 RVA: 0x00039BBC File Offset: 0x00037DBC
		public override void Reset()
		{
			this.screenRect = null;
			this.left = 0f;
			this.top = 0f;
			this.width = 1f;
			this.height = 1f;
			this.normalized = true;
			this.style = string.Empty;
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00039C2C File Offset: 0x00037E2C
		public override void OnGUI()
		{
			this.rect = (this.screenRect.IsNone ? default(Rect) : this.screenRect.Value);
			if (!this.left.IsNone)
			{
				this.rect.x = this.left.Value;
			}
			if (!this.top.IsNone)
			{
				this.rect.y = this.top.Value;
			}
			if (!this.width.IsNone)
			{
				this.rect.width = this.width.Value;
			}
			if (!this.height.IsNone)
			{
				this.rect.height = this.height.Value;
			}
			if (this.normalized.Value)
			{
				this.rect.x = this.rect.x * (float)Screen.width;
				this.rect.width = this.rect.width * (float)Screen.width;
				this.rect.y = this.rect.y * (float)Screen.height;
				this.rect.height = this.rect.height * (float)Screen.height;
			}
			GUILayout.BeginArea(this.rect, GUIContent.none, this.style.Value);
		}

		// Token: 0x04000C3E RID: 3134
		[UIHint(UIHint.Variable)]
		public FsmRect screenRect;

		// Token: 0x04000C3F RID: 3135
		public FsmFloat left;

		// Token: 0x04000C40 RID: 3136
		public FsmFloat top;

		// Token: 0x04000C41 RID: 3137
		public FsmFloat width;

		// Token: 0x04000C42 RID: 3138
		public FsmFloat height;

		// Token: 0x04000C43 RID: 3139
		public FsmBool normalized;

		// Token: 0x04000C44 RID: 3140
		public FsmString style;

		// Token: 0x04000C45 RID: 3141
		private Rect rect;
	}
}
