﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000156 RID: 342
	[Tooltip("Fade from a fullscreen Color. NOTE: Uses OnGUI so requires a PlayMakerGUI component in the scene.")]
	[ActionCategory(ActionCategory.Camera)]
	public class CameraFadeIn : FsmStateAction
	{
		// Token: 0x06000653 RID: 1619 RVA: 0x0002F6F0 File Offset: 0x0002D8F0
		public override void Reset()
		{
			this.color = Color.black;
			this.time = 1f;
			this.finishEvent = null;
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x0002F71C File Offset: 0x0002D91C
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.currentTime = 0f;
			this.colorLerp = this.color.Value;
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x0002F748 File Offset: 0x0002D948
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.currentTime = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.currentTime += Time.deltaTime;
			}
			this.colorLerp = Color.Lerp(this.color.Value, Color.clear, this.currentTime / this.time.Value);
			if (this.currentTime > this.time.Value)
			{
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
				base.Finish();
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0002F7F0 File Offset: 0x0002D9F0
		public override void OnGUI()
		{
			Color color = GUI.color;
			GUI.color = this.colorLerp;
			GUI.DrawTexture(new Rect(0f, 0f, (float)Screen.width, (float)Screen.height), ActionHelpers.WhiteTexture);
			GUI.color = color;
		}

		// Token: 0x04000951 RID: 2385
		[RequiredField]
		[Tooltip("Color to fade from. E.g., Fade up from black.")]
		public FsmColor color;

		// Token: 0x04000952 RID: 2386
		[HasFloatSlider(0f, 10f)]
		[Tooltip("Fade in time in seconds.")]
		[RequiredField]
		public FsmFloat time;

		// Token: 0x04000953 RID: 2387
		[Tooltip("Event to send when finished.")]
		public FsmEvent finishEvent;

		// Token: 0x04000954 RID: 2388
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x04000955 RID: 2389
		private float startTime;

		// Token: 0x04000956 RID: 2390
		private float currentTime;

		// Token: 0x04000957 RID: 2391
		private Color colorLerp;
	}
}
