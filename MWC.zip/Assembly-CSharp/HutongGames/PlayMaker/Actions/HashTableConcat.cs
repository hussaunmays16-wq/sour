﻿using System;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003BD RID: 957
	[Tooltip("Concat joins two or more hashTable proxy components. if a target is specified, the method use the target store the concatenation, else the ")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableConcat : HashTableActions
	{
		// Token: 0x0600102E RID: 4142 RVA: 0x00058730 File Offset: 0x00056930
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.hashTableGameObjectTargets = null;
			this.referenceTargets = null;
			this.overwriteExistingKey = null;
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x00058758 File Offset: 0x00056958
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DoHashTableConcat(this.proxy.hashTable);
			}
			base.Finish();
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x000587A4 File Offset: 0x000569A4
		public void DoHashTableConcat(Hashtable source)
		{
			if (!base.isProxyValid())
			{
				return;
			}
			for (int i = 0; i < this.hashTableGameObjectTargets.Length; i++)
			{
				if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.hashTableGameObjectTargets[i]), this.referenceTargets[i].Value) && base.isProxyValid())
				{
					foreach (object key in this.proxy.hashTable.Keys)
					{
						if (source.ContainsKey(key))
						{
							if (this.overwriteExistingKey.Value)
							{
								source[key] = this.proxy.hashTable[key];
							}
						}
						else
						{
							source[key] = this.proxy.hashTable[key];
						}
					}
				}
			}
		}

		// Token: 0x040014FB RID: 5371
		[RequiredField]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[ActionSection("Storage")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040014FC RID: 5372
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component to store the concatenation ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x040014FD RID: 5373
		[ActionSection("HashTables to concatenate")]
		[CompoundArray("HashTables", "HashTable GameObject", "Reference")]
		[RequiredField]
		[Tooltip("The GameObject with the PlayMaker HashTable Proxy component to copy to")]
		[ObjectType(typeof(PlayMakerHashTableProxy))]
		public FsmOwnerDefault[] hashTableGameObjectTargets;

		// Token: 0x040014FE RID: 5374
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component to copy to ( necessary if several component coexists on the same GameObject")]
		public FsmString[] referenceTargets;

		// Token: 0x040014FF RID: 5375
		[Tooltip("Overwrite existing key with new values")]
		[UIHint(UIHint.FsmBool)]
		public FsmBool overwriteExistingKey;
	}
}
