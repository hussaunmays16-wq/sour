﻿using System;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D9 RID: 985
	[Tooltip("Loads a PlayMaker Array List Proxy component From MySQL Server via ES2.php file. See moodkie.com/easysave/WebSetup.php for how to set up MySQL.")]
	[ActionCategory("Easy Save 2")]
	public class ArrayListEasyDownload : ArrayListActions
	{
		// Token: 0x060010AB RID: 4267 RVA: 0x0005A988 File Offset: 0x00058B88
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.uniqueTag = new FsmString
			{
				UseVariable = true
			};
			this.localFile = string.Empty;
			this.saveFile = "defaultES2File.txt";
			this.urlToPHPFile = "http://www.mysite.com/ES2.php";
			this.web = null;
			this.errorMessage = string.Empty;
			this.errorCode = string.Empty;
		}

		// Token: 0x060010AC RID: 4268 RVA: 0x0005AA10 File Offset: 0x00058C10
		public override void OnEnter()
		{
			if (base.SetUpArrayListProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.DownloadArrayList();
			}
		}

		// Token: 0x060010AD RID: 4269 RVA: 0x0005AA4C File Offset: 0x00058C4C
		private void DownloadArrayList()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			this._tag = this.uniqueTag.Value;
			if (string.IsNullOrEmpty(this._tag))
			{
				this._tag = string.Concat(new string[]
				{
					base.Fsm.GameObjectName,
					"/",
					base.Fsm.Name,
					"/arraylist/",
					this.reference.Value
				});
			}
			this.web = new ES2Web(string.Concat(new object[]
			{
				this.urlToPHPFile,
				"?tag=",
				this._tag,
				"&webfilename=",
				this.saveFile.Value,
				"&webpassword=",
				this.password.Value,
				"&webusername=",
				this.username.Value
			}));
			base.Fsm.Owner.StartCoroutine(this.web.Download());
			this.Log(string.Concat(new string[]
			{
				"Downloading from ",
				this.urlToPHPFile.Value,
				"?tag=",
				this.uniqueTag.Value,
				"&webfilename=",
				this.saveFile.Value
			}));
		}

		// Token: 0x060010AE RID: 4270 RVA: 0x0005ABB4 File Offset: 0x00058DB4
		public override void OnUpdate()
		{
			if (this.web.isError)
			{
				this.errorMessage = this.web.error;
				this.errorCode = this.web.errorCode;
				base.Fsm.Event(this.isError);
				base.Finish();
			}
			else if (this.web.isDone)
			{
				base.Fsm.Event(this.isDownloaded);
				List<string> list = this.web.LoadList<string>(this._tag);
				if (this.localFile.Value != string.Empty)
				{
					this.web.SaveToFile(this.localFile.Value);
				}
				this.Log(string.Concat(new object[]
				{
					"Loaded from ",
					this.saveFile.Value,
					"?tag=",
					this.uniqueTag
				}));
				this.proxy.arrayList.Clear();
				foreach (string source in list)
				{
					this.proxy.arrayList.Add(PlayMakerUtils.ParseValueFromString(source));
				}
				base.Finish();
			}
		}

		// Token: 0x04001594 RID: 5524
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001595 RID: 5525
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component (necessary if several component coexists on the same GameObject)")]
		[UIHint(UIHint.FsmString)]
		public FsmString reference;

		// Token: 0x04001596 RID: 5526
		[Tooltip("A unique tag for this save. For example, the object's name if no other objects use the same name. Leave to none or empty, to use the GameObject Name + Fsm Name + array Reference as tag.")]
		public FsmString uniqueTag = string.Empty;

		// Token: 0x04001597 RID: 5527
		[RequiredField]
		[Tooltip("The name of the file that we'll create to store our data. Leave as default if unsure.")]
		public FsmString saveFile = "defaultES2File.txt";

		// Token: 0x04001598 RID: 5528
		[Tooltip("The name of the local file we want to create to store our data. Leave blank if you don't want to store data locally.")]
		public FsmString localFile = string.Empty;

		// Token: 0x04001599 RID: 5529
		[RequiredField]
		[Tooltip("The URL to our ES2.PHP file. See http://www.moodkie.com/easysave/WebSetup.php for more information on setting up ES2Web")]
		[ActionSection("Upload Set up")]
		public FsmString urlToPHPFile = "http://www.mysite.com/ES2.php";

		// Token: 0x0400159A RID: 5530
		[Tooltip("The username that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString username = "ES2";

		// Token: 0x0400159B RID: 5531
		[Tooltip("The password that you have specified in your ES2.php file.")]
		[RequiredField]
		public FsmString password = "65w84e4p994z3Oq";

		// Token: 0x0400159C RID: 5532
		[ActionSection("Result")]
		[Tooltip("The Event to send if Download succeeded.")]
		public FsmEvent isDownloaded;

		// Token: 0x0400159D RID: 5533
		[Tooltip("The event to send if Download failed.")]
		public FsmEvent isError;

		// Token: 0x0400159E RID: 5534
		[Tooltip("Where any errors thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorMessage = string.Empty;

		// Token: 0x0400159F RID: 5535
		[Tooltip("Where any error codes thrown will be stored. Set this to a variable, or leave it blank.")]
		public FsmString errorCode = string.Empty;

		// Token: 0x040015A0 RID: 5536
		private ES2Web web;

		// Token: 0x040015A1 RID: 5537
		private string _tag;
	}
}
