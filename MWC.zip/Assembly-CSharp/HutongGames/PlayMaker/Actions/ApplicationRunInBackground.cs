﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000143 RID: 323
	[Tooltip("Sets if the Application should play in the background. Useful for servers or testing network games on one machine.")]
	[ActionCategory(ActionCategory.Application)]
	public class ApplicationRunInBackground : FsmStateAction
	{
		// Token: 0x06000609 RID: 1545 RVA: 0x0002E4B4 File Offset: 0x0002C6B4
		public override void Reset()
		{
			this.runInBackground = true;
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0002E4C4 File Offset: 0x0002C6C4
		public override void OnEnter()
		{
			Application.runInBackground = this.runInBackground.Value;
			base.Finish();
		}

		// Token: 0x040008FD RID: 2301
		public FsmBool runInBackground;
	}
}
