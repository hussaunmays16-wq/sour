﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015B RID: 347
	[Tooltip("Samples a Color on a continuous Colors gradient.")]
	[ActionCategory(ActionCategory.Color)]
	public class ColorRamp : FsmStateAction
	{
		// Token: 0x06000674 RID: 1652 RVA: 0x00030170 File Offset: 0x0002E370
		public override void Reset()
		{
			this.colors = new FsmColor[3];
			this.sampleAt = 0f;
			this.storeColor = null;
			this.everyFrame = false;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x000301A8 File Offset: 0x0002E3A8
		public override void OnEnter()
		{
			this.DoColorRamp();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x000301C4 File Offset: 0x0002E3C4
		public override void OnUpdate()
		{
			this.DoColorRamp();
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x000301CC File Offset: 0x0002E3CC
		private void DoColorRamp()
		{
			if (this.colors == null)
			{
				return;
			}
			if (this.colors.Length == 0)
			{
				return;
			}
			if (this.sampleAt == null)
			{
				return;
			}
			if (this.storeColor == null)
			{
				return;
			}
			float num = Mathf.Clamp(this.sampleAt.Value, 0f, (float)(this.colors.Length - 1));
			Color value;
			if (num == 0f)
			{
				value = this.colors[0].Value;
			}
			else if (num == (float)this.colors.Length)
			{
				value = this.colors[this.colors.Length - 1].Value;
			}
			else
			{
				Color value2 = this.colors[Mathf.FloorToInt(num)].Value;
				Color value3 = this.colors[Mathf.CeilToInt(num)].Value;
				num -= Mathf.Floor(num);
				value = Color.Lerp(value2, value3, num);
			}
			this.storeColor.Value = value;
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x000302BC File Offset: 0x0002E4BC
		public override string ErrorCheck()
		{
			if (this.colors.Length < 2)
			{
				return "Define at least 2 colors to make a gradient.";
			}
			return null;
		}

		// Token: 0x04000970 RID: 2416
		[RequiredField]
		[Tooltip("Array of colors to defining the gradient.")]
		public FsmColor[] colors;

		// Token: 0x04000971 RID: 2417
		[Tooltip("Point on the gradient to sample. Should be between 0 and the number of colors in the gradient.")]
		[RequiredField]
		public FsmFloat sampleAt;

		// Token: 0x04000972 RID: 2418
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the sampled color in a Color variable.")]
		[RequiredField]
		public FsmColor storeColor;

		// Token: 0x04000973 RID: 2419
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
