﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FB RID: 507
	[Tooltip("A Horizontal Slider linked to a Float Variable.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutHorizontalSlider : GUILayoutAction
	{
		// Token: 0x060008BE RID: 2238 RVA: 0x0003A82C File Offset: 0x00038A2C
		public override void Reset()
		{
			base.Reset();
			this.floatVariable = null;
			this.leftValue = 0f;
			this.rightValue = 100f;
			this.changedEvent = null;
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x0003A870 File Offset: 0x00038A70
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			if (this.floatVariable != null)
			{
				this.floatVariable.Value = GUILayout.HorizontalSlider(this.floatVariable.Value, this.leftValue.Value, this.rightValue.Value, base.LayoutOptions);
			}
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C78 RID: 3192
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat floatVariable;

		// Token: 0x04000C79 RID: 3193
		[RequiredField]
		public FsmFloat leftValue;

		// Token: 0x04000C7A RID: 3194
		[RequiredField]
		public FsmFloat rightValue;

		// Token: 0x04000C7B RID: 3195
		public FsmEvent changedEvent;
	}
}
