﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FA RID: 506
	[Tooltip("GUILayout Label for a Float Variable.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutFloatLabel : GUILayoutAction
	{
		// Token: 0x060008BB RID: 2235 RVA: 0x0003A75C File Offset: 0x0003895C
		public override void Reset()
		{
			base.Reset();
			this.prefix = string.Empty;
			this.style = string.Empty;
			this.floatVariable = null;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x0003A78C File Offset: 0x0003898C
		public override void OnGUI()
		{
			if (string.IsNullOrEmpty(this.style.Value))
			{
				GUILayout.Label(new GUIContent(this.prefix.Value + this.floatVariable.Value), base.LayoutOptions);
			}
			else
			{
				GUILayout.Label(new GUIContent(this.prefix.Value + this.floatVariable.Value), this.style.Value, base.LayoutOptions);
			}
		}

		// Token: 0x04000C75 RID: 3189
		[Tooltip("Text to put before the float variable.")]
		public FsmString prefix;

		// Token: 0x04000C76 RID: 3190
		[Tooltip("Float variable to display.")]
		[UIHint(UIHint.Variable)]
		[RequiredField]
		public FsmFloat floatVariable;

		// Token: 0x04000C77 RID: 3191
		[Tooltip("Optional GUIStyle in the active GUISKin.")]
		public FsmString style;
	}
}
