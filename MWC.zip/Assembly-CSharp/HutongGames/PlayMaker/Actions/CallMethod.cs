﻿using System;
using System.Reflection;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000155 RID: 341
	[ActionCategory(ActionCategory.ScriptControl)]
	public class CallMethod : FsmStateAction
	{
		// Token: 0x0600064D RID: 1613 RVA: 0x0002F364 File Offset: 0x0002D564
		public override void OnEnter()
		{
			this.parametersArray = new object[this.parameters.Length];
			this.DoMethodCall();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x0002F39C File Offset: 0x0002D59C
		public override void OnUpdate()
		{
			this.DoMethodCall();
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x0002F3A4 File Offset: 0x0002D5A4
		private void DoMethodCall()
		{
			if (this.behaviour.Value == null)
			{
				base.Finish();
				return;
			}
			if (this.cachedBehaviour != this.behaviour.Value)
			{
				this.errorString = string.Empty;
				if (!this.DoCache())
				{
					Debug.LogError(this.errorString);
					base.Finish();
					return;
				}
			}
			object value;
			if (this.cachedParameterInfo.Length == 0)
			{
				value = this.cachedMethodInfo.Invoke(this.cachedBehaviour, null);
			}
			else
			{
				for (int i = 0; i < this.parameters.Length; i++)
				{
					FsmVar fsmVar = this.parameters[i];
					fsmVar.UpdateValue();
					this.parametersArray[i] = fsmVar.GetValue();
				}
				value = this.cachedMethodInfo.Invoke(this.cachedBehaviour, this.parametersArray);
			}
			this.storeResult.SetValue(value);
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x0002F494 File Offset: 0x0002D694
		private bool DoCache()
		{
			this.cachedBehaviour = (this.behaviour.Value as MonoBehaviour);
			if (this.cachedBehaviour == null)
			{
				this.errorString += "Behaviour is invalid!\n";
				base.Finish();
				return false;
			}
			this.cachedType = this.behaviour.Value.GetType();
			this.cachedMethodInfo = this.cachedType.GetMethod(this.methodName.Value);
			if (this.cachedMethodInfo == null)
			{
				this.errorString = this.errorString + "Method Name is invalid: " + this.methodName.Value + "\n";
				base.Finish();
				return false;
			}
			this.cachedParameterInfo = this.cachedMethodInfo.GetParameters();
			return true;
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x0002F564 File Offset: 0x0002D764
		public override string ErrorCheck()
		{
			this.errorString = string.Empty;
			this.DoCache();
			if (!string.IsNullOrEmpty(this.errorString))
			{
				return this.errorString;
			}
			if (this.parameters.Length != this.cachedParameterInfo.Length)
			{
				return string.Concat(new object[]
				{
					"Parameter count does not match method.\nMethod has ",
					this.cachedParameterInfo.Length,
					" parameters.\nYou specified ",
					this.parameters.Length,
					" paramaters."
				});
			}
			for (int i = 0; i < this.parameters.Length; i++)
			{
				FsmVar fsmVar = this.parameters[i];
				Type realType = fsmVar.RealType;
				Type parameterType = this.cachedParameterInfo[i].ParameterType;
				if (!object.ReferenceEquals(realType, parameterType))
				{
					return string.Concat(new object[]
					{
						"Parameters do not match method signature.\nParameter ",
						i + 1,
						" (",
						realType,
						") should be of type: ",
						parameterType
					});
				}
			}
			if (object.ReferenceEquals(this.cachedMethodInfo.ReturnType, typeof(void)))
			{
				if (!string.IsNullOrEmpty(this.storeResult.variableName))
				{
					return "Method does not have return.\nSpecify 'none' in Store Result.";
				}
			}
			else if (!object.ReferenceEquals(this.cachedMethodInfo.ReturnType, this.storeResult.RealType))
			{
				return "Store Result is of the wrong type.\nIt should be of type: " + this.cachedMethodInfo.ReturnType;
			}
			return string.Empty;
		}

		// Token: 0x04000946 RID: 2374
		[Tooltip("Store the component in an Object variable.\nNOTE: Set theObject variable's Object Type to get a component of that type. E.g., set Object Type to UnityEngine.AudioListener to get the AudioListener component on the camera.")]
		[ObjectType(typeof(MonoBehaviour))]
		public FsmObject behaviour;

		// Token: 0x04000947 RID: 2375
		[Tooltip("Name of the method to call on the component")]
		public FsmString methodName;

		// Token: 0x04000948 RID: 2376
		[Tooltip("Method paramters. NOTE: these must match the method's signature!")]
		public FsmVar[] parameters;

		// Token: 0x04000949 RID: 2377
		[Tooltip("Store the result of the method call.")]
		[UIHint(UIHint.Variable)]
		[ActionSection("Store Result")]
		public FsmVar storeResult;

		// Token: 0x0400094A RID: 2378
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;

		// Token: 0x0400094B RID: 2379
		private UnityEngine.Object cachedBehaviour;

		// Token: 0x0400094C RID: 2380
		private Type cachedType;

		// Token: 0x0400094D RID: 2381
		private MethodInfo cachedMethodInfo;

		// Token: 0x0400094E RID: 2382
		private ParameterInfo[] cachedParameterInfo;

		// Token: 0x0400094F RID: 2383
		private object[] parametersArray;

		// Token: 0x04000950 RID: 2384
		private string errorString;
	}
}
