﻿using System;
using UnityEngine;

// Token: 0x02000475 RID: 1141
public class CarCamerasController : MonoBehaviour
{
	// Token: 0x06001327 RID: 4903 RVA: 0x0006D398 File Offset: 0x0006B598
	private void Awake()
	{
		this.carCameras = base.GetComponent<CarCameras>();
	}

	// Token: 0x06001328 RID: 4904 RVA: 0x0006D3A8 File Offset: 0x0006B5A8
	private float FindMaxBoundingSize(Collider[] colliders)
	{
		this.sizex = 0f;
		this.sizey = 0f;
		this.sizez = 0f;
		if (colliders.Length != 0)
		{
			foreach (Collider collider in colliders)
			{
				if (collider.gameObject.layer != LayerMask.NameToLayer("Wheel") && collider.transform.GetComponent<FuelTank>() == null)
				{
					this.sizex += collider.bounds.size.x;
					this.sizey += collider.bounds.size.y;
					this.sizez += collider.bounds.size.z;
				}
			}
		}
		return Mathf.Max(new float[]
		{
			this.sizex + this.externalSizex,
			this.sizey + this.externalSizey,
			this.sizez + this.externalSizez
		});
	}

	// Token: 0x06001329 RID: 4905 RVA: 0x0006D4D4 File Offset: 0x0006B6D4
	public void SetCamera(int index, Transform target, bool newTarget)
	{
		this.i = index;
		if (newTarget)
		{
			this.carCameras.mtarget = target;
		}
		this.carCameras.dampFixedCamera = false;
		this.carCameras.mouseOrbitFixedCamera = false;
		this.carCameras.driverView = false;
		if (index == 0 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.SmoothLookAt;
			this.carCameras.target = target;
			this.carCameras.rotationDamping = 3f;
			this.carCameras.heightDamping = 100f;
			Collider[] componentsInChildren = target.gameObject.GetComponentsInChildren<Collider>();
			this.carCameras.distance = this.FindMaxBoundingSize(componentsInChildren) * 1.5f;
			if (this.carCameras.distance < 4f)
			{
				this.carCameras.distance = 4f;
			}
			this.carCameras.height = this.carCameras.distance / 2f;
			this.carCameras.pitchAngle = -this.carCameras.height / 1.5f;
			this.carCameras.yawAngle = 0f;
		}
		else if (index == 1 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.FixedTo;
			foreach (Transform transform in this.carCameras.mtarget.gameObject.GetComponentsInChildren<Transform>())
			{
				if (transform.gameObject.tag == "Fixed_Camera_Driver_View" || transform.gameObject.name == "Fixed_Camera_Driver_View")
				{
					this.carCameras.target = transform;
				}
			}
			this.carCameras.distance = 0f;
			this.carCameras.height = 0f;
			this.carCameras.pitchAngle = 0f;
			this.carCameras.yawAngle = 0f;
			this.carCameras.dampFixedCamera = true;
			this.carCameras.mouseOrbitFixedCamera = true;
			this.carCameras.x = 0f;
			this.carCameras.y = 0f;
			this.carCameras.driverView = true;
		}
		else if (index == 2 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.SmoothLookAt;
			this.carCameras.target = target;
			this.carCameras.rotationDamping = 3f;
			this.carCameras.heightDamping = 100f;
			Collider[] componentsInChildren3 = target.gameObject.GetComponentsInChildren<Collider>();
			this.carCameras.distance = this.FindMaxBoundingSize(componentsInChildren3);
			if (this.carCameras.distance < 4f)
			{
				this.carCameras.distance = 4f;
			}
			this.carCameras.distance *= 2f;
			this.carCameras.height = this.carCameras.distance / 2f;
			this.carCameras.pitchAngle = -this.carCameras.height / 2.5f;
			this.carCameras.yawAngle = 0f;
		}
		else if (index == 3 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.FixedTo;
			foreach (Transform transform2 in this.carCameras.mtarget.gameObject.GetComponentsInChildren<Transform>())
			{
				if (transform2.gameObject.tag == "Fixed_Camera_1" || transform2.gameObject.name == "Fixed_Camera_1")
				{
					this.carCameras.target = transform2;
				}
			}
			this.carCameras.distance = 0f;
			this.carCameras.height = 0f;
			this.carCameras.pitchAngle = 0f;
			this.carCameras.yawAngle = 0f;
		}
		else if (index == 4 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.FixedTo;
			foreach (Transform transform3 in this.carCameras.mtarget.gameObject.GetComponentsInChildren<Transform>())
			{
				if (transform3.gameObject.tag == "Fixed_Camera_2" || transform3.gameObject.name == "Fixed_Camera_2")
				{
					this.carCameras.target = transform3;
				}
			}
			this.carCameras.distance = 0f;
			this.carCameras.height = 0f;
			this.carCameras.pitchAngle = 0f;
			this.carCameras.yawAngle = 0f;
		}
		else if (index == 5 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.SmoothLookAt;
			this.carCameras.rotationDamping = 3f;
			this.carCameras.heightDamping = 50f;
			this.carCameras.target = target;
			Collider[] componentsInChildren6 = target.gameObject.GetComponentsInChildren<Collider>();
			this.carCameras.distance = this.FindMaxBoundingSize(componentsInChildren6);
			if (this.carCameras.distance < 4f)
			{
				this.carCameras.distance = 4f;
			}
			this.carCameras.height = this.carCameras.distance / 2f;
			this.carCameras.pitchAngle = -this.carCameras.height;
			this.carCameras.yawAngle = 90f;
		}
		else if (index == 6 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.MouseOrbit;
			this.carCameras.target = target;
			if (this.carCameras.distance < this.carCameras.distanceMin || this.carCameras.distance > this.carCameras.distanceMax)
			{
				this.carCameras.distance = 5f;
			}
			this.carCameras.x = this.carCameras.myTransform.eulerAngles.y;
			this.carCameras.y = this.carCameras.myTransform.eulerAngles.x;
		}
		else if (index == 7 && target != null)
		{
			this.carCameras.mycamera = CarCameras.Cameras.Map;
			this.carCameras.target = target;
			this.carCameras.distance = 0f;
			this.carCameras.height = 0f;
			this.carCameras.pitchAngle = 0f;
			this.carCameras.yawAngle = 0f;
		}
	}

	// Token: 0x0600132A RID: 4906 RVA: 0x0006DBC8 File Offset: 0x0006BDC8
	private void Start()
	{
		this.SetCamera(0, this.carCameras.mtarget, false);
	}

	// Token: 0x0600132B RID: 4907 RVA: 0x0006DBE0 File Offset: 0x0006BDE0
	private void Update()
	{
		if (this.carCameras.mycamera != CarCameras.Cameras.Map && Input.GetKeyDown(KeyCode.C))
		{
			this.i++;
			if (this.i == 7)
			{
				this.i = 0;
			}
			this.SetCamera(this.i, this.carCameras.mtarget, false);
		}
	}

	// Token: 0x04001931 RID: 6449
	private CarCameras carCameras;

	// Token: 0x04001932 RID: 6450
	private float sizex;

	// Token: 0x04001933 RID: 6451
	private float sizey;

	// Token: 0x04001934 RID: 6452
	private float sizez;

	// Token: 0x04001935 RID: 6453
	[HideInInspector]
	public float externalSizex;

	// Token: 0x04001936 RID: 6454
	[HideInInspector]
	public float externalSizey;

	// Token: 0x04001937 RID: 6455
	[HideInInspector]
	public float externalSizez;

	// Token: 0x04001938 RID: 6456
	private int i;
}
