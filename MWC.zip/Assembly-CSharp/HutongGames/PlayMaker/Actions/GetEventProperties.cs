﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000415 RID: 1045
	[Tooltip("Gets properties on the last event that caused a state change. Use Set Event Properties to define these values when sending events")]
	[ActionCategory(ActionCategory.StateMachine)]
	public class GetEventProperties : FsmStateAction
	{
		// Token: 0x060011A0 RID: 4512 RVA: 0x00061184 File Offset: 0x0005F384
		public override void Reset()
		{
			this.keys = new FsmString[1];
			this.datas = new FsmVar[1];
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x000611A0 File Offset: 0x0005F3A0
		public override void OnEnter()
		{
			try
			{
				if (SetEventProperties.properties == null)
				{
					throw new ArgumentException("no properties");
				}
				for (int i = 0; i < this.keys.Length; i++)
				{
					Debug.Log(this.keys[i].Value);
					if (SetEventProperties.properties.ContainsKey(this.keys[i].Value))
					{
						Debug.Log("found");
						PlayMakerUtils.ApplyValueToFsmVar(base.Fsm, this.datas[i], SetEventProperties.properties[this.keys[i].Value]);
					}
					else
					{
						Debug.Log("not found");
					}
				}
			}
			catch (Exception arg)
			{
				Debug.Log("no properties found " + arg);
			}
			base.Finish();
		}

		// Token: 0x04001727 RID: 5927
		[CompoundArray("Event Properties", "Key", "Data")]
		public FsmString[] keys;

		// Token: 0x04001728 RID: 5928
		[UIHint(UIHint.Variable)]
		public FsmVar[] datas;
	}
}
