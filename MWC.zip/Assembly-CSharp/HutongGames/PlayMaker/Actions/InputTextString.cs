﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200001D RID: 29
	[ActionCategory("♥ Caligula ♥")]
	[Tooltip("Saves pressed keys to a string variable")]
	public class InputTextString : FsmStateAction
	{
		// Token: 0x06000061 RID: 97 RVA: 0x00004500 File Offset: 0x00002700
		public override void Reset()
		{
			this.laskuri = 0;
			this.isPressed = false;
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00004510 File Offset: 0x00002710
		private void addLetter(string s, bool b)
		{
			if (this.laskuri < this.max.Value)
			{
				if (b)
				{
					s = s.ToUpper();
					FsmString fsmString = this.variable;
					fsmString.Value += s;
				}
				else
				{
					FsmString fsmString2 = this.variable;
					fsmString2.Value += s;
				}
			}
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00004574 File Offset: 0x00002774
		public override void OnUpdate()
		{
			if (Input.GetKeyDown(KeyCode.Backspace) && this.variable.Value.Length > 0)
			{
				int length = this.variable.Value.Length;
				this.variable.Value = this.variable.Value.Remove(length - 1);
				this.laskuri--;
			}
			if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
			{
				this.isPressed = true;
			}
			else if (Input.GetKeyUp(KeyCode.LeftShift) || Input.GetKeyUp(KeyCode.RightShift))
			{
				this.isPressed = false;
			}
			if (Input.GetKeyDown(KeyCode.Q))
			{
				this.addLetter("q", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.W))
			{
				this.addLetter("w", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.E))
			{
				this.addLetter("e", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.R))
			{
				this.addLetter("r", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.T))
			{
				this.addLetter("t", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.Y))
			{
				this.addLetter("y", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.U))
			{
				this.addLetter("u", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.I))
			{
				this.addLetter("i", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.O))
			{
				this.addLetter("o", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.P))
			{
				this.addLetter("p", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.A))
			{
				this.addLetter("a", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.S))
			{
				this.addLetter("s", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.D))
			{
				this.addLetter("d", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.F))
			{
				this.addLetter("f", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.G))
			{
				this.addLetter("g", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.H))
			{
				this.addLetter("h", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.J))
			{
				this.addLetter("j", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.K))
			{
				this.addLetter("k", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.L))
			{
				this.addLetter("l", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.Z))
			{
				this.addLetter("z", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.X))
			{
				this.addLetter("x", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.C))
			{
				this.addLetter("c", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.V))
			{
				this.addLetter("v", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.B))
			{
				this.addLetter("b", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.N))
			{
				this.addLetter("n", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.M))
			{
				this.addLetter("m", this.isPressed);
			}
			if (Input.GetKeyDown(KeyCode.Keypad0) || Input.GetKeyDown(KeyCode.Alpha0))
			{
				this.addLetter("0", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad1) || Input.GetKeyDown(KeyCode.Alpha1))
			{
				this.addLetter("1", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad2) || Input.GetKeyDown(KeyCode.Alpha2))
			{
				this.addLetter("2", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad3) || Input.GetKeyDown(KeyCode.Alpha3))
			{
				this.addLetter("3", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad4) || Input.GetKeyDown(KeyCode.Alpha4))
			{
				this.addLetter("4", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad5) || Input.GetKeyDown(KeyCode.Alpha5))
			{
				this.addLetter("5", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad6) || Input.GetKeyDown(KeyCode.Alpha6))
			{
				this.addLetter("6", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad7) || Input.GetKeyDown(KeyCode.Alpha7))
			{
				this.addLetter("7", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad8) || Input.GetKeyDown(KeyCode.Alpha8))
			{
				this.addLetter("8", false);
			}
			if (Input.GetKeyDown(KeyCode.Keypad9) || Input.GetKeyDown(KeyCode.Alpha9))
			{
				this.addLetter("9", false);
			}
			if (Input.GetKeyDown(KeyCode.Space))
			{
				this.addLetter(" ", false);
			}
			if ((Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Return)) && this.laskuri >= this.min.Value)
			{
				base.Finish();
			}
			this.laskuri = this.variable.Value.Length;
		}

		// Token: 0x0400009C RID: 156
		[RequiredField]
		[Tooltip("A variable where the keys are stored.")]
		public FsmString variable;

		// Token: 0x0400009D RID: 157
		[RequiredField]
		[Tooltip("Manimum number of numbers!")]
		public FsmInt min;

		// Token: 0x0400009E RID: 158
		[Tooltip("Maximum number of numbers!")]
		[RequiredField]
		public FsmInt max;

		// Token: 0x0400009F RID: 159
		private int laskuri;

		// Token: 0x040000A0 RID: 160
		private bool isPressed;
	}
}
