﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000128 RID: 296
	[Tooltip("Adds a force to a Game Object. Use Vector3 variable and/or Float variables for each axis.")]
	[ActionCategory(ActionCategory.Physics)]
	public class AddForce : ComponentAction<Rigidbody>
	{
		// Token: 0x06000578 RID: 1400 RVA: 0x00028E44 File Offset: 0x00027044
		public override void Reset()
		{
			this.gameObject = null;
			this.atPosition = new FsmVector3
			{
				UseVariable = true
			};
			this.vector = null;
			this.x = new FsmFloat
			{
				UseVariable = true
			};
			this.y = new FsmFloat
			{
				UseVariable = true
			};
			this.z = new FsmFloat
			{
				UseVariable = true
			};
			this.space = Space.World;
			this.forceMode = ForceMode.Force;
			this.everyFrame = false;
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00028EC4 File Offset: 0x000270C4
		public override void Awake()
		{
			base.Fsm.HandleFixedUpdate = true;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x00028ED4 File Offset: 0x000270D4
		public override void OnEnter()
		{
			this.DoAddForce();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x00028EF0 File Offset: 0x000270F0
		public override void OnFixedUpdate()
		{
			this.DoAddForce();
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00028EF8 File Offset: 0x000270F8
		private void DoAddForce()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (!base.UpdateCache(ownerDefaultTarget))
			{
				return;
			}
			Vector3 force = (!this.vector.IsNone) ? this.vector.Value : new Vector3(this.x.Value, this.y.Value, this.z.Value);
			if (!this.x.IsNone)
			{
				force.x = this.x.Value;
			}
			if (!this.y.IsNone)
			{
				force.y = this.y.Value;
			}
			if (!this.z.IsNone)
			{
				force.z = this.z.Value;
			}
			if (this.space == Space.World)
			{
				if (!this.atPosition.IsNone)
				{
					base.rigidbody.AddForceAtPosition(force, this.atPosition.Value, this.forceMode);
				}
				else
				{
					base.rigidbody.AddForce(force, this.forceMode);
				}
			}
			else
			{
				base.rigidbody.AddRelativeForce(force, this.forceMode);
			}
		}

		// Token: 0x040007FC RID: 2044
		[RequiredField]
		[CheckForComponent(typeof(Rigidbody))]
		[Tooltip("The GameObject to apply the force to.")]
		public FsmOwnerDefault gameObject;

		// Token: 0x040007FD RID: 2045
		[UIHint(UIHint.Variable)]
		[Tooltip("Optionally apply the force at a position on the object. This will also add some torque. The position is often returned from MousePick or GetCollisionInfo actions.")]
		public FsmVector3 atPosition;

		// Token: 0x040007FE RID: 2046
		[Tooltip("A Vector3 force to add. Optionally override any axis with the X, Y, Z parameters.")]
		[UIHint(UIHint.Variable)]
		public FsmVector3 vector;

		// Token: 0x040007FF RID: 2047
		[Tooltip("Force along the X axis. To leave unchanged, set to 'None'.")]
		public FsmFloat x;

		// Token: 0x04000800 RID: 2048
		[Tooltip("Force along the Y axis. To leave unchanged, set to 'None'.")]
		public FsmFloat y;

		// Token: 0x04000801 RID: 2049
		[Tooltip("Force along the Z axis. To leave unchanged, set to 'None'.")]
		public FsmFloat z;

		// Token: 0x04000802 RID: 2050
		[Tooltip("Apply the force in world or local space.")]
		public Space space;

		// Token: 0x04000803 RID: 2051
		[Tooltip("The type of force to apply. See Unity Physics docs.")]
		public ForceMode forceMode;

		// Token: 0x04000804 RID: 2052
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
