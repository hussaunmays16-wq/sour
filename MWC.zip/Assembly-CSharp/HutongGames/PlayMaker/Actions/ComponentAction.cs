﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200015D RID: 349
	public abstract class ComponentAction<T> : FsmStateAction where T : Component
	{
		// Token: 0x1700007B RID: 123
		// (get) Token: 0x0600067D RID: 1661 RVA: 0x000302FC File Offset: 0x0002E4FC
		protected Rigidbody rigidbody
		{
			get
			{
				return this.component as Rigidbody;
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600067E RID: 1662 RVA: 0x00030310 File Offset: 0x0002E510
		protected Renderer renderer
		{
			get
			{
				return this.component as Renderer;
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600067F RID: 1663 RVA: 0x00030324 File Offset: 0x0002E524
		protected Animation animation
		{
			get
			{
				return this.component as Animation;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06000680 RID: 1664 RVA: 0x00030338 File Offset: 0x0002E538
		protected AudioSource audio
		{
			get
			{
				return this.component as AudioSource;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000681 RID: 1665 RVA: 0x0003034C File Offset: 0x0002E54C
		protected Camera camera
		{
			get
			{
				return this.component as Camera;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000682 RID: 1666 RVA: 0x00030360 File Offset: 0x0002E560
		protected GUIText guiText
		{
			get
			{
				return this.component as GUIText;
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000683 RID: 1667 RVA: 0x00030374 File Offset: 0x0002E574
		protected GUITexture guiTexture
		{
			get
			{
				return this.component as GUITexture;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000684 RID: 1668 RVA: 0x00030388 File Offset: 0x0002E588
		protected Light light
		{
			get
			{
				return this.component as Light;
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000685 RID: 1669 RVA: 0x0003039C File Offset: 0x0002E59C
		protected NetworkView networkView
		{
			get
			{
				return this.component as NetworkView;
			}
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x000303B0 File Offset: 0x0002E5B0
		protected bool UpdateCache(GameObject go)
		{
			if (go == null)
			{
				return false;
			}
			if (this.component == null || this.cachedGameObject != go)
			{
				this.component = go.GetComponent<T>();
				this.cachedGameObject = go;
				if (this.component == null)
				{
					this.LogWarning("Missing component: " + typeof(T).FullName + " on: " + go.name);
				}
			}
			return this.component != null;
		}

		// Token: 0x04000975 RID: 2421
		private GameObject cachedGameObject;

		// Token: 0x04000976 RID: 2422
		private T component;
	}
}
