﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000259 RID: 601
	[Tooltip("Gets a sub-string from a String Variable.")]
	[ActionCategory(ActionCategory.String)]
	public class GetSubstring : FsmStateAction
	{
		// Token: 0x06000A41 RID: 2625 RVA: 0x0003F644 File Offset: 0x0003D844
		public override void Reset()
		{
			this.stringVariable = null;
			this.startIndex = 0;
			this.length = 1;
			this.storeResult = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A42 RID: 2626 RVA: 0x0003F674 File Offset: 0x0003D874
		public override void OnEnter()
		{
			this.DoGetSubstring();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A43 RID: 2627 RVA: 0x0003F690 File Offset: 0x0003D890
		public override void OnUpdate()
		{
			this.DoGetSubstring();
		}

		// Token: 0x06000A44 RID: 2628 RVA: 0x0003F698 File Offset: 0x0003D898
		private void DoGetSubstring()
		{
			if (this.stringVariable == null)
			{
				return;
			}
			if (this.storeResult == null)
			{
				return;
			}
			this.storeResult.Value = this.stringVariable.Value.Substring(this.startIndex.Value, this.length.Value);
		}

		// Token: 0x04000E29 RID: 3625
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString stringVariable;

		// Token: 0x04000E2A RID: 3626
		[RequiredField]
		public FsmInt startIndex;

		// Token: 0x04000E2B RID: 3627
		[RequiredField]
		public FsmInt length;

		// Token: 0x04000E2C RID: 3628
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;

		// Token: 0x04000E2D RID: 3629
		public bool everyFrame;
	}
}
