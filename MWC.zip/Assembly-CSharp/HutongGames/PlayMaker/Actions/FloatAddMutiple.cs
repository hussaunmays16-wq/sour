﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001CF RID: 463
	[Tooltip("Adds multipe float variables to float variable.")]
	[ActionCategory(ActionCategory.Math)]
	public class FloatAddMutiple : FsmStateAction
	{
		// Token: 0x06000823 RID: 2083 RVA: 0x0003868C File Offset: 0x0003688C
		public override void Reset()
		{
			this.floatVariables = null;
			this.addTo = null;
			this.everyFrame = false;
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x000386A4 File Offset: 0x000368A4
		public override void OnEnter()
		{
			this.DoFloatAdd();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x000386C0 File Offset: 0x000368C0
		public override void OnUpdate()
		{
			this.DoFloatAdd();
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x000386C8 File Offset: 0x000368C8
		private void DoFloatAdd()
		{
			for (int i = 0; i < this.floatVariables.Length; i++)
			{
				this.addTo.Value += this.floatVariables[i].Value;
			}
		}

		// Token: 0x04000BC5 RID: 3013
		[Tooltip("The float variables to add.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat[] floatVariables;

		// Token: 0x04000BC6 RID: 3014
		[RequiredField]
		[Tooltip("Add to this variable.")]
		[UIHint(UIHint.Variable)]
		public FsmFloat addTo;

		// Token: 0x04000BC7 RID: 3015
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;
	}
}
