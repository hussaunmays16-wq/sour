﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200012D RID: 301
	[Tooltip("Animates the value of a Float Variable using an Animation Curve.")]
	[ActionCategory(ActionCategory.AnimateVariables)]
	public class AnimateFloat : FsmStateAction
	{
		// Token: 0x06000593 RID: 1427 RVA: 0x0002956C File Offset: 0x0002776C
		public override void Reset()
		{
			this.animCurve = null;
			this.floatVariable = null;
			this.finishEvent = null;
			this.realTime = false;
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0002958C File Offset: 0x0002778C
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.currentTime = 0f;
			if (this.animCurve != null && this.animCurve.curve != null && this.animCurve.curve.keys.Length > 0)
			{
				this.endTime = this.animCurve.curve.keys[this.animCurve.curve.length - 1].time;
				this.looping = ActionHelpers.IsLoopingWrapMode(this.animCurve.curve.postWrapMode);
				this.floatVariable.Value = this.animCurve.curve.Evaluate(0f);
				return;
			}
			base.Finish();
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0002965C File Offset: 0x0002785C
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.currentTime = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.currentTime += Time.deltaTime;
			}
			if (this.animCurve != null && this.animCurve.curve != null && this.floatVariable != null)
			{
				this.floatVariable.Value = this.animCurve.curve.Evaluate(this.currentTime);
			}
			if (this.currentTime >= this.endTime)
			{
				if (!this.looping)
				{
					base.Finish();
				}
				if (this.finishEvent != null)
				{
					base.Fsm.Event(this.finishEvent);
				}
			}
		}

		// Token: 0x0400081D RID: 2077
		[Tooltip("The animation curve to use.")]
		[RequiredField]
		public FsmAnimationCurve animCurve;

		// Token: 0x0400081E RID: 2078
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The float variable to set.")]
		public FsmFloat floatVariable;

		// Token: 0x0400081F RID: 2079
		[Tooltip("Optionally send an Event when the animation finishes.")]
		public FsmEvent finishEvent;

		// Token: 0x04000820 RID: 2080
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x04000821 RID: 2081
		private float startTime;

		// Token: 0x04000822 RID: 2082
		private float currentTime;

		// Token: 0x04000823 RID: 2083
		private float endTime;

		// Token: 0x04000824 RID: 2084
		private bool looping;
	}
}
