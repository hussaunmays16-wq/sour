﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000164 RID: 356
	[Tooltip("Converts a Bool value to an Integer value.")]
	[ActionCategory(ActionCategory.Convert)]
	public class ConvertBoolToInt : FsmStateAction
	{
		// Token: 0x060006A2 RID: 1698 RVA: 0x00030AB0 File Offset: 0x0002ECB0
		public override void Reset()
		{
			this.boolVariable = null;
			this.intVariable = null;
			this.falseValue = 0;
			this.trueValue = 1;
			this.everyFrame = false;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00030AE0 File Offset: 0x0002ECE0
		public override void OnEnter()
		{
			this.DoConvertBoolToInt();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00030AFC File Offset: 0x0002ECFC
		public override void OnUpdate()
		{
			this.DoConvertBoolToInt();
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x00030B04 File Offset: 0x0002ED04
		private void DoConvertBoolToInt()
		{
			this.intVariable.Value = ((!this.boolVariable.Value) ? this.falseValue.Value : this.trueValue.Value);
		}

		// Token: 0x0400099E RID: 2462
		[UIHint(UIHint.Variable)]
		[Tooltip("The Bool variable to test.")]
		[RequiredField]
		public FsmBool boolVariable;

		// Token: 0x0400099F RID: 2463
		[UIHint(UIHint.Variable)]
		[RequiredField]
		[Tooltip("The Integer variable to set based on the Bool variable value.")]
		public FsmInt intVariable;

		// Token: 0x040009A0 RID: 2464
		[Tooltip("Integer value if Bool variable is false.")]
		public FsmInt falseValue;

		// Token: 0x040009A1 RID: 2465
		[Tooltip("Integer value if Bool variable is false.")]
		public FsmInt trueValue;

		// Token: 0x040009A2 RID: 2466
		[Tooltip("Repeat every frame. Useful if the Bool variable is changing.")]
		public bool everyFrame;
	}
}
