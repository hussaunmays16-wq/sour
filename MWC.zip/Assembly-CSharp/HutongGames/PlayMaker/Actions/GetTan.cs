﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000036 RID: 54
	[Tooltip("Get the Tangent. You can use degrees, simply check on the DegToRad conversion")]
	[ActionCategory("Trigonometry")]
	public class GetTan : FsmStateAction
	{
		// Token: 0x060000BA RID: 186 RVA: 0x00006848 File Offset: 0x00004A48
		public override void Reset()
		{
			this.angle = null;
			this.DegToRad = true;
			this.everyFrame = false;
			this.result = null;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x0000686C File Offset: 0x00004A6C
		public override void OnEnter()
		{
			this.DoTan();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00006888 File Offset: 0x00004A88
		public override void OnUpdate()
		{
			this.DoTan();
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00006890 File Offset: 0x00004A90
		private void DoTan()
		{
			float num = this.angle.Value;
			if (this.DegToRad.Value)
			{
				num *= 0.017453292f;
			}
			this.result.Value = Mathf.Tan(num);
		}

		// Token: 0x04000110 RID: 272
		[RequiredField]
		[Tooltip("The angle. Note: You can use degrees, simply check DegtoRad if the angle is expressed in degrees.")]
		public FsmFloat angle;

		// Token: 0x04000111 RID: 273
		[Tooltip("Check on if the angle is expressed in degrees.")]
		public FsmBool DegToRad;

		// Token: 0x04000112 RID: 274
		[UIHint(UIHint.Variable)]
		[Tooltip("The angle tan")]
		[RequiredField]
		public FsmFloat result;

		// Token: 0x04000113 RID: 275
		[Tooltip("Repeat every frame.")]
		public bool everyFrame;
	}
}
