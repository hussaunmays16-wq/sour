﻿using System;
using UnityEngine;

// Token: 0x020000DC RID: 220
[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class CameraFog : MonoBehaviour
{
	// Token: 0x0600042D RID: 1069 RVA: 0x0001C6E4 File Offset: 0x0001A8E4
	private void OnPreRender()
	{
		this._startDistance = RenderSettings.fogStartDistance;
		this._endDistance = RenderSettings.fogEndDistance;
		this._mode = RenderSettings.fogMode;
		this._density = RenderSettings.fogDensity;
		this._color = RenderSettings.fogColor;
		this._enabled = RenderSettings.fog;
		RenderSettings.fog = this.Enabled;
		RenderSettings.fogStartDistance = this.StartDistance;
		RenderSettings.fogEndDistance = this.EndDistance;
		RenderSettings.fogMode = this.Mode;
		RenderSettings.fogDensity = this.Density;
		RenderSettings.fogColor = this.Color;
	}

	// Token: 0x0600042E RID: 1070 RVA: 0x0001C778 File Offset: 0x0001A978
	private void OnPostRender()
	{
		RenderSettings.fog = this._enabled;
		RenderSettings.fogStartDistance = this._startDistance;
		RenderSettings.fogEndDistance = this._endDistance;
		RenderSettings.fogMode = this._mode;
		RenderSettings.fogDensity = this._density;
		RenderSettings.fogColor = this._color;
	}

	// Token: 0x04000611 RID: 1553
	public bool Enabled;

	// Token: 0x04000612 RID: 1554
	public float StartDistance;

	// Token: 0x04000613 RID: 1555
	public float EndDistance;

	// Token: 0x04000614 RID: 1556
	public FogMode Mode;

	// Token: 0x04000615 RID: 1557
	public float Density;

	// Token: 0x04000616 RID: 1558
	public Color Color;

	// Token: 0x04000617 RID: 1559
	private float _startDistance;

	// Token: 0x04000618 RID: 1560
	private float _endDistance;

	// Token: 0x04000619 RID: 1561
	private FogMode _mode;

	// Token: 0x0400061A RID: 1562
	private float _density;

	// Token: 0x0400061B RID: 1563
	private Color _color;

	// Token: 0x0400061C RID: 1564
	private bool _enabled;
}
