﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000243 RID: 579
	[ActionCategory(ActionCategory.Input)]
	[Tooltip("Gets the X Position of the mouse and stores it in a Float Variable.")]
	public class GetMouseX : FsmStateAction
	{
		// Token: 0x060009E1 RID: 2529 RVA: 0x0003E828 File Offset: 0x0003CA28
		public override void Reset()
		{
			this.storeResult = null;
			this.normalize = true;
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x0003E838 File Offset: 0x0003CA38
		public override void OnEnter()
		{
			this.DoGetMouseX();
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x0003E840 File Offset: 0x0003CA40
		public override void OnUpdate()
		{
			this.DoGetMouseX();
		}

		// Token: 0x060009E4 RID: 2532 RVA: 0x0003E848 File Offset: 0x0003CA48
		private void DoGetMouseX()
		{
			if (this.storeResult != null)
			{
				float num = Input.mousePosition.x;
				if (this.normalize)
				{
					num /= (float)Screen.width;
				}
				this.storeResult.Value = num;
			}
		}

		// Token: 0x04000DDE RID: 3550
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmFloat storeResult;

		// Token: 0x04000DDF RID: 3551
		public bool normalize;
	}
}
