﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001FF RID: 511
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("GUILayout Password Field. Optionally send an event if the text has been edited.")]
	public class GUILayoutPasswordField : GUILayoutAction
	{
		// Token: 0x060008CA RID: 2250 RVA: 0x0003ABBC File Offset: 0x00038DBC
		public override void Reset()
		{
			this.text = null;
			this.maxLength = 25;
			this.style = "TextField";
			this.mask = "*";
			this.changedEvent = null;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0003ABFC File Offset: 0x00038DFC
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.text.Value = GUILayout.PasswordField(this.text.Value, this.mask.Value[0], this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C86 RID: 3206
		[UIHint(UIHint.Variable)]
		public FsmString text;

		// Token: 0x04000C87 RID: 3207
		public FsmInt maxLength;

		// Token: 0x04000C88 RID: 3208
		public FsmString style;

		// Token: 0x04000C89 RID: 3209
		public FsmEvent changedEvent;

		// Token: 0x04000C8A RID: 3210
		public FsmString mask;
	}
}
