﻿using System;
using HutongGames.PlayMaker;

// Token: 0x0200016F RID: 367
[ActionCategory(ActionCategory.Color)]
public class CustomActionTest : FsmStateAction
{
	// Token: 0x060006D0 RID: 1744 RVA: 0x000312EC File Offset: 0x0002F4EC
	public override void OnEnter()
	{
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x000312F0 File Offset: 0x0002F4F0
	public override void OnUpdate()
	{
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x000312F4 File Offset: 0x0002F4F4
	public override void OnFixedUpdate()
	{
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x000312F8 File Offset: 0x0002F4F8
	public override void OnLateUpdate()
	{
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x000312FC File Offset: 0x0002F4FC
	public override void OnExit()
	{
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x00031300 File Offset: 0x0002F500
	public override string ErrorCheck()
	{
		return null;
	}
}
