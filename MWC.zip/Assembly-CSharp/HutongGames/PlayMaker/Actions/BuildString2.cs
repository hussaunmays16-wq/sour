﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200040C RID: 1036
	[ActionCategory(ActionCategory.String)]
	[Tooltip("Builds a String from other Strings. Separator is optional and can be inserted before, after or in between parts.")]
	public class BuildString2 : FsmStateAction
	{
		// Token: 0x0600117F RID: 4479 RVA: 0x0006088C File Offset: 0x0005EA8C
		public override void Reset()
		{
			this.stringParts = new FsmString[3];
			this.separator = null;
			this.storeResult = null;
			this.separatorInsert = BuildString2.separatorInsertion.After;
			this.everyFrame = false;
		}

		// Token: 0x06001180 RID: 4480 RVA: 0x000608C4 File Offset: 0x0005EAC4
		public override void OnEnter()
		{
			this.DoBuildString();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06001181 RID: 4481 RVA: 0x000608E0 File Offset: 0x0005EAE0
		public override void OnUpdate()
		{
			this.DoBuildString();
		}

		// Token: 0x06001182 RID: 4482 RVA: 0x000608E8 File Offset: 0x0005EAE8
		private void DoBuildString()
		{
			if (this.storeResult == null)
			{
				return;
			}
			this.result = string.Empty;
			for (int i = 0; i < this.stringParts.Length; i++)
			{
				if (this.separatorInsert == BuildString2.separatorInsertion.Before)
				{
					this.result += this.separator.Value;
				}
				this.result += this.stringParts[i];
				if (this.separatorInsert == BuildString2.separatorInsertion.After)
				{
					this.result += this.separator.Value;
				}
				if (this.separatorInsert == BuildString2.separatorInsertion.InBetween && i < this.stringParts.Length - 1)
				{
					this.result += this.separator.Value;
				}
			}
			this.storeResult.Value = this.result;
		}

		// Token: 0x040016F8 RID: 5880
		[Tooltip("Array of Strings to combine.")]
		[RequiredField]
		public FsmString[] stringParts;

		// Token: 0x040016F9 RID: 5881
		[Tooltip("Separator. E.g. space character.")]
		public FsmString separator;

		// Token: 0x040016FA RID: 5882
		[Tooltip("Separator behavior.")]
		public BuildString2.separatorInsertion separatorInsert;

		// Token: 0x040016FB RID: 5883
		[Tooltip("Store the final String in a variable.")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString storeResult;

		// Token: 0x040016FC RID: 5884
		[Tooltip("Repeat every frame while the state is active.")]
		public bool everyFrame;

		// Token: 0x040016FD RID: 5885
		private string result;

		// Token: 0x0200040D RID: 1037
		public enum separatorInsertion
		{
			// Token: 0x040016FF RID: 5887
			InBetween,
			// Token: 0x04001700 RID: 5888
			After,
			// Token: 0x04001701 RID: 5889
			Before
		}
	}
}
