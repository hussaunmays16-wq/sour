﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003D0 RID: 976
	[Tooltip("Store all the values of a PlayMaker HashTable Proxy component (PlayMakerHashTableProxy) into a PlayMaker arrayList Proxy component (PlayMakerArrayListProxy).")]
	[ActionCategory("ArrayMaker/HashTable")]
	public class HashTableValues : HashTableActions
	{
		// Token: 0x06001078 RID: 4216 RVA: 0x0005989C File Offset: 0x00057A9C
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.arrayListGameObject = null;
			this.arrayListReference = null;
		}

		// Token: 0x06001079 RID: 4217 RVA: 0x000598BC File Offset: 0x00057ABC
		public override void OnEnter()
		{
			if (base.SetUpHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value))
			{
				this.doHashTableValues();
			}
			base.Finish();
		}

		// Token: 0x0600107A RID: 4218 RVA: 0x000598FC File Offset: 0x00057AFC
		public void doHashTableValues()
		{
			if (!base.isProxyValid())
			{
				return;
			}
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.arrayListGameObject);
			if (ownerDefaultTarget == null)
			{
				return;
			}
			PlayMakerArrayListProxy arrayListProxyPointer = base.GetArrayListProxyPointer(ownerDefaultTarget, this.arrayListReference.Value, false);
			if (arrayListProxyPointer != null)
			{
				arrayListProxyPointer.arrayList.AddRange(this.proxy.hashTable.Values);
			}
		}

		// Token: 0x04001554 RID: 5460
		[RequiredField]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		[CheckForComponent(typeof(PlayMakerHashTableProxy))]
		[ActionSection("Set up")]
		public FsmOwnerDefault gameObject;

		// Token: 0x04001555 RID: 5461
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x04001556 RID: 5462
		[Tooltip("The gameObject with the PlayMaker ArrayList Proxy component that will store the values")]
		[ActionSection("Result")]
		[CheckForComponent(typeof(PlayMakerArrayListProxy))]
		[RequiredField]
		public FsmOwnerDefault arrayListGameObject;

		// Token: 0x04001557 RID: 5463
		[Tooltip("Author defined Reference of the PlayMaker ArrayList Proxy component that will store the values ( necessary if several component coexists on the same GameObject")]
		public FsmString arrayListReference;
	}
}
