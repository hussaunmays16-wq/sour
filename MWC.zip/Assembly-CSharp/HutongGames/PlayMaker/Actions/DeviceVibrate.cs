﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000182 RID: 386
	[Tooltip("Causes the device to vibrate for half a second.")]
	[ActionCategory(ActionCategory.Device)]
	public class DeviceVibrate : FsmStateAction
	{
		// Token: 0x06000711 RID: 1809 RVA: 0x00031BBC File Offset: 0x0002FDBC
		public override void Reset()
		{
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00031BC0 File Offset: 0x0002FDC0
		public override void OnEnter()
		{
			base.Finish();
		}
	}
}
