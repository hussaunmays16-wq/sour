﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000200 RID: 512
	[Tooltip("GUILayout Repeat Button. Sends an Event while pressed. Optionally store the button state in a Bool Variable.")]
	[ActionCategory(ActionCategory.GUILayout)]
	public class GUILayoutRepeatButton : GUILayoutAction
	{
		// Token: 0x060008CD RID: 2253 RVA: 0x0003AC8C File Offset: 0x00038E8C
		public override void Reset()
		{
			base.Reset();
			this.sendEvent = null;
			this.storeButtonState = null;
			this.text = string.Empty;
			this.image = null;
			this.tooltip = string.Empty;
			this.style = string.Empty;
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x0003ACE4 File Offset: 0x00038EE4
		public override void OnGUI()
		{
			bool flag;
			if (string.IsNullOrEmpty(this.style.Value))
			{
				flag = GUILayout.RepeatButton(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), base.LayoutOptions);
			}
			else
			{
				flag = GUILayout.RepeatButton(new GUIContent(this.text.Value, this.image.Value, this.tooltip.Value), this.style.Value, base.LayoutOptions);
			}
			if (flag)
			{
				base.Fsm.Event(this.sendEvent);
			}
			this.storeButtonState.Value = flag;
		}

		// Token: 0x04000C8B RID: 3211
		public FsmEvent sendEvent;

		// Token: 0x04000C8C RID: 3212
		[UIHint(UIHint.Variable)]
		public FsmBool storeButtonState;

		// Token: 0x04000C8D RID: 3213
		public FsmTexture image;

		// Token: 0x04000C8E RID: 3214
		public FsmString text;

		// Token: 0x04000C8F RID: 3215
		public FsmString tooltip;

		// Token: 0x04000C90 RID: 3216
		public FsmString style;
	}
}
