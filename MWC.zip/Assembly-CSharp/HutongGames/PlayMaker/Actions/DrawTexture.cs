﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000188 RID: 392
	[Tooltip("Draws a GUI Texture. NOTE: Uses OnGUI so you need a PlayMakerGUI component in the scene.")]
	[ActionCategory(ActionCategory.GUI)]
	public class DrawTexture : FsmStateAction
	{
		// Token: 0x06000723 RID: 1827 RVA: 0x00031E14 File Offset: 0x00030014
		public override void Reset()
		{
			this.texture = null;
			this.screenRect = null;
			this.left = 0f;
			this.top = 0f;
			this.width = 1f;
			this.height = 1f;
			this.scaleMode = ScaleMode.StretchToFill;
			this.alphaBlend = true;
			this.imageAspect = 0f;
			this.normalized = true;
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x00031EA0 File Offset: 0x000300A0
		public override void OnGUI()
		{
			if (this.texture.Value == null)
			{
				return;
			}
			this.rect = (this.screenRect.IsNone ? default(Rect) : this.screenRect.Value);
			if (!this.left.IsNone)
			{
				this.rect.x = this.left.Value;
			}
			if (!this.top.IsNone)
			{
				this.rect.y = this.top.Value;
			}
			if (!this.width.IsNone)
			{
				this.rect.width = this.width.Value;
			}
			if (!this.height.IsNone)
			{
				this.rect.height = this.height.Value;
			}
			if (this.normalized.Value)
			{
				this.rect.x = this.rect.x * (float)Screen.width;
				this.rect.width = this.rect.width * (float)Screen.width;
				this.rect.y = this.rect.y * (float)Screen.height;
				this.rect.height = this.rect.height * (float)Screen.height;
			}
			GUI.DrawTexture(this.rect, this.texture.Value, this.scaleMode, this.alphaBlend.Value, this.imageAspect.Value);
		}

		// Token: 0x04000A07 RID: 2567
		[RequiredField]
		[Tooltip("Texture to draw.")]
		public FsmTexture texture;

		// Token: 0x04000A08 RID: 2568
		[Tooltip("Rectangle on the screen to draw the texture within. Alternatively, set or override individual properties below.")]
		[Title("Position")]
		[UIHint(UIHint.Variable)]
		public FsmRect screenRect;

		// Token: 0x04000A09 RID: 2569
		[Tooltip("Left screen coordinate.")]
		public FsmFloat left;

		// Token: 0x04000A0A RID: 2570
		[Tooltip("Top screen coordinate.")]
		public FsmFloat top;

		// Token: 0x04000A0B RID: 2571
		[Tooltip("Width of texture on screen.")]
		public FsmFloat width;

		// Token: 0x04000A0C RID: 2572
		[Tooltip("Height of texture on screen.")]
		public FsmFloat height;

		// Token: 0x04000A0D RID: 2573
		[Tooltip("How to scale the image when the aspect ratio of it doesn't fit the aspect ratio to be drawn within.")]
		public ScaleMode scaleMode;

		// Token: 0x04000A0E RID: 2574
		[Tooltip("Whether to alpha blend the image on to the display (the default). If false, the picture is drawn on to the display.")]
		public FsmBool alphaBlend;

		// Token: 0x04000A0F RID: 2575
		[Tooltip("Aspect ratio to use for the source image. If 0 (the default), the aspect ratio from the image is used. Pass in w/h for the desired aspect ratio. This allows the aspect ratio of the source image to be adjusted without changing the pixel width and height.")]
		public FsmFloat imageAspect;

		// Token: 0x04000A10 RID: 2576
		[Tooltip("Use normalized screen coordinates (0-1)")]
		public FsmBool normalized;

		// Token: 0x04000A11 RID: 2577
		private Rect rect;
	}
}
