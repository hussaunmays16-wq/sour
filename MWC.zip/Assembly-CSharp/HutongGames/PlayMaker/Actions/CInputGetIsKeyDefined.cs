﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020004AA RID: 1194
	[Tooltip("Gets if a cInput key is defined and stores the value in a fsm variable.")]
	[ActionCategory("cInput")]
	public class CInputGetIsKeyDefined : FsmStateAction
	{
		// Token: 0x06001459 RID: 5209 RVA: 0x00088CEC File Offset: 0x00086EEC
		public override void Reset()
		{
			this.keyName = null;
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x00088CF8 File Offset: 0x00086EF8
		public override void OnUpdate()
		{
			if (this.keyName == null)
			{
				return;
			}
			this.storeKeyIsDefined.Value = cInput.IsKeyDefined(this.keyName.Value);
			if (!this.everyFrame.Value)
			{
				base.Finish();
			}
		}

		// Token: 0x04001CC6 RID: 7366
		[Tooltip("The name of the key.")]
		public FsmString keyName;

		// Token: 0x04001CC7 RID: 7367
		[Tooltip("Store if the key is defined.")]
		public FsmBool storeKeyIsDefined;

		// Token: 0x04001CC8 RID: 7368
		[Tooltip("Get axis value every frame or finish.")]
		public FsmBool everyFrame;
	}
}
