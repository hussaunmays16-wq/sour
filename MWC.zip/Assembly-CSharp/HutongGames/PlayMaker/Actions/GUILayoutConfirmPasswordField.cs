﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020001F1 RID: 497
	[ActionCategory(ActionCategory.GUILayout)]
	[Tooltip("GUILayout Password Field. Optionally send an event if the text has been edited.")]
	public class GUILayoutConfirmPasswordField : GUILayoutAction
	{
		// Token: 0x060008A1 RID: 2209 RVA: 0x0003A424 File Offset: 0x00038624
		public override void Reset()
		{
			this.text = null;
			this.maxLength = 25;
			this.style = "TextField";
			this.mask = "*";
			this.changedEvent = null;
			this.confirm = false;
			this.password = null;
		}

		// Token: 0x060008A2 RID: 2210 RVA: 0x0003A480 File Offset: 0x00038680
		public override void OnGUI()
		{
			bool changed = GUI.changed;
			GUI.changed = false;
			this.text.Value = GUILayout.PasswordField(this.text.Value, this.mask.Value[0], this.style.Value, base.LayoutOptions);
			if (GUI.changed)
			{
				base.Fsm.Event(this.changedEvent);
				GUIUtility.ExitGUI();
			}
			else
			{
				GUI.changed = changed;
			}
		}

		// Token: 0x04000C66 RID: 3174
		[UIHint(UIHint.Variable)]
		public FsmString text;

		// Token: 0x04000C67 RID: 3175
		public FsmInt maxLength;

		// Token: 0x04000C68 RID: 3176
		public FsmString style;

		// Token: 0x04000C69 RID: 3177
		public FsmEvent changedEvent;

		// Token: 0x04000C6A RID: 3178
		public FsmString mask;

		// Token: 0x04000C6B RID: 3179
		public FsmBool confirm;

		// Token: 0x04000C6C RID: 3180
		public FsmString password;
	}
}
