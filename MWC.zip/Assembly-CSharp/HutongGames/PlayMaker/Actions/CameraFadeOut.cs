﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000157 RID: 343
	[Tooltip("Fade to a fullscreen Color. NOTE: Uses OnGUI so requires a PlayMakerGUI component in the scene.")]
	[ActionCategory(ActionCategory.Camera)]
	public class CameraFadeOut : FsmStateAction
	{
		// Token: 0x06000658 RID: 1624 RVA: 0x0002F844 File Offset: 0x0002DA44
		public override void Reset()
		{
			this.color = Color.black;
			this.time = 1f;
			this.finishEvent = null;
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x0002F870 File Offset: 0x0002DA70
		public override void OnEnter()
		{
			this.startTime = FsmTime.RealtimeSinceStartup;
			this.currentTime = 0f;
			this.colorLerp = Color.clear;
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x0002F894 File Offset: 0x0002DA94
		public override void OnUpdate()
		{
			if (this.realTime)
			{
				this.currentTime = FsmTime.RealtimeSinceStartup - this.startTime;
			}
			else
			{
				this.currentTime += Time.deltaTime;
			}
			this.colorLerp = Color.Lerp(Color.clear, this.color.Value, this.currentTime / this.time.Value);
			if (this.currentTime > this.time.Value && this.finishEvent != null)
			{
				base.Fsm.Event(this.finishEvent);
			}
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x0002F934 File Offset: 0x0002DB34
		public override void OnGUI()
		{
			Color color = GUI.color;
			GUI.color = this.colorLerp;
			GUI.DrawTexture(new Rect(0f, 0f, (float)Screen.width, (float)Screen.height), ActionHelpers.WhiteTexture);
			GUI.color = color;
		}

		// Token: 0x04000958 RID: 2392
		[Tooltip("Color to fade to. E.g., Fade to black.")]
		[RequiredField]
		public FsmColor color;

		// Token: 0x04000959 RID: 2393
		[RequiredField]
		[HasFloatSlider(0f, 10f)]
		[Tooltip("Fade out time in seconds.")]
		public FsmFloat time;

		// Token: 0x0400095A RID: 2394
		[Tooltip("Event to send when finished.")]
		public FsmEvent finishEvent;

		// Token: 0x0400095B RID: 2395
		[Tooltip("Ignore TimeScale. Useful if the game is paused.")]
		public bool realTime;

		// Token: 0x0400095C RID: 2396
		private float startTime;

		// Token: 0x0400095D RID: 2397
		private float currentTime;

		// Token: 0x0400095E RID: 2398
		private Color colorLerp;
	}
}
