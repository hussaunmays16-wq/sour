﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200024A RID: 586
	[ActionCategory(ActionCategory.StateMachine)]
	[Tooltip("Gets the name of the previously active state and stores it in a String Variable.")]
	public class GetPreviousStateName : FsmStateAction
	{
		// Token: 0x060009FF RID: 2559 RVA: 0x0003EC94 File Offset: 0x0003CE94
		public override void Reset()
		{
			this.storeName = null;
		}

		// Token: 0x06000A00 RID: 2560 RVA: 0x0003ECA0 File Offset: 0x0003CEA0
		public override void OnEnter()
		{
			this.storeName.Value = ((base.Fsm.PreviousActiveState != null) ? base.Fsm.PreviousActiveState.Name : null);
			base.Finish();
		}

		// Token: 0x04000DF5 RID: 3573
		[UIHint(UIHint.Variable)]
		public FsmString storeName;
	}
}
