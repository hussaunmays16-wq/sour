﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200026B RID: 619
	[ActionCategory(ActionCategory.Math)]
	[Tooltip("Adds a value to an Integer Variable.")]
	public class IntAdd : FsmStateAction
	{
		// Token: 0x06000A8E RID: 2702 RVA: 0x000403BC File Offset: 0x0003E5BC
		public override void Reset()
		{
			this.intVariable = null;
			this.add = null;
			this.everyFrame = false;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x000403D4 File Offset: 0x0003E5D4
		public override void OnEnter()
		{
			this.intVariable.Value += this.add.Value;
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x00040410 File Offset: 0x0003E610
		public override void OnUpdate()
		{
			this.intVariable.Value += this.add.Value;
		}

		// Token: 0x04000E74 RID: 3700
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmInt intVariable;

		// Token: 0x04000E75 RID: 3701
		[RequiredField]
		public FsmInt add;

		// Token: 0x04000E76 RID: 3702
		public bool everyFrame;
	}
}
