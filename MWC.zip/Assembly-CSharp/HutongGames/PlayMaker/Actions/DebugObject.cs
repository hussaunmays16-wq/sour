﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000179 RID: 377
	[ActionCategory(ActionCategory.Debug)]
	[Tooltip("Logs the value of an Object Variable in the PlayMaker Log Window.")]
	public class DebugObject : FsmStateAction
	{
		// Token: 0x060006F1 RID: 1777 RVA: 0x000317B4 File Offset: 0x0002F9B4
		public override void Reset()
		{
			this.logLevel = LogLevel.Info;
			this.fsmObject = null;
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x000317C4 File Offset: 0x0002F9C4
		public override void OnEnter()
		{
			string text = "None";
			if (!this.fsmObject.IsNone)
			{
				text = this.fsmObject.Name + ": " + this.fsmObject;
			}
			ActionHelpers.DebugLog(base.Fsm, this.logLevel, text);
			base.Finish();
		}

		// Token: 0x040009E7 RID: 2535
		[Tooltip("Info, Warning, or Error.")]
		public LogLevel logLevel;

		// Token: 0x040009E8 RID: 2536
		[UIHint(UIHint.Variable)]
		[Tooltip("Prints the value of an Object variable in the PlayMaker log window.")]
		public FsmObject fsmObject;
	}
}
