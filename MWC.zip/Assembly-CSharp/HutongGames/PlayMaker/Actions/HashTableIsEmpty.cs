﻿using System;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x020003C8 RID: 968
	[ActionCategory("ArrayMaker/HashTable")]
	[Tooltip("Check if an HashTable Proxy component is empty.")]
	public class HashTableIsEmpty : ArrayListActions
	{
		// Token: 0x0600105A RID: 4186 RVA: 0x00059408 File Offset: 0x00057608
		public override void Reset()
		{
			this.gameObject = null;
			this.reference = null;
			this.isEmpty = null;
			this.isEmptyEvent = null;
			this.isNotEmptyEvent = null;
		}

		// Token: 0x0600105B RID: 4187 RVA: 0x00059430 File Offset: 0x00057630
		public override void OnEnter()
		{
			PlayMakerHashTableProxy hashTableProxyPointer = base.GetHashTableProxyPointer(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.reference.Value, true);
			bool flag = hashTableProxyPointer.hashTable.Count == 0;
			this.isEmpty.Value = flag;
			if (flag)
			{
				base.Fsm.Event(this.isEmptyEvent);
			}
			else
			{
				base.Fsm.Event(this.isNotEmptyEvent);
			}
			base.Finish();
		}

		// Token: 0x0400153C RID: 5436
		[RequiredField]
		[ActionSection("Set up")]
		[Tooltip("The gameObject with the PlayMaker HashTable Proxy component")]
		public FsmOwnerDefault gameObject;

		// Token: 0x0400153D RID: 5437
		[Tooltip("Author defined Reference of the PlayMaker HashTable Proxy component ( necessary if several component coexists on the same GameObject")]
		public FsmString reference;

		// Token: 0x0400153E RID: 5438
		[ActionSection("Result")]
		[Tooltip("Store in a bool wether it is empty or not")]
		[UIHint(UIHint.Variable)]
		public FsmBool isEmpty;

		// Token: 0x0400153F RID: 5439
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this HashTable is empty ")]
		public FsmEvent isEmptyEvent;

		// Token: 0x04001540 RID: 5440
		[UIHint(UIHint.FsmEvent)]
		[Tooltip("Event sent if this HashTable is not empty")]
		public FsmEvent isNotEmptyEvent;
	}
}
