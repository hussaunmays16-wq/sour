﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x0200002F RID: 47
	[ActionCategory("Trigonometry")]
	[Tooltip("Get the Arc Tangent. You can get the result in degrees, simply check on the RadToDeg conversion")]
	public class GetAtan : FsmStateAction
	{
		// Token: 0x0600009C RID: 156 RVA: 0x000063D8 File Offset: 0x000045D8
		public override void Reset()
		{
			this.Value = null;
			this.RadToDeg = true;
			this.everyFrame = false;
			this.angle = null;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x000063FC File Offset: 0x000045FC
		public override void OnEnter()
		{
			this.DoATan();
			if (!this.everyFrame)
			{
				base.Finish();
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00006418 File Offset: 0x00004618
		public override void OnUpdate()
		{
			this.DoATan();
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00006420 File Offset: 0x00004620
		private void DoATan()
		{
			float num = Mathf.Atan(this.Value.Value);
			if (this.RadToDeg.Value)
			{
				num *= 57.29578f;
			}
			this.angle.Value = num;
		}

		// Token: 0x040000F1 RID: 241
		[RequiredField]
		[Tooltip("The value of the tan")]
		public FsmFloat Value;

		// Token: 0x040000F2 RID: 242
		[RequiredField]
		[Tooltip("The resulting angle. Note:If you want degrees, simply check RadToDeg")]
		[UIHint(UIHint.Variable)]
		public FsmFloat angle;

		// Token: 0x040000F3 RID: 243
		[Tooltip("Check on if you want the angle expressed in degrees.")]
		public FsmBool RadToDeg;

		// Token: 0x040000F4 RID: 244
		public bool everyFrame;
	}
}
