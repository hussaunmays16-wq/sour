﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000218 RID: 536
	[Tooltip("Finds the Child of a GameObject by Name and/or Tag. Use this to find attach points etc. NOTE: This action will search recursively through all children and return the first match; To find a specific child use Find Child.")]
	[ActionCategory(ActionCategory.GameObject)]
	public class GetChild : FsmStateAction
	{
		// Token: 0x06000928 RID: 2344 RVA: 0x0003C12C File Offset: 0x0003A32C
		public override void Reset()
		{
			this.gameObject = null;
			this.childName = string.Empty;
			this.withTag = "Untagged";
			this.storeResult = null;
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x0003C168 File Offset: 0x0003A368
		public override void OnEnter()
		{
			this.storeResult.Value = GetChild.DoGetChildByName(base.Fsm.GetOwnerDefaultTarget(this.gameObject), this.childName.Value, this.withTag.Value);
			base.Finish();
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x0003C1B4 File Offset: 0x0003A3B4
		private static GameObject DoGetChildByName(GameObject root, string name, string tag)
		{
			if (root == null)
			{
				return null;
			}
			foreach (object obj in root.transform)
			{
				Transform transform = (Transform)obj;
				if (!string.IsNullOrEmpty(name))
				{
					if (transform.name == name)
					{
						if (string.IsNullOrEmpty(tag))
						{
							return transform.gameObject;
						}
						if (transform.tag.Equals(tag))
						{
							return transform.gameObject;
						}
					}
				}
				else if (!string.IsNullOrEmpty(tag) && transform.tag == tag)
				{
					return transform.gameObject;
				}
				GameObject gameObject = GetChild.DoGetChildByName(transform.gameObject, name, tag);
				if (gameObject != null)
				{
					return gameObject;
				}
			}
			return null;
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x0003C2D4 File Offset: 0x0003A4D4
		public override string ErrorCheck()
		{
			if (string.IsNullOrEmpty(this.childName.Value) && string.IsNullOrEmpty(this.withTag.Value))
			{
				return "Specify Child Name, Tag, or both.";
			}
			return null;
		}

		// Token: 0x04000CF6 RID: 3318
		[Tooltip("The GameObject to search.")]
		[RequiredField]
		public FsmOwnerDefault gameObject;

		// Token: 0x04000CF7 RID: 3319
		[Tooltip("The name of the child to search for.")]
		public FsmString childName;

		// Token: 0x04000CF8 RID: 3320
		[Tooltip("The Tag to search for. If Child Name is set, both name and Tag need to match.")]
		[UIHint(UIHint.Tag)]
		public FsmString withTag;

		// Token: 0x04000CF9 RID: 3321
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a GameObject variable.")]
		public FsmGameObject storeResult;
	}
}
