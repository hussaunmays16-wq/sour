﻿using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	// Token: 0x02000147 RID: 327
	[Tooltip("Stops playing the Audio Clip played by an Audio Source component on a Game Object.")]
	[ActionCategory(ActionCategory.Audio)]
	public class AudioStop : FsmStateAction
	{
		// Token: 0x06000616 RID: 1558 RVA: 0x0002E75C File Offset: 0x0002C95C
		public override void Reset()
		{
			this.gameObject = null;
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0002E768 File Offset: 0x0002C968
		public override void OnEnter()
		{
			GameObject ownerDefaultTarget = base.Fsm.GetOwnerDefaultTarget(this.gameObject);
			if (ownerDefaultTarget != null)
			{
				AudioSource component = ownerDefaultTarget.GetComponent<AudioSource>();
				if (component != null)
				{
					component.Stop();
				}
			}
			base.Finish();
		}

		// Token: 0x04000906 RID: 2310
		[RequiredField]
		[CheckForComponent(typeof(AudioSource))]
		[Tooltip("The GameObject with an AudioSource component.")]
		public FsmOwnerDefault gameObject;
	}
}
